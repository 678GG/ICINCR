"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [64007], {
        290636: (e, s, t) => {
            t.r(s), t.d(s, {
                MenuFillDesktop: () => u
            });
            var l = t(927012),
                i = t(365043),
                o = t(918675),
                a = t(179177),
                n = t(555329),
                c = t(573206),
                r = t(570579);
            a.Ay.IS_RTL && t.e(97525).then(t.bind(t, 897525));
            const u = () => {
                const {
                    items: e,
                    selectedItem: s,
                    onSelectItem: t
                } = (0, i.useContext)(l.x);
                return (0, r.jsx)("div", {
                    className: "menu-wrapper",
                    children: (0, r.jsx)(o.Carousel, {
                        items: (null === e || void 0 === e ? void 0 : e.map((e => (0, r.jsx)(c.y, {
                            item: e,
                            active: (null === s || void 0 === s ? void 0 : s.alias) === e.alias,
                            onClick: () => t(e)
                        }, e.id)))) || [],
                        fallback: (0, r.jsx)(n.G, {})
                    })
                })
            }
        }
    }
]);
//# sourceMappingURL=MenuFillDesktop.fd7299ae.chunk.js.map