"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [75949], {
        875949: (s, e, a) => {
            a.d(e, {
                p: () => c
            });
            var o = a(870905),
                n = a(735905),
                i = a(55418),
                l = a(179177),
                b = a(570579);
            l.Ay.IS_RTL && a.e(30138).then(a.bind(a, 930138));
            const c = () => {
                const {
                    t: s
                } = (0, o.B)();
                return (0, b.jsx)("div", {
                    className: (0, i.F)() ? "gambleCasinoMob" : "gambleCasino",
                    children: (0, b.jsxs)("span", {
                        className: (0, i.F)() ? "gambleCasinoMob_text" : "",
                        children: [(0, b.jsx)(n.GlobalIcon, {
                            name: "ShieldTick",
                            theme: "default",
                            lib: "generic",
                            size: 24,
                            className: (0, i.F)() ? "gambleCasinoMob_iconMob" : "gambleCasino_icon"
                        }), s("casino.gambleCasino")]
                    })
                })
            }
        }
    }
]);
//# sourceMappingURL=75949.145a6622.chunk.js.map