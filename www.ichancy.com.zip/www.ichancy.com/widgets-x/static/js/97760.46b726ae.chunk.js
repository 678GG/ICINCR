"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [97760], {
        797760: (o, s, e) => {
            e.d(s, {
                L: () => a,
                S: () => t
            });
            const t = {
                    home: "",
                    live: "desktop-sportsbook-live",
                    prematch: "desktop-sportsbook-prematch",
                    virtualSports: "virtual-sport",
                    eLive: "e-live",
                    ePrematch: "e-prematch",
                    casinoGames: "casino",
                    casinoTournaments: "tournaments",
                    racing: "racing"
                },
                a = {
                    addToBetslip: "/add-to-betslip",
                    deposit: "/account/deposit"
                }
        }
    }
]);
//# sourceMappingURL=97760.46b726ae.chunk.js.map