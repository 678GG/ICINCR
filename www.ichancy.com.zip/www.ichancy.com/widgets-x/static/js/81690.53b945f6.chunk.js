"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [81690], {
        781690: (s, o, e) => {
            e.r(o), e.d(o, {
                default: () => k
            });
            const k = {}
        }
    }
]);
//# sourceMappingURL=81690.53b945f6.chunk.js.map