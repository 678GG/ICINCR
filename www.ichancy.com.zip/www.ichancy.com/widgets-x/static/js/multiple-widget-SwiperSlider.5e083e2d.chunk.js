"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [61850], {
        893662: (e, r, s) => {
            s.r(r), s.d(r, {
                SwiperSlider: () => v
            });
            var l = s(365043),
                i = s(889181),
                t = s(994167),
                a = s(716806),
                n = s(179177),
                o = s(423400),
                d = s(432148),
                c = s(735905),
                u = s(120376),
                p = (s(78517), s(799450), s(570579));
            n.Ay.IS_RTL && s.e(85584).then(s.bind(s, 385584)), a.Ay.use([a.Vx, a.Ij, a.dK]);
            const h = e => e ? `SLIDER_SELECTOR_${e}` : null,
                w = e => e ? `SLIDE_SELECTOR_${e}` : "",
                v = e => {
                    var r, s;
                    let {
                        delay: a,
                        autoplay: n,
                        bodyArrows: v,
                        headerTitle: b,
                        activeSlide: m,
                        headerArrows: f,
                        drawableTabs: g,
                        slidesPerView: x,
                        showIndicators: j,
                        slideClassName: _ = "",
                        sliderClassName: S = "",
                        arrowsPortalId: C = null,
                        disableSwiping: N = !1,
                        interactiveIndicators: k = !1,
                        loop: E = !1,
                        sliderWrapperClassName: I = ""
                    } = e;
                    const [R, y] = (0, l.useState)(!1), $ = (0, l.useRef)(null), [A, L] = (0, l.useState)(0), P = (0, l.useRef)(null), [T, W] = (0, l.useState)(!0), [z, M] = (0, l.useState)(!1), q = (0, l.useRef)(o.A.gCustom()), G = d.P ? "caretleft" : "caretRight", O = d.P ? "caretRight" : "caretleft";
                    (0, l.useLayoutEffect)((() => {
                        var e, r;
                        const s = null === (e = P.current) || void 0 === e || null === (r = e.querySelector(".swiper-wrapper")) || void 0 === r ? void 0 : r.childNodes;
                        if (s) {
                            const e = () => {
                                var e;
                                y(!1), L(0);
                                const r = (null === (e = P.current) || void 0 === e ? void 0 : e.clientWidth) || 0;
                                let l = 0,
                                    i = 0;
                                for (let a = 0; a < s.length; a++) {
                                    var t;
                                    const e = null === (t = s[a]) || void 0 === t ? void 0 : t.offsetWidth;
                                    if (i + e > r) break;
                                    l++, i += e
                                }
                                W(g.length > l)
                            };
                            return e(), window.addEventListener("resize", e), () => {
                                window.removeEventListener("resize", e)
                            }
                        }
                    }), [g.length]), (0, l.useEffect)((() => {
                        var e;
                        null !== (e = $.current) && void 0 !== e && e.swiper && m && ($.current.swiper.slideTo(m, 0), L(m))
                    }), [m]);
                    const V = (0, l.useMemo)((() => `swiper-pagination-${(Math.random()+1).toString(36).substring(7)}`), []),
                        D = e => {
                            var r;
                            e.stopPropagation(), null !== (r = $.current) && void 0 !== r && r.swiper && $.current.swiper.slidePrev()
                        },
                        F = e => {
                            var r;
                            e.stopPropagation(), null !== (r = $.current) && void 0 !== r && r.swiper && ($.current.swiper.slideNext(), y($.current.swiper.isEnd))
                        },
                        K = (0, l.useCallback)((e => {
                            y(e.isEnd)
                        }), []);
                    (0, l.useEffect)((() => (M(!0), () => M(!1))), [g]);
                    const Z = (0, l.useMemo)((() => {
                            if (!g || !g.length) return [];
                            if (!(z && "auto" === x && n)) return g;
                            const e = document.querySelector(`.${w(q.current)}`),
                                r = document.querySelector(`.${h(q.current)}`);
                            if (e && r) {
                                const s = e.getClientRects()[0].width,
                                    i = r.getClientRects()[0].width,
                                    t = Math.floor(i / s);
                                if (g.length > t && g.length < 2 * t) return [...g, ...g].map(((e, r) => (0, p.jsx)(l.Fragment, {
                                    children: e
                                }, r)))
                            }
                            return g
                        }), [n, g, x, z, q.current]),
                        B = (0, l.useCallback)((e => {
                            y(e.isEnd), L(e.activeIndex)
                        }), []),
                        H = (0, l.useCallback)((e => {
                            let {
                                children: r
                            } = e;
                            return C ? (0, p.jsx)(u.Z, {
                                rootId: C,
                                children: r
                            }) : r
                        }), [C]),
                        J = !n && !E && 0 === A,
                        Q = !n && !E && R;
                    return (0, p.jsxs)("div", {
                        ref: P,
                        className: I,
                        children: [f ? (0, p.jsxs)("div", {
                            className: "swiper__slider--header",
                            children: [(0, p.jsx)("h3", {
                                children: b
                            }), T && (0, p.jsxs)("div", {
                                className: "swiper__slider--header__arrowsRow",
                                children: [(0, p.jsx)("button", {
                                    onClick: D,
                                    disabled: J,
                                    className: (0, i.A)([{
                                        "disabled-arrow": J
                                    }]),
                                    children: (0, p.jsx)(c.GlobalIcon, {
                                        lib: "generic",
                                        name: O,
                                        theme: "default",
                                        size: 12,
                                        skeleton: !0
                                    })
                                }), (0, p.jsx)("button", {
                                    className: (0, i.A)([{
                                        "disabled-arrow": Q
                                    }]),
                                    onClick: F,
                                    disabled: Q,
                                    children: (0, p.jsx)(c.GlobalIcon, {
                                        lib: "generic",
                                        name: G,
                                        theme: "default",
                                        size: 12,
                                        skeleton: !0
                                    })
                                })]
                            })]
                        }) : null, (0, p.jsxs)("div", {
                            className: "swiperWrapper",
                            children: [v && T && (0, p.jsx)(H, {
                                children: (0, p.jsxs)(p.Fragment, {
                                    children: [(0, p.jsx)("div", {
                                        className: "swiperWrapper__arrows",
                                        children: (0, p.jsx)("button", {
                                            onClick: D,
                                            disabled: J,
                                            className: (0, i.A)([{
                                                "disabled-arrow": J
                                            }]),
                                            children: (0, p.jsx)(c.GlobalIcon, {
                                                lib: "generic",
                                                name: O,
                                                theme: "default",
                                                size: 12
                                            })
                                        })
                                    }), (0, p.jsx)("div", {
                                        className: "swiperWrapper__arrows",
                                        children: (0, p.jsx)("button", {
                                            className: (0, i.A)([{
                                                "disabled-arrow": Q
                                            }]),
                                            onClick: F,
                                            disabled: Q,
                                            children: (0, p.jsx)(c.GlobalIcon, {
                                                lib: "generic",
                                                name: G,
                                                theme: "default",
                                                size: 12
                                            })
                                        })
                                    })]
                                })
                            }), (0, p.jsx)(t.RC, {
                                loop: n || E,
                                className: `${h(q.current)} ${S}`,
                                allowTouchMove: !N,
                                pagination: {
                                    type: "bullets",
                                    el: `.${V}`,
                                    clickable: k
                                },
                                autoplay: n && {
                                    delay: a || 1e3,
                                    disableOnInteraction: !1
                                },
                                slidesPerView: x || "auto",
                                onSwiper: K,
                                onSlideChange: B,
                                ref: $,
                                onSliderMove: null === (r = $.current) || void 0 === r || null === (s = r.swiper) || void 0 === s ? void 0 : s.update,
                                children: null === Z || void 0 === Z ? void 0 : Z.map(((e, r) => (0, p.jsx)(t.qr, {
                                    className: `${w(q.current)} ${_} `,
                                    children: (0, p.jsx)("div", {
                                        children: e
                                    })
                                }, r)))
                            })]
                        }), j && (0, p.jsx)("div", {
                            className: `swiperWrapper__swiper-pagination swiper-pagination ${V}`
                        })]
                    })
                }
        }
    }
]);
//# sourceMappingURL=multiple-widget-SwiperSlider.5e083e2d.chunk.js.map