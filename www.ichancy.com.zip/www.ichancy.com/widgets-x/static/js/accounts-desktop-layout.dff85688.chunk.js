"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [71103], {
        879504: (e, a, n) => {
            n.d(a, {
                g: () => h
            });
            n(50999);
            var c = n(69661),
                l = n(365043),
                s = n(507712),
                o = n(679559),
                i = n(870905),
                t = n(860446),
                d = n.n(t),
                r = n(735905),
                u = n(179177),
                _ = n(831179),
                m = n(570579);
            const h = () => {
                const e = (0, l.useRef)(null),
                    a = (0, s.d4)(o.wz),
                    {
                        t: n
                    } = (0, i.B)();
                return (0, m.jsx)("div", {
                    className: "popoverWrapper",
                    ref: e,
                    ...(0, _.q)("popover-wrapper"),
                    children: (0, m.jsx)(c.default, {
                        trigger: "click",
                        placement: "bottom",
                        arrowPointAtCenter: !0,
                        overlayStyle: {
                            width: "100%",
                            paddingLeft: 12,
                            paddingRight: 12
                        },
                        getPopupContainer: () => e.current,
                        content: (0, m.jsxs)(m.Fragment, {
                            children: [(0, m.jsxs)("div", {
                                className: "accountInfoRow",
                                children: [(0, m.jsx)("span", {
                                    children: n("account.registrationDate")
                                }), (0, m.jsx)("span", {
                                    className: "popoverWrapper_date",
                                    children: a.reg_date ? d()(a.reg_date).format(u.Ay.DT.longDate) : "-"
                                })]
                            }), (0, m.jsxs)("div", {
                                className: "accountInfoRow",
                                children: [(0, m.jsx)("span", {
                                    children: n("account.lastLoginDate")
                                }), (0, m.jsx)("span", {
                                    className: "popoverWrapper_date",
                                    children: a.last_login_date ? d().unix(a.last_login_date).format(u.Ay.DT.longDate) : "-"
                                })]
                            }), (0, m.jsxs)("div", {
                                className: "accountInfoRow",
                                children: [(0, m.jsx)("span", {
                                    children: n("account.lastTermAndCondAcceptDate")
                                }), (0, m.jsx)("span", {
                                    className: "popoverWrapper_date",
                                    children: a.terms_and_conditions_acceptance_date ? d()(a.terms_and_conditions_acceptance_date).format(u.Ay.DT.longDate) : "-"
                                })]
                            })]
                        }),
                        children: (0, m.jsx)(r.GlobalIcon, {
                            lib: "generic",
                            name: "info",
                            theme: "default",
                            size: 16,
                            className: "text-color"
                        })
                    })
                })
            }
        },
        646061: (e, a, n) => {
            n.d(a, {
                f: () => i
            });
            var c = n(870905),
                l = n(735905),
                s = n(626038),
                o = n(570579);
            const i = () => {
                const e = (0, s.N)(),
                    {
                        t: a
                    } = (0, c.B)();
                return (0, o.jsxs)("div", {
                    className: "accountModal__logoutButton",
                    onClick: () => e(!0),
                    children: [(0, o.jsx)(l.GlobalIcon, {
                        lib: "account",
                        name: "logout",
                        theme: "default",
                        size: 24,
                        className: "accountModal__logoutButton__icon"
                    }), a("account.logout")]
                })
            }
        },
        126246: (e, a, n) => {
            n.r(a), n.d(a, {
                DesktopLayout: () => H
            });
            n(461243);
            var c = n(923233),
                l = (n(678257), n(144719)),
                s = n(365043),
                o = n(995392),
                i = n(188397),
                t = n(507712),
                d = n(679559),
                r = n(841591),
                u = n(870905),
                _ = n(889181),
                m = n(197262),
                h = n(329675),
                v = n(670641),
                f = n(735905),
                p = n(384716),
                x = n(816343),
                j = n(638686),
                y = (n(270757), n(694227)),
                N = (n(176481), n(945375)),
                g = (n(864099), n(804473)),
                b = n(307022),
                B = n(80489),
                A = n(191523),
                I = n(989618),
                k = n(302258),
                M = n(879504),
                w = n(306572),
                C = n(179177),
                z = n(457250),
                S = n(570579);
            const {
                ShowInformationForGameBreak: R
            } = (0, I.R)((() => Promise.all([n.e(58073), n.e(88694)]).then(n.bind(n, 887610)))), T = function() {
                var e, a;
                const n = (0, t.wA)(),
                    c = (0, o.W6)(),
                    l = (0, t.d4)(d.eP),
                    i = (0, t.d4)(d.M0),
                    m = (0, t.d4)(d.wz),
                    h = (0, t.d4)(r.gh),
                    {
                        t: v
                    } = (0, u.B)(),
                    p = (0, t.d4)(r.h0),
                    {
                        is_verified: j,
                        id: I
                    } = m;
                (0, s.useEffect)((() => {
                    l && (null !== i && void 0 !== i && i.freeBonuses || z.nK || n((0, b.Bt)(!0)), null !== i && void 0 !== i && i.casinoBonuses || z.C4 || n((0, b.Bt)(!1)))
                }), [l]);
                const T = (0, s.useMemo)((() => w.R.find((e => String(e.key) === String(m.status)))), [m.status]),
                    E = null === (e = p.find((e => {
                        let {
                            formType: a
                        } = e;
                        return "username" === a
                    }))) || void 0 === e || null === (a = e.editForm) || void 0 === a ? void 0 : a.usernameInMyProfile;
                return (0, S.jsxs)("div", {
                    className: "userInfoAndBalance",
                    children: [(0, S.jsxs)("div", {
                        className: "userInfoAndBalance__info",
                        children: [I ? (0, S.jsxs)(S.Fragment, {
                            children: [(0, S.jsxs)("div", {
                                className: "userInfoAndBalance__info__wrapper",
                                children: [(0, S.jsxs)("div", {
                                    children: [j && (0, S.jsx)(f.GlobalIcon, {
                                        lib: "generic",
                                        name: "check",
                                        theme: "default",
                                        position: "absolute",
                                        size: 9,
                                        className: "userInfoAndBalance__info__checkedIcon"
                                    }), (0, S.jsx)(g.Ay, {
                                        className: "user__avatar",
                                        gap: 10,
                                        size: 56,
                                        children: (0, k.ki)(m)
                                    })]
                                }), (0, S.jsxs)("div", {
                                    className: "userInfoAndBalance__info__details",
                                    children: [!m.owner_id && (0, S.jsx)(N.default, {
                                        overlayClassName: "userInfoAndBalance__info__tooltip",
                                        placement: C.Ay.IS_RTL ? "topRight" : "topLeft",
                                        title: (0, k.J3)(m),
                                        children: (0, S.jsx)("div", {
                                            className: "userInfoAndBalance__userInfo",
                                            children: (0, S.jsx)("div", {
                                                className: "userInfoAndBalance__info__details__username",
                                                children: (0, k.J3)(m)
                                            })
                                        })
                                    }), !!Number(E) && (0, S.jsx)(N.default, {
                                        overlayClassName: "userInfoAndBalance__info__tooltip",
                                        placement: C.Ay.IS_RTL ? "topRight" : "topLeft",
                                        title: m.username,
                                        children: (0, S.jsx)("div", {
                                            className: "userInfoAndBalance__info__details__user",
                                            children: m.username
                                        })
                                    }), (0, S.jsxs)("div", {
                                        className: "userInfoAndBalance__info__details__icon",
                                        children: [(0, S.jsx)(M.g, {}), (0, S.jsxs)("div", {
                                            className: "userInfoAndBalance__info__details__id",
                                            children: ["ID: ", I, !!+(null === h || void 0 === h ? void 0 : h.accountStatusX) && (0, S.jsx)("div", {
                                                className: `${null===T||void 0===T?void 0:T.styled} statusColorDes`,
                                                children: (null === T || void 0 === T ? void 0 : T.value) || ""
                                            })]
                                        })]
                                    })]
                                })]
                            }), (1 === +(null === h || void 0 === h ? void 0 : h.verifiedAccount) || C.Ay.HAS_BONUS_ELIGIBLE) && null !== m.is_bonus_allowed && (m.is_bonus_allowed && m.is_verified ? C.Ay.HAS_BONUS_ELIGIBLE ? (0, S.jsx)("div", {
                                className: "userInfoAndBalance__info__details__bonus green",
                                children: (0, S.jsx)("span", {
                                    className: "bonus-text",
                                    children: v("account.EligibleForBonus")
                                })
                            }) : null : (0, S.jsxs)("div", {
                                className: (0, _.A)(["userInfoAndBalance__info__details__bonus", {
                                    gray: m.is_verified,
                                    red: !m.is_verified
                                }]),
                                children: [(0, S.jsx)(f.GlobalIcon, {
                                    lib: "generic",
                                    name: "attentionError",
                                    theme: "default",
                                    size: 16,
                                    skeleton: !0
                                }), (0, S.jsx)("span", {
                                    className: "bonus-text",
                                    children: m.is_verified ? v("account.notEligibleForBonus") : v("account.verificationRequired")
                                })]
                            }))]
                        }) : (0, S.jsx)("div", {
                            className: "userInfoAndBalance__info__wrapper",
                            children: (0, S.jsx)(y.A, {
                                active: !0,
                                avatar: {
                                    shape: "circle",
                                    size: 56
                                },
                                title: {
                                    width: "100%"
                                },
                                paragraph: {
                                    rows: 1,
                                    width: "50%",
                                    style: {
                                        margin: 0
                                    }
                                }
                            })
                        }), m.owner_id ? null : (0, S.jsx)(B.$, {
                            type: "cancel",
                            size: "large",
                            className: "full-width",
                            onClick: () => c.push((0, x.oR)({
                                accounts: "*",
                                settings: "*",
                                profile: "*"
                            })),
                            icon: (0, S.jsx)(f.GlobalIcon, {
                                lib: "generic",
                                name: "edit",
                                theme: "default",
                                size: 16,
                                className: "userInfoAndBalance__info__editIcon"
                            }),
                            children: v("account.editProfile")
                        })]
                    }), !!m.exclude_date && (0, S.jsx)(s.Suspense, {
                        fallback: null,
                        children: (0, S.jsx)(R, {})
                    }), (0, S.jsx)(A.h, {})]
                })
            };
            var E = n(123343),
                L = n(646061),
                G = n(120376),
                P = n(123213),
                D = n(556785),
                W = n(140999),
                O = n(787154),
                U = n(640763),
                F = n(261190);
            const $ = "true" === P.A.getItem((0, D.U)("account", "LOYALTY_POINTS_AVAILABLE")),
                H = e => {
                    const a = (0, o.zy)(),
                        n = (0, o.W6)(),
                        {
                            t: y
                        } = (0, u.B)(),
                        N = (0, t.d4)(d.eP),
                        g = (0, t.d4)(r.yX),
                        b = (0, p.o)(),
                        B = (0, t.d4)(h.xx),
                        A = (0, U.e)(),
                        I = (() => {
                            const e = (0, t.d4)(r.gh),
                                a = (0, t.d4)(d.wz);
                            return (0, s.useMemo)((() => {
                                if (e && !a.pending) {
                                    const n = new Set([]);
                                    return (1 !== +e.stakeAndEarn || a.currency_id !== F.Yr) && n.add("accounts:wallet:stake-and-earn"), Array.from(n)
                                }
                                return null
                            }), [e, a])
                        })(),
                        M = (0, t.d4)(d.M0),
                        w = (0, t.d4)(r.JL),
                        [z, R, P] = a.search.includes("=*") ? a.search.split("=*&") : a.search.replace(/\?|=%2A$/g, "").split("=%2A&"),
                        D = z.concat(":").concat(R),
                        H = (0, t.d4)(d.Zd),
                        [q, Y] = (0, s.useState)(),
                        Z = D.concat(":").concat(P),
                        J = (0, t.d4)(r.gh),
                        X = (0, t.d4)(d.wz),
                        V = ["myCards"],
                        K = new URLSearchParams(window.location.search),
                        Q = (0, s.useMemo)((() => {
                            if (!J && C.Ay.ACCOUNT_PARAMS) return {};
                            const e = i.HM.find((e => {
                                let {
                                    key: a
                                } = e;
                                return D.includes(a)
                            })) || {};
                            return "bonuses" === (null === e || void 0 === e ? void 0 : e.formType) && e.children && A && A.forEach((a => {
                                var n;
                                e.children = null === (n = e.children) || void 0 === n ? void 0 : n.filter((e => e.key !== a))
                            })), "myWallet" === (null === e || void 0 === e ? void 0 : e.formType) && e.children && I && I.forEach((a => {
                                var n;
                                e.children = null === (n = e.children) || void 0 === n ? void 0 : n.filter((e => e.key !== a))
                            })), e
                        }), [D, X, A, J]),
                        ee = b.register || b.login || b["forgot-password"] || b["reset-password"] || b["forgot-username"];
                    (0, s.useEffect)((() => {
                        var e, a, n;
                        Y(((null === M || void 0 === M || null === (e = M.casinoBonuses) || void 0 === e ? void 0 : e.length) || 0) + ((null === M || void 0 === M || null === (a = M.freeBonuses) || void 0 === a ? void 0 : a.length) || 0) + ((null === M || void 0 === M || null === (n = M.freeSpinBonuses) || void 0 === n ? void 0 : n.length) || 0))
                    }), [M]);
                    const ae = (0, s.useMemo)((() => {
                        const e = [];
                        return (null !== w && void 0 !== w && w.sections && null !== w && void 0 !== w && w.sections.length ? [...null === w || void 0 === w ? void 0 : w.sections, ...$ ? [{
                            key: "accounts:loyalty-points",
                            name: m.A.t("account.loyaltyPoints"),
                            auth: !0,
                            icon: (0, S.jsx)(f.GlobalIcon, {
                                lib: "account",
                                name: "medal",
                                theme: "default",
                                size: 24
                            }),
                            query: {
                                accounts: "*",
                                "loyalty-points": "*"
                            },
                            hidden: !1,
                            formType: "loyalty-points"
                        }] : []] : i.HM).map((a => {
                            var c, s;
                            let o = !0;
                            if (null !== w && void 0 !== w && null !== (c = w.sections) && void 0 !== c && c.length) {
                                const e = i.HM.filter((e => e.formType === a.formType));
                                e.length && !a.hidden && (o = !1, "myProfile" === a.formType && X.owner_id && (o = !0)), a = e[0]
                            }
                            if (a && a.auth && (null === w || void 0 === w || null === (s = w.sections) || void 0 === s || !s.length) || !o) {
                                if ("myProfile" === a.formType && null !== w && void 0 !== w && w.myProfile && null !== w && void 0 !== w && w.myProfile.length) {
                                    const e = [];
                                    w.myProfile.map((n => {
                                        const c = a.children.filter((e => e.formType === n.formType));
                                        c && c[0] && !n.hidden && (c[0].hidden = n.hidden, e.push(c[0]))
                                    })), e.length && (a.children = e)
                                }
                                if (!1 !== X.is_bonus_allowed && "bonuses" === a.formType || "bonuses" !== a.formType) {
                                    const c = k.Av.includes(`${a.formType}`),
                                        s = "bonuses" === a.formType ? q : "messages" === a.formType && H;
                                    e.push((0, S.jsx)(j.c, {
                                        arrow: "horizontal",
                                        noNeedClass: Boolean("accounts:bonuses" === a.key && s),
                                        thumb: c && s ? (0, S.jsx)(l.A, {
                                            className: "listItem_badgeAccount",
                                            count: s,
                                            offset: [-12, 1],
                                            size: "small",
                                            children: (0, S.jsxs)("div", {
                                                className: "listItem__thumb",
                                                children: [" ", a.icon, " "]
                                            })
                                        }) : a.icon && 1 === +(null === J || void 0 === J ? void 0 : J.verifiedAccount) && "accounts:settings" === a.key && !X.is_verified ? (0, S.jsx)(l.A, {
                                            count: !1,
                                            offset: [-12, 1],
                                            size: "small",
                                            className: "icon__Settings",
                                            children: (0, S.jsxs)("div", {
                                                className: "listItem__thumb",
                                                children: [" ", a.icon, " "]
                                            })
                                        }) : a.icon,
                                        active: D.includes(a.key),
                                        onClick: () => n.push((0, x.oR)(a.query)),
                                        children: a.name
                                    }, a.key))
                                }
                            }
                        })), e
                    }), [w, D, q, H, X.owner_id]);
                    return (0, W.v)(!B), ee ? (0, S.jsx)(c.A, {
                        className: "accountModal--desktop--small",
                        visible: !0,
                        footer: null,
                        width: 463,
                        centered: !0,
                        zIndex: O.Bo,
                        maskStyle: {
                            backgroundColor: "var(--v3-black-2)"
                        },
                        style: {
                            borderRadius: 12
                        },
                        bodyStyle: {
                            padding: 0
                        },
                        onCancel: e.closeModal,
                        closable: !b.booking_id,
                        closeIcon: b.booking_id ? null : (0, S.jsx)(f.GlobalIcon, {
                            lib: "generic",
                            name: "close",
                            theme: "default",
                            position: "absolute",
                            size: 16,
                            className: "accountModal__header__close"
                        }),
                        maskClosable: !1,
                        renderInBody: !0,
                        children: e.children
                    }) : (0, S.jsx)(G.Z, {
                        children: (0, S.jsx)("div", {
                            className: "accountModal accountModal--desktop",
                            style: {
                                zIndex: g ? O.uG : O.so
                            },
                            children: (0, S.jsxs)("div", {
                                className: "accountModal__container",
                                children: [(0, S.jsx)("div", {
                                    className: "accountModal__mainMenu accountModal__sectionWrapper",
                                    children: w && (0, S.jsxs)("div", {
                                        className: "accountModal__main-menu",
                                        children: [(0, S.jsx)(T, {}), C.Ay.CANADIAN_ACCOUNT_TYPE && (0, S.jsx)(v.Z, {}), (0, S.jsx)("div", {
                                            className: "accountModal__section-title",
                                            children: y("account.myAccount")
                                        }), ae, (0, S.jsx)(L.f, {})]
                                    })
                                }), (0, S.jsxs)("div", {
                                    className: "accountModal__wrapper",
                                    children: [(0, S.jsxs)("div", {
                                        className: "accountModal__header accountModal__sectionWrapper",
                                        children: [(0, S.jsx)("div", {
                                            className: "accountModal__header__title",
                                            children: y(null === Q || void 0 === Q ? void 0 : Q.name)
                                        }), b.booking_id ? null : (0, S.jsx)(f.GlobalIcon, {
                                            lib: "generic",
                                            name: "close",
                                            theme: "default",
                                            size: 16,
                                            position: "absolute",
                                            className: "accountModal__header__close",
                                            onClick: e.closeModal
                                        })]
                                    }), (0, S.jsxs)("div", {
                                        className: "accountModal__body",
                                        children: [null !== w && Q && (null === Q || void 0 === Q ? void 0 : Q.children) && Q.children.length > 0 && (0, S.jsx)("div", {
                                            className: "accountModal__subMenu accountModal__sectionWrapper",
                                            children: (0, S.jsx)("div", {
                                                className: "accMenu",
                                                children: null === Q || void 0 === Q ? void 0 : Q.children.map((e => {
                                                    if (V.includes(e.alias) && (e.hidden = !0, J && +J[e.alias] && (e.hidden = !1)), e && !e.hidden) return (0, S.jsxs)("div", {
                                                        className: (0, _.A)([`accMenu__item ${e.name.replace(" ","-")}`, {
                                                            "accMenu__item--active": Z.includes(e.key)
                                                        }]),
                                                        onClick: () => n.push((0, x.oR)(e.query)),
                                                        children: [(0, S.jsx)("div", {
                                                            className: (0, _.A)(["accMenu__item__icon", {
                                                                "accMenu__item__icon--active": Z.includes(e.key)
                                                            }]),
                                                            children: e.icon
                                                        }), e.name, 1 !== +(null === J || void 0 === J ? void 0 : J.verifiedAccount) || X.is_verified || e.name !== `${y("account.documents")}` ? null : (0, S.jsx)(f.GlobalIcon, {
                                                            name: "attentionError",
                                                            lib: "generic",
                                                            theme: "default",
                                                            size: 24,
                                                            className: "icon__ErrorDocument"
                                                        })]
                                                    }, e.key)
                                                }))
                                            })
                                        }), (0, S.jsxs)("div", {
                                            className: (0, _.A)(["accountModal__mainSection accountModal__sectionWrapper", {
                                                "accountModal__sectionWrapper-messages": K.has("messages") && !(!N && null === w)
                                            }]),
                                            children: [!N && null === w && (0, S.jsx)(E.R, {}), e.children, (0, S.jsx)("div", {
                                                id: "fixed-footer"
                                            })]
                                        })]
                                    })]
                                })]
                            })
                        })
                    })
                }
        },
        191523: (e, a, n) => {
            n.d(a, {
                h: () => g
            });
            n(270757);
            var c = n(694227),
                l = n(365043),
                s = n(870905),
                o = n(995392),
                i = n(507712),
                t = n(841591),
                d = n(889181),
                r = n(679559),
                u = n(80489),
                _ = n(735905),
                m = n(816343),
                h = n(384716),
                v = n(424541),
                f = n(55418),
                p = n(706683),
                x = n(683753),
                j = n(743544),
                y = n(179177),
                N = n(570579);
            const g = e => {
                var a;
                const {
                    t: n
                } = (0, s.B)(), g = (0, o.W6)(), {
                    wallet: b
                } = (0, h.o)(), B = (0, i.d4)(t.gh), A = (0, i.d4)(r.wz), {
                    currency: I,
                    currencyId: k,
                    placement: M
                } = (0, v.H)(), w = (0, i.d4)(t.d1), [C, z] = (0, l.useState)(!1), [S, R] = (0, l.useState)(!!y.Ay.IS_BONUS_BALANCE_VIEW_EXPANDED_BY_DEFAULT), T = (0, l.useCallback)((() => (0, N.jsx)("div", {
                    className: "accountBalance__valueCurrency",
                    children: (0, N.jsx)(c.A, {
                        title: {
                            style: {
                                width: 36,
                                height: 26,
                                margin: 0
                            }
                        },
                        paragraph: !1,
                        active: !0
                    })
                })), []), E = (0, l.useMemo)((() => j.$6 ? (0, N.jsxs)("div", {
                    className: (0, d.A)(["accountBalance__balance", "accountBalance__balance__bottom"]),
                    children: [(0, N.jsx)("div", {
                        className: "accountBalance__label",
                        children: n("account.casinoBalance")
                    }), k ? (0, N.jsxs)("div", {
                        className: "accountBalance__valueCurrency",
                        "data-testid": "casino-balance",
                        children: ["left" === M && (0, N.jsx)("div", {
                            className: "accountBalance__currency accountBalance__currency-left",
                            children: I
                        }), (0, N.jsx)("div", {
                            className: "accountBalance__value",
                            "data-testid": "casino-balance",
                            dir: "ltr",
                            children: (0, x.Mp)(A.casino_balance)
                        }), "right" === M && (0, N.jsx)("div", {
                            className: "accountBalance__currency accountBalance__currency-right",
                            children: I
                        })]
                    }) : (0, N.jsx)(T, {})]
                }) : null), [k, I, A.casino_balance]), L = (0, l.useMemo)((() => (0, N.jsxs)("div", {
                    className: (0, d.A)(["accountBalance__balance", "accountBalance__balance__bottom"]),
                    children: [(0, N.jsx)("div", {
                        className: "accountBalance__label",
                        children: n("account.frozenBalance")
                    }), k ? (0, N.jsxs)("div", {
                        className: "accountBalance__valueCurrency",
                        children: ["left" === M && (0, N.jsx)("div", {
                            className: "accountBalance__currency accountBalance__currency-left",
                            children: I
                        }), (0, N.jsx)("div", {
                            className: "accountBalance__value",
                            "data-testid": "frozen-balance",
                            children: (0, p.Q8)(A.frozen_balance)
                        }), "right" === M && (0, N.jsx)("div", {
                            className: "accountBalance__currency accountBalance__currency-right",
                            children: I
                        })]
                    }) : (0, N.jsx)(T, {})]
                })), [k, I, A.frozen_balance]);
                return (0, N.jsxs)("div", {
                    className: "accountBalance",
                    children: [(0, N.jsxs)("div", {
                        className: "accountBalance__wrapper",
                        children: [(0, N.jsxs)("div", {
                            className: (0, d.A)(["accountBalance__group", {
                                "accountBalance__group--expandable": E
                            }]),
                            onClick: () => z((e => !e)),
                            children: [(0, N.jsxs)("div", {
                                className: "accountBalance__balance",
                                children: [(0, N.jsxs)("div", {
                                    className: "accountBalance__label",
                                    children: [n("account.accountBalance"), E ? (0, N.jsx)(_.GlobalIcon, {
                                        lib: "generic",
                                        name: "caretDown",
                                        theme: "default",
                                        size: 12,
                                        className: (0, d.A)(["accountBalance__caret", {
                                            "accountBalance__caret--expanded": C
                                        }])
                                    }) : null]
                                }), k ? (0, N.jsxs)("div", {
                                    className: "accountBalance__valueCurrency",
                                    children: ["left" === M && (0, N.jsx)("div", {
                                        className: "accountBalance__currency accountBalance__currency-left",
                                        children: I
                                    }), (0, N.jsx)("div", {
                                        className: "accountBalance__value",
                                        "data-testid": "account-balance",
                                        dir: "ltr",
                                        children: (0, x.Bk)({
                                            balance: A.balance
                                        }, A.frozen_balance, w || 0)
                                    }), "right" === M && (0, N.jsx)("div", {
                                        className: "accountBalance__currency accountBalance__currency-right",
                                        children: I
                                    })]
                                }) : (0, N.jsx)(T, {})]
                            }), C && E]
                        }), +(null !== (a = null === B || void 0 === B ? void 0 : B.showBonusBalance) && void 0 !== a ? a : 1) ? (0, N.jsxs)("div", {
                            className: (0, d.A)(["accountBalance__group", {
                                "accountBalance__group--expandable": L
                            }]),
                            onClick: () => R((e => !e)),
                            children: [(0, N.jsxs)("div", {
                                className: "accountBalance__balance",
                                children: [(0, N.jsxs)("div", {
                                    className: "accountBalance__label",
                                    children: [n("account.bonusBalance"), L ? (0, N.jsx)(_.GlobalIcon, {
                                        lib: "generic",
                                        name: "caretDown",
                                        theme: "default",
                                        size: 12,
                                        className: (0, d.A)(["accountBalance__caret"]),
                                        iconClassName: (0, d.A)(["caretIcon", {
                                            "accountBalance__caret--expanded": S
                                        }])
                                    }) : null]
                                }), k ? (0, N.jsxs)("div", {
                                    className: "accountBalance__valueCurrency",
                                    children: ["left" === M && (0, N.jsx)("div", {
                                        className: "accountBalance__currency accountBalance__currency-left",
                                        children: I
                                    }), (0, N.jsx)("div", {
                                        className: "accountBalance__value",
                                        "data-testid": "bonus-balance",
                                        dir: "ltr",
                                        children: (0, x.e7)(A)
                                    }), "right" === M && (0, N.jsx)("div", {
                                        className: "accountBalance__currency accountBalance__currency-right",
                                        children: I
                                    })]
                                }) : (0, N.jsx)(T, {})]
                            }), S && L]
                        }) : null]
                    }), (!b || !(0, f.F)()) && (0, N.jsx)("div", {
                        className: "accountBalance__btnWrapper",
                        onClick: e => {
                            e.stopPropagation(), g.push((0, m.oR)({
                                accounts: "*",
                                wallet: "*",
                                [(0, f.F)() ? "deposit-methods" : "deposit"]: "*"
                            }))
                        },
                        children: (0, N.jsx)(u.$, {
                            size: "large",
                            fullwidth: !0,
                            type: "primary",
                            children: (0, N.jsxs)("div", {
                                className: "accountBalance__buttonContent",
                                children: [(0, N.jsx)(_.GlobalIcon, {
                                    lib: "generic",
                                    name: "add",
                                    theme: "default",
                                    size: 16,
                                    className: "accountBalance__addIcon"
                                }), n("account.deposit")]
                            })
                        })
                    }), e.children]
                })
            }
        },
        670641: (e, a, n) => {
            n.d(a, {
                Z: () => i
            });
            n(365043);
            var c = n(870905),
                l = n(735905),
                s = n(179177),
                o = n(570579);
            const i = () => {
                const {
                    t: e
                } = (0, c.B)();
                return (0, o.jsx)("div", {
                    className: "gamblingMessageCa",
                    children: (0, o.jsxs)("div", {
                        className: "attention",
                        children: [(0, o.jsx)(l.GlobalIcon, {
                            lib: "generic",
                            name: "attentionGeneric",
                            theme: "colored",
                            size: 42,
                            className: "accounts_attentionImg"
                        }), (0, o.jsxs)("div", {
                            children: [(0, o.jsx)("div", {
                                className: "account_attention",
                                children: e("account.attentionMessageCa")
                            }), (0, o.jsxs)("div", {
                                className: "gamblingMessageCa_account",
                                children: [e("account.gamblingMessageCa"), (0, o.jsx)("span", {
                                    className: "span_account",
                                    dangerouslySetInnerHTML: {
                                        __html: e("account.playResponsibly", {
                                            RESPONSIBLE_GAMING_URL: s.Ay.RESPONSIBLE_GAMING_URL
                                        })
                                    }
                                })]
                            })]
                        })]
                    })
                })
            }
        },
        306572: (e, a, n) => {
            n.d(a, {
                R: () => l
            });
            var c = n(197262);
            const l = [{
                key: 1,
                value: c.A.t("account.temporary"),
                styled: "colorOrange"
            }, {
                key: 2,
                value: c.A.t("account.permanent"),
                styled: "colorGreen"
            }, {
                key: 3,
                value: c.A.t("account.deactivate"),
                styled: "colorRed"
            }, {
                key: 4,
                value: c.A.t("account.closed"),
                styled: "colorRed"
            }, {
                key: 5,
                value: c.A.t("account.forbidden"),
                styled: "colorRed"
            }, {
                key: 6,
                value: c.A.t("account.blocked"),
                styled: "colorRed"
            }]
        }
    }
]);
//# sourceMappingURL=accounts-desktop-layout.dff85688.chunk.js.map