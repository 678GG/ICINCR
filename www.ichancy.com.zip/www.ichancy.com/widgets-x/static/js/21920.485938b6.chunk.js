"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [21920], {
        421920: (e, l, s) => {
            s.r(l), s.d(l, {
                MenuFill: () => a
            });
            var o = s(555329),
                i = s(989618),
                n = s(185762),
                b = s(570579);
            const {
                MenuFillDesktop: k
            } = (0, i.R)((() => Promise.all([s.e(87161), s.e(34426), s.e(55608), s.e(84107), s.e(81927), s.e(35834), s.e(70136), s.e(90440), s.e(35905), s.e(40012), s.e(27012), s.e(50245), s.e(73206), s.e(64007)]).then(s.bind(s, 290636)))), {
                MenuFillMobile: t
            } = (0, i.R)((() => Promise.all([s.e(87161), s.e(34426), s.e(55608), s.e(84107), s.e(81927), s.e(35834), s.e(70136), s.e(90440), s.e(35905), s.e(27012), s.e(50245), s.e(73206), s.e(33675)]).then(s.bind(s, 14400)))), a = () => (0, b.jsx)(n.L, {
                desktop: k,
                mobile: t,
                fallback: (0, b.jsx)(o.G, {})
            })
        }
    }
]);
//# sourceMappingURL=21920.485938b6.chunk.js.map