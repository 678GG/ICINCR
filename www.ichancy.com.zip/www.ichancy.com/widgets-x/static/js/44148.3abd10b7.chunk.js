"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [44148], {
        944148: (n, e, l) => {
            l.d(e, {
                Q: () => i
            });
            var t = l(365043),
                o = l(995392),
                s = l(507712),
                u = l(679559),
                a = l(462330),
                r = l(596771),
                c = l(816343);
            const i = n => {
                const e = (0, s.d4)(u.eP),
                    l = (0, o.W6)(),
                    i = (0, t.useCallback)((function() {
                        let n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "fun";
                        return "real" !== n || e ? (f(n), null) : ((0, c.qx)(), r.y.setAfterSignIn((() => {
                            f("real")
                        })), l.push((0, c.U7)({
                            accounts: "*",
                            login: "*"
                        })), null)
                    }), [n, e]),
                    f = (0, t.useCallback)((function() {
                        let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "fun";
                        return n && window.open((0, a.I)(n.extearnal_game_id, e, n.game_options), "_self"), null
                    }), [n]);
                return i
            }
        }
    }
]);
//# sourceMappingURL=44148.3abd10b7.chunk.js.map