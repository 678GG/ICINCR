"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [223], {
        500223: (s, n, o) => {
            o.d(n, {
                S8: () => d,
                lx: () => r,
                qE: () => m
            });
            var e = o(704270),
                a = o(423400);
            const m = (s, n, o, m, d) => {
                    e.l.then((e => {
                        e.sendCommand({
                            command: s,
                            params: n,
                            rid: a.A.gForCommand()
                        }, "", o, m, d)
                    }))
                },
                d = async (s, n, o, a) => {
                    e.l.then((e => e.sendCommand(s, "", n, o, a)))
                },
                r = s => {
                    e.l.then((n => n.unsubscribe(s)))
                }
        }
    }
]);
//# sourceMappingURL=223.d7f538e3.chunk.js.map