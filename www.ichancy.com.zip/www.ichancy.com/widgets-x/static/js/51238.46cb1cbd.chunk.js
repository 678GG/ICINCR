"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [51238], {
        151238: (t, o, r) => {
            var n;
            r.d(o, {
                A: () => d
            });
            var e = new Uint8Array(16);

            function s() {
                if (!n && !(n = "undefined" !== typeof crypto && crypto.getRandomValues && crypto.getRandomValues.bind(crypto) || "undefined" !== typeof msCrypto && "function" === typeof msCrypto.getRandomValues && msCrypto.getRandomValues.bind(msCrypto))) throw new Error("crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported");
                return n(e)
            }
            const u = /^(?:[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000)$/i;
            const a = function(t) {
                return "string" === typeof t && u.test(t)
            };
            for (var i = [], p = 0; p < 256; ++p) i.push((p + 256).toString(16).substr(1));
            const f = function(t) {
                var o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
                    r = (i[t[o + 0]] + i[t[o + 1]] + i[t[o + 2]] + i[t[o + 3]] + "-" + i[t[o + 4]] + i[t[o + 5]] + "-" + i[t[o + 6]] + i[t[o + 7]] + "-" + i[t[o + 8]] + i[t[o + 9]] + "-" + i[t[o + 10]] + i[t[o + 11]] + i[t[o + 12]] + i[t[o + 13]] + i[t[o + 14]] + i[t[o + 15]]).toLowerCase();
                if (!a(r)) throw TypeError("Stringified UUID is invalid");
                return r
            };
            const d = function(t, o, r) {
                var n = (t = t || {}).random || (t.rng || s)();
                if (n[6] = 15 & n[6] | 64, n[8] = 63 & n[8] | 128, o) {
                    r = r || 0;
                    for (var e = 0; e < 16; ++e) o[r + e] = n[e];
                    return o
                }
                return f(n)
            }
        }
    }
]);
//# sourceMappingURL=51238.46cb1cbd.chunk.js.map