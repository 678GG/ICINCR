"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [38686], {
        638686: (e, s, t) => {
            t.d(s, {
                c: () => c
            });
            t(365043);
            var a = t(889181),
                l = t(735905),
                i = t(570579);
            const c = e => {
                let {
                    children: s,
                    thumb: t,
                    extra: c,
                    disabled: r,
                    arrow: d,
                    onClick: n,
                    active: m,
                    noNeedClass: o,
                    dataTestId: h
                } = e;
                return (0, i.jsxs)("div", { ...h ? {
                        "data-testid": h
                    } : {},
                    className: (0, a.A)(["listItem", {
                        "listItem--active": m
                    }]),
                    onClick: n,
                    children: [t && (0, i.jsx)("div", {
                        className: o ? "" : "listItem__thumb",
                        children: t
                    }), (0, i.jsx)("div", {
                        className: "listItem__name",
                        children: s
                    }), c && (0, i.jsx)("div", {
                        className: "listItem__extra",
                        children: c
                    }), "horizontal" === d && !r && (0, i.jsx)(l.GlobalIcon, {
                        lib: "generic",
                        name: "caretRight",
                        theme: "default",
                        size: 11,
                        className: "listItem__arrow"
                    })]
                })
            }
        }
    }
]);
//# sourceMappingURL=38686.71123295.chunk.js.map