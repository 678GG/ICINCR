"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [9545], {
        703532: (s, a, e) => {
            e.d(a, {
                d: () => c
            });
            e(270757);
            var r = e(694227),
                p = (e(133059), e(570579));
            const c = () => (0, p.jsxs)("div", {
                className: "searchBar",
                children: [(0, p.jsx)(r.A, {
                    paragraph: !1,
                    title: {
                        style: {
                            margin: "3px 0px 3px 11px",
                            width: 80
                        }
                    }
                }), (0, p.jsx)("span", {
                    className: "searchBar__postfixIcon",
                    children: (0, p.jsx)(r.A.Avatar, {
                        size: 14.5
                    })
                })]
            })
        },
        244261: () => {},
        133059: () => {}
    }
]);
//# sourceMappingURL=9545.10392c8a.chunk.js.map