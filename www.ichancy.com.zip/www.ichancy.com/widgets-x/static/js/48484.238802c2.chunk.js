"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [48484], {
        124942: (e, t) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            t.default = {
                icon: {
                    tag: "svg",
                    attrs: {
                        viewBox: "64 64 896 896",
                        focusable: "false"
                    },
                    children: [{
                        tag: "path",
                        attrs: {
                            d: "M724 218.3V141c0-6.7-7.7-10.4-12.9-6.3L260.3 486.8a31.86 31.86 0 000 50.3l450.8 352.1c5.3 4.1 12.9.4 12.9-6.3v-77.3c0-4.9-2.3-9.6-6.1-12.6l-360-281 360-281.1c3.8-3 6.1-7.7 6.1-12.6z"
                        }
                    }]
                },
                name: "left",
                theme: "outlined"
            }
        },
        848484: (e, t, r) => {
            var a;
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var u = (a = r(206775)) && a.__esModule ? a : {
                default: a
            };
            t.default = u, e.exports = u
        },
        206775: (e, t, r) => {
            var a = r(245288),
                u = r(310684);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = a(r(601459)),
                n = function(e, t) {
                    if (!t && e && e.__esModule) return e;
                    if (null === e || "object" != u(e) && "function" != typeof e) return {
                        default: e
                    };
                    var r = c(t);
                    if (r && r.has(e)) return r.get(e);
                    var a = {
                            __proto__: null
                        },
                        o = Object.defineProperty && Object.getOwnPropertyDescriptor;
                    for (var n in e)
                        if ("default" !== n && Object.prototype.hasOwnProperty.call(e, n)) {
                            var l = o ? Object.getOwnPropertyDescriptor(e, n) : null;
                            l && (l.get || l.set) ? Object.defineProperty(a, n, l) : a[n] = e[n]
                        }
                    return a.default = e, r && r.set(e, a), a
                }(r(365043)),
                l = a(r(124942)),
                f = a(r(942740));

            function c(e) {
                if ("function" != typeof WeakMap) return null;
                var t = new WeakMap,
                    r = new WeakMap;
                return (c = function(e) {
                    return e ? r : t
                })(e)
            }
            var d = function(e, t) {
                    return n.createElement(f.default, (0, o.default)((0, o.default)({}, e), {}, {
                        ref: t,
                        icon: l.default
                    }))
                },
                i = n.forwardRef(d);
            t.default = i
        }
    }
]);
//# sourceMappingURL=48484.238802c2.chunk.js.map