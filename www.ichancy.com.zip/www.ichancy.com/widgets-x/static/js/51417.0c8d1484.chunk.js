(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [51417], {
        851417: function(e, t, r) {
            e.exports = function(e) {
                "use strict";

                function t(e) {
                    return e && "object" == typeof e && "default" in e ? e : {
                        default: e
                    }
                }
                var r = t(e),
                    _ = "\u064a\u0646\u0627\u064a\u0631_\u0641\u0628\u0631\u0627\u064a\u0631_\u0645\u0627\u0631\u0633_\u0623\u0628\u0631\u064a\u0644_\u0645\u0627\u064a\u0648_\u064a\u0648\u0646\u064a\u0648_\u064a\u0648\u0644\u064a\u0648_\u0623\u063a\u0633\u0637\u0633_\u0633\u0628\u062a\u0645\u0628\u0631_\u0623\u0643\u062a\u0648\u0628\u0631_\u0646\u0648\u0641\u0645\u0628\u0631_\u062f\u064a\u0633\u0645\u0628\u0631".split("_"),
                    n = {
                        1: "\u0661",
                        2: "\u0662",
                        3: "\u0663",
                        4: "\u0664",
                        5: "\u0665",
                        6: "\u0666",
                        7: "\u0667",
                        8: "\u0668",
                        9: "\u0669",
                        0: "\u0660"
                    },
                    s = {
                        "\u0661": "1",
                        "\u0662": "2",
                        "\u0663": "3",
                        "\u0664": "4",
                        "\u0665": "5",
                        "\u0666": "6",
                        "\u0667": "7",
                        "\u0668": "8",
                        "\u0669": "9",
                        "\u0660": "0"
                    },
                    o = {
                        name: "ar",
                        weekdays: "\u0627\u0644\u0623\u062d\u062f_\u0627\u0644\u0625\u062b\u0646\u064a\u0646_\u0627\u0644\u062b\u0644\u0627\u062b\u0627\u0621_\u0627\u0644\u0623\u0631\u0628\u0639\u0627\u0621_\u0627\u0644\u062e\u0645\u064a\u0633_\u0627\u0644\u062c\u0645\u0639\u0629_\u0627\u0644\u0633\u0628\u062a".split("_"),
                        weekdaysShort: "\u0623\u062d\u062f_\u0625\u062b\u0646\u064a\u0646_\u062b\u0644\u0627\u062b\u0627\u0621_\u0623\u0631\u0628\u0639\u0627\u0621_\u062e\u0645\u064a\u0633_\u062c\u0645\u0639\u0629_\u0633\u0628\u062a".split("_"),
                        weekdaysMin: "\u062d_\u0646_\u062b_\u0631_\u062e_\u062c_\u0633".split("_"),
                        months: _,
                        monthsShort: _,
                        weekStart: 6,
                        meridiem: function(e) {
                            return e > 12 ? "\u0645" : "\u0635"
                        },
                        relativeTime: {
                            future: "\u0628\u0639\u062f %s",
                            past: "\u0645\u0646\u0630 %s",
                            s: "\u062b\u0627\u0646\u064a\u0629 \u0648\u0627\u062d\u062f\u0629",
                            m: "\u062f\u0642\u064a\u0642\u0629 \u0648\u0627\u062d\u062f\u0629",
                            mm: "%d \u062f\u0642\u0627\u0626\u0642",
                            h: "\u0633\u0627\u0639\u0629 \u0648\u0627\u062d\u062f\u0629",
                            hh: "%d \u0633\u0627\u0639\u0627\u062a",
                            d: "\u064a\u0648\u0645 \u0648\u0627\u062d\u062f",
                            dd: "%d \u0623\u064a\u0627\u0645",
                            M: "\u0634\u0647\u0631 \u0648\u0627\u062d\u062f",
                            MM: "%d \u0623\u0634\u0647\u0631",
                            y: "\u0639\u0627\u0645 \u0648\u0627\u062d\u062f",
                            yy: "%d \u0623\u0639\u0648\u0627\u0645"
                        },
                        preparse: function(e) {
                            return e.replace(/[\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669\u0660]/g, (function(e) {
                                return s[e]
                            })).replace(/\u060c/g, ",")
                        },
                        postformat: function(e) {
                            return e.replace(/\d/g, (function(e) {
                                return n[e]
                            })).replace(/,/g, "\u060c")
                        },
                        ordinal: function(e) {
                            return e
                        },
                        formats: {
                            LT: "HH:mm",
                            LTS: "HH:mm:ss",
                            L: "D/\u200fM/\u200fYYYY",
                            LL: "D MMMM YYYY",
                            LLL: "D MMMM YYYY HH:mm",
                            LLLL: "dddd D MMMM YYYY HH:mm"
                        }
                    };
                return r.default.locale(o, null, !0), o
            }(r(860446))
        }
    }
]);
//# sourceMappingURL=51417.0c8d1484.chunk.js.map