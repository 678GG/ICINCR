"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [10015], {
        610015: (e, t, a) => {
            a.r(t), a.d(t, {
                default: () => h
            });
            var l, n, r, i, C, c, p, o, s, f, d = a(365043);

            function m() {
                return m = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var a = arguments[t];
                        for (var l in a) Object.prototype.hasOwnProperty.call(a, l) && (e[l] = a[l])
                    }
                    return e
                }, m.apply(this, arguments)
            }

            function E(e, t) {
                let {
                    title: a,
                    titleId: E,
                    ..._
                } = e;
                return d.createElement("svg", m({
                    width: 32,
                    height: 32,
                    viewBox: "0 0 32 33",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    ref: t,
                    "aria-labelledby": E
                }, _), a ? d.createElement("title", {
                    id: E
                }, a) : null, l || (l = d.createElement("g", {
                    opacity: .08
                }, d.createElement("path", {
                    opacity: .08,
                    d: "M8.06527 32.0039C3.40902 32.0039 0.280273 28.8752 0.280273 24.2189V9.47311C0.280273 4.81686 3.40896 1.68811 8.06527 1.68811H23.9339C28.5901 1.68811 31.7189 4.8168 31.7189 9.47311V24.2189C31.7189 28.8752 28.5902 32.0039 23.9339 32.0039H8.06527Z",
                    fill: "black"
                }))), n || (n = d.createElement("path", {
                    d: "M8.06527 31.4425C3.40902 31.4425 0.280273 28.3138 0.280273 23.6575V8.91174C0.280273 4.25549 3.40896 1.12674 8.06527 1.12674H23.9339C28.5901 1.12674 31.7189 4.25543 31.7189 8.91174V23.6575C31.7189 28.3138 28.5902 31.4425 23.9339 31.4425H8.06527Z",
                    fill: "#F3F3F3"
                })), r || (r = d.createElement("path", {
                    d: "M0.280273 8.98636V8.91167C0.280273 4.25543 3.40896 1.12668 8.06527 1.12668H23.9339C28.5901 1.12668 31.7189 4.25536 31.7189 8.91167V8.98636H0.280273Z",
                    fill: "#F4413D"
                })), i || (i = d.createElement("g", {
                    opacity: .16
                }, d.createElement("path", {
                    opacity: .16,
                    d: "M23.9339 1.12674H8.06527C3.40902 1.12674 0.280273 4.25543 0.280273 8.91174V23.6575C0.280273 28.3138 3.40896 31.4425 8.06527 31.4425H23.9339C28.5901 31.4425 31.7189 28.3138 31.7189 23.6575V8.91174C31.7189 4.25543 28.5902 1.12674 23.9339 1.12674ZM30.5961 23.6575C30.5961 27.7047 27.9811 30.3197 23.9339 30.3197H8.06527C4.01809 30.3197 1.40309 27.7047 1.40309 23.6575V8.91174C1.40309 4.86455 4.01809 2.24955 8.06527 2.24955H23.9339C27.9811 2.24955 30.5961 4.86455 30.5961 8.91174V23.6575Z",
                    fill: "url(#paint0_linear_226_2395)"
                }))), C || (C = d.createElement("path", {
                    opacity: .24,
                    d: "M7.57872 6.74072C8.50887 6.74072 9.26291 5.98669 9.26291 5.05654C9.26291 4.12639 8.50887 3.37234 7.57872 3.37234C6.64857 3.37234 5.89453 4.12639 5.89453 5.05654C5.89453 5.98669 6.64857 6.74072 7.57872 6.74072Z",
                    fill: "black"
                })), c || (c = d.createElement("path", {
                    opacity: .24,
                    d: "M24.4215 6.74072C25.3516 6.74072 26.1057 5.98669 26.1057 5.05654C26.1057 4.12639 25.3516 3.37234 24.4215 3.37234C23.4913 3.37234 22.7373 4.12639 22.7373 5.05654C22.7373 5.98669 23.4913 6.74072 24.4215 6.74072Z",
                    fill: "black"
                })), p || (p = d.createElement("g", {
                    opacity: .16
                }, d.createElement("path", {
                    opacity: .16,
                    d: "M23.9339 1.12674H8.06527C3.40902 1.12674 0.280273 4.25543 0.280273 8.91174V23.6575C0.280273 28.3138 3.40896 31.4425 8.06527 31.4425H23.9339C28.5901 31.4425 31.7189 28.3138 31.7189 23.6575V8.91174C31.7189 4.25543 28.5902 1.12674 23.9339 1.12674ZM31.1575 23.6575C31.1575 27.9781 28.2545 30.8811 23.9339 30.8811H8.06527C3.74471 30.8811 0.841711 27.9781 0.841711 23.6575V8.91174C0.841711 4.59118 3.74471 1.68818 8.06527 1.68818H23.9339C28.2545 1.68818 31.1575 4.59118 31.1575 8.91174V23.6575Z",
                    fill: "black"
                }))), o || (o = d.createElement("path", {
                    d: "M7.57895 5.61797C7.26908 5.61797 7.01758 5.36647 7.01758 5.0566V0.565281C7.01758 0.255406 7.26908 0.00390625 7.57895 0.00390625C7.88883 0.00390625 8.14033 0.255406 8.14033 0.565281V5.05653C8.14039 5.36641 7.88883 5.61797 7.57895 5.61797Z",
                    fill: "url(#paint1_linear_226_2395)"
                })), s || (s = d.createElement("path", {
                    d: "M24.4207 5.61797C24.1109 5.61797 23.8594 5.36647 23.8594 5.0566V0.565281C23.8594 0.255406 24.1109 0.00390625 24.4207 0.00390625C24.7306 0.00390625 24.9821 0.255406 24.9821 0.565281V5.05653C24.9821 5.36641 24.7306 5.61797 24.4207 5.61797Z",
                    fill: "url(#paint2_linear_226_2395)"
                })), f || (f = d.createElement("defs", null, d.createElement("linearGradient", {
                    id: "paint0_linear_226_2395",
                    x1: 15.9996,
                    y1: 31.4409,
                    x2: 15.9996,
                    y2: 1.12499,
                    gradientUnits: "userSpaceOnUse"
                }, d.createElement("stop", null), d.createElement("stop", {
                    offset: .06,
                    stopOpacity: 0
                })), d.createElement("linearGradient", {
                    id: "paint1_linear_226_2395",
                    x1: 7.5789,
                    y1: 5.61622,
                    x2: 7.5789,
                    y2: .00215583,
                    gradientUnits: "userSpaceOnUse"
                }, d.createElement("stop", {
                    stopColor: "white"
                }), d.createElement("stop", {
                    offset: 1,
                    stopColor: "#DCDCDC"
                })), d.createElement("linearGradient", {
                    id: "paint2_linear_226_2395",
                    x1: 24.4208,
                    y1: 5.61622,
                    x2: 24.4208,
                    y2: .00215583,
                    gradientUnits: "userSpaceOnUse"
                }, d.createElement("stop", {
                    stopColor: "white"
                }), d.createElement("stop", {
                    offset: 1,
                    stopColor: "#DCDCDC"
                })))))
            }
            const _ = d.forwardRef(E),
                h = (a.p, _)
        }
    }
]);
//# sourceMappingURL=10015.6834c854.chunk.js.map