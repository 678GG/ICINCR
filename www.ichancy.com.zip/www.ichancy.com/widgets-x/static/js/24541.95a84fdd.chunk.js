"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [24541], {
        424541: (e, c, r) => {
            r.d(c, {
                H: () => p
            });
            var n = r(507712),
                u = r(365043),
                t = r(462956),
                s = r(679559),
                o = r(68392),
                a = r(261190);
            const p = () => {
                const [e, c] = (0, u.useState)(""), {
                    currency: r
                } = (0, n.d4)(s.wz), p = (0, n.d4)(s.eP), y = (0, n.d4)(t.gU);
                (0, u.useLayoutEffect)((() => {
                    p && r ? c(r) : null !== y && void 0 !== y && y.currency && c(y.currency)
                }), [y, p, r]);
                return (0, u.useMemo)((() => {
                    const c = (0, o.N8)(e),
                        r = c.currency === a.Mi ? a.Wq : c.currency;
                    return {
                        currency: r,
                        currencyId: e,
                        placement: c.placement,
                        formatAmount: (0, o.Hv)(r, c.placement)
                    }
                }), [e])
            }
        }
    }
]);
//# sourceMappingURL=24541.95a84fdd.chunk.js.map