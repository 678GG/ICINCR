"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [70289], {
        770289: (e, t, r) => {
            function n() {
                return n = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = arguments[t];
                        for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n])
                    }
                    return e
                }, n.apply(this, arguments)
            }
            r.r(t), r.d(t, {
                _rs: () => b,
                default: () => _
            });
            var o = r(365043),
                u = r(462149);
            r(297907);

            function c(e, t, r) {
                return t in e ? Object.defineProperty(e, t, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = r, e
            }

            function i(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function f(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? i(Object(r), !0).forEach((function(t) {
                        c(e, t, r[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : i(Object(r)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    }))
                }
                return e
            }

            function a(e) {
                return a = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                    return typeof e
                } : function(e) {
                    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                }, a(e)
            }
            var l = r(925593),
                s = r(113758),
                p = o.createContext(null);
            var h = r(535820),
                y = new Map;
            var v = new h.A((function(e) {
                    e.forEach((function(e) {
                        var t, r = e.target;
                        null === (t = y.get(r)) || void 0 === t || t.forEach((function(e) {
                            return e(r)
                        }))
                    }))
                })),
                b = null;

            function d(e, t) {
                for (var r = 0; r < t.length; r++) {
                    var n = t[r];
                    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n)
                }
            }

            function O(e, t) {
                return O = Object.setPrototypeOf || function(e, t) {
                    return e.__proto__ = t, e
                }, O(e, t)
            }

            function g(e) {
                return g = Object.setPrototypeOf ? Object.getPrototypeOf : function(e) {
                    return e.__proto__ || Object.getPrototypeOf(e)
                }, g(e)
            }

            function w(e, t) {
                if (t && ("object" === a(t) || "function" === typeof t)) return t;
                if (void 0 !== t) throw new TypeError("Derived constructors may only return object or undefined");
                return function(e) {
                    if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                    return e
                }(e)
            }

            function m(e) {
                var t = function() {
                    if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" === typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var r, n = g(e);
                    if (t) {
                        var o = g(this).constructor;
                        r = Reflect.construct(n, arguments, o)
                    } else r = n.apply(this, arguments);
                    return w(this, r)
                }
            }
            var j = function(e) {
                ! function(e, t) {
                    if ("function" !== typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
                    e.prototype = Object.create(t && t.prototype, {
                        constructor: {
                            value: e,
                            writable: !0,
                            configurable: !0
                        }
                    }), Object.defineProperty(e, "prototype", {
                        writable: !1
                    }), t && O(e, t)
                }(u, e);
                var t, r, n, o = m(u);

                function u() {
                    return function(e, t) {
                        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                    }(this, u), o.apply(this, arguments)
                }
                return t = u, (r = [{
                    key: "render",
                    value: function() {
                        return this.props.children
                    }
                }]) && d(t.prototype, r), n && d(t, n), Object.defineProperty(t, "prototype", {
                    writable: !1
                }), u
            }(o.Component);

            function P(e, t) {
                var r = e.children,
                    n = e.disabled,
                    u = o.useRef(null),
                    c = o.useRef(null),
                    i = o.useContext(p),
                    h = "function" === typeof r,
                    b = h ? r(u) : r,
                    d = o.useRef({
                        width: -1,
                        height: -1,
                        offsetWidth: -1,
                        offsetHeight: -1
                    }),
                    O = !h && o.isValidElement(b) && (0, s.f3)(b),
                    g = O ? b.ref : null,
                    w = (0, s.xK)(g, u),
                    m = function() {
                        var e;
                        return (0, l.A)(u.current) || (u.current && "object" === a(u.current) ? (0, l.A)(null === (e = u.current) || void 0 === e ? void 0 : e.nativeElement) : null) || (0, l.A)(c.current)
                    };
                o.useImperativeHandle(t, (function() {
                    return m()
                }));
                var P = o.useRef(e);
                P.current = e;
                var R = o.useCallback((function(e) {
                    var t = P.current,
                        r = t.onResize,
                        n = t.data,
                        o = e.getBoundingClientRect(),
                        u = o.width,
                        c = o.height,
                        a = e.offsetWidth,
                        l = e.offsetHeight,
                        s = Math.floor(u),
                        p = Math.floor(c);
                    if (d.current.width !== s || d.current.height !== p || d.current.offsetWidth !== a || d.current.offsetHeight !== l) {
                        var h = {
                            width: s,
                            height: p,
                            offsetWidth: a,
                            offsetHeight: l
                        };
                        d.current = h;
                        var y = a === Math.round(u) ? u : a,
                            v = l === Math.round(c) ? c : l,
                            b = f(f({}, h), {}, {
                                offsetWidth: y,
                                offsetHeight: v
                            });
                        null === i || void 0 === i || i(b, e, n), r && Promise.resolve().then((function() {
                            r(b, e)
                        }))
                    }
                }), []);
                return o.useEffect((function() {
                    var e, t, r = m();
                    return r && !n && (e = r, t = R, y.has(e) || (y.set(e, new Set), v.observe(e)), y.get(e).add(t)),
                        function() {
                            return function(e, t) {
                                y.has(e) && (y.get(e).delete(t), y.get(e).size || (v.unobserve(e), y.delete(e)))
                            }(r, R)
                        }
                }), [u.current, n]), o.createElement(j, {
                    ref: c
                }, O ? o.cloneElement(b, {
                    ref: w
                }) : b)
            }
            const R = o.forwardRef(P);

            function E(e, t) {
                var r = e.children;
                return ("function" === typeof r ? [r] : (0, u.A)(r)).map((function(r, u) {
                    var c = (null === r || void 0 === r ? void 0 : r.key) || "".concat("rc-observer-key", "-").concat(u);
                    return o.createElement(R, n({}, e, {
                        key: c,
                        ref: 0 === u ? t : void 0
                    }), r)
                }))
            }
            var k = o.forwardRef(E);
            k.Collection = function(e) {
                var t = e.children,
                    r = e.onBatchResize,
                    n = o.useRef(0),
                    u = o.useRef([]),
                    c = o.useContext(p),
                    i = o.useCallback((function(e, t, o) {
                        n.current += 1;
                        var i = n.current;
                        u.current.push({
                            size: e,
                            element: t,
                            data: o
                        }), Promise.resolve().then((function() {
                            i === n.current && (null === r || void 0 === r || r(u.current), u.current = [])
                        })), null === c || void 0 === c || c(e, t, o)
                    }), [r, c]);
                return o.createElement(p.Provider, {
                    value: i
                }, t)
            };
            const _ = k
        }
    }
]);
//# sourceMappingURL=70289.8727bbfe.chunk.js.map