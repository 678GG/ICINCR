"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [99989], {
        699989: (e, t, r) => {
            var o = r(50130),
                n = r(487066);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.NoStyleItemContext = t.NoFormStatus = t.FormProvider = t.FormItemPrefixContext = t.FormItemInputContext = t.FormContext = void 0;
            var a = function(e, t) {
                    if (!t && e && e.__esModule) return e;
                    if (null === e || "object" !== n(e) && "function" !== typeof e) return {
                        default: e
                    };
                    var r = f(t);
                    if (r && r.has(e)) return r.get(e);
                    var o = {},
                        a = Object.defineProperty && Object.getOwnPropertyDescriptor;
                    for (var u in e)
                        if ("default" !== u && Object.prototype.hasOwnProperty.call(e, u)) {
                            var i = a ? Object.getOwnPropertyDescriptor(e, u) : null;
                            i && (i.get || i.set) ? Object.defineProperty(o, u, i) : o[u] = e[u]
                        }
                    o.default = e, r && r.set(e, o);
                    return o
                }(r(365043)),
                u = o(r(449193)),
                i = r(166962);

            function f(e) {
                if ("function" !== typeof WeakMap) return null;
                var t = new WeakMap,
                    r = new WeakMap;
                return (f = function(e) {
                    return e ? r : t
                })(e)
            }
            var l = a.createContext({
                labelAlign: "right",
                vertical: !1,
                itemRef: function() {}
            });
            t.FormContext = l;
            var c = a.createContext(null);
            t.NoStyleItemContext = c;
            t.FormProvider = function(e) {
                var t = (0, u.default)(e, ["prefixCls"]);
                return a.createElement(i.FormProvider, t)
            };
            var p = a.createContext({
                prefixCls: ""
            });
            t.FormItemPrefixContext = p;
            var v = a.createContext({});
            t.FormItemInputContext = v;
            t.NoFormStatus = function(e) {
                var t = e.children,
                    r = (0, a.useMemo)((function() {
                        return {}
                    }), []);
                return a.createElement(v.Provider, {
                    value: r
                }, t)
            }
        }
    }
]);
//# sourceMappingURL=99989.9e0f5559.chunk.js.map