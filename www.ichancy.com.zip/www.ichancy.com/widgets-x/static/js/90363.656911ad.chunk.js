"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [90363], {
        390363: (e, t, i) => {
            var r = i(50130);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.responsiveMap = t.responsiveArray = t.default = void 0;
            var s = r(i(329085)),
                n = r(i(319290));
            t.responsiveArray = ["xxl", "xl", "lg", "md", "sm", "xs"];
            var a = {
                xs: "(max-width: 575px)",
                sm: "(min-width: 576px)",
                md: "(min-width: 768px)",
                lg: "(min-width: 992px)",
                xl: "(min-width: 1200px)",
                xxl: "(min-width: 1600px)"
            };
            t.responsiveMap = a;
            var o = new Map,
                u = -1,
                d = {},
                c = {
                    matchHandlers: {},
                    dispatch: function(e) {
                        return d = e, o.forEach((function(e) {
                            return e(d)
                        })), o.size >= 1
                    },
                    subscribe: function(e) {
                        return o.size || this.register(), u += 1, o.set(u, e), e(d), u
                    },
                    unsubscribe: function(e) {
                        o.delete(e), o.size || this.unregister()
                    },
                    unregister: function() {
                        var e = this;
                        Object.keys(a).forEach((function(t) {
                            var i = a[t],
                                r = e.matchHandlers[i];
                            null === r || void 0 === r || r.mql.removeListener(null === r || void 0 === r ? void 0 : r.listener)
                        })), o.clear()
                    },
                    register: function() {
                        var e = this;
                        Object.keys(a).forEach((function(t) {
                            var i = a[t],
                                r = function(i) {
                                    var r = i.matches;
                                    e.dispatch((0, n.default)((0, n.default)({}, d), (0, s.default)({}, t, r)))
                                },
                                o = window.matchMedia(i);
                            o.addListener(r), e.matchHandlers[i] = {
                                mql: o,
                                listener: r
                            }, r(o)
                        }))
                    }
                };
            t.default = c
        }
    }
]);
//# sourceMappingURL=90363.656911ad.chunk.js.map