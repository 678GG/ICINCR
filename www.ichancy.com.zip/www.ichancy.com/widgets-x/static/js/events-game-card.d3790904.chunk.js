"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [25142, 61850, 80279, 61878, 2546, 29634, 16006, 91877, 3295, 35947, 6324, 96843, 940, 43166], {
        947362: (e, t, a) => {
            a.d(t, {
                h: () => u,
                D: () => m
            });
            var o = a(365043),
                s = a(117893),
                i = a(507712),
                n = a(283573),
                l = a(735905),
                r = a(365506),
                d = a(724131),
                c = a(570579);
            const m = e => {
                let {
                    group: t,
                    updateFavorites: a,
                    isMainMarket: m,
                    className: p
                } = e;
                const u = (0, i.wA)(),
                    v = (0, o.useMemo)((() => {
                        var e, a, o, s;
                        return m ? d.$w : `${(null===t||void 0===t||null===(e=t.markets)||void 0===e||null===(a=e[0])||void 0===a?void 0:a.type)||""}-${(null===t||void 0===t||null===(o=t.markets)||void 0===o||null===(s=o[0])||void 0===s?void 0:s.name)||""}`
                    }), [m, t]),
                    h = (0, i.d4)((0, n.YK)(v, "markets"));
                return (0, c.jsx)(r.H, {
                    size: "md",
                    ghost: !0,
                    active: h,
                    icon: (0, c.jsx)(l.GlobalIcon, {
                        lib: "generic",
                        name: "favorite",
                        theme: "default",
                        size: 20,
                        skeleton: !0,
                        keepInCache: !0
                    }),
                    className: p,
                    onClick: e => {
                        e.stopPropagation(), u((0, s.dwU)({
                            groupKey: "markets",
                            entity: v
                        })), a()
                    }
                })
            };
            var p = a(398610);
            const u = e => {
                let {
                    game: t,
                    size: a,
                    className: o,
                    iconMargin: s = "left",
                    ghost: d,
                    iconContainerSize: m,
                    externalCallback: u
                } = e;
                const {
                    id: v
                } = t, h = (0, i.wA)(), _ = (0, i.d4)(n.Kh), g = 1 === t.type ? "live" : "prematch", b = {
                    gameType: g,
                    groupKey: _.esport[g].includes(v) ? "esport" : "sportsbook"
                }, x = (0, i.d4)((0, n.YK)(t.id, b.groupKey));
                return (0, c.jsx)(r.H, {
                    margin: s,
                    iconContainerSize: m,
                    ghost: d,
                    active: x,
                    className: o,
                    onClick: e => {
                        e.stopPropagation(), e.preventDefault(), h((0, p.dw)({ ...b,
                            entity: v
                        })), null === u || void 0 === u || u()
                    },
                    icon: (0, c.jsx)(l.GlobalIcon, {
                        lib: "generic",
                        name: "favorite",
                        theme: "default",
                        size: a,
                        skeleton: !0,
                        keepInCache: !0,
                        className: "gameFavIcon"
                    })
                })
            }
        },
        714368: (e, t, a) => {
            a.d(t, {
                f: () => l
            });
            var o = a(365043),
                s = a(889181),
                i = a(777619),
                n = a(570579);
            const l = o.memo((e => {
                let {
                    size: t,
                    className: a = "",
                    emptyOddStyle: o,
                    colorVariables: l
                } = e;
                return (0, n.jsxs)(i.a, {
                    className: (0, s.A)([a, {
                        empty__OddStyle: o
                    }]),
                    size: t,
                    onClick: e => e.stopPropagation(),
                    style: l && {
                        background: l.oddsBgColor,
                        border: `1px solid ${l.oddBorderColor}`
                    },
                    children: [(0, n.jsx)("div", {
                        className: "emptyRadioBtnContainer",
                        style: l && {
                            color: l.oddTextColor
                        },
                        children: "-"
                    }), o ? (0, n.jsx)("div", {
                        className: "emptyRadioBtnContainer",
                        children: "-"
                    }) : null]
                })
            }))
        },
        390125: (e, t, a) => {
            a.d(t, {
                i: () => d
            });
            var o = a(365043),
                s = a(507712),
                i = a(841591),
                n = a(55418),
                l = a(714368),
                r = a(570579);
            const d = (0, o.memo)((e => {
                let {
                    size: t,
                    sportName: a,
                    isExpanded: o,
                    colorVariables: d
                } = e;
                const c = (0, s.d4)(i.KD) || (!o && (0, n.F)() && "soccer" !== (null === a || void 0 === a ? void 0 : a.toLocaleLowerCase()) ? 2 : 3);
                return c ? (0, r.jsx)(r.Fragment, {
                    children: new Array(c).fill("").map(((e, a) => (0, r.jsx)(l.f, {
                        colorVariables: d,
                        size: t
                    }, a)))
                }) : null
            }))
        },
        143166: (e, t, a) => {
            a.d(t, {
                w: () => x
            });
            a(50999);
            var o = a(69661),
                s = a(365043),
                i = a(889181),
                n = a(878509),
                l = a(241123),
                r = a(559178),
                d = a(390648),
                c = a(507712),
                m = a(589415),
                p = a(777619),
                u = a(855221),
                v = a(735905),
                h = a(177971),
                _ = a(55418),
                g = a(570579);
            const b = (0, s.forwardRef)(((e, t) => {
                    var a, o, s;
                    let {
                        size: i,
                        visible: n,
                        parent: l,
                        handicap: b,
                        name: x,
                        value: f,
                        style: y,
                        isBlocked: w,
                        fullName: C,
                        marketType: N,
                        type1: S,
                        base: j,
                        gameId: A,
                        noBoosted: k,
                        coeficient: T,
                        oddFormat: I,
                        isLive: $,
                        oddTextColor: E
                    } = e;
                    const B = (0, c.d4)(d.zH),
                        P = (0, h.Z)(T),
                        G = !k && (null === B || void 0 === B || null === (a = B[A]) || void 0 === a ? void 0 : a[f]) && ((null === B || void 0 === B || null === (o = B[A]) || void 0 === o ? void 0 : o[f].type) === m.j.ALL || (null === B || void 0 === B || null === (s = B[A]) || void 0 === s ? void 0 : s[f].type) === ($ ? m.j.LIVE : m.j.PREMATCH));
                    return (0, g.jsxs)(p.a, {
                        "data-testid": "odd",
                        size: i,
                        onClick: n ? l.hidePopover : e => {
                            e.stopPropagation(), T && T !== 1 / 0 && (w || (l.value.includes(f) ? l.onChange(f) : l.onChange(f, T)))
                        },
                        handicap: !!b || (0, _.F)() && !!x || l.showHandicaps,
                        checked: l.value.includes(f),
                        style: y,
                        $colCount: l.marketColCount,
                        whiteText: l.whiteText,
                        ref: t,
                        disabled: !!w,
                        children: [b && (0, g.jsx)(p.$D, {
                            className: "handicap",
                            fullName: C,
                            children: b
                        }), ((0, _.F)() || l.showHandicaps) && (0, g.jsxs)(p.$D, {
                            className: "handicap",
                            fullName: C,
                            whiteText: l.whiteText,
                            children: [(N && N.includes("Handicap") ? S : x) || "", "number" === typeof j && ` (${j})`]
                        }), (0, g.jsxs)(p.Iv, {
                            whiteText: l.whiteText,
                            oddTextColor: E,
                            className: "odd__coeficient",
                            children: [G && (0, g.jsx)(v.GlobalIcon, {
                                lib: "generic",
                                name: "boostedOdds",
                                theme: "colored",
                                size: 16,
                                keepInCache: !0,
                                style: {
                                    marginRight: 4
                                },
                                skeleton: !0
                            }), w ? (0, g.jsx)(v.GlobalIcon, {
                                lib: "generic",
                                name: "lock",
                                theme: "default",
                                size: 11,
                                keepInCache: !0,
                                className: "isBlocked-odd"
                            }) : (0, u.C)(T, I), P && (0, g.jsx)(r.R, {
                                coefficient: +T,
                                prevCoefficient: +(P || 0)
                            })]
                        })]
                    })
                })),
                x = (0, s.memo)((e => {
                    var t, a, r;
                    let {
                        parent: d,
                        value: c,
                        coeficient: m,
                        oddFormat: p,
                        name: u,
                        base: v,
                        marketType: h,
                        type1: x,
                        handicap: f,
                        fullName: y,
                        gameId: w,
                        noBoosted: C,
                        size: N,
                        style: S,
                        isBlocked: j,
                        isLive: A,
                        oddTextColor: k
                    } = e;
                    const T = (0, s.useMemo)((() => {
                            var e, t;
                            return Boolean((null === (e = d.popover) || void 0 === e ? void 0 : e.id) && (null === (t = d.popover) || void 0 === t ? void 0 : t.id) === c)
                        }), [null === (t = d.popover) || void 0 === t ? void 0 : t.id, c]),
                        {
                            buttonRef: I,
                            buttonPosition: $
                        } = (0, n.K)();
                    return null !== d && void 0 !== d && null !== (a = d.popover) && void 0 !== a && a.validateRecaptcha && T ? (0, g.jsxs)(g.Fragment, {
                        children: [(0, g.jsx)(l.r, { ...d.popover || {}
                        }), (0, g.jsx)(b, {
                            oddFormat: p,
                            gameId: w,
                            coeficient: m,
                            value: c,
                            size: N,
                            parent: d,
                            visible: T,
                            style: S,
                            noBoosted: C,
                            ref: I,
                            name: u,
                            base: v,
                            fullName: y,
                            handicap: f,
                            isBlocked: j,
                            type1: x,
                            marketType: h,
                            isLive: A,
                            oddTextColor: k
                        })]
                    }) : (0, g.jsx)(o.default, {
                        content: (0, g.jsx)(l.r, { ...d.popover || {}
                        }),
                        placement: $,
                        trigger: "click",
                        visible: T,
                        onVisibleChange: e => !e && d.hidePopover(),
                        overlayClassName: (0, i.A)(["quick-bet-confirmation-popover", {
                            "quick-bet-confirmation-popover-right": (0, _.F)() && "topRight" === $,
                            "quick-bet-confirmation-popover-hide": null === (r = d.popover) || void 0 === r ? void 0 : r.validateRecaptcha
                        }]),
                        destroyTooltipOnHide: !0,
                        ...(0, _.F)() ? {
                            getPopupContainer: () => document.querySelector(".single-game-markets") || document.querySelector(".markets__body-container") || document.body
                        } : {},
                        children: (0, g.jsx)(b, {
                            oddFormat: p,
                            gameId: w,
                            coeficient: m,
                            value: c,
                            size: N,
                            parent: d,
                            visible: T,
                            style: S,
                            noBoosted: C,
                            ref: I,
                            name: u,
                            base: v,
                            fullName: y,
                            handicap: f,
                            isBlocked: j,
                            type1: x,
                            marketType: h,
                            oddTextColor: k
                        })
                    })
                }))
        },
        831018: (e, t, a) => {
            a.d(t, {
                h: () => v
            });
            var o = a(365043),
                s = a(507712),
                i = a(273549),
                n = a(777619),
                l = a(119432),
                r = a(390125),
                d = a(143166),
                c = a(242828),
                m = a(714368),
                p = a(570579);
            const u = ["CorrectScore", "SetCorrectScore", "GameCorrectScore"],
                v = (0, o.memo)((e => {
                    const t = (0, s.d4)(i.RT),
                        a = (0, o.useMemo)((() => {
                            var t;
                            return null === (t = e.marketType) || void 0 === t ? void 0 : t.includes("CorrectScore")
                        }), [e.marketType]),
                        v = (0, o.useMemo)((() => u.includes(e.marketType || "")), [e.marketType]),
                        h = (0, o.useMemo)((() => e.size || "default"), [e.size]),
                        _ = (0, o.useMemo)((() => a ? v ? e.marketColCount : 3 : e.marketColCount), [a, v, e.marketColCount]),
                        g = (0, o.useMemo)((() => {
                            let t;
                            if (a) {
                                var o;
                                let a;
                                a = e.isCorrectScoreOrdered ? e.options : e.options && (0, l.$)(e.options), t = null === (o = a) || void 0 === o ? void 0 : o.filter((e => !v || !!e))
                            } else t = e.options;
                            return t
                        }), [e.options, e.isCorrectScoreOrdered, a, v]),
                        b = Math.ceil(((null === g || void 0 === g ? void 0 : g.length) || 1) / (_ || 1)) * (_ || 1) - ((null === g || void 0 === g ? void 0 : g.length) || 1);
                    return null !== g && void 0 !== g && g.length ? (0, p.jsxs)(p.Fragment, {
                        children: [g.map(((a, o) => a ? (0, p.jsx)(d.w, {
                            size: h,
                            oddFormat: t,
                            noBoosted: e.noBoosted,
                            gameId: e.gameId || "",
                            fullName: e.fullName,
                            isBlocked: e.isBlocked,
                            isLive: e.isLive,
                            parent: { ...e,
                                marketColCount: _
                            },
                            ...a,
                            style: e.style,
                            oddTextColor: e.oddTextColor
                        }, a.value) : (0, p.jsx)(n.a, {
                            size: h,
                            $colCount: _,
                            disabled: !0,
                            children: "-"
                        }, o))), (0, c.K)(b).map((e => (0, p.jsx)(m.f, {
                            emptyOddStyle: !0
                        }, e)))]
                    }) : (0, p.jsx)(r.i, {
                        colorVariables: e.colorVariables,
                        size: h
                    })
                }))
        },
        777619: (e, t, a) => {
            a.d(t, {
                $D: () => i,
                Iv: () => n,
                a: () => l
            });
            var o = a(294574),
                s = a(55418);
            const i = o.Ay.span.withConfig({
                    displayName: "style__Handicap",
                    componentId: "sc-3ucvic-0"
                })(["color:var(--v3-", ");font-weight:300;font-size:12px;line-height:16px;text-align:left;padding-right:2px;word-break:break-word;direction:ltr;", " ", ""], (e => {
                    let {
                        whiteText: t
                    } = e;
                    return t ? "white" : "text-color"
                }), (e => {
                    let {
                        style: t
                    } = e;
                    return t && `\n     ${t}\n    `
                }), (e => {
                    let {
                        fullName: t
                    } = e;
                    return !t && "\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;"
                })),
                n = o.Ay.span.withConfig({
                    displayName: "style__Coeficient",
                    componentId: "sc-3ucvic-1"
                })(["color:var( --v3-", " );position:relative;font-weight:600;font-size:12px;line-height:16px;display:flex;white-space:nowrap;direction:ltr;align-items:center;"], (e => {
                    let {
                        whiteText: t,
                        oddTextColor: a
                    } = e;
                    return a || (t ? "white" : "text-color")
                })),
                l = o.Ay.button.withConfig({
                    displayName: "style__RadioButton",
                    componentId: "sc-3ucvic-2"
                })(["font-size:12px;min-height:32px;padding:7px 8px;border-radius:6px;display:flex;box-sizing:border-box;flex:1;width:auto !important;margin:0 2px;flex-direction:row;align-items:center;justify-content:", ";cursor:pointer;overflow:hidden;cursor:", ";&:focus-within{box-shadow:none;}&:not(:first-child):before{display:none;}", " ", " background-color:transparent;border:1px solid ", ";", " ", " ", " ", ""], (e => {
                    let {
                        handicap: t
                    } = e;
                    return t ? "space-between" : "center"
                }), (e => {
                    let {
                        disabled: t
                    } = e;
                    return t ? "default" : "pointer"
                }), (e => {
                    let {
                        $colCount: t
                    } = e;
                    return t && `\n    max-width: ${100/t}%;\n    min-width: ${Math.floor(100/t)-2}%;\n    &:last-child:not(:nth-child(${t}n)) {\n      max-width: 100%;\n    }\n  `
                }), (e => {
                    let {
                        checked: t,
                        whiteText: a,
                        disabled: o
                    } = e;
                    return !(0, s.F)() && !t && !a && !o && "\n    &:hover{\n      background-color: var(--v3-black-0);\n      border: 1px solid var(--v3-primary-5) !important;\n      box-shadow: 0px 2px 4px -1px rgba(82, 91, 255, 0.08);\n    }\n  "
                }), (e => {
                    let {
                        whiteText: t
                    } = e;
                    return t ? "var(--v3-black-15-fixed)" : "var(--v3-black-15)"
                }), (e => {
                    let {
                        whiteText: t
                    } = e;
                    return t && " \n      &:hover{\n        border: 1px solid var(--v3-primary-5);\n        box-shadow: 0px 2px 4px -1px rgba(82, 91, 255, 0.08);\n      }\n    "
                }), (e => {
                    let {
                        checked: t
                    } = e;
                    return !!t && ` \n      background-color: var(--v3-primary-6) !important;\n      border: 1px solid var(--v3-primary-6) !important;\n      ${n}, \n      ${i} {\n        color: var(--v3-color-on-primary) !important;\n      }\n    `
                }), (e => {
                    let {
                        size: t
                    } = e;
                    return "large" === t && "\n      height: 44px;\n    "
                }), (e => {
                    let {
                        style: t
                    } = e;
                    return t && `\n     ${t}\n    `
                }))
        },
        241123: (e, t, a) => {
            a.d(t, {
                r: () => A
            });
            var o = a(365043),
                s = a(777196),
                i = a(870905),
                n = a(507712),
                l = a(464418),
                r = a(273549),
                d = a(80489),
                c = a(841591),
                m = a(735905),
                p = a(294574),
                u = a(55418);
            const v = p.Ay.div.withConfig({
                    displayName: "ConfirmationPopoverstyled__ConfirmationPopoverStyled",
                    componentId: "sc-1m4kg8u-0"
                })(["width:", ";padding:4px 0;"], (0, u.F)() ? "264px" : "328px"),
                h = p.Ay.div.withConfig({
                    displayName: "ConfirmationPopoverstyled__MainSectionStyled",
                    componentId: "sc-1m4kg8u-1"
                })(["display:flex;align-items:center;padding-bottom:16px;"]),
                _ = p.Ay.div.withConfig({
                    displayName: "ConfirmationPopoverstyled__MainSectionIconStyled",
                    componentId: "sc-1m4kg8u-2"
                })(["width:68px;min-width:68px;height:68px;border-radius:50%;display:flex;align-items:center;justify-content:center;background-color:var(--v3-black-4);& > div{width:48px;height:48px;border-radius:50%;display:flex;align-items:center;justify-content:center;background-color:var(--v3-black-6);& path{fill:var(--v3-primary-6);}}"]),
                g = p.Ay.div.withConfig({
                    displayName: "ConfirmationPopoverstyled__MainSectionWrapperStyled",
                    componentId: "sc-1m4kg8u-3"
                })(["width:100%;padding-left:8px;"]),
                b = p.Ay.div.withConfig({
                    displayName: "ConfirmationPopoverstyled__MainSectionTitleStyled",
                    componentId: "sc-1m4kg8u-4"
                })(["font-weight:600;font-size:16px;line-height:24px;color:var(--v3-text-color);padding-bottom:4px;"]),
                x = p.Ay.div.withConfig({
                    displayName: "ConfirmationPopoverstyled__MainSectionMessageStyled",
                    componentId: "sc-1m4kg8u-5"
                })(["font-weight:normal;font-size:14px;line-height:20px;color:var(--v3-text-color-secondary);"]),
                f = p.Ay.div.withConfig({
                    displayName: "ConfirmationPopoverstyled__CheckboxSectionWrapperStyled",
                    componentId: "sc-1m4kg8u-6"
                })(["padding:16px 0;border-top:1px solid var(--v3-black-6);"]),
                y = p.Ay.div.withConfig({
                    displayName: "ConfirmationPopoverstyled__CheckboxSectionStyled",
                    componentId: "sc-1m4kg8u-7"
                })(["display:flex;align-items:center;justify-content:flex-start;cursor:pointer;"]),
                w = p.Ay.div.withConfig({
                    displayName: "ConfirmationPopoverstyled__ButtonsSectionStyled",
                    componentId: "sc-1m4kg8u-8"
                })(["display:flex;justify-content:space-between;align-items:center;"]),
                C = p.Ay.div.withConfig({
                    displayName: "ConfirmationPopoverstyled__ButtonWrapperStyled",
                    componentId: "sc-1m4kg8u-9"
                })(["width:calc(50% - 4px);"]);
            var N = a(989618),
                S = a(570579);
            const {
                Recaptcha: j
            } = (0, N.R)((() => Promise.all([a.e(94574), a.e(90440), a.e(41591), a.e(56982)]).then(a.bind(a, 798923)))), A = (0, o.memo)((e => {
                let {
                    onCancel: t,
                    onConfirm: a,
                    validateRecaptcha: p,
                    selectedEvents: u
                } = e;
                const N = (0, n.wA)(),
                    A = (0, n.d4)(r.fX),
                    k = (0, n.d4)(c.Xb),
                    [T, I] = (0, o.useState)(!1),
                    {
                        t: $
                    } = (0, i.B)(),
                    E = (0, o.useCallback)((e => {
                        null === e || void 0 === e || e.stopPropagation(), k ? I(!0) : null === a || void 0 === a || a()
                    }), [k]);
                return (0, o.useEffect)((() => {
                    p && I(!0)
                }), [p, u]), (0, S.jsxs)(S.Fragment, {
                    children: [!p && (0, S.jsxs)(v, {
                        children: [(0, S.jsxs)(h, {
                            children: [(0, S.jsx)(_, {
                                children: (0, S.jsx)("div", {
                                    children: (0, S.jsx)(m.GlobalIcon, {
                                        lib: "generic",
                                        name: "infoOutlined",
                                        theme: "default",
                                        size: 30
                                    })
                                })
                            }), (0, S.jsxs)(g, {
                                children: [(0, S.jsx)(b, {
                                    children: $("betslip.howToBet")
                                }), (0, S.jsx)(x, {
                                    children: $("betslip.howToBetMessage")
                                })]
                            })]
                        }), (0, S.jsx)(f, {
                            children: (0, S.jsx)(y, {
                                onClick: e => {
                                    e.stopPropagation(), N((0, l.XS)())
                                },
                                children: (0, S.jsx)(s.Checkbox, {
                                    checked: !A,
                                    children: $("betslip.dontShowMessage")
                                })
                            })
                        }), (0, S.jsxs)(w, {
                            children: [(0, S.jsx)(C, {
                                children: (0, S.jsx)(d.$, {
                                    fullwidth: !0,
                                    type: "default",
                                    size: "large",
                                    onClick: t,
                                    children: $("account.cancel")
                                })
                            }), (0, S.jsx)(C, {
                                children: (0, S.jsx)(d.$, {
                                    fullwidth: !0,
                                    type: "primary",
                                    size: "large",
                                    onClick: E,
                                    children: $("betslip.betNow")
                                })
                            })]
                        })]
                    }), k && (0, S.jsx)(o.Suspense, {
                        children: (0, S.jsx)(j, {
                            action: "do_bet",
                            onSetRecaptchaToken: () => {
                                null === a || void 0 === a || a(), I(!1)
                            },
                            shouldValidate: T
                        })
                    })]
                })
            }))
        },
        541320: (e, t, a) => {
            a.d(t, {
                Q7: () => r,
                Sn: () => l,
                Y9: () => n,
                uY: () => i,
                z4: () => d
            });
            var o = a(294574);
            const s = {
                    D: "var(--v3-yellow-7)",
                    W: "var(--v3-cyan-base)",
                    L: "var(--v3-red-base)"
                },
                i = o.Ay.div.withConfig({
                    displayName: "style__StatisticsBanner",
                    componentId: "sc-5li1ba-0"
                })(["", " background-blend-mode:multiply;background-size:cover;height:140px;margin:8px 8px;border-radius:4px;color:var(--v3-black-0);padding:12px;"], (e => !e.$loading && `background: url(${e.bgImageSrc}) rgba(0, 0, 0, 0.5) no-repeat center center;`)),
                n = o.Ay.div.withConfig({
                    displayName: "style__Header",
                    componentId: "sc-5li1ba-1"
                })(["display:flex;justify-content:space-between;font-size:12px;color:var(--v3-black-15);"]),
                l = o.Ay.div.withConfig({
                    displayName: "style__GameWrapper",
                    componentId: "sc-5li1ba-2"
                })(["color:var(--v3-black-0);display:flex;justify-content:space-between;margin-top:", ";align-items:center;"], (e => e.fullHeight ? "2px" : "12px")),
                r = o.Ay.span.withConfig({
                    displayName: "style__Result",
                    componentId: "sc-5li1ba-3"
                })(["color:", ";background-color:var(--v3-black-100);border-radius:2px;width:16px;height:16px;text-align:center;font-size:11px;margin:1px;display:flex;align-items:center;justify-content:center;"], (e => s[e.resultKey])),
                d = o.Ay.p.withConfig({
                    displayName: "style__GameInfo",
                    componentId: "sc-5li1ba-4"
                })(["font-size:11px;color:var(--v3-white);padding-left:13px;margin-bottom:5px;"])
        },
        716006: (e, t, a) => {
            a.d(t, {
                L: () => s
            });
            var o = a(570579);
            const s = e => {
                let {
                    children: t,
                    url: a,
                    dataTestId: s,
                    className: i
                } = e;
                return (0, o.jsx)("a", {
                    href: a,
                    onClickCapture: e => {
                        e.preventDefault()
                    },
                    "data-testid": s,
                    className: i,
                    children: t
                })
            }
        },
        735947: (e, t, a) => {
            a.d(t, {
                C: () => v
            });
            var o = a(365043),
                s = a(870905),
                i = a(889181),
                n = a(294574);
            const l = n.Ay.span.withConfig({
                    displayName: "style__Logo",
                    componentId: "sc-1pz2fdq-0"
                })(["color:var(--v3-text-color);", " border-radius:100%;display:flex;justify-content:center;align-items:center;"], (e => !e.hasImage && "background: var(--v3-black-6);")),
                r = n.Ay.span.withConfig({
                    displayName: "style__Name",
                    componentId: "sc-1pz2fdq-1"
                })(["line-height:16px;height:20px;display:flex;align-items:center;color:var(--v3-", ");"], (e => e.whiteText ? "white" : "text-color")),
                d = n.Ay.span.withConfig({
                    displayName: "style__Container",
                    componentId: "sc-1pz2fdq-2"
                })(["flex-direction:", ";display:inline-flex;align-items:center;flex:1;", ";"], (e => e.reverse ? "row-reverse" : "row"), (e => {
                    const t = e.reverse ? "right" : "left";
                    switch (e.size) {
                        case "lg":
                            return `\n        ${l} {\n          width: 36px;\n          height: 36px;\n          font-size: 10px;\n          line-height: 10px;\n        }\n        ${r} {\n          font-size: 16px;\n          margin-${t}: 11px;\n          font-weight: 400;\n        }\n      `;
                        case "md":
                            return `\n        ${l} {\n          width: 20px;\n          min-width: 20px;\n          height: 20px;\n          font-size: 11px;\n          line-height: 11px;\n        }\n        ${r} {\n          font-size: 12px;\n          margin-${t}: 8px;\n          font-weight: 400;\n        }\n      `;
                        default:
                            return `\n        ${l} {\n          width: 18px;\n          height: 18px;  \n          font-size: 11px;\n          line-height: 11px;\n        }\n        ${r} {\n          font-size: 12px;\n          margin-${t}: 4px;\n        }\n      `
                    }
                }));
            var c = a(829782),
                m = a(541320),
                p = a(179177),
                u = a(570579);
            p.Ay.IS_RTL && a.e(11347).then(a.bind(a, 411347));
            const v = e => {
                var t, a, n, p, v, h;
                const [_, g] = (0, o.useState)(!1), {
                    t: b
                } = (0, s.B)();
                return (0, u.jsxs)(d, {
                    reverse: e.reverse || !1,
                    size: e.size || "sm",
                    children: [e.logo && (0, u.jsx)(l, {
                        hasImage: _,
                        className: (0, i.A)(["logo-simple", {
                            [e.className || ""]: e.className
                        }]),
                        children: (0, u.jsx)(c.L, {
                            teamId: e.teamId,
                            size: e.dontShowTitle ? "md" : e.size || "sm",
                            setHasImage: g,
                            competition: e.competition,
                            children: (0, u.jsx)("span", {
                                className: "teamNameAsIcon",
                                children: e.name ? String(e.name).substr(0, 2).toUpperCase() : "-"
                            })
                        })
                    }), (0, u.jsxs)("div", {
                        className: "comp__teamName__wrapper",
                        children: [!e.dontShowTitle && (0, u.jsx)(r, {
                            className: "comp__team-name",
                            whiteText: e.whiteText,
                            style: e.nameStyle,
                            children: e.name
                        }), ((null === (t = e.entry) || void 0 === t ? void 0 : t.Position) || (null === (a = e.entry) || void 0 === a ? void 0 : a.Points)) && (0, u.jsx)(m.z4, {
                            children: `${(null===(n=e.entry)||void 0===n?void 0:n.Position)&&`${b("sportsbook.position")}: ${null===(p=e.entry)||void 0===p?void 0:p.Position} |`} ${(null===(v=e.entry)||void 0===v?void 0:v.Points)&&`${b("sportsbook.point(s)")}: ${null===(h=e.entry)||void 0===h?void 0:h.Points}`}`
                        })]
                    })]
                })
            }
        },
        977667: (e, t, a) => {
            a.d(t, {
                l: () => y
            });
            var o = a(365043),
                s = a(507712),
                i = a(995392),
                n = a(464418),
                l = a(880279),
                r = a(273549),
                d = a(679559),
                c = a(462956),
                m = a(870905),
                p = a(123213),
                u = a(144891),
                v = a(200815),
                h = a(429634),
                _ = a(55418),
                g = a(320308),
                b = a(810795),
                x = a(179177),
                f = a(556785);
            const y = (e, t, a) => {
                const [y, w] = (0, o.useState)(null), C = (0, s.wA)(), N = (0, s.d4)(d.eP), S = (0, i.W6)(), {
                    t: j
                } = (0, m.B)(), A = (0, s.d4)(r.co), k = (0, s.d4)(r.fX), T = (0, s.d4)(r.hS), I = (0, s.d4)(r._3), $ = (0, s.d4)(c.gU), E = (0, s.d4)(r.hh), B = (0, s.d4)(r.A), P = (0, s.d4)(r.oc), G = (0, b.R)(), R = (0, o.useCallback)((e => {
                    if (!(0, _.F)()) {
                        document.querySelectorAll("[data-popover-parent]").forEach((t => {
                            t instanceof HTMLElement && (t.style.overflow = "enable" === e ? "auto" : "hidden")
                        }))
                    }
                }), []), O = (0, o.useCallback)((t => {
                    if (!N) return void G();
                    const a = (0, _.F)() ? document.body : document.getElementById("betslip-wrapper");
                    if (t && T) {
                        var o;
                        const s = null === (o = B[+t.id]) || void 0 === o ? void 0 : o.isActive,
                            i = P.some((e => e === +t.id));
                        C((0, n.Pp)("increase")), (0, l.rK)({
                            amount: Number(T),
                            bets: [{
                                event_id: Number(t.id),
                                price: Number(t.price)
                            }],
                            type: u.Kn.SINGLE,
                            mode: s ? 3 : i || x.Ay.SUPER_BET_DEFAULT_ON ? -1 : Number(JSON.parse(p.A.getItem((0, f.U)("betslip", "ACCEPT_BET"))).value)
                        }, (t => {
                            const {
                                result: a
                            } = t;
                            if ("OK" !== a && 1800 !== a) return (0, g.$)(j("betslip.wentWrong")), void C((0, n.Pp)("decrease"));
                            C((0, n.Pp)("decrease")), e([]), C((0, n.Jb)())
                        }), (() => {
                            C((0, n.Pp)("decrease")), e([])
                        }), (() => {}), a)
                    }
                }), [N, S, T, e, C, j]), M = (0, o.useCallback)(((t, o) => {
                    const s = e => {
                        null === e || void 0 === e || e.stopPropagation(), O({
                            id: t,
                            price: o
                        }), k && (w(null), R("enable"))
                    };
                    if (k && N) {
                        if (Number(T)) {
                            R("disable");
                            const a = t => {
                                null === t || void 0 === t || t.stopPropagation(), e([]), w(null), R("enable")
                            };
                            w({
                                id: t,
                                onCancel: a,
                                onConfirm: s
                            })
                        }
                    } else w({
                        id: t,
                        onCancel: () => {},
                        onConfirm: s,
                        validateRecaptcha: !0,
                        selectedEvents: a
                    })
                }), [k, T, O, N, R, j, a]), H = (0, o.useCallback)((() => {
                    k && (e([]), w(null), R("enable"))
                }), [R, k]), L = (0, o.useCallback)((function(o, s) {
                    let i = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
                        l = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
                    if (!A || null !== I && void 0 !== I && I.active || T) {
                        if (!a.includes(o) || i || l)
                            if (!A || null !== I && void 0 !== I && I.active) {
                                if (null !== $ && void 0 !== $ && $.max_selections_in_multiple_bet && E.length >= (null === $ || void 0 === $ ? void 0 : $.max_selections_in_multiple_bet)) return void(0, h.h)(j("betslip.eventsMaxCountMessage").replace("{%eventsMaxCount%}", `${null===$||void 0===$?void 0:$.max_selections_in_multiple_bet}`));
                                t(o, i)
                            } else k ? M(o, s) : O({
                                id: o,
                                price: s
                            });
                        else C((0, n.tR)(!1)), (0, v.qV)(o), k && (w(null), R("enable"));
                        e((e => e.includes(o) ? e.filter((e => e !== o)) : [...e, o]))
                    } else {
                        var r;
                        e([]), (0, g.$)(j("betslip.noStake")), null === (r = document.getElementById("quick-bet-input-stake")) || void 0 === r || r.focus()
                    }
                }), [k, A, T, I, $, E, a, O, t, M, j]);
                return (0, o.useMemo)((() => ({
                    oddChangeHandler: L,
                    popover: y,
                    hidePopover: H
                })), [L, y, H])
            }
        },
        84957: (e, t, a) => {
            a.d(t, {
                D: () => o
            });
            let o = function(e) {
                return e.lose = "lose", e.draw = "draw", e.win = "win", e
            }({})
        },
        200009: (e, t, a) => {
            a.d(t, {
                w: () => _
            });
            a(50999);
            var o = a(69661),
                s = a(365043),
                i = a(889181),
                n = a(735905),
                l = a(179177),
                r = a(490440),
                d = a(55418),
                c = a(989618),
                m = a(119847),
                p = a(341225),
                u = a(365506),
                v = a(570579);
            const {
                MatchStatisticPopover: h
            } = (0, c.R)((() => Promise.all([a.e(87161), a.e(34426), a.e(55608), a.e(84107), a.e(81927), a.e(35834), a.e(70136), a.e(28151), a.e(90440), a.e(35905), a.e(58073), a.e(42828), a.e(47505), a.e(29782), a.e(65310), a.e(96843), a.e(55459)]).then(a.bind(a, 603485)))), _ = (0, s.memo)((e => {
                let {
                    matchId: t,
                    showStatisticInPopover: a = !0,
                    size: c,
                    iconContainerSize: _,
                    className: g = ""
                } = e;
                const [b] = (0, s.useState)(`popover-trigger-${Math.floor(1e3*Math.random())}`), [x, f] = (0, s.useState)(null), {
                    mounted: y
                } = (0, r.q)();
                (0, s.useEffect)((() => {
                    if (a && !(0, d.F)() && y.current) {
                        const e = () => {
                            f((0, p.Lu)(b))
                        };
                        return e(), window.addEventListener("scroll", e), () => {
                            window.removeEventListener("scroll", e)
                        }
                    }
                }), [y.current]), (0, s.useEffect)((() => () => {
                    f(null)
                }), []);
                const w = (0, s.useCallback)((e => {
                        e.stopPropagation(), window.open(`${l.Ay.STATISTICS_URL}/#/${l.Ay.STATISTICS_LANG_PREFIX}/external/page/redirect/${t}`)
                    }), []),
                    C = (0, s.useMemo)((() => (0, v.jsx)(u.H, {
                        className: g,
                        iconContainerSize: _,
                        icon: (0, v.jsx)(n.GlobalIcon, {
                            lib: "generic",
                            name: "statistics",
                            theme: "default",
                            className: (0, i.A)(["match-statistic", {
                                "match-statistic-mobile": (0, d.F)()
                            }]),
                            onClick: w,
                            size: c,
                            keepInCache: !0,
                            skeleton: !0,
                            "data-popover-trigger": b
                        })
                    })), []);
                return a && !(0, d.F)() && x ? (0, v.jsx)(o.default, {
                    destroyTooltipOnHide: !0,
                    trigger: "hover",
                    overlayClassName: "match-statistic-popover",
                    placement: x,
                    content: (0, v.jsx)(s.Suspense, {
                        fallback: (0, v.jsx)(m.u, {}),
                        children: (0, v.jsx)(h, {
                            matchId: t
                        })
                    }),
                    children: C
                }) : C
            }))
        },
        119847: (e, t, a) => {
            a.d(t, {
                u: () => p
            });
            var o = a(179177),
                s = (a(270757), a(694227)),
                i = a(570579);
            const n = () => (0, i.jsxs)("div", {
                className: "match-stat-wrapper__tab-row",
                children: [(0, i.jsx)("div", {
                    className: "match-stat-col match-stat-col-sm",
                    children: (0, i.jsx)(s.A.Button, {
                        active: !0,
                        className: "match-stat-wrapper__tab-row__skeleton-lg"
                    })
                }), (0, i.jsx)("div", {
                    className: "match-stat-col match-stat-col-lg match-stat-spacer",
                    children: (0, i.jsx)(s.A.Button, {
                        active: !0,
                        className: "match-stat-wrapper__tab-row__skeleton-lg"
                    })
                }), (0, i.jsx)("div", {
                    className: "match-stat-col match-stat-col-lg match-stat-spacer",
                    children: (0, i.jsx)(s.A.Button, {
                        active: !0,
                        className: "match-stat-wrapper__tab-row__skeleton-lg"
                    })
                })]
            });
            var l = a(242828);
            const r = () => (0, i.jsxs)(i.Fragment, {
                    children: [(0, i.jsx)("div", {
                        className: "match-stat-wrapper__tab-row__title__icon",
                        children: (0, i.jsx)(s.A.Button, {
                            active: !0,
                            className: "match-stat-wrapper__tab-row__skeleton-circle"
                        })
                    }), (0, i.jsx)(s.A.Button, {
                        active: !0,
                        className: "match-stat-wrapper__tab-row__skeleton-lg"
                    })]
                }),
                d = () => (0, i.jsxs)(i.Fragment, {
                    children: [(0, i.jsxs)("div", {
                        className: "match-stat-wrapper__tab-row",
                        children: [(0, i.jsx)("div", {
                            className: "match-stat-col match-stat-col-sm match-stat-team-tab",
                            children: (0, i.jsx)(s.A.Button, {
                                active: !0,
                                className: "match-stat-wrapper__tab-row__skeleton-lg"
                            })
                        }), (0, i.jsx)("div", {
                            className: "match-stat-col match-stat-col-lg"
                        }), (0, i.jsx)("div", {
                            className: "match-stat-col match-stat-col-lg",
                            children: (0, l.K)(5).map((e => (0, i.jsx)("div", {
                                className: "match-stat-cube",
                                children: (0, i.jsx)(s.A.Button, {
                                    active: !0,
                                    className: "match-stat-wrapper__tab-row__skeleton-sm"
                                })
                            }, e)))
                        })]
                    }), (0, l.K)(2).map((e => (0, i.jsxs)("div", {
                        className: "match-stat-wrapper__tab-row match-stat-wrapper__tab-result",
                        children: [(0, i.jsx)("div", {
                            className: "match-stat-col match-stat-col-sm",
                            children: (0, i.jsx)(r, {})
                        }), (0, i.jsx)("div", {
                            className: "match-stat-col match-stat-col-lg",
                            children: (0, l.K)(5).map((e => (0, i.jsx)("div", {
                                className: "match-stat-cube",
                                children: (0, i.jsx)(s.A.Button, {
                                    active: !0,
                                    className: "match-stat-wrapper__tab-row__skeleton-sm"
                                })
                            }, e)))
                        }), (0, i.jsxs)("div", {
                            className: "match-stat-col match-stat-col-lg",
                            children: [(0, l.K)(3).map((e => (0, i.jsx)("div", {
                                className: "match-stat-cube",
                                children: (0, i.jsx)(s.A.Button, {
                                    active: !0,
                                    className: "match-stat-wrapper__tab-row__skeleton-sm"
                                })
                            }, e))), (0, i.jsx)("div", {
                                className: "match-stat-cube",
                                children: (0, i.jsx)("div", {
                                    className: "match-stat-result match-stat-result-bordered",
                                    children: (0, i.jsx)(s.A.Button, {
                                        active: !0,
                                        className: "match-stat-wrapper__tab-row__skeleton-sm"
                                    })
                                })
                            }), 0 === e && (0, i.jsx)("div", {
                                className: "match-stat-cube",
                                children: (0, i.jsx)("div", {
                                    className: "match-stat-result match-stat-result-bordered match-stat-result-extra",
                                    children: (0, i.jsx)(s.A.Button, {
                                        active: !0,
                                        className: "match-stat-wrapper__tab-row__skeleton-sm"
                                    })
                                })
                            })]
                        })]
                    }, e)))]
                }),
                c = () => (0, i.jsxs)(i.Fragment, {
                    children: [(0, i.jsx)("div", {
                        className: "match-stat-wrapper__tab-row",
                        children: (0, i.jsx)("div", {
                            className: "match-stat-col",
                            children: (0, i.jsx)(r, {})
                        })
                    }), (0, i.jsxs)("div", {
                        className: "match-stat-wrapper__tab-row",
                        children: [(0, i.jsx)("div", {
                            className: "match-stat-col match-stat-col-sm match-stat-team-tab",
                            children: (0, i.jsx)(s.A.Button, {
                                active: !0,
                                className: "match-stat-wrapper__tab-row__skeleton-lg"
                            })
                        }), (0, i.jsx)("div", {
                            className: "match-stat-col match-stat-col-lg",
                            children: (0, l.K)(3).map((e => (0, i.jsx)("div", {
                                className: "match-stat-cube",
                                children: (0, i.jsx)(s.A.Button, {
                                    active: !0,
                                    className: "match-stat-wrapper__tab-row__skeleton-sm"
                                })
                            }, e)))
                        }), (0, i.jsx)("div", {
                            className: "match-stat-col match-stat-col-lg match-stat-spacer",
                            children: (0, i.jsx)(s.A.Button, {
                                active: !0,
                                className: "match-stat-wrapper__tab-row__skeleton-lg"
                            })
                        })]
                    }), (0, l.K)(2).map((e => (0, i.jsxs)("div", {
                        className: "match-stat-wrapper__tab-row match-stat-wrapper__tab-result",
                        children: [(0, i.jsx)("div", {
                            className: "match-stat-col match-stat-col-sm",
                            children: (0, i.jsx)(r, {})
                        }), (0, i.jsx)("div", {
                            className: "match-stat-col match-stat-col-lg",
                            children: (0, l.K)(3).map((e => (0, i.jsx)("div", {
                                className: "match-stat-cube",
                                children: (0, i.jsx)(s.A.Button, {
                                    active: !0,
                                    className: "match-stat-wrapper__tab-row__skeleton-sm"
                                })
                            }, e)))
                        }), (0, i.jsx)("div", {
                            className: "match-stat-col match-stat-col-lg match-stat-spacer",
                            children: (0, i.jsx)(s.A.Button, {
                                active: !0,
                                className: "match-stat-wrapper__tab-row__skeleton-lg"
                            })
                        })]
                    }, e)))]
                }),
                m = () => (0, i.jsxs)(i.Fragment, {
                    children: [(0, i.jsxs)("div", {
                        className: "match-stat-wrapper__tab-row",
                        children: [(0, i.jsx)("div", {
                            className: "match-stat-col match-stat-col-sm",
                            children: (0, i.jsx)(s.A.Button, {
                                active: !0,
                                className: "match-stat-wrapper__tab-row__skeleton-lg"
                            })
                        }), (0, i.jsx)("div", {
                            className: "match-stat-col match-stat-col-lg match-stat-spacer",
                            children: (0, i.jsx)(s.A.Button, {
                                active: !0,
                                className: "match-stat-wrapper__tab-row__skeleton-sm"
                            })
                        }), (0, i.jsx)("div", {
                            className: "match-stat-col match-stat-col-lg",
                            children: (0, l.K)(2).map((e => (0, i.jsx)("div", {
                                className: "match-stat-cube",
                                children: (0, i.jsx)(s.A.Button, {
                                    active: !0,
                                    className: "match-stat-wrapper__tab-row__skeleton-sm"
                                })
                            }, e)))
                        })]
                    }), (0, l.K)(2).map((e => (0, i.jsxs)("div", {
                        className: "match-stat-wrapper__tab-row match-stat-wrapper__tab-result",
                        children: [(0, i.jsx)("div", {
                            className: "match-stat-col match-stat-col-sm",
                            children: (0, i.jsx)(r, {})
                        }), (0, i.jsx)("div", {
                            className: "match-stat-col match-stat-col-lg",
                            children: (0, l.K)(5).map((e => (0, i.jsx)("div", {
                                className: "match-stat-cube",
                                children: (0, i.jsx)(s.A.Button, {
                                    active: !0,
                                    className: "match-stat-wrapper__tab-row__skeleton-sm"
                                })
                            }, e)))
                        }), (0, i.jsx)("div", {
                            className: "match-stat-col match-stat-col-lg",
                            children: (0, l.K)(2).map((e => (0, i.jsx)("div", {
                                className: "match-stat-cube",
                                children: (0, i.jsx)(s.A.Button, {
                                    active: !0,
                                    className: "match-stat-wrapper__tab-row__skeleton-sm"
                                })
                            }, e)))
                        })]
                    }, e)))]
                });
            a(781621);
            o.Ay.IS_RTL && a.e(63219).then(a.bind(a, 263219));
            const p = () => (0, i.jsxs)(i.Fragment, {
                children: [(0, i.jsx)(n, {}), (0, i.jsx)(d, {}), (0, i.jsx)(c, {}), (0, i.jsx)(m, {})]
            })
        },
        559178: (e, t, a) => {
            a.d(t, {
                R: () => l
            });
            var o = a(889181),
                s = a(365043),
                i = a(735905),
                n = a(570579);
            const l = e => {
                let {
                    coefficient: t,
                    prevCoefficient: a,
                    withBase: l,
                    isEvent: r
                } = e;
                const d = (0, s.useMemo)((() => t > a ? "up" : t < a ? "down" : ""), [t, a]);
                return (0, n.jsx)(i.GlobalIcon, {
                    lib: "generic",
                    name: "arrowDown",
                    theme: "default",
                    size: 5.2,
                    position: "absolute",
                    className: (0, o.A)(["odd__indicator", `odd__indicator-${d}`, {
                        "odd__indicator-withBase": l,
                        "odd__indicator-isEvent": r
                    }])
                })
            }
        },
        374134: (e, t, a) => {
            a.r(t), a.d(t, {
                CardView: () => $
            });
            var o = a(365043),
                s = a(889181),
                i = a(507712),
                n = a(860446),
                l = a.n(n),
                r = a(273549),
                d = a(980127),
                c = a(679559),
                m = a(482463),
                p = a(735905),
                u = a(735947),
                v = a(179177),
                h = a(200009),
                _ = a(947362),
                g = a(831018),
                b = a(977667),
                x = a(200815),
                f = a(432148),
                y = a(623184),
                w = a(623902),
                C = a(600940),
                N = (a(739448), a(570579));
            const S = e => {
                var t, a, n;
                let {
                    game: S,
                    currentSport: j,
                    competitionName: A,
                    sportName: k,
                    regionName: T,
                    onClick: I,
                    bgImg: $,
                    sportId: E,
                    isLive: B,
                    colorVariables: P
                } = e;
                const [G, R] = (0, o.useState)([]), O = (0, i.d4)(r.$b), M = (0, i.d4)(d.c), H = (0, i.d4)(c.eP), L = S.type ? 1 === S.type : B, z = (0, o.useMemo)((() => H && L ? S : (0, w.w)(S, S.competitionId)), [S, H, L]), F = (0, o.useMemo)((() => {
                    var e;
                    const t = (null === (e = Object.values(z.market)[0]) || void 0 === e ? void 0 : e.event) || {};
                    return (0, m.I)(Object.values(t)).map((e => ({
                        value: String(e.id),
                        coeficient: e.price
                    })))
                }), [z.market]), D = (0, o.useMemo)((() => {
                    var e;
                    return null !== (e = z.info) && void 0 !== e && e.additional_data ? (0, C.B4)(z.info.additional_data) : (0, C.NT)(z.info || {}, j)
                }), [null === (t = z.info) || void 0 === t ? void 0 : t.current_game_time, null === (a = z.info) || void 0 === a ? void 0 : a.current_game_state, null === (n = z.info) || void 0 === n ? void 0 : n.additional_data]), K = (0, o.useMemo)((() => z.start_ts ? l()(1e3 * z.start_ts).format(`${v.Ay.DT.time} | ${v.Ay.DT.longDate}`) : "-"), [S]);
                (0, o.useLayoutEffect)((() => {
                    null !== O && void 0 !== O && O.length && null !== F && void 0 !== F && F.length ? (R([]), F.forEach((e => {
                        O.findIndex((t => Number(t) === Number(e.value))) >= 0 && R((t => [...t, String(e.value)]))
                    }))) : R([])
                }), [O, F]);
                const {
                    oddChangeHandler: U,
                    popover: V,
                    hidePopover: W
                } = (0, b.l)(R, (e => {
                    var t, a, o, s;
                    const i = null === (t = Object.values(z.market)) || void 0 === t ? void 0 : t[0],
                        n = null === (a = i.event) || void 0 === a ? void 0 : a[e];
                    (0, x.Hc)({
                        sport_id: E,
                        marketType: (null === i || void 0 === i ? void 0 : i.type) || "",
                        market: i,
                        gameId: Number(z.id),
                        eventId: Number(e),
                        eventBase: null === n || void 0 === n ? void 0 : n.base,
                        team1: z.team1_name,
                        team2: z.team2_name || "",
                        coeficient: null === n || void 0 === n ? void 0 : n.price,
                        event_name: (null === n || void 0 === n ? void 0 : n.name) || "",
                        game_start_date: z.start_ts,
                        sport_index: j || (null === S || void 0 === S ? void 0 : S.sport_alias),
                        sport_name: k || "",
                        competition_name: A || "",
                        current_game_state: (null === (o = z.info) || void 0 === o ? void 0 : o.current_game_state) || "",
                        current_game_time: (null === (s = z.info) || void 0 === s ? void 0 : s.current_game_time) || "",
                        isLive: L,
                        region_name: T,
                        market_name: (null === i || void 0 === i ? void 0 : i.name) || "",
                        game_name: `${z.team1_name} ${z.team2_name?` - ${z.team2_name}`:""}`,
                        game_info: z.info,
                        express_id: (null === i || void 0 === i ? void 0 : i.prematch_express_id) || (null === i || void 0 === i ? void 0 : i.express_id)
                    }, !0)
                }), G);
                return (0, N.jsxs)("div", {
                    className: "selectedGameCard__contanier",
                    style: { ...P ? {
                            background: P.layerColor
                        } : {},
                        ...$ ? {
                            backgroundImage: `url(${$})`
                        } : {}
                    },
                    children: [(0, N.jsxs)("div", {
                        className: "selectedGameCard__header",
                        children: [(0, N.jsxs)("div", {
                            className: (0, s.A)(["selectedGameCard__header__competitions", {
                                selectedGameCard__header__competitions__bgImg: !!$
                            }]),
                            children: [(0, N.jsx)(p.GlobalIcon, {
                                lib: "sports",
                                size: 20,
                                name: z.sport_alias || k,
                                skeleton: !0
                            }), (0, N.jsx)("span", {
                                className: "selectedGameCard__header__competitions__name",
                                style: P && {
                                    color: P.infoTextColor
                                },
                                children: z.competitionName
                            })]
                        }), (0, N.jsxs)("div", {
                            className: "selectedGameCard__header__date",
                            children: [(0, N.jsxs)("div", {
                                style: P && {
                                    color: P.infoTextColor
                                },
                                className: (0, s.A)(["selectedGameCard__header__text", {
                                    selectedGameCard__header__text__bgImg: !!$
                                }]),
                                onClick: I,
                                children: [!!L && (0, N.jsx)(p.GlobalIcon, {
                                    lib: "generic",
                                    name: "dot",
                                    theme: "default",
                                    size: 6,
                                    skeleton: !0,
                                    color: "#FF4D4F",
                                    style: {
                                        marginRight: 4
                                    },
                                    className: "MatchCardInLine__live-dot-icon"
                                }), (0, y.kB)(!!L, j) && D, !L && K]
                            }), (0, N.jsxs)("div", {
                                className: "selectedGameCard__header__icon",
                                children: [v.Ay.STATISTICS_SWITCHER && z.is_stat_available && (0, N.jsx)(h.w, {
                                    size: 16,
                                    iconContainerSize: 20,
                                    matchId: z.id,
                                    showStatisticInPopover: !L,
                                    className: "selectedGameCard__statisticIcon"
                                }), (0, N.jsx)(_.h, {
                                    size: 16,
                                    iconContainerSize: 20,
                                    game: S,
                                    iconMargin: f.P ? "right" : "left"
                                })]
                            })]
                        })]
                    }), (0, N.jsxs)("div", {
                        className: "selectedGameCard__title",
                        onClick: I,
                        children: [(0, N.jsx)("div", {
                            className: "selectedGameCard__title__teamCaption__left",
                            children: (0, N.jsx)(u.C, {
                                size: "md",
                                logo: !0,
                                whiteText: !!$,
                                name: z.team1_name,
                                teamId: z.team1_id,
                                className: "selectedGameCard__title__logo",
                                nameStyle: P && {
                                    color: P.infoTextColor
                                }
                            })
                        }), (0, N.jsx)("div", {
                            className: "selectedGameCard__title__gameInfo",
                            children: (0, N.jsx)("span", {
                                className: "selectedGameCard__title__gameInfo__text",
                                children: L ? (0, N.jsxs)(N.Fragment, {
                                    children: [(0, N.jsx)("span", {
                                        className: (0, s.A)(["selectedGameCard__title__gameInfo__score", {
                                            "selectedGameCard__header__competitions__bgImg  selectedGameCard__title__gameInfo__score--bgImg": !!$
                                        }]),
                                        style: P && {
                                            color: P.oddTextColor,
                                            background: P.oddsBgColor,
                                            border: `1px solid ${P.oddBorderColor}`
                                        },
                                        children: z.info.score1 || "-"
                                    }), (0, N.jsx)("span", {
                                        className: (0, s.A)(["selectedGameCard__title__gameInfo__score", {
                                            "selectedGameCard__header__competitions__bgImg selectedGameCard__title__gameInfo__score--bgImg": !!$
                                        }]),
                                        style: P && {
                                            color: P.oddTextColor,
                                            background: P.oddsBgColor,
                                            border: `1px solid ${P.oddBorderColor}`
                                        },
                                        children: z.info.score2 || "-"
                                    })]
                                }) : (0, N.jsx)("span", {
                                    style: P && {
                                        color: P.oddTextColor,
                                        background: P.oddsBgColor,
                                        border: `1px solid ${P.oddBorderColor}`
                                    },
                                    className: (0, s.A)(["selectedGameCard__title__gameInfo__vs", {
                                        "selectedGameCard__header__competitions__bgImg selectedGameCard__title__gameInfo__vs--bgImg": !!$
                                    }]),
                                    children: "VS"
                                })
                            })
                        }), (0, N.jsx)("div", {
                            className: "selectedGameCard__title__teamCaption__right",
                            children: (0, N.jsx)(u.C, {
                                size: "md",
                                logo: !0,
                                whiteText: !!$,
                                name: z.team2_name,
                                teamId: z.team2_id,
                                className: "selectedGameCard__title__logo",
                                nameStyle: P && {
                                    color: P.infoTextColor
                                }
                            })
                        })]
                    }), (0, N.jsx)("div", {
                        className: "selectedGameCard__odds",
                        children: (0, N.jsx)(g.h, {
                            style: P && {
                                color: P.oddTextColor,
                                background: P.oddsBgColor,
                                border: `1px solid ${P.oddBorderColor}`
                            },
                            colorVariables: P,
                            value: G,
                            gameId: z.id,
                            isBlocked: z.is_blocked,
                            onChange: (e, t, a, o) => {
                                M || v.Ay.IS_BETSLIP_FLOATING_ENABLED || G.includes(e) || I(), U(e, Number(t), a, o)
                            },
                            isLive: L,
                            options: F,
                            whiteText: !!$,
                            oddTextColor: null === P || void 0 === P ? void 0 : P.oddTextColor,
                            popover: V,
                            hidePopover: W
                        })
                    })]
                })
            };
            var j = a(55418),
                A = a(902546),
                k = a(716006),
                T = a(516058),
                I = a(893662);
            a(81996);
            v.Ay.IS_RTL && a.e(95330).then(a.bind(a, 395330));
            const $ = (0, o.memo)((e => {
                let {
                    gameData: t,
                    sliderData: a,
                    gamesPerView: o,
                    showSportIcon: i = !1,
                    showCompetitionLogo: n = !1,
                    autoplayDelay: l,
                    colorVariables: r
                } = e;
                const d = null === a || void 0 === a ? void 0 : a.map(((e, t) => (0, N.jsx)("div", {
                    className: (0, s.A)(["selectedGames__container", {
                        "selectedGames__container--mobile": (0, j.F)()
                    }]),
                    children: e.map(((e, t) => {
                        var a, l, d;
                        const c = 1 === (null === (a = e.data) || void 0 === a ? void 0 : a.type) ? "liveEvents" : "prematch";
                        return e.data && (0, N.jsx)("div", {
                            className: (0, s.A)(["selectedGames__innerItem", {
                                "selectedGames__innerItem--mobile": (0, j.F)()
                            }]),
                            style: {
                                width: `calc(100% / ${o})`
                            },
                            children: (0, N.jsx)(k.L, {
                                url: `${1===e.data.type?null===(l=v.Ay.PAGE_URLS.live)||void 0===l?void 0:l.split(window.location.origin)[1]:null===(d=v.Ay.PAGE_URLS.prematch)||void 0===d?void 0:d.split(window.location.origin)[1]}/${v.Ay.SPORTSBOOK_MOUNT_PATH}/${e.data.sportName||e.data.sport_alias}/${e.data.regionAlias}/${e.data.competitionId}/${e.data.id}`.replace(/([^:]\/)\/+/g, "$1"),
                                children: (0, N.jsx)(S, {
                                    colorVariables: r,
                                    hideCompetitionLogo: !n,
                                    showSportIcon: i,
                                    game: e.data,
                                    bgImg: null === e || void 0 === e ? void 0 : e.imgPath,
                                    currentSport: e.data.sportName,
                                    regionName: e.data.regionName,
                                    sportName: e.data.sportName,
                                    competitionName: e.data.competitionName,
                                    competitionId: e.data.competitionId,
                                    selectedGames: !0,
                                    longDate: !0,
                                    onClick: () => {
                                        (0, A.C)(0 === e.data.sportType ? 1 === e.data.type ? "live" : "prematch" : c, e.data.regionAlias, e.data.competitionId, e.data.id, e.data.sportName || e.data.sport_alias, 0 === e.data.sportType)
                                    }
                                })
                            })
                        }, t)
                    }))
                }, t)));
                return d ? (0, N.jsx)(I.SwiperSlider, {
                    drawableTabs: d,
                    activeSlide: 0,
                    slidesPerView: 1,
                    bodyArrows: !(0, j.F)() && !(null === a || void 0 === a || !a.length) && t.length > 1,
                    autoplay: !!l,
                    delay: l,
                    loop: !0,
                    showIndicators: (0, j.F)()
                }) : (0, N.jsx)("div", {
                    children: (0, N.jsx)(T.J, {
                        gamesPerView: o
                    })
                })
            }))
        },
        893662: (e, t, a) => {
            a.r(t), a.d(t, {
                SwiperSlider: () => h
            });
            var o = a(365043),
                s = a(889181),
                i = a(994167),
                n = a(716806),
                l = a(179177),
                r = a(423400),
                d = a(432148),
                c = a(735905),
                m = a(120376),
                p = (a(78517), a(799450), a(570579));
            l.Ay.IS_RTL && a.e(85584).then(a.bind(a, 385584)), n.Ay.use([n.Vx, n.Ij, n.dK]);
            const u = e => e ? `SLIDER_SELECTOR_${e}` : null,
                v = e => e ? `SLIDE_SELECTOR_${e}` : "",
                h = e => {
                    var t, a;
                    let {
                        delay: n,
                        autoplay: l,
                        bodyArrows: h,
                        headerTitle: _,
                        activeSlide: g,
                        headerArrows: b,
                        drawableTabs: x,
                        slidesPerView: f,
                        showIndicators: y,
                        slideClassName: w = "",
                        sliderClassName: C = "",
                        arrowsPortalId: N = null,
                        disableSwiping: S = !1,
                        interactiveIndicators: j = !1,
                        loop: A = !1,
                        sliderWrapperClassName: k = ""
                    } = e;
                    const [T, I] = (0, o.useState)(!1), $ = (0, o.useRef)(null), [E, B] = (0, o.useState)(0), P = (0, o.useRef)(null), [G, R] = (0, o.useState)(!0), [O, M] = (0, o.useState)(!1), H = (0, o.useRef)(r.A.gCustom()), L = d.P ? "caretleft" : "caretRight", z = d.P ? "caretRight" : "caretleft";
                    (0, o.useLayoutEffect)((() => {
                        var e, t;
                        const a = null === (e = P.current) || void 0 === e || null === (t = e.querySelector(".swiper-wrapper")) || void 0 === t ? void 0 : t.childNodes;
                        if (a) {
                            const e = () => {
                                var e;
                                I(!1), B(0);
                                const t = (null === (e = P.current) || void 0 === e ? void 0 : e.clientWidth) || 0;
                                let o = 0,
                                    s = 0;
                                for (let n = 0; n < a.length; n++) {
                                    var i;
                                    const e = null === (i = a[n]) || void 0 === i ? void 0 : i.offsetWidth;
                                    if (s + e > t) break;
                                    o++, s += e
                                }
                                R(x.length > o)
                            };
                            return e(), window.addEventListener("resize", e), () => {
                                window.removeEventListener("resize", e)
                            }
                        }
                    }), [x.length]), (0, o.useEffect)((() => {
                        var e;
                        null !== (e = $.current) && void 0 !== e && e.swiper && g && ($.current.swiper.slideTo(g, 0), B(g))
                    }), [g]);
                    const F = (0, o.useMemo)((() => `swiper-pagination-${(Math.random()+1).toString(36).substring(7)}`), []),
                        D = e => {
                            var t;
                            e.stopPropagation(), null !== (t = $.current) && void 0 !== t && t.swiper && $.current.swiper.slidePrev()
                        },
                        K = e => {
                            var t;
                            e.stopPropagation(), null !== (t = $.current) && void 0 !== t && t.swiper && ($.current.swiper.slideNext(), I($.current.swiper.isEnd))
                        },
                        U = (0, o.useCallback)((e => {
                            I(e.isEnd)
                        }), []);
                    (0, o.useEffect)((() => (M(!0), () => M(!1))), [x]);
                    const V = (0, o.useMemo)((() => {
                            if (!x || !x.length) return [];
                            if (!(O && "auto" === f && l)) return x;
                            const e = document.querySelector(`.${v(H.current)}`),
                                t = document.querySelector(`.${u(H.current)}`);
                            if (e && t) {
                                const a = e.getClientRects()[0].width,
                                    s = t.getClientRects()[0].width,
                                    i = Math.floor(s / a);
                                if (x.length > i && x.length < 2 * i) return [...x, ...x].map(((e, t) => (0, p.jsx)(o.Fragment, {
                                    children: e
                                }, t)))
                            }
                            return x
                        }), [l, x, f, O, H.current]),
                        W = (0, o.useCallback)((e => {
                            I(e.isEnd), B(e.activeIndex)
                        }), []),
                        q = (0, o.useCallback)((e => {
                            let {
                                children: t
                            } = e;
                            return N ? (0, p.jsx)(m.Z, {
                                rootId: N,
                                children: t
                            }) : t
                        }), [N]),
                        Q = !l && !A && 0 === E,
                        J = !l && !A && T;
                    return (0, p.jsxs)("div", {
                        ref: P,
                        className: k,
                        children: [b ? (0, p.jsxs)("div", {
                            className: "swiper__slider--header",
                            children: [(0, p.jsx)("h3", {
                                children: _
                            }), G && (0, p.jsxs)("div", {
                                className: "swiper__slider--header__arrowsRow",
                                children: [(0, p.jsx)("button", {
                                    onClick: D,
                                    disabled: Q,
                                    className: (0, s.A)([{
                                        "disabled-arrow": Q
                                    }]),
                                    children: (0, p.jsx)(c.GlobalIcon, {
                                        lib: "generic",
                                        name: z,
                                        theme: "default",
                                        size: 12,
                                        skeleton: !0
                                    })
                                }), (0, p.jsx)("button", {
                                    className: (0, s.A)([{
                                        "disabled-arrow": J
                                    }]),
                                    onClick: K,
                                    disabled: J,
                                    children: (0, p.jsx)(c.GlobalIcon, {
                                        lib: "generic",
                                        name: L,
                                        theme: "default",
                                        size: 12,
                                        skeleton: !0
                                    })
                                })]
                            })]
                        }) : null, (0, p.jsxs)("div", {
                            className: "swiperWrapper",
                            children: [h && G && (0, p.jsx)(q, {
                                children: (0, p.jsxs)(p.Fragment, {
                                    children: [(0, p.jsx)("div", {
                                        className: "swiperWrapper__arrows",
                                        children: (0, p.jsx)("button", {
                                            onClick: D,
                                            disabled: Q,
                                            className: (0, s.A)([{
                                                "disabled-arrow": Q
                                            }]),
                                            children: (0, p.jsx)(c.GlobalIcon, {
                                                lib: "generic",
                                                name: z,
                                                theme: "default",
                                                size: 12
                                            })
                                        })
                                    }), (0, p.jsx)("div", {
                                        className: "swiperWrapper__arrows",
                                        children: (0, p.jsx)("button", {
                                            className: (0, s.A)([{
                                                "disabled-arrow": J
                                            }]),
                                            onClick: K,
                                            disabled: J,
                                            children: (0, p.jsx)(c.GlobalIcon, {
                                                lib: "generic",
                                                name: L,
                                                theme: "default",
                                                size: 12
                                            })
                                        })
                                    })]
                                })
                            }), (0, p.jsx)(i.RC, {
                                loop: l || A,
                                className: `${u(H.current)} ${C}`,
                                allowTouchMove: !S,
                                pagination: {
                                    type: "bullets",
                                    el: `.${F}`,
                                    clickable: j
                                },
                                autoplay: l && {
                                    delay: n || 1e3,
                                    disableOnInteraction: !1
                                },
                                slidesPerView: f || "auto",
                                onSwiper: U,
                                onSlideChange: W,
                                ref: $,
                                onSliderMove: null === (t = $.current) || void 0 === t || null === (a = t.swiper) || void 0 === a ? void 0 : a.update,
                                children: null === V || void 0 === V ? void 0 : V.map(((e, t) => (0, p.jsx)(i.qr, {
                                    className: `${v(H.current)} ${w} `,
                                    children: (0, p.jsx)("div", {
                                        children: e
                                    })
                                }, t)))
                            })]
                        }), y && (0, p.jsx)("div", {
                            className: `swiperWrapper__swiper-pagination swiper-pagination ${F}`
                        })]
                    })
                }
        },
        878509: (e, t, a) => {
            a.d(t, {
                K: () => s
            });
            var o = a(365043);
            const s = () => {
                const e = (0, o.useRef)(null);
                return {
                    buttonRef: e,
                    buttonPosition: (() => {
                        if (e.current) {
                            var t, a;
                            const {
                                offsetLeft: o
                            } = e.current, {
                                innerWidth: s
                            } = window;
                            return (null === (t = e.current) || void 0 === t || null === (a = t.getBoundingClientRect()) || void 0 === a ? void 0 : a.top) < 280 ? o > (s - 32) / 2 ? "bottomRight" : o > (s - 32) / 4 ? "bottom" : "bottomLeft" : o > (s - 32) / 2 ? "topRight" : o > (s - 32) / 4 ? "top" : "topLeft"
                        }
                        return "topLeft"
                    })()
                }
            }
        },
        880279: (e, t, a) => {
            a.d(t, {
                GW: () => T,
                J2: () => A,
                P_: () => S,
                Zl: () => j,
                bT: () => b,
                bv: () => C,
                p7: () => N,
                pb: () => k,
                rK: () => f
            });
            var o = a(291372),
                s = a(197262),
                i = a(322908),
                n = a.n(i),
                l = a(737536),
                r = a(423400),
                d = a(144891),
                c = a(704270),
                m = a(588860),
                p = a(828088),
                u = a(855221),
                v = a(320308),
                h = a(759851),
                _ = a(179177);
            const g = e => {
                    var t;
                    const a = null === (t = o.A.getState().betSlip) || void 0 === t ? void 0 : t.betslipOpen,
                        s = _.Ay.IS_BETSLIP_FLOATING_ENABLED;
                    return !s || s && a ? e : null
                },
                b = async (e, t, a, o, s) => {
                    c.l.then((i => {
                        i.sendCommand(e, t, a, o, s)
                    }))
                },
                x = (e, t, a, o, i) => {
                    null === t || void 0 === t || t(e);
                    const {
                        result: n,
                        result_text: l,
                        details: r,
                        StatusCode: c,
                        Data: m
                    } = e, p = c === d.bN[0];
                    if (1800 === n || p) {
                        var h, _;
                        const e = p ? null !== m && void 0 !== m && m.ErrorData ? {
                            old_price: null === m || void 0 === m || null === (h = m.ErrorData) || void 0 === h ? void 0 : h.OldPrice,
                            new_price: null === m || void 0 === m || null === (_ = m.ErrorData) || void 0 === _ ? void 0 : _.ActualPrice
                        } : null : Array.isArray(r) ? {
                            old_price: r[0].old_price,
                            new_price: r[0].new_price
                        } : null;
                        if (o && o(!0), !e) return;
                        const t = s.A.t("swarm.OddsIsChanged").replace("{oldPrice}", (0, u.C)(e.old_price, a)).replace("{newPrice}", (0, u.C)(e.new_price, a));
                        (0, v.$)(t, g(i), l)
                    }
                },
                f = (e, t, a, s, i) => {
                    var n;
                    const l = null === (n = o.A.getState().betSlip) || void 0 === n ? void 0 : n.editBet;
                    null !== l && void 0 !== l && l.active ? w(e, t, a, s, i) : y(e, t, a, s, i)
                },
                y = (e, t, a, i, n) => {
                    const c = o.A.getState().betSlip.oddFormat,
                        u = o.A.getState().betSlip.editBet,
                        v = o.A.getState().betSlip.useBonusBalance,
                        f = o.A.getState().userData.user,
                        {
                            bets: y,
                            type: w,
                            mode: C,
                            sys_bet: N,
                            bonus_id: S,
                            predefined_multiple_id: j,
                            source: A,
                            each_way: k,
                            booking_id: T
                        } = e,
                        I = null !== u && void 0 !== u && u.active ? u.amount : e.amount,
                        $ = e.amount,
                        E = (null === u || void 0 === u ? void 0 : u.betId) || null,
                        B = {
                            command: l.y.DO_BET,
                            params: {
                                source: A,
                                each_way: k,
                                bonus_id: S,
                                amount: I,
                                bets: y,
                                mode: C || d.wH.ODD_NOT_CHANGE,
                                odd_type: c,
                                type: w,
                                booking_id: T,
                                ...!v || _.Ay.BET_WITH_ONLY_BONUS_OR_DEPOSIT && null !== f && void 0 !== f && f.bonus_balance ? {
                                    is_bonus_money: v
                                } : {}
                            },
                            rid: r.A.gForCommand()
                        };
                    N && (B.params.sys_bet = N), j && (B.params.predefined_multiple_id = j), null !== u && void 0 !== u && u.active && (B.params.additional_amount = $, B.params.old_bet_id = E), b(B, "", (e => {
                        var a, o, i;
                        (t(e), e && "OK" === e.result) && (null !== (a = e.details) && void 0 !== a && a.is_superbet ? (0, p.y)(s.A.t("betslip.superBetSuccess"), g(n)) : (0, p.y)(s.A.t(`betslip.${m.M.DO_BET}`), g(n)));
                        _.Ay.APPEND_CUSTOM_CODE_BETSLIP && (0, h.T)(_.Ay.CUSTOM_CODE_BETSLIP, {
                            amount: I,
                            currency: null === f || void 0 === f ? void 0 : f.currency,
                            bet_id: null === e || void 0 === e || null === (o = e.details) || void 0 === o ? void 0 : o.bet_id,
                            k: null === e || void 0 === e || null === (i = e.details) || void 0 === i ? void 0 : i.k,
                            is_superbet: -1 === C,
                            bet_type: w,
                            name: null === f || void 0 === f ? void 0 : f.name,
                            first_name: null === f || void 0 === f ? void 0 : f.first_name,
                            last_name: null === f || void 0 === f ? void 0 : f.last_name,
                            email: null === f || void 0 === f ? void 0 : f.email,
                            username: null === f || void 0 === f ? void 0 : f.username,
                            btag: null === f || void 0 === f ? void 0 : f.btag,
                            userId: null === f || void 0 === f ? void 0 : f.id,
                            phone: null === f || void 0 === f ? void 0 : f.phone
                        })
                    }), (() => {}), (e => {
                        let {
                            data: t
                        } = e;
                        x(t, a, c, i, n)
                    }))
                },
                w = (e, t, a, i, n) => {
                    const d = o.A.getState().betSlip.oddFormat,
                        c = o.A.getState().betSlip.editBet,
                        u = o.A.getState().userData.user,
                        {
                            bets: v,
                            type: f,
                            mode: y,
                            source: w,
                            each_way: C
                        } = e,
                        N = null !== c && void 0 !== c && c.active ? c.amount : e.amount,
                        S = e.amount,
                        j = (null === c || void 0 === c ? void 0 : c.betId) || null,
                        A = {
                            command: l.y.CREATE_BETS,
                            params: {
                                bets: [{
                                    Source: w,
                                    EachWay: C,
                                    Amount: N,
                                    Events: v.map((e => ({
                                        SelectionId: e.event_id,
                                        Coeficient: e.price
                                    }))),
                                    OddType: d,
                                    Type: f,
                                    AdditionalAmount: void 0
                                }]
                            },
                            rid: r.A.gForCommand()
                        };
                    null !== c && void 0 !== c && c.active && (A.params.bets[0].AdditionalAmount = S, A.params.bets[0].OldBetId = j), b(A, "", (e => {
                        var a, o, i, l;
                        "0" === e.StatusCode && (e.result = "OK", null !== (a = e.Data) && void 0 !== a && null !== (o = a[0]) && void 0 !== o && o.is_superbet ? (0, p.y)(s.A.t("betslip.superBetSuccess"), g(n)) : (0, p.y)(s.A.t(`betslip.${m.M.DO_BET}`), g(n)));
                        (t(e), _.Ay.APPEND_CUSTOM_CODE_BETSLIP) && (0, h.T)(_.Ay.CUSTOM_CODE_BETSLIP, {
                            amount: N,
                            currency: null === u || void 0 === u ? void 0 : u.currency,
                            bet_id: null === e || void 0 === e || null === (i = e.Data[0]) || void 0 === i ? void 0 : i.bet_id,
                            k: null === e || void 0 === e || null === (l = e.Data[0]) || void 0 === l ? void 0 : l.k,
                            is_superbet: -1 === y,
                            bet_type: f,
                            name: null === u || void 0 === u ? void 0 : u.name,
                            first_name: null === u || void 0 === u ? void 0 : u.first_name,
                            last_name: null === u || void 0 === u ? void 0 : u.last_name,
                            email: null === u || void 0 === u ? void 0 : u.email,
                            username: null === u || void 0 === u ? void 0 : u.username,
                            btag: null === u || void 0 === u ? void 0 : u.btag,
                            userId: null === u || void 0 === u ? void 0 : u.id,
                            phone: null === u || void 0 === u ? void 0 : u.phone
                        })
                    }), (() => {}), (e => {
                        let {
                            data: t
                        } = e;
                        x(t, a, d, i, n)
                    }))
                },
                C = (e, t, a) => {
                    const o = {
                        command: l.y.GET_FREEBETS_FOR_BETSLIP_V3,
                        params: e,
                        rid: r.A.gForCommand()
                    };
                    b(o, "", t, (() => {}), a)
                },
                N = async (e, t, a) => {
                    const o = {
                        command: l.y.GET,
                        rid: r.A.gForCommand(),
                        params: {
                            source: l.p.CURRENCY_CONFIG,
                            what: {
                                currency: []
                            },
                            where: {
                                currency: {
                                    name: e
                                }
                            },
                            subscribe: !1
                        }
                    };
                    c.l.then((e => e.sendCommand(o, "", t, void 0, a)))
                },
                S = async (e, t, a) => {
                    const o = {
                            command: l.y.BOOK_BET,
                            rid: r.A.gForCommand(),
                            params: {
                                bets: e
                            }
                        },
                        s = Number(n().parse(window.location.search, {
                            ignoreQueryPrefix: !0
                        }).tid);
                    s && (o.params.cashdesk_id = s), c.l.then((e => e.sendCommand(o, "", t, void 0, a)))
                },
                j = (e, t, a) => {
                    const o = {
                        command: l.y.GET_EVENTS_BY_BOOKING_ID,
                        rid: r.A.gForCommand(),
                        params: {
                            booking_id: +e
                        }
                    };
                    c.l.then((e => e.sendCommand(o, "", t, void 0, a)))
                },
                A = (e, t, a, o, s, i) => {
                    const n = s || (e ? e.map((e => e.gameId)) : []),
                        d = s && i ? i : e ? e.map((e => e.eventId)) : [],
                        m = {
                            command: l.y.GET,
                            rid: r.A.gForCommand(),
                            params: {
                                source: l.p.BETTING,
                                what: { ...!o && {
                                        sport: ["alias", "type"],
                                        region: ["name", "alias"],
                                        competition: ["name", "id"],
                                        game: ["id", "type", "team1_name", "team2_name", "start_ts", "info"],
                                        market: ["name", "type", "extra_info"]
                                    },
                                    event: o ? ["id"] : ["id", "base", "name", "price", "ew_allowed"]
                                },
                                where: {
                                    game: {
                                        id: {
                                            "@in": n
                                        }
                                    },
                                    event: {
                                        id: {
                                            "@in": d
                                        }
                                    }
                                }
                            }
                        };
                    c.l.then((e => {
                        e.sendCommand(m, "", t, void 0, a)
                    }))
                },
                k = (e, t, a, o) => {
                    const s = {
                        command: l.y.SUPER_BET_ANSWER,
                        rid: r.A.gForCommand(),
                        params: {
                            accept: e,
                            bet_id: t
                        }
                    };
                    c.l.then((e => e.sendCommand(s, "", a, void 0, o)))
                },
                T = (e, t, a) => {
                    const o = {
                        command: l.y.CHECK_BET_STATUS,
                        rid: r.A.gForCommand(),
                        params: {
                            bet_id: e
                        }
                    };
                    c.l.then((e => e.sendCommand(o, "", t, void 0, a)))
                }
        },
        207610: (e, t, a) => {
            a.d(t, {
                Hl: () => l,
                Kk: () => d,
                Pg: () => s,
                Zg: () => i,
                _0: () => m,
                fe: () => c,
                iR: () => o,
                k4: () => n,
                n6: () => r,
                tU: () => p
            });
            const o = 2,
                s = 6,
                i = {
                    0: 6,
                    1: 5,
                    2: 5
                },
                n = 3,
                l = 6,
                r = 10,
                d = 6,
                c = 3,
                m = 10,
                p = 3
        },
        903295: (e, t, a) => {
            a.d(t, {
                R: () => o
            });
            const o = {
                4: [1368, 1369, 9647, 9648, 1366, 1367, 9645, 9646, 1222, 9501, 4736, 4737, 11424, 11425, 10149, 10150, 11589]
            }
        },
        429634: (e, t, a) => {
            a.d(t, {
                h: () => n
            });
            a(737053);
            var o = a(918811),
                s = a(822631),
                i = a(179177);
            const n = function(e) {
                let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
                    a = arguments.length > 2 ? arguments[2] : void 0;
                (0, s.G)(t, i.Ay.ERROR_MSG_DURATION, a || e), o.default.warn({
                    content: e,
                    key: a || e
                })
            }
        },
        600940: (e, t, a) => {
            a.d(t, {
                wM: () => g,
                B4: () => b,
                NT: () => p,
                HU: () => h,
                I0: () => _,
                Bo: () => u,
                IE: () => v,
                Rt: () => x
            });
            var o = a(860446),
                s = a.n(o),
                i = a(197262);
            const n = {
                AmericanFootball: "Quarter",
                AustralianFootball: "Quarter",
                Badminton: "Game",
                BallHockey: "Half",
                Baseball: "Inning",
                Basketball: "Quarter",
                BeachFootball: "Half",
                BeachHandball: "Half",
                BeachVolleyball: "Set",
                Bowls: "End",
                Boxing: "Round",
                CounterStrike: "Map",
                Cricket: "Inning",
                Curling: "End",
                CyberFootball: "Half",
                Dota2: "Game",
                EBasketball: "Quarter",
                Floorball: "Period",
                Futsal: "Half",
                GaelicFootball: "Half",
                GearsOfWar: "Game",
                Handball: "Half",
                Hearthstone: "Game",
                HeroesOfTheStorm: "Game",
                Hockey: "Period",
                IceHockey: "Period",
                LeagueOfLegends: "Game",
                Mma: "Round",
                MortalKombatXL: "Game",
                Netball: "Quarter",
                Overwatch: "Game",
                RugbyLeague: "Half",
                RugbySevens: "Half",
                RugbyUnion: "Half",
                Smite: "Game",
                Snooker: "Frame",
                Soccer: "Half",
                StarCraft: "Game",
                StarCraft2: "Game",
                TableTennis: "Set",
                Tekken7: "Game",
                Tennis: "Set",
                Volleyball: "Set",
                WarcraftIII: "Game",
                WaterPolo: "Quarter",
                WorldOfTanks: "Game",
                WorldOfWarcraft: "Game",
                PistolShooting: "Set",
                PistolHead2Head: "Set",
                ArcheryH2H: "Set",
                CompoundArchery: "Set",
                Archery: "Set",
                BasketballShots: "Shot"
            };
            var l = a(207610),
                r = a(482463),
                d = a(558073),
                c = a(179177);
            const m = {
                    "Half End": "halfEnd",
                    "Quarter End": "quarterEnd"
                },
                p = function(e) {
                    let {
                        current_game_state: t,
                        current_game_time: a
                    } = e, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "", s = arguments.length > 2 && void 0 !== arguments[2] && arguments[2], n = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0;
                    switch (!0) {
                        case "Half Time" === t:
                            return s ? i.A.t("sportsbook.halfTimeShort") : i.A.t("sportsbook.halfTime");
                        case ["Half End", "Quarter End"].includes(t) && "Basketball" === o:
                            return i.A.t(`sportsbook.${m[t]}`);
                        case "timeout" === t:
                            return s ? i.A.t("sportsbook.timeoutShort") : i.A.t("sportsbook.timeout");
                        case "notstarted" === t:
                            return s ? "0'" : i.A.t("sportsbook.notStarted");
                        case "finished" === t:
                            return s ? i.A.t("sportsbook.finishedShort") : i.A.t("sportsbook.finished");
                        case a && !!t && "Soccer" === o && s:
                            return `${a}'`;
                        case a && !!t && s:
                            return `${u(o,t,s,n)}`;
                        case a && !!t:
                            return `${u(o,t,s,n)} ${a}'`;
                        case !!a:
                            return `${a}'`;
                        case !!t:
                            return u(o, t, s, n);
                        case !t && !a:
                            return s ? "-" : ""
                    }
                    return ""
                };

            function u(e, t, a, o) {
                const s = n[e] ? n[e] : "Set",
                    r = +t.replace("set", "");
                return isNaN(r) ? t.replace("set", "") : "PistolHead2Head" === e && r === l.iR || "ArcheryH2H" === e && r === l.Pg || "CompoundArchery" === e && r === o ? i.A.t("sportsbook.shootOff") : a ? `${i.A.t(`sportsbook.${s}`)[0]}${r}` : `${v(r,s)} ${i.A.t(`sportsbook.${s}`)}`
            }

            function v(e) {
                let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
                const a = ["First", "Second", "Third", "Fourth", "Fifth", "Sixth", "Seventh", "Eighth", "Ninth", "Tenth", "Eleventh", "Twelfth"];
                return e <= a.length ? i.A.t(`sportsbook.${(t?t.toLowerCase():"")+a[e-1]}`) : `${e}${i.A.t(`sportsbook.${t?t.toLowerCase():""}DefaultSuffix`)}`
            }

            function h(e, t, a, o, i) {
                return a ? p({
                    current_game_state: e,
                    current_game_time: t
                }, i, !1, arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : 0) : o ? s()(1e3 * o).format((0, d.i)({
                    date: c.Ay.DT.shortDate,
                    time: c.Ay.DT.time
                })) : "--"
            }

            function _(e, t) {
                let a = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
                try {
                    const o = Object.values(e[0].competition || {});
                    let s;
                    if (s = a ? (0, r.I)(Object.values(o))[0] : Object.values(o)[0], s) switch (t) {
                        case "competition":
                            return s.id;
                        case "game":
                            return Number(Object.values(s.game || {}).sort(((e, t) => e.start_ts - t.start_ts))[0].id)
                    }
                } catch (o) {
                    console.info(o)
                }
            }

            function g(e) {
                switch (e) {
                    case "Half Time":
                    case "timeout":
                    case "notstarted":
                    case "finished":
                        return !0;
                    default:
                        return !1
                }
            }
            const b = e => {
                const t = Object.values(e.maps || {}).find((t => t.mapNumber === e.currentMap));
                return null !== t && void 0 !== t && t.mapNumber ? (null === t || void 0 === t ? void 0 : t.mapName) || `${v(t.mapNumber)} ${i.A.t("sportsbook.Map")}` : ""
            };

            function x(e) {
                return 1 === e ? `${e}${i.A.t("sportsbook.st")}` : 2 === e ? `${e}${i.A.t("sportsbook.nd")}` : `${e}${i.A.t("sportsbook.th")}`
            }
        },
        902546: (e, t, a) => {
            a.d(t, {
                C: () => l
            });
            var o = a(291372),
                s = a(179177),
                i = a(55418),
                n = a(424757);
            const l = (e, t, a, l, r, d, c) => {
                const m = o.A.getState().appData.menuJsonData;
                let p = ["liveEvents", "live"].includes(e) ? s.Ay.PAGE_URLS.live : s.Ay.PAGE_URLS.prematch;
                var u;
                !p && m.length && (p = null === (u = m.find((t => "sport" === t.category && "liveEvents" === e ? 1 === t.status : 0 === t.status))) || void 0 === u ? void 0 : u.path);
                "/" === p && (p = `${window.location.origin}/`), a || l ? d && s.Ay.PAGE_URLS.esport ? (0, n.e2)(`${s.Ay.PAGE_URLS.esport}/${s.Ay.SPORTSBOOK_MOUNT_PATH}/${r}/${(0,i.F)()?"":`${t}/${a}/`}${l||""}?type=${e}${c?window.location.search:""}`.replace(/([^:]\/)\/+/g, "$1"), !1, !0) : (0, n.e2)(`${p}/${s.Ay.SPORTSBOOK_MOUNT_PATH}/${r}/${t}/${a}/${l||""}${c?window.location.search:""}`.replace(/([^:]\/)\/+/g, "$1"), !1, !0) : (0, n.e2)(`${p}/${s.Ay.SPORTSBOOK_MOUNT_PATH}${r?`/${r}`:""}`.replace(/([^:]\/)\/+/g, "$1"), !1, !0)
            }
        },
        623902: (e, t, a) => {
            a.d(t, {
                w: () => n
            });
            var o = a(197262),
                s = a(903295),
                i = a(179177);
            const n = (e, t) => {
                const a = s.R[i.Ay.JURISDICTION];
                if (t && a && a.includes(Number(t))) {
                    const t = JSON.parse(JSON.stringify(e));
                    if (t.text_info = o.A.t("sportsbook.signInStatistics"), null !== e && void 0 !== e && e.stats) {
                        t.stats.team1_value = "-", t.stats.team2_value = "-", t.stats.add_info = null;
                        const a = ["team1_value", "team2_value", "add_info"];
                        Object.keys(e.stats).forEach((e => {
                            const o = e;
                            a.includes(o) || (t.stats[o] = { ...t.stats[o],
                                team1_value: "-",
                                team2_value: "-"
                            })
                        }))
                    }
                    return t.info = t.info || {}, t.info.pass_team = "none", t.info.score1 = "-", t.info.score2 = "-", t.info.current_game_state = "", t.type = e.type, t
                }
                return e
            }
        },
        623184: (e, t, a) => {
            a.d(t, {
                PU: () => r,
                TF: () => d,
                kB: () => l
            });
            var o = a(928087),
                s = a(123213),
                i = a(556785),
                n = a(179177);
            const l = function(e) {
                    return !!e && "golf" !== (arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "").toLowerCase()
                },
                r = e => {
                    s.A.setItem((0, i.U)("sportsbook", "STREAM_ACTIVE_TAB_MODE"), `${e}`)
                },
                d = () => {
                    const e = parseInt(s.A.getItem((0, i.U)("sportsbook", "STREAM_ACTIVE_TAB_MODE"))),
                        t = Object.keys(o.q).filter((e => +e === +e)).map((e => +e)),
                        a = t.includes(e) ? e : +n.Ay.IS_ACTIVE_STREAM_TAB;
                    return t.filter((e => +e)).includes(a)
                }
        },
        341225: (e, t, a) => {
            a.d(t, {
                FJ: () => f,
                Lu: () => y,
                i5: () => x,
                mt: () => b
            });
            var o = a(860446),
                s = a.n(o),
                i = a(84957),
                n = a(179177),
                l = a(558073);
            const r = (e, t) => e === t.id,
                d = (e, t) => e < t ? i.D.lose : e > t ? i.D.win : i.D.draw,
                c = (e, t) => {
                    if (e.length < 5)
                        for (let a = 0; a < 5 - e.length; a++) t.push({
                            id: a,
                            score: "-",
                            status: i.D.draw
                        })
                },
                m = (e, t) => {
                    const a = t.map((t => {
                        let {
                            Id: a,
                            HomeTeam: o,
                            HomeScore: s,
                            AwayScore: i
                        } = t;
                        const n = r(e, o[0]),
                            l = n ? s : i,
                            c = n ? i : s;
                        return {
                            id: a,
                            score: `${l}:${c}`,
                            status: d(l, c)
                        }
                    }));
                    return c(t, a), a
                },
                p = (e, t) => {
                    const a = t.map((t => {
                        let {
                            Id: a,
                            HomeTeam: o,
                            AwayTeam: s,
                            HomeScore: i,
                            AwayScore: n
                        } = t;
                        const l = r(e, o[0]);
                        return {
                            id: a,
                            score: `${i}:${n}`,
                            status: d(l ? i : n, l ? n : i),
                            teams: `${o[0].name} - ${s[0].name}`
                        }
                    }));
                    return c(t, a), a
                },
                u = (e, t) => t.find((t => {
                    let {
                        EntityId: a
                    } = t;
                    return a === e
                })),
                v = e => e ? s()(e).format((0, l.i)({
                    date: n.Ay.DT.longDate
                })) : "-",
                h = (e, t, a) => {
                    if (!t.length) return "-";
                    let o = 0,
                        s = 0,
                        i = 0;
                    t.forEach((t => {
                        let {
                            HomeTeam: n,
                            HomeScore: l,
                            AwayScore: d
                        } = t;
                        const c = r(e, n[0]),
                            m = c ? l : d,
                            p = c ? d : l,
                            u = () => {
                                m > p && s++, m === p && i++
                            };
                        "all" === a && (o++, u()), "h" === a && c && (o++, u()), "a" !== a || c || (o++, u())
                    }));
                    const n = Math.round(100 * (1 * s + .5 * i) / o * 10) / 10;
                    return `${isNaN(n)?0:n}%`
                },
                _ = (e, t) => {
                    if (!t.length) return "-";
                    const a = t.reduce(((t, a) => {
                        let {
                            HomeTeam: o,
                            HomeScore: s,
                            AwayScore: i
                        } = a;
                        return t += r(e, o[0]) ? s : i
                    }), 0);
                    return "" + Math.round(a / t.length * 10) / 10
                },
                g = e => {
                    if (!e.length) return "-";
                    const t = e.reduce(((e, t) => {
                        let {
                            HomeScore: a,
                            AwayScore: o
                        } = t;
                        return e += a + o
                    }), 0);
                    return "" + Math.round(t / e.length * 10) / 10
                },
                b = e => `https://statistics.bcapps.org/images/c/s/0/${e}.png`,
                x = async e => {
                    const t = await fetch(`https://krosstats.betconstruct.com/api/${n.Ay.STATISTICS_LANG_PREFIX}/900/93f428d0-6591-48da-859d-b6c326db2448/Match/GetFullMatchInfo?matchId=${e}`);
                    return await t.json()
                },
                f = e => {
                    var t, a;
                    let {
                        HomeTeamId: o,
                        AwayTeamId: s,
                        CurrentMatch: i,
                        H2HMatches: n,
                        H2HleagueTable: l,
                        UpcomingMatchesEnt1: r,
                        UpcomingMatchesEnt2: d,
                        PlayedMatchesEnt1: c,
                        PlayedMatchesEnt2: b
                    } = e;
                    const x = {},
                        f = u(o, l),
                        y = u(s, l),
                        w = {
                            id: o,
                            name: i.HomeTeamName
                        },
                        C = {
                            id: s,
                            name: i.AwayTeamName
                        };
                    return x.competition = {
                        id: i.CompetitionId,
                        name: i.CompetitionName
                    }, x.h2h = [{
                        team: w,
                        matches: m(o, n),
                        all: h(o, n, "all"),
                        h: h(o, n, "h"),
                        a: h(o, n, "a"),
                        it: _(o, n),
                        gt: g(n)
                    }, {
                        team: C,
                        matches: m(s, n),
                        all: h(s, n, "all"),
                        h: h(s, n, "h"),
                        a: h(s, n, "a"),
                        it: _(s, n)
                    }], x.leagueResults = [{
                        team: w,
                        pos: `${(null===f||void 0===f?void 0:f.PositionTotal)||"-"}`,
                        pld: `${(null===f||void 0===f?void 0:f.PlayedTotal)||"-"}`,
                        pts: `${(null===f||void 0===f?void 0:f.PointsTotal)||"-"}`,
                        nextMatch: v(null === (t = r[0]) || void 0 === t ? void 0 : t.Date)
                    }, {
                        team: C,
                        pos: `${(null===y||void 0===y?void 0:y.PositionTotal)||"-"}`,
                        pld: `${(null===y||void 0===y?void 0:y.PlayedTotal)||"-"}`,
                        pts: `${(null===y||void 0===y?void 0:y.PointsTotal)||"-"}`,
                        nextMatch: v(null === (a = d[0]) || void 0 === a ? void 0 : a.Date)
                    }], x.lastGames = [{
                        team: w,
                        matches: p(o, c),
                        it: _(o, c),
                        gt: g(c)
                    }, {
                        team: C,
                        matches: p(s, b),
                        it: _(s, b),
                        gt: g(b)
                    }], x
                },
                y = e => {
                    var t;
                    const a = document.querySelector(`[data-popover-trigger="${e}"]`);
                    return ((null === a || void 0 === a || null === (t = a.getBoundingClientRect()) || void 0 === t ? void 0 : t.top) - 394 - 8 < 0 ? "bottom" : "top") + (n.Ay.IS_RTL ? "Right" : "Left")
                }
        },
        119432: (e, t, a) => {
            a.d(t, {
                $: () => o
            });
            const o = e => {
                const t = [],
                    a = [],
                    o = [];
                e.sort(((e, t) => {
                    var a, o;
                    return Number(null === (a = e.handicap) || void 0 === a ? void 0 : a.split("-").join("")) - Number(null === (o = t.handicap) || void 0 === o ? void 0 : o.split("-").join(""))
                }));
                for (const l of e) {
                    var s;
                    const e = null === (s = l.handicap) || void 0 === s ? void 0 : s.split("-").map((e => Number(e)));
                    e && (e[0] > e[1] ? t.push(l) : e[0] < e[1] ? o.push(l) : a.push(l))
                }
                const i = [],
                    n = Math.max(t.length, a.length, o.length);
                for (let l = 0; l < n; l++) i.push(t[l], a[l], o[l]);
                return i
            }
        },
        78517: () => {},
        781621: () => {},
        799450: () => {}
    }
]);
//# sourceMappingURL=events-game-card.d3790904.chunk.js.map