"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [2546], {
        902546: (e, t, o) => {
            o.d(t, {
                C: () => i
            });
            var s = o(291372),
                $ = o(179177),
                a = o(55418),
                n = o(424757);
            const i = (e, t, o, i, l, c, p) => {
                const r = s.A.getState().appData.menuJsonData;
                let A = ["liveEvents", "live"].includes(e) ? $.Ay.PAGE_URLS.live : $.Ay.PAGE_URLS.prematch;
                var _;
                !A && r.length && (A = null === (_ = r.find((t => "sport" === t.category && "liveEvents" === e ? 1 === t.status : 0 === t.status))) || void 0 === _ ? void 0 : _.path);
                "/" === A && (A = `${window.location.origin}/`), o || i ? c && $.Ay.PAGE_URLS.esport ? (0, n.e2)(`${$.Ay.PAGE_URLS.esport}/${$.Ay.SPORTSBOOK_MOUNT_PATH}/${l}/${(0,a.F)()?"":`${t}/${o}/`}${i||""}?type=${e}${p?window.location.search:""}`.replace(/([^:]\/)\/+/g, "$1"), !1, !0) : (0, n.e2)(`${A}/${$.Ay.SPORTSBOOK_MOUNT_PATH}/${l}/${t}/${o}/${i||""}${p?window.location.search:""}`.replace(/([^:]\/)\/+/g, "$1"), !1, !0) : (0, n.e2)(`${A}/${$.Ay.SPORTSBOOK_MOUNT_PATH}${l?`/${l}`:""}`.replace(/([^:]\/)\/+/g, "$1"), !1, !0)
            }
        }
    }
]);
//# sourceMappingURL=2546.949de8a9.chunk.js.map