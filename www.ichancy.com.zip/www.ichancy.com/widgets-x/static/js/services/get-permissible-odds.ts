import { WebsocketEnhanced } from 'interfaces/spring-websocket-interfaces';

import { CommandNames } from 'utils/constants/swarm/swarm-command-names';
import RidGenerator from 'utils/swarm/rid-generator';
import { connectingWS } from 'hooks/useSpringConnect';

const permissibleOddsCommand = async (
  commandObj: any,
  rid: string,
  callback: Function,
  updateCallback: Function,
  callbackError: Function | null
) => {
  connectingWS.then((socket: WebsocketEnhanced) => {
    socket.sendCommand(
      commandObj,
      rid,
      callback,
      updateCallback,
      callbackError
    );
  });
};

export const getPermissibleOdds = (
  callback: Function,
  callbackError: Function | null
): void => {
  const command = {
    command: CommandNames.GET_PERMISSIBLE_ODDS,
    params: {},
    rid: RidGenerator.gForCommand()
  };

  permissibleOddsCommand(command, '', callback, () => undefined, callbackError);
};
