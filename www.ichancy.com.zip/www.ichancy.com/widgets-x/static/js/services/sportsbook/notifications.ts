import { WebsocketEnhanced } from 'interfaces/spring-websocket-interfaces';
import { UserNotificationsResponse } from 'interfaces/notifications';
import { setUserNotifications } from 'store/actions/sport-data';
import store from 'store';

import { CommandNames } from 'utils/constants/swarm/swarm-command-names';
import RidGenerator from 'utils/swarm/rid-generator';
import { connectingWS } from 'hooks/useSpringConnect';

export const setGamesNotifications = (
  gameInfo: {
    id: number;
    game_start_ts: number;
  },
  shouldSubscribe: boolean,
  callback: Function,
  updateCallback?: Function
): void => {
  const command = {
    command: CommandNames.SET_GAMES_NOTIFICATIONS,
    params: {
      game_list: [gameInfo],
      events: [
        {
          event_name: 'MatchFinished',
          is_subscribed: shouldSubscribe
        }
      ]
    },
    rid: RidGenerator.gForCommand()
  };

  connectingWS.then((socket: WebsocketEnhanced) => {
    socket.sendCommand(command, '', callback, null, updateCallback);
  });
};

export const getUserAllNotifications = (): void => {
  const command = {
    command: CommandNames.GET_USER_ALL_NOTIFICATIONS,
    params: {},
    rid: RidGenerator.gForCommand()
  };

  const callback = (resp: UserNotificationsResponse) => {
    if (resp?.details) {
      store.dispatch(setUserNotifications(resp.details));
    }
  };

  connectingWS.then((socket: WebsocketEnhanced) => {
    socket.sendCommand(command, '', callback);
  });
};
