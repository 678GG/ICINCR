"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [3695], {
        203695: (e, t, l) => {
            l.r(t), l.d(t, {
                default: () => c
            });
            var r, n, a, i = l(365043);

            function o() {
                return o = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var l = arguments[t];
                        for (var r in l) Object.prototype.hasOwnProperty.call(l, r) && (e[r] = l[r])
                    }
                    return e
                }, o.apply(this, arguments)
            }

            function s(e, t) {
                let {
                    title: l,
                    titleId: s,
                    ...C
                } = e;
                return i.createElement("svg", o({
                    width: 32,
                    height: 32,
                    viewBox: "0 0 32 32",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    ref: t,
                    "aria-labelledby": s
                }, C), l ? i.createElement("title", {
                    id: s
                }, l) : null, r || (r = i.createElement("path", {
                    d: "M31.2555 6.64646L25.1178 0.508152C24.4715 -0.138134 23.4235 -0.138134 22.7772 0.508152L6.56404 16.7213C5.71433 17.571 6.09833 19.1876 7.71604 19.3447C8.34576 19.4059 8.61662 20.1767 8.16919 20.6242L0.346345 28.4476C-0.114797 28.9087 -0.114797 29.6567 0.346345 30.1185L1.59949 31.3716C2.06063 31.8327 2.80863 31.8327 3.27035 31.3716L10.7703 23.8716C11.344 23.2979 12.2789 23.6093 12.48 24.3962C12.8183 25.7173 14.2578 25.9859 15.0429 25.2007L20.1743 20.0693C19.048 19.1059 18.3926 17.6076 18.6126 15.9647C18.8812 13.9613 20.5075 12.3356 22.5109 12.0665C24.1532 11.8459 25.652 12.5013 26.6155 13.6282L31.2566 8.98703C31.9018 8.34017 31.9018 7.29217 31.2555 6.64646Z",
                    fill: "#FAC176"
                })), n || (n = i.createElement("path", {
                    d: "M5.6198 29.0208L7.23604 27.4045L4.31227 24.4808L2.69604 26.097L5.6198 29.0208Z",
                    fill: "#38454F"
                })), a || (a = i.createElement("path", {
                    d: "M23.1413 21.1663C25.6659 21.1663 27.7127 19.1196 27.7127 16.5949C27.7127 14.0701 25.6659 12.0234 23.1413 12.0234C20.6165 12.0234 18.5698 14.0701 18.5698 16.5949C18.5698 19.1196 20.6165 21.1663 23.1413 21.1663Z",
                    fill: "#C2615F"
                })))
            }
            const C = i.forwardRef(s),
                c = (l.p, C)
        }
    }
]);
//# sourceMappingURL=3695.ba4220ae.chunk.js.map