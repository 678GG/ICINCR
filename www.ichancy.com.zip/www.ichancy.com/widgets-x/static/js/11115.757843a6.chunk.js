"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [11115], {
        369536: (e, t) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            t.default = {
                icon: {
                    tag: "svg",
                    attrs: {
                        viewBox: "64 64 896 896",
                        focusable: "false"
                    },
                    children: [{
                        tag: "path",
                        attrs: {
                            d: "M176 511a56 56 0 10112 0 56 56 0 10-112 0zm280 0a56 56 0 10112 0 56 56 0 10-112 0zm280 0a56 56 0 10112 0 56 56 0 10-112 0z"
                        }
                    }]
                },
                name: "ellipsis",
                theme: "outlined"
            }
        },
        219730: (e, t, n) => {
            var r;
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = (r = n(539657)) && r.__esModule ? r : {
                default: r
            };
            t.default = o, e.exports = o
        },
        539657: (e, t, n) => {
            var r = n(245288),
                o = n(310684);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = r(n(601459)),
                l = function(e, t) {
                    if (!t && e && e.__esModule) return e;
                    if (null === e || "object" != o(e) && "function" != typeof e) return {
                        default: e
                    };
                    var n = c(t);
                    if (n && n.has(e)) return n.get(e);
                    var r = {
                            __proto__: null
                        },
                        i = Object.defineProperty && Object.getOwnPropertyDescriptor;
                    for (var l in e)
                        if ("default" !== l && Object.prototype.hasOwnProperty.call(e, l)) {
                            var u = i ? Object.getOwnPropertyDescriptor(e, l) : null;
                            u && (u.get || u.set) ? Object.defineProperty(r, l, u) : r[l] = e[l]
                        }
                    return r.default = e, n && n.set(e, r), r
                }(n(365043)),
                u = r(n(369536)),
                a = r(n(942740));

            function c(e) {
                if ("function" != typeof WeakMap) return null;
                var t = new WeakMap,
                    n = new WeakMap;
                return (c = function(e) {
                    return e ? n : t
                })(e)
            }
            var s = function(e, t) {
                    return l.createElement(a.default, (0, i.default)((0, i.default)({}, e), {}, {
                        ref: t,
                        icon: u.default
                    }))
                },
                f = l.forwardRef(s);
            t.default = f
        },
        685109: (e, t, n) => {
            function r(e, t, n) {
                return t in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }

            function o(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, r)
                }
                return n
            }

            function i(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? o(Object(n), !0).forEach((function(t) {
                        r(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : o(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function l(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                return r
            }

            function u(e, t) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, t) {
                    var n = null == e ? null : "undefined" !== typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                    if (null != n) {
                        var r, o, i = [],
                            l = !0,
                            u = !1;
                        try {
                            for (n = n.call(e); !(l = (r = n.next()).done) && (i.push(r.value), !t || i.length !== t); l = !0);
                        } catch (a) {
                            u = !0, o = a
                        } finally {
                            try {
                                l || null == n.return || n.return()
                            } finally {
                                if (u) throw o
                            }
                        }
                        return i
                    }
                }(e, t) || function(e, t) {
                    if (e) {
                        if ("string" === typeof e) return l(e, t);
                        var n = Object.prototype.toString.call(e).slice(8, -1);
                        return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? l(e, t) : void 0
                    }
                }(e, t) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function a(e, t) {
                if (null == e) return {};
                var n, r, o = function(e, t) {
                    if (null == e) return {};
                    var n, r, o = {},
                        i = Object.keys(e);
                    for (r = 0; r < i.length; r++) n = i[r], t.indexOf(n) >= 0 || (o[n] = e[n]);
                    return o
                }(e, t);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    for (r = 0; r < i.length; r++) n = i[r], t.indexOf(n) >= 0 || Object.prototype.propertyIsEnumerable.call(e, n) && (o[n] = e[n])
                }
                return o
            }
            n.r(t), n.d(t, {
                default: () => O
            });
            var c = n(365043),
                s = n(731528),
                f = n(498139),
                d = n.n(f),
                p = {
                    adjustX: 1,
                    adjustY: 1
                },
                v = [0, 0];
            const m = {
                topLeft: {
                    points: ["bl", "tl"],
                    overflow: p,
                    offset: [0, -4],
                    targetOffset: v
                },
                topCenter: {
                    points: ["bc", "tc"],
                    overflow: p,
                    offset: [0, -4],
                    targetOffset: v
                },
                topRight: {
                    points: ["br", "tr"],
                    overflow: p,
                    offset: [0, -4],
                    targetOffset: v
                },
                bottomLeft: {
                    points: ["tl", "bl"],
                    overflow: p,
                    offset: [0, 4],
                    targetOffset: v
                },
                bottomCenter: {
                    points: ["tc", "bc"],
                    overflow: p,
                    offset: [0, 4],
                    targetOffset: v
                },
                bottomRight: {
                    points: ["tr", "br"],
                    overflow: p,
                    offset: [0, 4],
                    targetOffset: v
                }
            };
            var y = n(25001),
                b = y.A.ESC,
                h = y.A.TAB;
            var g = n(113758),
                C = ["arrow", "prefixCls", "transitionName", "animation", "align", "placement", "placements", "getPopupContainer", "showAction", "hideAction", "overlayClassName", "overlayStyle", "visible", "trigger"];

            function w(e, t) {
                var n = e.arrow,
                    o = void 0 !== n && n,
                    l = e.prefixCls,
                    f = void 0 === l ? "rc-dropdown" : l,
                    p = e.transitionName,
                    v = e.animation,
                    y = e.align,
                    w = e.placement,
                    O = void 0 === w ? "bottomLeft" : w,
                    E = e.placements,
                    P = void 0 === E ? m : E,
                    A = e.getPopupContainer,
                    S = e.showAction,
                    M = e.hideAction,
                    k = e.overlayClassName,
                    I = e.overlayStyle,
                    j = e.visible,
                    x = e.trigger,
                    R = void 0 === x ? ["hover"] : x,
                    N = a(e, C),
                    K = u(c.useState(), 2),
                    _ = K[0],
                    D = K[1],
                    T = "visible" in e ? j : _,
                    L = c.useRef(null);
                c.useImperativeHandle(t, (function() {
                    return L.current
                }));
                var V = c.useRef(null),
                    z = "".concat(f, "-menu");
                ! function(e) {
                    var t = e.visible,
                        n = e.setTriggerVisible,
                        r = e.triggerRef,
                        o = e.menuRef,
                        i = e.onVisibleChange,
                        l = c.useRef(!1),
                        u = function() {
                            var e, o, l, u;
                            t && r.current && (null === (e = r.current) || void 0 === e || null === (o = e.triggerRef) || void 0 === o || null === (l = o.current) || void 0 === l || null === (u = l.focus) || void 0 === u || u.call(l), n(!1), "function" === typeof i && i(!1))
                        },
                        a = function(e) {
                            var t;
                            switch (e.keyCode) {
                                case b:
                                    u();
                                    break;
                                case h:
                                    !l.current && (null === (t = o.current) || void 0 === t ? void 0 : t.focus) ? (e.preventDefault(), o.current.focus(), l.current = !0) : u()
                            }
                        };
                    c.useEffect((function() {
                        return t ? (window.addEventListener("keydown", a), function() {
                            window.removeEventListener("keydown", a), l.current = !1
                        }) : function() {
                            return null
                        }
                    }), [t])
                }({
                    visible: T,
                    setTriggerVisible: D,
                    triggerRef: L,
                    menuRef: V,
                    onVisibleChange: e.onVisibleChange
                });
                var F = function() {
                        var t = e.overlay;
                        return "function" === typeof t ? t() : t
                    },
                    W = function(t) {
                        var n = e.onOverlayClick,
                            r = F().props;
                        D(!1), n && n(t), r.onClick && r.onClick(t)
                    },
                    B = function() {
                        var e, t = F(),
                            n = (0, g.K4)(V, t.ref),
                            i = (r(e = {
                                prefixCls: z
                            }, "data-dropdown-inject", !0), r(e, "onClick", W), r(e, "ref", (0, g.f3)(t) ? n : void 0), e);
                        return "string" === typeof t.type && (delete i.prefixCls, delete i["data-dropdown-inject"]), c.createElement(c.Fragment, null, o && c.createElement("div", {
                            className: "".concat(f, "-arrow")
                        }), c.cloneElement(t, i))
                    },
                    H = M;
                return H || -1 === R.indexOf("contextMenu") || (H = ["click"]), c.createElement(s.A, i(i({
                    builtinPlacements: P
                }, N), {}, {
                    prefixCls: f,
                    ref: L,
                    popupClassName: d()(k, r({}, "".concat(f, "-show-arrow"), o)),
                    popupStyle: I,
                    action: R,
                    showAction: S,
                    hideAction: H || [],
                    popupPlacement: O,
                    popupAlign: y,
                    popupTransitionName: p,
                    popupAnimation: v,
                    popupVisible: T,
                    stretch: function() {
                        var t = e.minOverlayWidthMatchTrigger,
                            n = e.alignPoint;
                        return "minOverlayWidthMatchTrigger" in e ? t : !n
                    }() ? "minWidth" : "",
                    popup: "function" === typeof e.overlay ? B : B(),
                    onPopupVisibleChange: function(t) {
                        var n = e.onVisibleChange;
                        D(t), "function" === typeof n && n(t)
                    },
                    getPopupContainer: A
                }), function() {
                    var t = e.children,
                        n = t.props ? t.props : {},
                        r = d()(n.className, function() {
                            var t = e.openClassName;
                            return void 0 !== t ? t : "".concat(f, "-open")
                        }());
                    return T && t ? c.cloneElement(t, {
                        className: r
                    }) : t
                }())
            }
            const O = c.forwardRef(w)
        },
        263088: (e, t, n) => {
            function r() {
                return r = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }, r.apply(this, arguments)
            }

            function o(e, t, n) {
                return t in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }

            function i(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, r)
                }
                return n
            }

            function l(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? i(Object(n), !0).forEach((function(t) {
                        o(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : i(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function u(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                return r
            }

            function a(e, t) {
                if (e) {
                    if ("string" === typeof e) return u(e, t);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? u(e, t) : void 0
                }
            }

            function c(e) {
                return function(e) {
                    if (Array.isArray(e)) return u(e)
                }(e) || function(e) {
                    if ("undefined" !== typeof Symbol && null != e[Symbol.iterator] || null != e["@@iterator"]) return Array.from(e)
                }(e) || a(e) || function() {
                    throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function s(e, t) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, t) {
                    var n = null == e ? null : "undefined" !== typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                    if (null != n) {
                        var r, o, i = [],
                            l = !0,
                            u = !1;
                        try {
                            for (n = n.call(e); !(l = (r = n.next()).done) && (i.push(r.value), !t || i.length !== t); l = !0);
                        } catch (a) {
                            u = !0, o = a
                        } finally {
                            try {
                                l || null == n.return || n.return()
                            } finally {
                                if (u) throw o
                            }
                        }
                        return i
                    }
                }(e, t) || a(e, t) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function f(e, t) {
                if (null == e) return {};
                var n, r, o = function(e, t) {
                    if (null == e) return {};
                    var n, r, o = {},
                        i = Object.keys(e);
                    for (r = 0; r < i.length; r++) n = i[r], t.indexOf(n) >= 0 || (o[n] = e[n]);
                    return o
                }(e, t);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    for (r = 0; r < i.length; r++) n = i[r], t.indexOf(n) >= 0 || Object.prototype.propertyIsEnumerable.call(e, n) && (o[n] = e[n])
                }
                return o
            }
            n.r(t), n.d(t, {
                Divider: () => Je,
                Item: () => Q,
                ItemGroup: () => $e,
                MenuItem: () => Q,
                MenuItemGroup: () => $e,
                SubMenu: () => Oe,
                default: () => et,
                useFullPath: () => Qe
            });
            var d = n(365043),
                p = n(498139),
                v = n.n(p),
                m = n(417324),
                y = n.n(m),
                b = n(628678),
                h = n(297907),
                g = n(181643);

            function C(e, t) {
                for (var n = 0; n < t.length; n++) {
                    var r = t[n];
                    r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                }
            }

            function w(e, t) {
                return w = Object.setPrototypeOf || function(e, t) {
                    return e.__proto__ = t, e
                }, w(e, t)
            }

            function O(e) {
                return O = Object.setPrototypeOf ? Object.getPrototypeOf : function(e) {
                    return e.__proto__ || Object.getPrototypeOf(e)
                }, O(e)
            }

            function E(e) {
                return E = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                    return typeof e
                } : function(e) {
                    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                }, E(e)
            }

            function P(e, t) {
                if (t && ("object" === E(t) || "function" === typeof t)) return t;
                if (void 0 !== t) throw new TypeError("Derived constructors may only return object or undefined");
                return function(e) {
                    if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                    return e
                }(e)
            }

            function A(e) {
                var t = function() {
                    if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" === typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, r = O(e);
                    if (t) {
                        var o = O(this).constructor;
                        n = Reflect.construct(r, arguments, o)
                    } else n = r.apply(this, arguments);
                    return P(this, n)
                }
            }
            var S = n(25001),
                M = n(918574),
                k = n(513709),
                I = ["children", "locked"],
                j = d.createContext(null);

            function x(e) {
                var t = e.children,
                    n = e.locked,
                    r = f(e, I),
                    o = d.useContext(j),
                    i = (0, k.A)((function() {
                        return function(e, t) {
                            var n = l({}, e);
                            return Object.keys(t).forEach((function(e) {
                                var r = t[e];
                                void 0 !== r && (n[e] = r)
                            })), n
                        }(o, r)
                    }), [o, r], (function(e, t) {
                        return !n && (e[0] !== t[0] || !y()(e[1], t[1]))
                    }));
                return d.createElement(j.Provider, {
                    value: i
                }, t)
            }

            function R(e, t, n, r) {
                var o = d.useContext(j),
                    i = o.activeKey,
                    l = o.onActive,
                    u = o.onInactive,
                    a = {
                        active: i === e
                    };
                return t || (a.onMouseEnter = function(t) {
                    null === n || void 0 === n || n({
                        key: e,
                        domEvent: t
                    }), l(e)
                }, a.onMouseLeave = function(t) {
                    null === r || void 0 === r || r({
                        key: e,
                        domEvent: t
                    }), u(e)
                }), a
            }
            var N = ["item"];

            function K(e) {
                var t = e.item,
                    n = f(e, N);
                return Object.defineProperty(n, "item", {
                    get: function() {
                        return (0, h.Ay)(!1, "`info.item` is deprecated since we will move to function component that not provides React Node instance in future."), t
                    }
                }), n
            }

            function _(e) {
                var t = e.icon,
                    n = e.props,
                    r = e.children;
                return ("function" === typeof t ? d.createElement(t, l({}, n)) : t) || r || null
            }

            function D(e) {
                var t = d.useContext(j),
                    n = t.mode,
                    r = t.rtl,
                    o = t.inlineIndent;
                if ("inline" !== n) return null;
                return r ? {
                    paddingRight: e * o
                } : {
                    paddingLeft: e * o
                }
            }
            var T = [],
                L = d.createContext(null);

            function V() {
                return d.useContext(L)
            }
            var z = d.createContext(T);

            function F(e) {
                var t = d.useContext(z);
                return d.useMemo((function() {
                    return void 0 !== e ? [].concat(c(t), [e]) : t
                }), [t, e])
            }
            var W = d.createContext(null),
                B = d.createContext(null);

            function H(e, t) {
                return void 0 === e ? null : "".concat(e, "-").concat(t)
            }

            function G(e) {
                return H(d.useContext(B), e)
            }
            const U = d.createContext({});
            var q = ["title", "attribute", "elementRef"],
                X = ["style", "className", "eventKey", "warnKey", "disabled", "itemIcon", "children", "role", "onMouseEnter", "onMouseLeave", "onClick", "onKeyDown", "onFocus"],
                Y = ["active"],
                $ = function(e) {
                    ! function(e, t) {
                        if ("function" !== typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
                        e.prototype = Object.create(t && t.prototype, {
                            constructor: {
                                value: e,
                                writable: !0,
                                configurable: !0
                            }
                        }), Object.defineProperty(e, "prototype", {
                            writable: !1
                        }), t && w(e, t)
                    }(l, e);
                    var t, n, o, i = A(l);

                    function l() {
                        return function(e, t) {
                            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        }(this, l), i.apply(this, arguments)
                    }
                    return t = l, (n = [{
                        key: "render",
                        value: function() {
                            var e = this.props,
                                t = e.title,
                                n = e.attribute,
                                o = e.elementRef,
                                i = f(e, q),
                                l = (0, M.A)(i, ["eventKey"]);
                            return (0, h.Ay)(!n, "`attribute` of Menu.Item is deprecated. Please pass attribute directly."), d.createElement(g.A.Item, r({}, n, {
                                title: "string" === typeof t ? t : void 0
                            }, l, {
                                ref: o
                            }))
                        }
                    }]) && C(t.prototype, n), o && C(t, o), Object.defineProperty(t, "prototype", {
                        writable: !1
                    }), l
                }(d.Component),
                J = function(e) {
                    var t, n = e.style,
                        i = e.className,
                        u = e.eventKey,
                        a = (e.warnKey, e.disabled),
                        s = e.itemIcon,
                        p = e.children,
                        m = e.role,
                        y = e.onMouseEnter,
                        b = e.onMouseLeave,
                        h = e.onClick,
                        g = e.onKeyDown,
                        C = e.onFocus,
                        w = f(e, X),
                        O = G(u),
                        E = d.useContext(j),
                        P = E.prefixCls,
                        A = E.onItemClick,
                        M = E.disabled,
                        k = E.overflowDisabled,
                        I = E.itemIcon,
                        x = E.selectedKeys,
                        N = E.onActive,
                        T = d.useContext(U)._internalRenderMenuItem,
                        L = "".concat(P, "-item"),
                        V = d.useRef(),
                        z = d.useRef(),
                        W = M || a,
                        B = F(u);
                    var H = function(e) {
                            return {
                                key: u,
                                keyPath: c(B).reverse(),
                                item: V.current,
                                domEvent: e
                            }
                        },
                        q = s || I,
                        J = R(u, W, y, b),
                        Q = J.active,
                        Z = f(J, Y),
                        ee = x.includes(u),
                        te = D(B.length),
                        ne = {};
                    "option" === e.role && (ne["aria-selected"] = ee);
                    var re = d.createElement($, r({
                        ref: V,
                        elementRef: z,
                        role: null === m ? "none" : m || "menuitem",
                        tabIndex: a ? null : -1,
                        "data-menu-id": k && O ? null : O
                    }, w, Z, ne, {
                        component: "li",
                        "aria-disabled": a,
                        style: l(l({}, te), n),
                        className: v()(L, (t = {}, o(t, "".concat(L, "-active"), Q), o(t, "".concat(L, "-selected"), ee), o(t, "".concat(L, "-disabled"), W), t), i),
                        onClick: function(e) {
                            if (!W) {
                                var t = H(e);
                                null === h || void 0 === h || h(K(t)), A(t)
                            }
                        },
                        onKeyDown: function(e) {
                            if (null === g || void 0 === g || g(e), e.which === S.A.ENTER) {
                                var t = H(e);
                                null === h || void 0 === h || h(K(t)), A(t)
                            }
                        },
                        onFocus: function(e) {
                            N(u), null === C || void 0 === C || C(e)
                        }
                    }), p, d.createElement(_, {
                        props: l(l({}, e), {}, {
                            isSelected: ee
                        }),
                        icon: q
                    }));
                    return T && (re = T(re, e, {
                        selected: ee
                    })), re
                };
            const Q = function(e) {
                var t = e.eventKey,
                    n = V(),
                    r = F(t);
                return d.useEffect((function() {
                    if (n) return n.registerPath(t, r),
                        function() {
                            n.unregisterPath(t, r)
                        }
                }), [r]), n ? null : d.createElement(J, e)
            };
            var Z = n(462149),
                ee = ["label", "children", "key", "type"];

            function te(e, t) {
                return (0, Z.A)(e).map((function(e, n) {
                    if (d.isValidElement(e)) {
                        var r, o, i = e.key,
                            l = null !== (r = null === (o = e.props) || void 0 === o ? void 0 : o.eventKey) && void 0 !== r ? r : i;
                        (null === l || void 0 === l) && (l = "tmp_key-".concat([].concat(c(t), [n]).join("-")));
                        var u = {
                            key: l,
                            eventKey: l
                        };
                        return d.cloneElement(e, u)
                    }
                    return e
                }))
            }

            function ne(e) {
                return (e || []).map((function(e, t) {
                    if (e && "object" === E(e)) {
                        var n = e.label,
                            o = e.children,
                            i = e.key,
                            l = e.type,
                            u = f(e, ee),
                            a = null !== i && void 0 !== i ? i : "tmp-".concat(t);
                        return o || "group" === l ? "group" === l ? d.createElement($e, r({
                            key: a
                        }, u, {
                            title: n
                        }), ne(o)) : d.createElement(Oe, r({
                            key: a
                        }, u, {
                            title: n
                        }), ne(o)) : "divider" === l ? d.createElement(Je, r({
                            key: a
                        }, u)) : d.createElement(Q, r({
                            key: a
                        }, u), n)
                    }
                    return null
                })).filter((function(e) {
                    return e
                }))
            }

            function re(e, t, n) {
                var r = e;
                return t && (r = ne(t)), te(r, n)
            }

            function oe(e) {
                var t = d.useRef(e);
                t.current = e;
                var n = d.useCallback((function() {
                    for (var e, n = arguments.length, r = new Array(n), o = 0; o < n; o++) r[o] = arguments[o];
                    return null === (e = t.current) || void 0 === e ? void 0 : e.call.apply(e, [t].concat(r))
                }), []);
                return e ? n : void 0
            }
            var ie = ["className", "children"],
                le = function(e, t) {
                    var n = e.className,
                        o = e.children,
                        i = f(e, ie),
                        l = d.useContext(j),
                        u = l.prefixCls,
                        a = l.mode,
                        c = l.rtl;
                    return d.createElement("ul", r({
                        className: v()(u, c && "".concat(u, "-rtl"), "".concat(u, "-sub"), "".concat(u, "-").concat("inline" === a ? "inline" : "vertical"), n)
                    }, i, {
                        "data-menu-list": !0,
                        ref: t
                    }), o)
                },
                ue = d.forwardRef(le);
            ue.displayName = "SubMenuList";
            const ae = ue;
            var ce = n(731528),
                se = n(445818),
                fe = {
                    adjustX: 1,
                    adjustY: 1
                },
                de = {
                    topLeft: {
                        points: ["bl", "tl"],
                        overflow: fe,
                        offset: [0, -7]
                    },
                    bottomLeft: {
                        points: ["tl", "bl"],
                        overflow: fe,
                        offset: [0, 7]
                    },
                    leftTop: {
                        points: ["tr", "tl"],
                        overflow: fe,
                        offset: [-4, 0]
                    },
                    rightTop: {
                        points: ["tl", "tr"],
                        overflow: fe,
                        offset: [4, 0]
                    }
                },
                pe = {
                    topLeft: {
                        points: ["bl", "tl"],
                        overflow: fe,
                        offset: [0, -7]
                    },
                    bottomLeft: {
                        points: ["tl", "bl"],
                        overflow: fe,
                        offset: [0, 7]
                    },
                    rightTop: {
                        points: ["tr", "tl"],
                        overflow: fe,
                        offset: [-4, 0]
                    },
                    leftTop: {
                        points: ["tl", "tr"],
                        overflow: fe,
                        offset: [4, 0]
                    }
                };

            function ve(e, t, n) {
                return t || (n ? n[e] || n.other : void 0)
            }
            var me = {
                horizontal: "bottomLeft",
                vertical: "rightTop",
                "vertical-left": "rightTop",
                "vertical-right": "leftTop"
            };

            function ye(e) {
                var t = e.prefixCls,
                    n = e.visible,
                    r = e.children,
                    i = e.popup,
                    u = e.popupClassName,
                    a = e.popupOffset,
                    c = e.disabled,
                    f = e.mode,
                    p = e.onVisibleChange,
                    m = d.useContext(j),
                    y = m.getPopupContainer,
                    b = m.rtl,
                    h = m.subMenuOpenDelay,
                    g = m.subMenuCloseDelay,
                    C = m.builtinPlacements,
                    w = m.triggerSubMenuAction,
                    O = m.forceSubMenuRender,
                    E = m.rootClassName,
                    P = m.motion,
                    A = m.defaultMotions,
                    S = s(d.useState(!1), 2),
                    M = S[0],
                    k = S[1],
                    I = l(l({}, b ? pe : de), C),
                    x = me[f],
                    R = l(l({}, ve(f, P, A)), {}, {
                        leavedClassName: "".concat(t, "-hidden"),
                        removeOnLeave: !1,
                        motionAppear: !0
                    }),
                    N = d.useRef();
                return d.useEffect((function() {
                    return N.current = (0, se.A)((function() {
                            k(n)
                        })),
                        function() {
                            se.A.cancel(N.current)
                        }
                }), [n]), d.createElement(ce.A, {
                    prefixCls: t,
                    popupClassName: v()("".concat(t, "-popup"), o({}, "".concat(t, "-rtl"), b), u, E),
                    stretch: "horizontal" === f ? "minWidth" : null,
                    getPopupContainer: y,
                    builtinPlacements: I,
                    popupPlacement: x,
                    popupVisible: M,
                    popup: i,
                    popupAlign: a && {
                        offset: a
                    },
                    action: c ? [] : [w],
                    mouseEnterDelay: h,
                    mouseLeaveDelay: g,
                    onPopupVisibleChange: p,
                    forceRender: O,
                    popupMotion: R
                }, r)
            }
            var be = n(85301);

            function he(e) {
                var t = e.id,
                    n = e.open,
                    o = e.keyPath,
                    i = e.children,
                    u = "inline",
                    a = d.useContext(j),
                    c = a.prefixCls,
                    f = a.forceSubMenuRender,
                    p = a.motion,
                    v = a.defaultMotions,
                    m = a.mode,
                    y = d.useRef(!1);
                y.current = m === u;
                var b = s(d.useState(!y.current), 2),
                    h = b[0],
                    g = b[1],
                    C = !!y.current && n;
                d.useEffect((function() {
                    y.current && g(!1)
                }), [m]);
                var w = l({}, ve(u, p, v));
                o.length > 1 && (w.motionAppear = !1);
                var O = w.onVisibleChanged;
                return w.onVisibleChanged = function(e) {
                    return y.current || e || g(!0), null === O || void 0 === O ? void 0 : O(e)
                }, h ? null : d.createElement(x, {
                    mode: u,
                    locked: !y.current
                }, d.createElement(be.default, r({
                    visible: C
                }, w, {
                    forceRender: f,
                    removeOnLeave: !1,
                    leavedClassName: "".concat(c, "-hidden")
                }), (function(e) {
                    var n = e.className,
                        r = e.style;
                    return d.createElement(ae, {
                        id: t,
                        className: n,
                        style: r
                    }, i)
                })))
            }
            var ge = ["style", "className", "title", "eventKey", "warnKey", "disabled", "internalPopupClose", "children", "itemIcon", "expandIcon", "popupClassName", "popupOffset", "onClick", "onMouseEnter", "onMouseLeave", "onTitleClick", "onTitleMouseEnter", "onTitleMouseLeave"],
                Ce = ["active"],
                we = function(e) {
                    var t, n = e.style,
                        i = e.className,
                        u = e.title,
                        a = e.eventKey,
                        c = (e.warnKey, e.disabled),
                        p = e.internalPopupClose,
                        m = e.children,
                        y = e.itemIcon,
                        b = e.expandIcon,
                        h = e.popupClassName,
                        C = e.popupOffset,
                        w = e.onClick,
                        O = e.onMouseEnter,
                        E = e.onMouseLeave,
                        P = e.onTitleClick,
                        A = e.onTitleMouseEnter,
                        S = e.onTitleMouseLeave,
                        M = f(e, ge),
                        k = G(a),
                        I = d.useContext(j),
                        N = I.prefixCls,
                        T = I.mode,
                        L = I.openKeys,
                        V = I.disabled,
                        z = I.overflowDisabled,
                        B = I.activeKey,
                        H = I.selectedKeys,
                        q = I.itemIcon,
                        X = I.expandIcon,
                        Y = I.onItemClick,
                        $ = I.onOpenChange,
                        J = I.onActive,
                        Q = d.useContext(U)._internalRenderSubMenuItem,
                        Z = d.useContext(W).isSubPathKey,
                        ee = F(),
                        te = "".concat(N, "-submenu"),
                        ne = V || c,
                        re = d.useRef(),
                        ie = d.useRef();
                    var le = y || q,
                        ue = b || X,
                        ce = L.includes(a),
                        se = !z && ce,
                        fe = Z(H, a),
                        de = R(a, ne, A, S),
                        pe = de.active,
                        ve = f(de, Ce),
                        me = s(d.useState(!1), 2),
                        be = me[0],
                        we = me[1],
                        Oe = function(e) {
                            ne || we(e)
                        },
                        Ee = d.useMemo((function() {
                            return pe || "inline" !== T && (be || Z([B], a))
                        }), [T, pe, B, be, a, Z]),
                        Pe = D(ee.length),
                        Ae = oe((function(e) {
                            null === w || void 0 === w || w(K(e)), Y(e)
                        })),
                        Se = k && "".concat(k, "-popup"),
                        Me = d.createElement("div", r({
                            role: "menuitem",
                            style: Pe,
                            className: "".concat(te, "-title"),
                            tabIndex: ne ? null : -1,
                            ref: re,
                            title: "string" === typeof u ? u : null,
                            "data-menu-id": z && k ? null : k,
                            "aria-expanded": se,
                            "aria-haspopup": !0,
                            "aria-controls": Se,
                            "aria-disabled": ne,
                            onClick: function(e) {
                                ne || (null === P || void 0 === P || P({
                                    key: a,
                                    domEvent: e
                                }), "inline" === T && $(a, !ce))
                            },
                            onFocus: function() {
                                J(a)
                            }
                        }, ve), u, d.createElement(_, {
                            icon: "horizontal" !== T ? ue : null,
                            props: l(l({}, e), {}, {
                                isOpen: se,
                                isSubMenu: !0
                            })
                        }, d.createElement("i", {
                            className: "".concat(te, "-arrow")
                        }))),
                        ke = d.useRef(T);
                    if ("inline" !== T && (ke.current = ee.length > 1 ? "vertical" : T), !z) {
                        var Ie = ke.current;
                        Me = d.createElement(ye, {
                            mode: Ie,
                            prefixCls: te,
                            visible: !p && se && "inline" !== T,
                            popupClassName: h,
                            popupOffset: C,
                            popup: d.createElement(x, {
                                mode: "horizontal" === Ie ? "vertical" : Ie
                            }, d.createElement(ae, {
                                id: Se,
                                ref: ie
                            }, m)),
                            disabled: ne,
                            onVisibleChange: function(e) {
                                "inline" !== T && $(a, e)
                            }
                        }, Me)
                    }
                    var je = d.createElement(g.A.Item, r({
                        role: "none"
                    }, M, {
                        component: "li",
                        style: n,
                        className: v()(te, "".concat(te, "-").concat(T), i, (t = {}, o(t, "".concat(te, "-open"), se), o(t, "".concat(te, "-active"), Ee), o(t, "".concat(te, "-selected"), fe), o(t, "".concat(te, "-disabled"), ne), t)),
                        onMouseEnter: function(e) {
                            Oe(!0), null === O || void 0 === O || O({
                                key: a,
                                domEvent: e
                            })
                        },
                        onMouseLeave: function(e) {
                            Oe(!1), null === E || void 0 === E || E({
                                key: a,
                                domEvent: e
                            })
                        }
                    }), Me, !z && d.createElement(he, {
                        id: Se,
                        open: se,
                        keyPath: ee
                    }, m));
                    return Q && (je = Q(je, e, {
                        selected: fe,
                        active: Ee,
                        open: se,
                        disabled: ne
                    })), d.createElement(x, {
                        onItemClick: Ae,
                        mode: "horizontal" === T ? "vertical" : T,
                        itemIcon: le,
                        expandIcon: ue
                    }, je)
                };

            function Oe(e) {
                var t, n = e.eventKey,
                    r = e.children,
                    o = F(n),
                    i = te(r, o),
                    l = V();
                return d.useEffect((function() {
                    if (l) return l.registerPath(n, o),
                        function() {
                            l.unregisterPath(n, o)
                        }
                }), [o]), t = l ? i : d.createElement(we, e, i), d.createElement(z.Provider, {
                    value: o
                }, t)
            }
            var Ee = n(732490),
                Pe = n(676590);

            function Ae(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                if ((0, Pe.A)(e)) {
                    var n = e.nodeName.toLowerCase(),
                        r = ["input", "select", "textarea", "button"].includes(n) || e.isContentEditable || "a" === n && !!e.getAttribute("href"),
                        o = e.getAttribute("tabindex"),
                        i = Number(o),
                        l = null;
                    return o && !Number.isNaN(i) ? l = i : r && null === l && (l = 0), r && e.disabled && (l = null), null !== l && (l >= 0 || t && l < 0)
                }
                return !1
            }

            function Se(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
                    n = (0, Ee.A)(e.querySelectorAll("*")).filter((function(e) {
                        return Ae(e, t)
                    }));
                return Ae(e, t) && n.unshift(e), n
            }
            var Me = S.A.LEFT,
                ke = S.A.RIGHT,
                Ie = S.A.UP,
                je = S.A.DOWN,
                xe = S.A.ENTER,
                Re = S.A.ESC,
                Ne = S.A.HOME,
                Ke = S.A.END,
                _e = [Ie, je, Me, ke];

            function De(e, t) {
                return Se(e, !0).filter((function(e) {
                    return t.has(e)
                }))
            }

            function Te(e, t, n) {
                var r = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 1;
                if (!e) return null;
                var o = De(e, t),
                    i = o.length,
                    l = o.findIndex((function(e) {
                        return n === e
                    }));
                return r < 0 ? -1 === l ? l = i - 1 : l -= 1 : r > 0 && (l += 1), o[l = (l + i) % i]
            }

            function Le(e, t, n, r, i, l, u, a, c, s) {
                var f = d.useRef(),
                    p = d.useRef();
                p.current = t;
                var v = function() {
                    se.A.cancel(f.current)
                };
                return d.useEffect((function() {
                        return function() {
                            v()
                        }
                    }), []),
                    function(d) {
                        var m = d.which;
                        if ([].concat(_e, [xe, Re, Ne, Ke]).includes(m)) {
                            var y, b, h, g = function() {
                                return y = new Set, b = new Map, h = new Map, l().forEach((function(e) {
                                    var t = document.querySelector("[data-menu-id='".concat(H(r, e), "']"));
                                    t && (y.add(t), h.set(t, e), b.set(e, t))
                                })), y
                            };
                            g();
                            var C = function(e, t) {
                                    for (var n = e || document.activeElement; n;) {
                                        if (t.has(n)) return n;
                                        n = n.parentElement
                                    }
                                    return null
                                }(b.get(t), y),
                                w = h.get(C),
                                O = function(e, t, n, r) {
                                    var i, l, u, a, c = "prev",
                                        s = "next",
                                        f = "children",
                                        d = "parent";
                                    if ("inline" === e && r === xe) return {
                                        inlineTrigger: !0
                                    };
                                    var p = (o(i = {}, Ie, c), o(i, je, s), i),
                                        v = (o(l = {}, Me, n ? s : c), o(l, ke, n ? c : s), o(l, je, f), o(l, xe, f), l),
                                        m = (o(u = {}, Ie, c), o(u, je, s), o(u, xe, f), o(u, Re, d), o(u, Me, n ? f : d), o(u, ke, n ? d : f), u);
                                    switch (null === (a = {
                                        inline: p,
                                        horizontal: v,
                                        vertical: m,
                                        inlineSub: p,
                                        horizontalSub: m,
                                        verticalSub: m
                                    }["".concat(e).concat(t ? "" : "Sub")]) || void 0 === a ? void 0 : a[r]) {
                                        case c:
                                            return {
                                                offset: -1,
                                                sibling: !0
                                            };
                                        case s:
                                            return {
                                                offset: 1,
                                                sibling: !0
                                            };
                                        case d:
                                            return {
                                                offset: -1,
                                                sibling: !1
                                            };
                                        case f:
                                            return {
                                                offset: 1,
                                                sibling: !1
                                            };
                                        default:
                                            return null
                                    }
                                }(e, 1 === u(w, !0).length, n, m);
                            if (!O && m !== Ne && m !== Ke) return;
                            (_e.includes(m) || [Ne, Ke].includes(m)) && d.preventDefault();
                            var E = function(e) {
                                if (e) {
                                    var t = e,
                                        n = e.querySelector("a");
                                    (null === n || void 0 === n ? void 0 : n.getAttribute("href")) && (t = n);
                                    var r = h.get(e);
                                    a(r), v(), f.current = (0, se.A)((function() {
                                        p.current === r && t.focus()
                                    }))
                                }
                            };
                            if ([Ne, Ke].includes(m) || O.sibling || !C) {
                                var P, A, S = De(P = C && "inline" !== e ? function(e) {
                                    for (var t = e; t;) {
                                        if (t.getAttribute("data-menu-list")) return t;
                                        t = t.parentElement
                                    }
                                    return null
                                }(C) : i.current, y);
                                A = m === Ne ? S[0] : m === Ke ? S[S.length - 1] : Te(P, y, C, O.offset), E(A)
                            } else if (O.inlineTrigger) c(w);
                            else if (O.offset > 0) c(w, !0), v(), f.current = (0, se.A)((function() {
                                g();
                                var e = C.getAttribute("aria-controls"),
                                    t = Te(document.getElementById(e), y);
                                E(t)
                            }), 5);
                            else if (O.offset < 0) {
                                var M = u(w, !0),
                                    k = M[M.length - 2],
                                    I = b.get(k);
                                c(k, !1), E(I)
                            }
                        }
                        null === s || void 0 === s || s(d)
                    }
            }
            var Ve = Math.random().toFixed(5).toString().slice(2),
                ze = 0;
            var Fe = "__RC_UTIL_PATH_SPLIT__",
                We = function(e) {
                    return e.join(Fe)
                },
                Be = "rc-menu-more";

            function He() {
                var e = s(d.useState({}), 2)[1],
                    t = (0, d.useRef)(new Map),
                    n = (0, d.useRef)(new Map),
                    r = s(d.useState([]), 2),
                    o = r[0],
                    i = r[1],
                    l = (0, d.useRef)(0),
                    u = (0, d.useRef)(!1),
                    a = (0, d.useCallback)((function(r, o) {
                        var i = We(o);
                        n.current.set(i, r), t.current.set(r, i), l.current += 1;
                        var a, c = l.current;
                        a = function() {
                            c === l.current && (u.current || e({}))
                        }, Promise.resolve().then(a)
                    }), []),
                    f = (0, d.useCallback)((function(e, r) {
                        var o = We(r);
                        n.current.delete(o), t.current.delete(e)
                    }), []),
                    p = (0, d.useCallback)((function(e) {
                        i(e)
                    }), []),
                    v = (0, d.useCallback)((function(e, n) {
                        var r = t.current.get(e) || "",
                            i = r.split(Fe);
                        return n && o.includes(i[0]) && i.unshift(Be), i
                    }), [o]),
                    m = (0, d.useCallback)((function(e, t) {
                        return e.some((function(e) {
                            return v(e, !0).includes(t)
                        }))
                    }), [v]),
                    y = (0, d.useCallback)((function(e) {
                        var r = "".concat(t.current.get(e)).concat(Fe),
                            o = new Set;
                        return c(n.current.keys()).forEach((function(e) {
                            e.startsWith(r) && o.add(n.current.get(e))
                        })), o
                    }), []);
                return d.useEffect((function() {
                    return function() {
                        u.current = !0
                    }
                }), []), {
                    registerPath: a,
                    unregisterPath: f,
                    refreshOverflowKeys: p,
                    isSubPathKey: m,
                    getKeyPath: v,
                    getKeys: function() {
                        var e = c(t.current.keys());
                        return o.length && e.push(Be), e
                    },
                    getSubPathKeys: y
                }
            }
            var Ge = ["prefixCls", "rootClassName", "style", "className", "tabIndex", "items", "children", "direction", "id", "mode", "inlineCollapsed", "disabled", "disabledOverflow", "subMenuOpenDelay", "subMenuCloseDelay", "forceSubMenuRender", "defaultOpenKeys", "openKeys", "activeKey", "defaultActiveFirst", "selectable", "multiple", "defaultSelectedKeys", "selectedKeys", "onSelect", "onDeselect", "inlineIndent", "motion", "defaultMotions", "triggerSubMenuAction", "builtinPlacements", "itemIcon", "expandIcon", "overflowedIndicator", "overflowedIndicatorPopupClassName", "getPopupContainer", "onClick", "onOpenChange", "onKeyDown", "openAnimation", "openTransitionName", "_internalRenderMenuItem", "_internalRenderSubMenuItem"],
                Ue = [];
            var qe = ["className", "title", "eventKey", "children"],
                Xe = ["children"],
                Ye = function(e) {
                    var t = e.className,
                        n = e.title,
                        o = (e.eventKey, e.children),
                        i = f(e, qe),
                        l = d.useContext(j).prefixCls,
                        u = "".concat(l, "-item-group");
                    return d.createElement("li", r({}, i, {
                        onClick: function(e) {
                            return e.stopPropagation()
                        },
                        className: v()(u, t)
                    }), d.createElement("div", {
                        className: "".concat(u, "-title"),
                        title: "string" === typeof n ? n : void 0
                    }, n), d.createElement("ul", {
                        className: "".concat(u, "-list")
                    }, o))
                };

            function $e(e) {
                var t = e.children,
                    n = f(e, Xe),
                    r = te(t, F(n.eventKey));
                return V() ? r : d.createElement(Ye, (0, M.A)(n, ["warnKey"]), r)
            }

            function Je(e) {
                var t = e.className,
                    n = e.style,
                    r = d.useContext(j).prefixCls;
                return V() ? null : d.createElement("li", {
                    className: v()("".concat(r, "-item-divider"), t),
                    style: n
                })
            }
            var Qe = F,
                Ze = d.forwardRef((function(e, t) {
                    var n, i, u = e.prefixCls,
                        a = void 0 === u ? "rc-menu" : u,
                        p = e.rootClassName,
                        m = e.style,
                        h = e.className,
                        C = e.tabIndex,
                        w = void 0 === C ? 0 : C,
                        O = e.items,
                        E = e.children,
                        P = e.direction,
                        A = e.id,
                        S = e.mode,
                        M = void 0 === S ? "vertical" : S,
                        k = e.inlineCollapsed,
                        I = e.disabled,
                        j = e.disabledOverflow,
                        R = e.subMenuOpenDelay,
                        N = void 0 === R ? .1 : R,
                        _ = e.subMenuCloseDelay,
                        D = void 0 === _ ? .1 : _,
                        T = e.forceSubMenuRender,
                        V = e.defaultOpenKeys,
                        z = e.openKeys,
                        F = e.activeKey,
                        H = e.defaultActiveFirst,
                        G = e.selectable,
                        q = void 0 === G || G,
                        X = e.multiple,
                        Y = void 0 !== X && X,
                        $ = e.defaultSelectedKeys,
                        J = e.selectedKeys,
                        Z = e.onSelect,
                        ee = e.onDeselect,
                        te = e.inlineIndent,
                        ne = void 0 === te ? 24 : te,
                        ie = e.motion,
                        le = e.defaultMotions,
                        ue = e.triggerSubMenuAction,
                        ae = void 0 === ue ? "hover" : ue,
                        ce = e.builtinPlacements,
                        se = e.itemIcon,
                        fe = e.expandIcon,
                        de = e.overflowedIndicator,
                        pe = void 0 === de ? "..." : de,
                        ve = e.overflowedIndicatorPopupClassName,
                        me = e.getPopupContainer,
                        ye = e.onClick,
                        be = e.onOpenChange,
                        he = e.onKeyDown,
                        ge = (e.openAnimation, e.openTransitionName, e._internalRenderMenuItem),
                        Ce = e._internalRenderSubMenuItem,
                        we = f(e, Ge),
                        Ee = d.useMemo((function() {
                            return re(E, O, Ue)
                        }), [E, O]),
                        Pe = s(d.useState(!1), 2),
                        Ae = Pe[0],
                        Se = Pe[1],
                        Me = d.useRef();
                    (0, d.useImperativeHandle)(t, (function() {
                        return {
                            list: Me.current,
                            focus: function(e) {
                                var t;
                                null === (t = Me.current) || void 0 === t || t.focus(e)
                            }
                        }
                    }));
                    var ke = function(e) {
                            var t = s((0, b.A)(e, {
                                    value: e
                                }), 2),
                                n = t[0],
                                r = t[1];
                            return d.useEffect((function() {
                                ze += 1;
                                var e = "".concat(Ve, "-").concat(ze);
                                r("rc-menu-uuid-".concat(e))
                            }), []), n
                        }(A),
                        Ie = "rtl" === P;
                    var je = s(d.useMemo((function() {
                            return "inline" !== M && "vertical" !== M || !k ? [M, !1] : ["vertical", k]
                        }), [M, k]), 2),
                        xe = je[0],
                        Re = je[1],
                        Ne = s(d.useState(0), 2),
                        Ke = Ne[0],
                        _e = Ne[1],
                        De = Ke >= Ee.length - 1 || "horizontal" !== xe || j,
                        Te = s((0, b.A)(V, {
                            value: z,
                            postState: function(e) {
                                return e || Ue
                            }
                        }), 2),
                        Fe = Te[0],
                        We = Te[1],
                        qe = function(e) {
                            We(e), null === be || void 0 === be || be(e)
                        },
                        Xe = s(d.useState(Fe), 2),
                        Ye = Xe[0],
                        $e = Xe[1],
                        Je = "inline" === xe,
                        Qe = d.useRef(!1);
                    d.useEffect((function() {
                        Je && $e(Fe)
                    }), [Fe]), d.useEffect((function() {
                        Qe.current ? Je ? We(Ye) : qe(Ue) : Qe.current = !0
                    }), [Je]);
                    var Ze = He(),
                        et = Ze.registerPath,
                        tt = Ze.unregisterPath,
                        nt = Ze.refreshOverflowKeys,
                        rt = Ze.isSubPathKey,
                        ot = Ze.getKeyPath,
                        it = Ze.getKeys,
                        lt = Ze.getSubPathKeys,
                        ut = d.useMemo((function() {
                            return {
                                registerPath: et,
                                unregisterPath: tt
                            }
                        }), [et, tt]),
                        at = d.useMemo((function() {
                            return {
                                isSubPathKey: rt
                            }
                        }), [rt]);
                    d.useEffect((function() {
                        nt(De ? Ue : Ee.slice(Ke + 1).map((function(e) {
                            return e.key
                        })))
                    }), [Ke, De]);
                    var ct = s((0, b.A)(F || H && (null === (n = Ee[0]) || void 0 === n ? void 0 : n.key), {
                            value: F
                        }), 2),
                        st = ct[0],
                        ft = ct[1],
                        dt = oe((function(e) {
                            ft(e)
                        })),
                        pt = oe((function() {
                            ft(void 0)
                        })),
                        vt = s((0, b.A)($ || [], {
                            value: J,
                            postState: function(e) {
                                return Array.isArray(e) ? e : null === e || void 0 === e ? Ue : [e]
                            }
                        }), 2),
                        mt = vt[0],
                        yt = vt[1],
                        bt = oe((function(e) {
                            null === ye || void 0 === ye || ye(K(e)),
                                function(e) {
                                    if (q) {
                                        var t, n = e.key,
                                            r = mt.includes(n);
                                        t = Y ? r ? mt.filter((function(e) {
                                            return e !== n
                                        })) : [].concat(c(mt), [n]) : [n], yt(t);
                                        var o = l(l({}, e), {}, {
                                            selectedKeys: t
                                        });
                                        r ? null === ee || void 0 === ee || ee(o) : null === Z || void 0 === Z || Z(o)
                                    }!Y && Fe.length && "inline" !== xe && qe(Ue)
                                }(e)
                        })),
                        ht = oe((function(e, t) {
                            var n = Fe.filter((function(t) {
                                return t !== e
                            }));
                            if (t) n.push(e);
                            else if ("inline" !== xe) {
                                var r = lt(e);
                                n = n.filter((function(e) {
                                    return !r.has(e)
                                }))
                            }
                            y()(Fe, n) || qe(n)
                        })),
                        gt = oe(me),
                        Ct = Le(xe, st, Ie, ke, Me, it, ot, ft, (function(e, t) {
                            var n = null !== t && void 0 !== t ? t : !Fe.includes(e);
                            ht(e, n)
                        }), he);
                    d.useEffect((function() {
                        Se(!0)
                    }), []);
                    var wt = d.useMemo((function() {
                            return {
                                _internalRenderMenuItem: ge,
                                _internalRenderSubMenuItem: Ce
                            }
                        }), [ge, Ce]),
                        Ot = "horizontal" !== xe || j ? Ee : Ee.map((function(e, t) {
                            return d.createElement(x, {
                                key: e.key,
                                overflowDisabled: t > Ke
                            }, e)
                        })),
                        Et = d.createElement(g.A, r({
                            id: A,
                            ref: Me,
                            prefixCls: "".concat(a, "-overflow"),
                            component: "ul",
                            itemComponent: Q,
                            className: v()(a, "".concat(a, "-root"), "".concat(a, "-").concat(xe), h, (i = {}, o(i, "".concat(a, "-inline-collapsed"), Re), o(i, "".concat(a, "-rtl"), Ie), i), p),
                            dir: P,
                            style: m,
                            role: "menu",
                            tabIndex: w,
                            data: Ot,
                            renderRawItem: function(e) {
                                return e
                            },
                            renderRawRest: function(e) {
                                var t = e.length,
                                    n = t ? Ee.slice(-t) : null;
                                return d.createElement(Oe, {
                                    eventKey: Be,
                                    title: pe,
                                    disabled: De,
                                    internalPopupClose: 0 === t,
                                    popupClassName: ve
                                }, n)
                            },
                            maxCount: "horizontal" !== xe || j ? g.A.INVALIDATE : g.A.RESPONSIVE,
                            ssr: "full",
                            "data-menu-list": !0,
                            onVisibleChange: function(e) {
                                _e(e)
                            },
                            onKeyDown: Ct
                        }, we));
                    return d.createElement(U.Provider, {
                        value: wt
                    }, d.createElement(B.Provider, {
                        value: ke
                    }, d.createElement(x, {
                        prefixCls: a,
                        rootClassName: p,
                        mode: xe,
                        openKeys: Fe,
                        rtl: Ie,
                        disabled: I,
                        motion: Ae ? ie : null,
                        defaultMotions: Ae ? le : null,
                        activeKey: st,
                        onActive: dt,
                        onInactive: pt,
                        selectedKeys: mt,
                        inlineIndent: ne,
                        subMenuOpenDelay: N,
                        subMenuCloseDelay: D,
                        forceSubMenuRender: T,
                        builtinPlacements: ce,
                        triggerSubMenuAction: ae,
                        getPopupContainer: gt,
                        itemIcon: se,
                        expandIcon: fe,
                        onItemClick: bt,
                        onOpenChange: ht
                    }, d.createElement(W.Provider, {
                        value: at
                    }, Et), d.createElement("div", {
                        style: {
                            display: "none"
                        },
                        "aria-hidden": !0
                    }, d.createElement(L.Provider, {
                        value: ut
                    }, Ee)))))
                }));
            Ze.Item = Q, Ze.SubMenu = Oe, Ze.ItemGroup = $e, Ze.Divider = Je;
            const et = Ze
        }
    }
]);
//# sourceMappingURL=11115.757843a6.chunk.js.map