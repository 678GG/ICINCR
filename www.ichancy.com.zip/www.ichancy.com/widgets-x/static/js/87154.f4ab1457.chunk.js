"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [87154], {
        787154: (o, t, s) => {
            s.d(t, {
                Bo: () => h,
                JX: () => f,
                Ti: () => u,
                dZ: () => k,
                pi: () => p,
                s0: () => c,
                so: () => i,
                uG: () => _
            });
            var b = s(55418),
                e = s(179177);
            const k = (0, b.F)() ? 32 : 40,
                p = 1014,
                _ = 1013,
                h = 1012,
                i = 1011,
                u = 10001,
                c = e.Ay.IS_RTL ? "bottomRight" : "bottomLeft",
                f = e.Ay.IS_RTL ? "bottomLeft" : "bottomRight"
        }
    }
]);
//# sourceMappingURL=87154.f4ab1457.chunk.js.map