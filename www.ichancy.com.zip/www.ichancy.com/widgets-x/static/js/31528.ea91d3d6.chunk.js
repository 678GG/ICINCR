/*! For license information please see 31528.ea91d3d6.chunk.js.LICENSE.txt */
"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [31528, 13439], {
        731528: (t, e, n) => {
            function o(t, e, n) {
                return e in t ? Object.defineProperty(t, e, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = n, t
            }

            function r(t, e) {
                var n = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(t);
                    e && (o = o.filter((function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable
                    }))), n.push.apply(n, o)
                }
                return n
            }

            function i(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? r(Object(n), !0).forEach((function(e) {
                        o(t, e, n[e])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : r(Object(n)).forEach((function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
                    }))
                }
                return t
            }

            function a() {
                return a = Object.assign || function(t) {
                    for (var e = 1; e < arguments.length; e++) {
                        var n = arguments[e];
                        for (var o in n) Object.prototype.hasOwnProperty.call(n, o) && (t[o] = n[o])
                    }
                    return t
                }, a.apply(this, arguments)
            }

            function u(t, e) {
                for (var n = 0; n < e.length; n++) {
                    var o = e[n];
                    o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(t, o.key, o)
                }
            }

            function s(t) {
                if (void 0 === t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                return t
            }

            function c(t, e) {
                return c = Object.setPrototypeOf || function(t, e) {
                    return t.__proto__ = e, t
                }, c(t, e)
            }

            function l(t) {
                return l = Object.setPrototypeOf ? Object.getPrototypeOf : function(t) {
                    return t.__proto__ || Object.getPrototypeOf(t)
                }, l(t)
            }

            function f(t) {
                return f = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                    return typeof t
                } : function(t) {
                    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
                }, f(t)
            }

            function p(t) {
                var e = function() {
                    if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" === typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (t) {
                        return !1
                    }
                }();
                return function() {
                    var n, o = l(t);
                    if (e) {
                        var r = l(this).constructor;
                        n = Reflect.construct(o, arguments, r)
                    } else n = o.apply(this, arguments);
                    return function(t, e) {
                        if (e && ("object" === f(e) || "function" === typeof e)) return e;
                        if (void 0 !== e) throw new TypeError("Derived constructors may only return object or undefined");
                        return s(t)
                    }(this, n)
                }
            }
            n.d(e, {
                A: () => de
            });
            var h = n(365043),
                d = n(297950),
                v = n(445818),
                m = n(223739),
                y = n(925593),
                g = n(113758),
                b = n(504903),
                w = n(716417),
                O = n(498139),
                x = n.n(O);

            function T(t, e, n) {
                return n ? t[0] === e[0] : t[0] === e[0] && t[1] === e[1]
            }

            function E(t, e) {
                (null == e || e > t.length) && (e = t.length);
                for (var n = 0, o = new Array(e); n < e; n++) o[n] = t[n];
                return o
            }

            function M(t, e) {
                return function(t) {
                    if (Array.isArray(t)) return t
                }(t) || function(t, e) {
                    var n = null == t ? null : "undefined" !== typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
                    if (null != n) {
                        var o, r, i = [],
                            a = !0,
                            u = !1;
                        try {
                            for (n = n.call(t); !(a = (o = n.next()).done) && (i.push(o.value), !e || i.length !== e); a = !0);
                        } catch (s) {
                            u = !0, r = s
                        } finally {
                            try {
                                a || null == n.return || n.return()
                            } finally {
                                if (u) throw r
                            }
                        }
                        return i
                    }
                }(t, e) || function(t, e) {
                    if (t) {
                        if ("string" === typeof t) return E(t, e);
                        var n = Object.prototype.toString.call(t).slice(8, -1);
                        return "Object" === n && t.constructor && (n = t.constructor.name), "Map" === n || "Set" === n ? Array.from(t) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? E(t, e) : void 0
                    }
                }(t, e) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function k(t, e) {
                if (null == t) return {};
                var n, o, r = function(t, e) {
                    if (null == t) return {};
                    var n, o, r = {},
                        i = Object.keys(t);
                    for (o = 0; o < i.length; o++) n = i[o], e.indexOf(n) >= 0 || (r[n] = t[n]);
                    return r
                }(t, e);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(t);
                    for (o = 0; o < i.length; o++) n = i[o], e.indexOf(n) >= 0 || Object.prototype.propertyIsEnumerable.call(t, n) && (r[n] = t[n])
                }
                return r
            }
            var C, P = n(816765),
                _ = n(85301);

            function A(t) {
                var e = t.prefixCls,
                    n = t.motion,
                    o = t.animation,
                    r = t.transitionName;
                return n || (o ? {
                    motionName: "".concat(e, "-").concat(o)
                } : r ? {
                    motionName: r
                } : null)
            }

            function S(t) {
                var e = t.prefixCls,
                    n = t.visible,
                    o = t.zIndex,
                    r = t.mask,
                    u = t.maskMotion,
                    s = t.maskAnimation,
                    c = t.maskTransitionName;
                if (!r) return null;
                var l = {};
                return (u || c || s) && (l = i({
                    motionAppear: !0
                }, A({
                    motion: u,
                    prefixCls: e,
                    transitionName: c,
                    animation: s
                }))), h.createElement(_.default, a({}, l, {
                    visible: n,
                    removeOnLeave: !0
                }), (function(t) {
                    var n = t.className;
                    return h.createElement("div", {
                        style: {
                            zIndex: o
                        },
                        className: x()("".concat(e, "-mask"), n)
                    })
                }))
            }

            function D(t, e) {
                (null == e || e > t.length) && (e = t.length);
                for (var n = 0, o = new Array(e); n < e; n++) o[n] = t[n];
                return o
            }

            function j(t, e) {
                return function(t) {
                    if (Array.isArray(t)) return t
                }(t) || function(t, e) {
                    var n = null == t ? null : "undefined" !== typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
                    if (null != n) {
                        var o, r, i = [],
                            a = !0,
                            u = !1;
                        try {
                            for (n = n.call(t); !(a = (o = n.next()).done) && (i.push(o.value), !e || i.length !== e); a = !0);
                        } catch (s) {
                            u = !0, r = s
                        } finally {
                            try {
                                a || null == n.return || n.return()
                            } finally {
                                if (u) throw r
                            }
                        }
                        return i
                    }
                }(t, e) || function(t, e) {
                    if (t) {
                        if ("string" === typeof t) return D(t, e);
                        var n = Object.prototype.toString.call(t).slice(8, -1);
                        return "Object" === n && t.constructor && (n = t.constructor.name), "Map" === n || "Set" === n ? Array.from(t) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? D(t, e) : void 0
                    }
                }(t, e) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function R(t) {
                return R = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                    return typeof t
                } : function(t) {
                    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
                }, R(t)
            }

            function L(t, e) {
                var n = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(t);
                    e && (o = o.filter((function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable
                    }))), n.push.apply(n, o)
                }
                return n
            }

            function H(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? L(Object(n), !0).forEach((function(e) {
                        V(t, e, n[e])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : L(Object(n)).forEach((function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
                    }))
                }
                return t
            }

            function N(t) {
                return N = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                    return typeof t
                } : function(t) {
                    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
                }, N(t)
            }

            function V(t, e, n) {
                return e in t ? Object.defineProperty(t, e, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = n, t
            }
            var W = {
                Webkit: "-webkit-",
                Moz: "-moz-",
                ms: "-ms-",
                O: "-o-"
            };

            function B() {
                if (void 0 !== C) return C;
                C = "";
                var t = document.createElement("p").style;
                for (var e in W) e + "Transform" in t && (C = e);
                return C
            }

            function F() {
                return B() ? "".concat(B(), "TransitionProperty") : "transitionProperty"
            }

            function z() {
                return B() ? "".concat(B(), "Transform") : "transform"
            }

            function I(t, e) {
                var n = F();
                n && (t.style[n] = e, "transitionProperty" !== n && (t.style.transitionProperty = e))
            }

            function Y(t, e) {
                var n = z();
                n && (t.style[n] = e, "transform" !== n && (t.style.transform = e))
            }
            var X, G = /matrix\((.*)\)/,
                U = /matrix3d\((.*)\)/;

            function q(t) {
                var e = t.style.display;
                t.style.display = "none", t.offsetHeight, t.style.display = e
            }

            function $(t, e, n) {
                var o = n;
                if ("object" !== N(e)) return "undefined" !== typeof o ? ("number" === typeof o && (o = "".concat(o, "px")), void(t.style[e] = o)) : X(t, e);
                for (var r in e) e.hasOwnProperty(r) && $(t, r, e[r])
            }

            function K(t, e) {
                var n = t["page".concat(e ? "Y" : "X", "Offset")],
                    o = "scroll".concat(e ? "Top" : "Left");
                if ("number" !== typeof n) {
                    var r = t.document;
                    "number" !== typeof(n = r.documentElement[o]) && (n = r.body[o])
                }
                return n
            }

            function Z(t) {
                return K(t)
            }

            function J(t) {
                return K(t, !0)
            }

            function Q(t) {
                var e = function(t) {
                        var e, n, o, r = t.ownerDocument,
                            i = r.body,
                            a = r && r.documentElement;
                        return e = t.getBoundingClientRect(), n = Math.floor(e.left), o = Math.floor(e.top), {
                            left: n -= a.clientLeft || i.clientLeft || 0,
                            top: o -= a.clientTop || i.clientTop || 0
                        }
                    }(t),
                    n = t.ownerDocument,
                    o = n.defaultView || n.parentWindow;
                return e.left += Z(o), e.top += J(o), e
            }

            function tt(t) {
                return null !== t && void 0 !== t && t == t.window
            }

            function et(t) {
                return tt(t) ? t.document : 9 === t.nodeType ? t : t.ownerDocument
            }
            var nt = new RegExp("^(".concat(/[\-+]?(?:\d*\.|)\d+(?:[eE][\-+]?\d+|)/.source, ")(?!px)[a-z%]+$"), "i"),
                ot = /^(top|right|bottom|left)$/,
                rt = "currentStyle",
                it = "runtimeStyle",
                at = "left";

            function ut(t, e) {
                return "left" === t ? e.useCssRight ? "right" : t : e.useCssBottom ? "bottom" : t
            }

            function st(t) {
                return "left" === t ? "right" : "right" === t ? "left" : "top" === t ? "bottom" : "bottom" === t ? "top" : void 0
            }

            function ct(t, e, n) {
                "static" === $(t, "position") && (t.style.position = "relative");
                var o = -999,
                    r = -999,
                    i = ut("left", n),
                    a = ut("top", n),
                    u = st(i),
                    s = st(a);
                "left" !== i && (o = 999), "top" !== a && (r = 999);
                var c, l = "",
                    f = Q(t);
                ("left" in e || "top" in e) && (l = (c = t).style.transitionProperty || c.style[F()] || "", I(t, "none")), "left" in e && (t.style[u] = "", t.style[i] = "".concat(o, "px")), "top" in e && (t.style[s] = "", t.style[a] = "".concat(r, "px")), q(t);
                var p = Q(t),
                    h = {};
                for (var d in e)
                    if (e.hasOwnProperty(d)) {
                        var v = ut(d, n),
                            m = "left" === d ? o : r,
                            y = f[d] - p[d];
                        h[v] = v === d ? m + y : m - y
                    }
                $(t, h), q(t), ("left" in e || "top" in e) && I(t, l);
                var g = {};
                for (var b in e)
                    if (e.hasOwnProperty(b)) {
                        var w = ut(b, n),
                            O = e[b] - f[b];
                        g[w] = b === w ? h[w] + O : h[w] - O
                    }
                $(t, g)
            }

            function lt(t, e) {
                var n = Q(t),
                    o = function(t) {
                        var e = window.getComputedStyle(t, null),
                            n = e.getPropertyValue("transform") || e.getPropertyValue(z());
                        if (n && "none" !== n) {
                            var o = n.replace(/[^0-9\-.,]/g, "").split(",");
                            return {
                                x: parseFloat(o[12] || o[4], 0),
                                y: parseFloat(o[13] || o[5], 0)
                            }
                        }
                        return {
                            x: 0,
                            y: 0
                        }
                    }(t),
                    r = {
                        x: o.x,
                        y: o.y
                    };
                "left" in e && (r.x = o.x + e.left - n.left), "top" in e && (r.y = o.y + e.top - n.top),
                    function(t, e) {
                        var n = window.getComputedStyle(t, null),
                            o = n.getPropertyValue("transform") || n.getPropertyValue(z());
                        if (o && "none" !== o) {
                            var r, i = o.match(G);
                            i ? ((r = (i = i[1]).split(",").map((function(t) {
                                return parseFloat(t, 10)
                            })))[4] = e.x, r[5] = e.y, Y(t, "matrix(".concat(r.join(","), ")"))) : ((r = o.match(U)[1].split(",").map((function(t) {
                                return parseFloat(t, 10)
                            })))[12] = e.x, r[13] = e.y, Y(t, "matrix3d(".concat(r.join(","), ")")))
                        } else Y(t, "translateX(".concat(e.x, "px) translateY(").concat(e.y, "px) translateZ(0)"))
                    }(t, r)
            }

            function ft(t, e) {
                for (var n = 0; n < t.length; n++) e(t[n])
            }

            function pt(t) {
                return "border-box" === X(t, "boxSizing")
            }
            "undefined" !== typeof window && (X = window.getComputedStyle ? function(t, e, n) {
                var o = n,
                    r = "",
                    i = et(t);
                return (o = o || i.defaultView.getComputedStyle(t, null)) && (r = o.getPropertyValue(e) || o[e]), r
            } : function(t, e) {
                var n = t[rt] && t[rt][e];
                if (nt.test(n) && !ot.test(e)) {
                    var o = t.style,
                        r = o[at],
                        i = t[it][at];
                    t[it][at] = t[rt][at], o[at] = "fontSize" === e ? "1em" : n || 0, n = o.pixelLeft + "px", o[at] = r, t[it][at] = i
                }
                return "" === n ? "auto" : n
            });
            var ht = ["margin", "border", "padding"],
                dt = -1,
                vt = 2,
                mt = 1;

            function yt(t, e, n) {
                var o, r, i, a = 0;
                for (r = 0; r < e.length; r++)
                    if (o = e[r])
                        for (i = 0; i < n.length; i++) {
                            var u = void 0;
                            u = "border" === o ? "".concat(o).concat(n[i], "Width") : o + n[i], a += parseFloat(X(t, u)) || 0
                        }
                return a
            }
            var gt = {
                getParent: function(t) {
                    var e = t;
                    do {
                        e = 11 === e.nodeType && e.host ? e.host : e.parentNode
                    } while (e && 1 !== e.nodeType && 9 !== e.nodeType);
                    return e
                }
            };

            function bt(t, e, n) {
                var o = n;
                if (tt(t)) return "width" === e ? gt.viewportWidth(t) : gt.viewportHeight(t);
                if (9 === t.nodeType) return "width" === e ? gt.docWidth(t) : gt.docHeight(t);
                var r = "width" === e ? ["Left", "Right"] : ["Top", "Bottom"],
                    i = "width" === e ? Math.floor(t.getBoundingClientRect().width) : Math.floor(t.getBoundingClientRect().height),
                    a = pt(t),
                    u = 0;
                (null === i || void 0 === i || i <= 0) && (i = void 0, (null === (u = X(t, e)) || void 0 === u || Number(u) < 0) && (u = t.style[e] || 0), u = Math.floor(parseFloat(u)) || 0), void 0 === o && (o = a ? mt : dt);
                var s = void 0 !== i || a,
                    c = i || u;
                return o === dt ? s ? c - yt(t, ["border", "padding"], r) : u : s ? o === mt ? c : c + (o === vt ? -yt(t, ["border"], r) : yt(t, ["margin"], r)) : u + yt(t, ht.slice(o), r)
            }
            ft(["Width", "Height"], (function(t) {
                gt["doc".concat(t)] = function(e) {
                    var n = e.document;
                    return Math.max(n.documentElement["scroll".concat(t)], n.body["scroll".concat(t)], gt["viewport".concat(t)](n))
                }, gt["viewport".concat(t)] = function(e) {
                    var n = "client".concat(t),
                        o = e.document,
                        r = o.body,
                        i = o.documentElement[n];
                    return "CSS1Compat" === o.compatMode && i || r && r[n] || i
                }
            }));
            var wt = {
                position: "absolute",
                visibility: "hidden",
                display: "block"
            };

            function Ot() {
                for (var t = arguments.length, e = new Array(t), n = 0; n < t; n++) e[n] = arguments[n];
                var o, r = e[0];
                return 0 !== r.offsetWidth ? o = bt.apply(void 0, e) : function(t, e, n) {
                    var o, r = {},
                        i = t.style;
                    for (o in e) e.hasOwnProperty(o) && (r[o] = i[o], i[o] = e[o]);
                    for (o in n.call(t), e) e.hasOwnProperty(o) && (i[o] = r[o])
                }(r, wt, (function() {
                    o = bt.apply(void 0, e)
                })), o
            }

            function xt(t, e) {
                for (var n in e) e.hasOwnProperty(n) && (t[n] = e[n]);
                return t
            }
            ft(["width", "height"], (function(t) {
                var e = t.charAt(0).toUpperCase() + t.slice(1);
                gt["outer".concat(e)] = function(e, n) {
                    return e && Ot(e, t, n ? 0 : mt)
                };
                var n = "width" === t ? ["Left", "Right"] : ["Top", "Bottom"];
                gt[t] = function(e, o) {
                    var r = o;
                    return void 0 !== r ? e ? (pt(e) && (r += yt(e, ["padding", "border"], n)), $(e, t, r)) : void 0 : e && Ot(e, t, dt)
                }
            }));
            var Tt = {
                getWindow: function(t) {
                    if (t && t.document && t.setTimeout) return t;
                    var e = t.ownerDocument || t;
                    return e.defaultView || e.parentWindow
                },
                getDocument: et,
                offset: function(t, e, n) {
                    if ("undefined" === typeof e) return Q(t);
                    ! function(t, e, n) {
                        if (n.ignoreShake) {
                            var o = Q(t),
                                r = o.left.toFixed(0),
                                i = o.top.toFixed(0),
                                a = e.left.toFixed(0),
                                u = e.top.toFixed(0);
                            if (r === a && i === u) return
                        }
                        n.useCssRight || n.useCssBottom ? ct(t, e, n) : n.useCssTransform && z() in document.body.style ? lt(t, e) : ct(t, e, n)
                    }(t, e, n || {})
                },
                isWindow: tt,
                each: ft,
                css: $,
                clone: function(t) {
                    var e, n = {};
                    for (e in t) t.hasOwnProperty(e) && (n[e] = t[e]);
                    if (t.overflow)
                        for (e in t) t.hasOwnProperty(e) && (n.overflow[e] = t.overflow[e]);
                    return n
                },
                mix: xt,
                getWindowScrollLeft: function(t) {
                    return Z(t)
                },
                getWindowScrollTop: function(t) {
                    return J(t)
                },
                merge: function() {
                    for (var t = {}, e = 0; e < arguments.length; e++) Tt.mix(t, e < 0 || arguments.length <= e ? void 0 : arguments[e]);
                    return t
                },
                viewportWidth: 0,
                viewportHeight: 0
            };
            xt(Tt, gt);
            var Et = Tt.getParent;

            function Mt(t) {
                if (Tt.isWindow(t) || 9 === t.nodeType) return null;
                var e, n = Tt.getDocument(t).body,
                    o = Tt.css(t, "position");
                if (!("fixed" === o || "absolute" === o)) return "html" === t.nodeName.toLowerCase() ? null : Et(t);
                for (e = Et(t); e && e !== n && 9 !== e.nodeType; e = Et(e))
                    if ("static" !== (o = Tt.css(e, "position"))) return e;
                return null
            }
            var kt = Tt.getParent;

            function Ct(t, e) {
                for (var n = {
                        left: 0,
                        right: 1 / 0,
                        top: 0,
                        bottom: 1 / 0
                    }, o = Mt(t), r = Tt.getDocument(t), i = r.defaultView || r.parentWindow, a = r.body, u = r.documentElement; o;) {
                    if (-1 !== navigator.userAgent.indexOf("MSIE") && 0 === o.clientWidth || o === a || o === u || "visible" === Tt.css(o, "overflow")) {
                        if (o === a || o === u) break
                    } else {
                        var s = Tt.offset(o);
                        s.left += o.clientLeft, s.top += o.clientTop, n.top = Math.max(n.top, s.top), n.right = Math.min(n.right, s.left + o.clientWidth), n.bottom = Math.min(n.bottom, s.top + o.clientHeight), n.left = Math.max(n.left, s.left)
                    }
                    o = Mt(o)
                }
                var c = null;
                Tt.isWindow(t) || 9 === t.nodeType || (c = t.style.position, "absolute" === Tt.css(t, "position") && (t.style.position = "fixed"));
                var l = Tt.getWindowScrollLeft(i),
                    f = Tt.getWindowScrollTop(i),
                    p = Tt.viewportWidth(i),
                    h = Tt.viewportHeight(i),
                    d = u.scrollWidth,
                    v = u.scrollHeight,
                    m = window.getComputedStyle(a);
                if ("hidden" === m.overflowX && (d = i.innerWidth), "hidden" === m.overflowY && (v = i.innerHeight), t.style && (t.style.position = c), e || function(t) {
                        if (Tt.isWindow(t) || 9 === t.nodeType) return !1;
                        var e = Tt.getDocument(t),
                            n = e.body,
                            o = null;
                        for (o = kt(t); o && o !== n && o !== e; o = kt(o))
                            if ("fixed" === Tt.css(o, "position")) return !0;
                        return !1
                    }(t)) n.left = Math.max(n.left, l), n.top = Math.max(n.top, f), n.right = Math.min(n.right, l + p), n.bottom = Math.min(n.bottom, f + h);
                else {
                    var y = Math.max(d, l + p);
                    n.right = Math.min(n.right, y);
                    var g = Math.max(v, f + h);
                    n.bottom = Math.min(n.bottom, g)
                }
                return n.top >= 0 && n.left >= 0 && n.bottom > n.top && n.right > n.left ? n : null
            }

            function Pt(t) {
                var e, n, o;
                if (Tt.isWindow(t) || 9 === t.nodeType) {
                    var r = Tt.getWindow(t);
                    e = {
                        left: Tt.getWindowScrollLeft(r),
                        top: Tt.getWindowScrollTop(r)
                    }, n = Tt.viewportWidth(r), o = Tt.viewportHeight(r)
                } else e = Tt.offset(t), n = Tt.outerWidth(t), o = Tt.outerHeight(t);
                return e.width = n, e.height = o, e
            }

            function _t(t, e) {
                var n = e.charAt(0),
                    o = e.charAt(1),
                    r = t.width,
                    i = t.height,
                    a = t.left,
                    u = t.top;
                return "c" === n ? u += i / 2 : "b" === n && (u += i), "c" === o ? a += r / 2 : "r" === o && (a += r), {
                    left: a,
                    top: u
                }
            }

            function At(t, e, n, o, r) {
                var i = _t(e, n[1]),
                    a = _t(t, n[0]),
                    u = [a.left - i.left, a.top - i.top];
                return {
                    left: Math.round(t.left - u[0] + o[0] - r[0]),
                    top: Math.round(t.top - u[1] + o[1] - r[1])
                }
            }

            function St(t, e, n) {
                return t.left < n.left || t.left + e.width > n.right
            }

            function Dt(t, e, n) {
                return t.top < n.top || t.top + e.height > n.bottom
            }

            function jt(t, e, n) {
                var o = [];
                return Tt.each(t, (function(t) {
                    o.push(t.replace(e, (function(t) {
                        return n[t]
                    })))
                })), o
            }

            function Rt(t, e) {
                return t[e] = -t[e], t
            }

            function Lt(t, e) {
                return (/%$/.test(t) ? parseInt(t.substring(0, t.length - 1), 10) / 100 * e : parseInt(t, 10)) || 0
            }

            function Ht(t, e) {
                t[0] = Lt(t[0], e.width), t[1] = Lt(t[1], e.height)
            }

            function Nt(t, e, n, o) {
                var r = n.points,
                    i = n.offset || [0, 0],
                    a = n.targetOffset || [0, 0],
                    u = n.overflow,
                    s = n.source || t;
                i = [].concat(i), a = [].concat(a);
                var c = {},
                    l = 0,
                    f = Ct(s, !(!(u = u || {}) || !u.alwaysByViewport)),
                    p = Pt(s);
                Ht(i, p), Ht(a, e);
                var h = At(p, e, r, i, a),
                    d = Tt.merge(p, h);
                if (f && (u.adjustX || u.adjustY) && o) {
                    if (u.adjustX && St(h, p, f)) {
                        var v = jt(r, /[lr]/gi, {
                                l: "r",
                                r: "l"
                            }),
                            m = Rt(i, 0),
                            y = Rt(a, 0);
                        (function(t, e, n) {
                            return t.left > n.right || t.left + e.width < n.left
                        })(At(p, e, v, m, y), p, f) || (l = 1, r = v, i = m, a = y)
                    }
                    if (u.adjustY && Dt(h, p, f)) {
                        var g = jt(r, /[tb]/gi, {
                                t: "b",
                                b: "t"
                            }),
                            b = Rt(i, 1),
                            w = Rt(a, 1);
                        (function(t, e, n) {
                            return t.top > n.bottom || t.top + e.height < n.top
                        })(At(p, e, g, b, w), p, f) || (l = 1, r = g, i = b, a = w)
                    }
                    l && (h = At(p, e, r, i, a), Tt.mix(d, h));
                    var O = St(h, p, f),
                        x = Dt(h, p, f);
                    if (O || x) {
                        var T = r;
                        O && (T = jt(r, /[lr]/gi, {
                            l: "r",
                            r: "l"
                        })), x && (T = jt(r, /[tb]/gi, {
                            t: "b",
                            b: "t"
                        })), r = T, i = n.offset || [0, 0], a = n.targetOffset || [0, 0]
                    }
                    c.adjustX = u.adjustX && O, c.adjustY = u.adjustY && x, (c.adjustX || c.adjustY) && (d = function(t, e, n, o) {
                        var r = Tt.clone(t),
                            i = {
                                width: e.width,
                                height: e.height
                            };
                        return o.adjustX && r.left < n.left && (r.left = n.left), o.resizeWidth && r.left >= n.left && r.left + i.width > n.right && (i.width -= r.left + i.width - n.right), o.adjustX && r.left + i.width > n.right && (r.left = Math.max(n.right - i.width, n.left)), o.adjustY && r.top < n.top && (r.top = n.top), o.resizeHeight && r.top >= n.top && r.top + i.height > n.bottom && (i.height -= r.top + i.height - n.bottom), o.adjustY && r.top + i.height > n.bottom && (r.top = Math.max(n.bottom - i.height, n.top)), Tt.mix(r, i)
                    }(h, p, f, c))
                }
                return d.width !== p.width && Tt.css(s, "width", Tt.width(s) + d.width - p.width), d.height !== p.height && Tt.css(s, "height", Tt.height(s) + d.height - p.height), Tt.offset(s, {
                    left: d.left,
                    top: d.top
                }, {
                    useCssRight: n.useCssRight,
                    useCssBottom: n.useCssBottom,
                    useCssTransform: n.useCssTransform,
                    ignoreShake: n.ignoreShake
                }), {
                    points: r,
                    offset: i,
                    targetOffset: a,
                    overflow: c
                }
            }

            function Vt(t, e, n) {
                var o = n.target || e,
                    r = Pt(o),
                    i = ! function(t, e) {
                        var n = Ct(t, e),
                            o = Pt(t);
                        return !n || o.left + o.width <= n.left || o.top + o.height <= n.top || o.left >= n.right || o.top >= n.bottom
                    }(o, n.overflow && n.overflow.alwaysByViewport);
                return Nt(t, r, n, i)
            }
            Vt.__getOffsetParent = Mt, Vt.__getVisibleRectForElement = Ct;
            var Wt = n(738314),
                Bt = n(297907);
            const Ft = function(t, e) {
                var n = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
                    o = new Set;
                return function t(e, r) {
                    var i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1,
                        a = o.has(e);
                    if ((0, Bt.Ay)(!a, "Warning: There may be circular references"), a) return !1;
                    if (e === r) return !0;
                    if (n && i > 1) return !1;
                    o.add(e);
                    var u = i + 1;
                    if (Array.isArray(e)) {
                        if (!Array.isArray(r) || e.length !== r.length) return !1;
                        for (var s = 0; s < e.length; s++)
                            if (!t(e[s], r[s], u)) return !1;
                        return !0
                    }
                    if (e && r && "object" === (0, Wt.A)(e) && "object" === (0, Wt.A)(r)) {
                        var c = Object.keys(e);
                        return c.length === Object.keys(r).length && c.every((function(n) {
                            return t(e[n], r[n], u)
                        }))
                    }
                    return !1
                }(t, e)
            };
            var zt = n(676590),
                It = n(152664);
            var Yt = n(535820);

            function Xt(t, e) {
                var n = null,
                    o = null;
                var r = new Yt.A((function(t) {
                    var r = j(t, 1)[0].target;
                    if (document.documentElement.contains(r)) {
                        var i = r.getBoundingClientRect(),
                            a = i.width,
                            u = i.height,
                            s = Math.floor(a),
                            c = Math.floor(u);
                        n === s && o === c || Promise.resolve().then((function() {
                            e({
                                width: s,
                                height: c
                            })
                        })), n = s, o = c
                    }
                }));
                return t && r.observe(t),
                    function() {
                        r.disconnect()
                    }
            }

            function Gt(t) {
                return "function" !== typeof t ? null : t()
            }

            function Ut(t) {
                return "object" === R(t) && t ? t : null
            }
            var qt = function(t, e) {
                    var n = t.children,
                        o = t.disabled,
                        r = t.target,
                        i = t.align,
                        a = t.onAlign,
                        u = t.monitorWindowResize,
                        s = t.monitorBufferTime,
                        c = void 0 === s ? 0 : s,
                        l = h.useRef({}),
                        f = h.useRef(),
                        p = h.Children.only(n),
                        d = h.useRef({});
                    d.current.disabled = o, d.current.target = r, d.current.align = i, d.current.onAlign = a;
                    var v = function(t, e) {
                            var n = h.useRef(!1),
                                o = h.useRef(null);

                            function r() {
                                window.clearTimeout(o.current)
                            }
                            return [function i(a) {
                                if (r(), n.current && !0 !== a) o.current = window.setTimeout((function() {
                                    n.current = !1, i()
                                }), e);
                                else {
                                    if (!1 === t(a)) return;
                                    n.current = !0, o.current = window.setTimeout((function() {
                                        n.current = !1
                                    }), e)
                                }
                            }, function() {
                                n.current = !1, r()
                            }]
                        }((function() {
                            var t = d.current,
                                e = t.disabled,
                                n = t.target,
                                o = t.align,
                                r = t.onAlign,
                                i = f.current;
                            if (!e && n && i) {
                                var a, u = Gt(n),
                                    s = Ut(n);
                                l.current.element = u, l.current.point = s, l.current.align = o;
                                var c = document.activeElement;
                                return u && (0, zt.A)(u) ? a = Vt(i, u, o) : s && (a = function(t, e, n) {
                                        var o, r, i = Tt.getDocument(t),
                                            a = i.defaultView || i.parentWindow,
                                            u = Tt.getWindowScrollLeft(a),
                                            s = Tt.getWindowScrollTop(a),
                                            c = Tt.viewportWidth(a),
                                            l = Tt.viewportHeight(a),
                                            f = {
                                                left: o = "pageX" in e ? e.pageX : u + e.clientX,
                                                top: r = "pageY" in e ? e.pageY : s + e.clientY,
                                                width: 0,
                                                height: 0
                                            },
                                            p = o >= 0 && o <= u + c && r >= 0 && r <= s + l,
                                            h = [n.points[0], "cc"];
                                        return Nt(t, f, H(H({}, n), {}, {
                                            points: h
                                        }), p)
                                    }(i, s, o)),
                                    function(t, e) {
                                        t !== document.activeElement && (0, m.A)(e, t) && "function" === typeof t.focus && t.focus()
                                    }(c, i), r && a && r(i, a), !0
                            }
                            return !1
                        }), c),
                        y = j(v, 2),
                        w = y[0],
                        O = y[1],
                        x = j(h.useState(), 2),
                        T = x[0],
                        E = x[1],
                        M = j(h.useState(), 2),
                        k = M[0],
                        C = M[1];
                    return (0, It.A)((function() {
                        E(Gt(r)), C(Ut(r))
                    })), h.useEffect((function() {
                        var t, e;
                        l.current.element === T && ((t = l.current.point) === (e = k) || t && e && ("pageX" in e && "pageY" in e ? t.pageX === e.pageX && t.pageY === e.pageY : "clientX" in e && "clientY" in e && t.clientX === e.clientX && t.clientY === e.clientY)) && Ft(l.current.align, i) || w()
                    })), h.useEffect((function() {
                        return Xt(f.current, w)
                    }), [f.current]), h.useEffect((function() {
                        return Xt(T, w)
                    }), [T]), h.useEffect((function() {
                        o ? O() : w()
                    }), [o]), h.useEffect((function() {
                        if (u) return (0, b.A)(window, "resize", w).remove
                    }), [u]), h.useEffect((function() {
                        return function() {
                            O()
                        }
                    }), []), h.useImperativeHandle(e, (function() {
                        return {
                            forceAlign: function() {
                                return w(!0)
                            }
                        }
                    })), h.isValidElement(p) && (p = h.cloneElement(p, {
                        ref: (0, g.K4)(p.ref, f)
                    })), p
                },
                $t = h.forwardRef(qt);
            $t.displayName = "Align";
            const Kt = $t;

            function Zt() {
                Zt = function() {
                    return t
                };
                var t = {},
                    e = Object.prototype,
                    n = e.hasOwnProperty,
                    o = "function" == typeof Symbol ? Symbol : {},
                    r = o.iterator || "@@iterator",
                    i = o.asyncIterator || "@@asyncIterator",
                    a = o.toStringTag || "@@toStringTag";

                function u(t, e, n) {
                    return Object.defineProperty(t, e, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }), t[e]
                }
                try {
                    u({}, "")
                } catch (C) {
                    u = function(t, e, n) {
                        return t[e] = n
                    }
                }

                function s(t, e, n, o) {
                    var r = e && e.prototype instanceof p ? e : p,
                        i = Object.create(r.prototype),
                        a = new E(o || []);
                    return i._invoke = function(t, e, n) {
                        var o = "suspendedStart";
                        return function(r, i) {
                            if ("executing" === o) throw new Error("Generator is already running");
                            if ("completed" === o) {
                                if ("throw" === r) throw i;
                                return k()
                            }
                            for (n.method = r, n.arg = i;;) {
                                var a = n.delegate;
                                if (a) {
                                    var u = O(a, n);
                                    if (u) {
                                        if (u === l) continue;
                                        return u
                                    }
                                }
                                if ("next" === n.method) n.sent = n._sent = n.arg;
                                else if ("throw" === n.method) {
                                    if ("suspendedStart" === o) throw o = "completed", n.arg;
                                    n.dispatchException(n.arg)
                                } else "return" === n.method && n.abrupt("return", n.arg);
                                o = "executing";
                                var s = c(t, e, n);
                                if ("normal" === s.type) {
                                    if (o = n.done ? "completed" : "suspendedYield", s.arg === l) continue;
                                    return {
                                        value: s.arg,
                                        done: n.done
                                    }
                                }
                                "throw" === s.type && (o = "completed", n.method = "throw", n.arg = s.arg)
                            }
                        }
                    }(t, n, a), i
                }

                function c(t, e, n) {
                    try {
                        return {
                            type: "normal",
                            arg: t.call(e, n)
                        }
                    } catch (C) {
                        return {
                            type: "throw",
                            arg: C
                        }
                    }
                }
                t.wrap = s;
                var l = {};

                function p() {}

                function h() {}

                function d() {}
                var v = {};
                u(v, r, (function() {
                    return this
                }));
                var m = Object.getPrototypeOf,
                    y = m && m(m(M([])));
                y && y !== e && n.call(y, r) && (v = y);
                var g = d.prototype = p.prototype = Object.create(v);

                function b(t) {
                    ["next", "throw", "return"].forEach((function(e) {
                        u(t, e, (function(t) {
                            return this._invoke(e, t)
                        }))
                    }))
                }

                function w(t, e) {
                    function o(r, i, a, u) {
                        var s = c(t[r], t, i);
                        if ("throw" !== s.type) {
                            var l = s.arg,
                                p = l.value;
                            return p && "object" == f(p) && n.call(p, "__await") ? e.resolve(p.__await).then((function(t) {
                                o("next", t, a, u)
                            }), (function(t) {
                                o("throw", t, a, u)
                            })) : e.resolve(p).then((function(t) {
                                l.value = t, a(l)
                            }), (function(t) {
                                return o("throw", t, a, u)
                            }))
                        }
                        u(s.arg)
                    }
                    var r;
                    this._invoke = function(t, n) {
                        function i() {
                            return new e((function(e, r) {
                                o(t, n, e, r)
                            }))
                        }
                        return r = r ? r.then(i, i) : i()
                    }
                }

                function O(t, e) {
                    var n = t.iterator[e.method];
                    if (void 0 === n) {
                        if (e.delegate = null, "throw" === e.method) {
                            if (t.iterator.return && (e.method = "return", e.arg = void 0, O(t, e), "throw" === e.method)) return l;
                            e.method = "throw", e.arg = new TypeError("The iterator does not provide a 'throw' method")
                        }
                        return l
                    }
                    var o = c(n, t.iterator, e.arg);
                    if ("throw" === o.type) return e.method = "throw", e.arg = o.arg, e.delegate = null, l;
                    var r = o.arg;
                    return r ? r.done ? (e[t.resultName] = r.value, e.next = t.nextLoc, "return" !== e.method && (e.method = "next", e.arg = void 0), e.delegate = null, l) : r : (e.method = "throw", e.arg = new TypeError("iterator result is not an object"), e.delegate = null, l)
                }

                function x(t) {
                    var e = {
                        tryLoc: t[0]
                    };
                    1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e)
                }

                function T(t) {
                    var e = t.completion || {};
                    e.type = "normal", delete e.arg, t.completion = e
                }

                function E(t) {
                    this.tryEntries = [{
                        tryLoc: "root"
                    }], t.forEach(x, this), this.reset(!0)
                }

                function M(t) {
                    if (t) {
                        var e = t[r];
                        if (e) return e.call(t);
                        if ("function" == typeof t.next) return t;
                        if (!isNaN(t.length)) {
                            var o = -1,
                                i = function e() {
                                    for (; ++o < t.length;)
                                        if (n.call(t, o)) return e.value = t[o], e.done = !1, e;
                                    return e.value = void 0, e.done = !0, e
                                };
                            return i.next = i
                        }
                    }
                    return {
                        next: k
                    }
                }

                function k() {
                    return {
                        value: void 0,
                        done: !0
                    }
                }
                return h.prototype = d, u(g, "constructor", d), u(d, "constructor", h), h.displayName = u(d, a, "GeneratorFunction"), t.isGeneratorFunction = function(t) {
                    var e = "function" == typeof t && t.constructor;
                    return !!e && (e === h || "GeneratorFunction" === (e.displayName || e.name))
                }, t.mark = function(t) {
                    return Object.setPrototypeOf ? Object.setPrototypeOf(t, d) : (t.__proto__ = d, u(t, a, "GeneratorFunction")), t.prototype = Object.create(g), t
                }, t.awrap = function(t) {
                    return {
                        __await: t
                    }
                }, b(w.prototype), u(w.prototype, i, (function() {
                    return this
                })), t.AsyncIterator = w, t.async = function(e, n, o, r, i) {
                    void 0 === i && (i = Promise);
                    var a = new w(s(e, n, o, r), i);
                    return t.isGeneratorFunction(n) ? a : a.next().then((function(t) {
                        return t.done ? t.value : a.next()
                    }))
                }, b(g), u(g, a, "Generator"), u(g, r, (function() {
                    return this
                })), u(g, "toString", (function() {
                    return "[object Generator]"
                })), t.keys = function(t) {
                    var e = [];
                    for (var n in t) e.push(n);
                    return e.reverse(),
                        function n() {
                            for (; e.length;) {
                                var o = e.pop();
                                if (o in t) return n.value = o, n.done = !1, n
                            }
                            return n.done = !0, n
                        }
                }, t.values = M, E.prototype = {
                    constructor: E,
                    reset: function(t) {
                        if (this.prev = 0, this.next = 0, this.sent = this._sent = void 0, this.done = !1, this.delegate = null, this.method = "next", this.arg = void 0, this.tryEntries.forEach(T), !t)
                            for (var e in this) "t" === e.charAt(0) && n.call(this, e) && !isNaN(+e.slice(1)) && (this[e] = void 0)
                    },
                    stop: function() {
                        this.done = !0;
                        var t = this.tryEntries[0].completion;
                        if ("throw" === t.type) throw t.arg;
                        return this.rval
                    },
                    dispatchException: function(t) {
                        if (this.done) throw t;
                        var e = this;

                        function o(n, o) {
                            return a.type = "throw", a.arg = t, e.next = n, o && (e.method = "next", e.arg = void 0), !!o
                        }
                        for (var r = this.tryEntries.length - 1; r >= 0; --r) {
                            var i = this.tryEntries[r],
                                a = i.completion;
                            if ("root" === i.tryLoc) return o("end");
                            if (i.tryLoc <= this.prev) {
                                var u = n.call(i, "catchLoc"),
                                    s = n.call(i, "finallyLoc");
                                if (u && s) {
                                    if (this.prev < i.catchLoc) return o(i.catchLoc, !0);
                                    if (this.prev < i.finallyLoc) return o(i.finallyLoc)
                                } else if (u) {
                                    if (this.prev < i.catchLoc) return o(i.catchLoc, !0)
                                } else {
                                    if (!s) throw new Error("try statement without catch or finally");
                                    if (this.prev < i.finallyLoc) return o(i.finallyLoc)
                                }
                            }
                        }
                    },
                    abrupt: function(t, e) {
                        for (var o = this.tryEntries.length - 1; o >= 0; --o) {
                            var r = this.tryEntries[o];
                            if (r.tryLoc <= this.prev && n.call(r, "finallyLoc") && this.prev < r.finallyLoc) {
                                var i = r;
                                break
                            }
                        }
                        i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null);
                        var a = i ? i.completion : {};
                        return a.type = t, a.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, l) : this.complete(a)
                    },
                    complete: function(t, e) {
                        if ("throw" === t.type) throw t.arg;
                        return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), l
                    },
                    finish: function(t) {
                        for (var e = this.tryEntries.length - 1; e >= 0; --e) {
                            var n = this.tryEntries[e];
                            if (n.finallyLoc === t) return this.complete(n.completion, n.afterLoc), T(n), l
                        }
                    },
                    catch: function(t) {
                        for (var e = this.tryEntries.length - 1; e >= 0; --e) {
                            var n = this.tryEntries[e];
                            if (n.tryLoc === t) {
                                var o = n.completion;
                                if ("throw" === o.type) {
                                    var r = o.arg;
                                    T(n)
                                }
                                return r
                            }
                        }
                        throw new Error("illegal catch attempt")
                    },
                    delegateYield: function(t, e, n) {
                        return this.delegate = {
                            iterator: M(t),
                            resultName: e,
                            nextLoc: n
                        }, "next" === this.method && (this.arg = void 0), l
                    }
                }, t
            }

            function Jt(t, e, n, o, r, i, a) {
                try {
                    var u = t[i](a),
                        s = u.value
                } catch (c) {
                    return void n(c)
                }
                u.done ? e(s) : Promise.resolve(s).then(o, r)
            }

            function Qt(t) {
                return function() {
                    var e = this,
                        n = arguments;
                    return new Promise((function(o, r) {
                        var i = t.apply(e, n);

                        function a(t) {
                            Jt(i, o, r, a, u, "next", t)
                        }

                        function u(t) {
                            Jt(i, o, r, a, u, "throw", t)
                        }
                        a(void 0)
                    }))
                }
            }
            var te = n(208566),
                ee = ["measure", "alignPre", "align", null, "motion"];
            var ne = h.forwardRef((function(t, e) {
                var n = t.visible,
                    o = t.prefixCls,
                    r = t.className,
                    u = t.style,
                    s = t.children,
                    c = t.zIndex,
                    l = t.stretch,
                    f = t.destroyPopupOnHide,
                    p = t.forceRender,
                    d = t.align,
                    m = t.point,
                    y = t.getRootDomNode,
                    g = t.getClassNameFromAlign,
                    b = t.onAlign,
                    w = t.onMouseEnter,
                    O = t.onMouseLeave,
                    T = t.onMouseDown,
                    E = t.onTouchStart,
                    k = t.onClick,
                    C = (0, h.useRef)(),
                    P = (0, h.useRef)(),
                    S = M((0, h.useState)(), 2),
                    D = S[0],
                    j = S[1],
                    R = function(t) {
                        var e = M(h.useState({
                                width: 0,
                                height: 0
                            }), 2),
                            n = e[0],
                            o = e[1];
                        return [h.useMemo((function() {
                            var e = {};
                            if (t) {
                                var o = n.width,
                                    r = n.height; - 1 !== t.indexOf("height") && r ? e.height = r : -1 !== t.indexOf("minHeight") && r && (e.minHeight = r), -1 !== t.indexOf("width") && o ? e.width = o : -1 !== t.indexOf("minWidth") && o && (e.minWidth = o)
                            }
                            return e
                        }), [t, n]), function(t) {
                            var e = t.offsetWidth,
                                n = t.offsetHeight,
                                r = t.getBoundingClientRect(),
                                i = r.width,
                                a = r.height;
                            Math.abs(e - i) < 1 && Math.abs(n - a) < 1 && (e = i, n = a), o({
                                width: e,
                                height: n
                            })
                        }]
                    }(l),
                    L = M(R, 2),
                    H = L[0],
                    N = L[1];
                var V = function(t, e) {
                        var n = M((0, te.A)(null), 2),
                            o = n[0],
                            r = n[1],
                            i = (0, h.useRef)();

                        function a(t) {
                            r(t, !0)
                        }

                        function u() {
                            v.A.cancel(i.current)
                        }
                        return (0, h.useEffect)((function() {
                            a("measure")
                        }), [t]), (0, h.useEffect)((function() {
                            "measure" === o && e(), o && (i.current = (0, v.A)(Qt(Zt().mark((function t() {
                                var e, n;
                                return Zt().wrap((function(t) {
                                    for (;;) switch (t.prev = t.next) {
                                        case 0:
                                            e = ee.indexOf(o), (n = ee[e + 1]) && -1 !== e && a(n);
                                        case 3:
                                        case "end":
                                            return t.stop()
                                    }
                                }), t)
                            })))))
                        }), [o]), (0, h.useEffect)((function() {
                            return function() {
                                u()
                            }
                        }), []), [o, function(t) {
                            u(), i.current = (0, v.A)((function() {
                                a((function(t) {
                                    switch (o) {
                                        case "align":
                                            return "motion";
                                        case "motion":
                                            return "stable"
                                    }
                                    return t
                                })), null === t || void 0 === t || t()
                            }))
                        }]
                    }(n, (function() {
                        l && N(y())
                    })),
                    W = M(V, 2),
                    B = W[0],
                    F = W[1],
                    z = M((0, h.useState)(0), 2),
                    I = z[0],
                    Y = z[1],
                    X = (0, h.useRef)();

                function G() {
                    var t;
                    null === (t = C.current) || void 0 === t || t.forceAlign()
                }

                function U(t, e) {
                    var n = g(e);
                    D !== n && j(n), Y((function(t) {
                        return t + 1
                    })), "align" === B && (null === b || void 0 === b || b(t, e))
                }(0, It.A)((function() {
                    "alignPre" === B && Y(0)
                }), [B]), (0, It.A)((function() {
                    "align" === B && (I < 3 ? G() : F((function() {
                        var t;
                        null === (t = X.current) || void 0 === t || t.call(X)
                    })))
                }), [I]);
                var q = i({}, A(t));

                function $() {
                    return new Promise((function(t) {
                        X.current = t
                    }))
                }["onAppearEnd", "onEnterEnd", "onLeaveEnd"].forEach((function(t) {
                    var e = q[t];
                    q[t] = function(t, n) {
                        return F(), null === e || void 0 === e ? void 0 : e(t, n)
                    }
                })), h.useEffect((function() {
                    q.motionName || "motion" !== B || F()
                }), [q.motionName, B]), h.useImperativeHandle(e, (function() {
                    return {
                        forceAlign: G,
                        getElement: function() {
                            return P.current
                        }
                    }
                }));
                var K = i(i({}, H), {}, {
                        zIndex: c,
                        opacity: "motion" !== B && "stable" !== B && n ? 0 : void 0,
                        pointerEvents: n || "stable" === B ? void 0 : "none"
                    }, u),
                    Z = !0;
                null === d || void 0 === d || !d.points || "align" !== B && "stable" !== B || (Z = !1);
                var J = s;
                return h.Children.count(s) > 1 && (J = h.createElement("div", {
                    className: "".concat(o, "-content")
                }, s)), h.createElement(_.default, a({
                    visible: n,
                    ref: P,
                    leavedClassName: "".concat(o, "-hidden")
                }, q, {
                    onAppearPrepare: $,
                    onEnterPrepare: $,
                    removeOnLeave: f,
                    forceRender: p
                }), (function(t, e) {
                    var n = t.className,
                        a = t.style,
                        u = x()(o, r, D, n);
                    return h.createElement(Kt, {
                        target: m || y,
                        key: "popup",
                        ref: C,
                        monitorWindowResize: !0,
                        disabled: Z,
                        align: d,
                        onAlign: U
                    }, h.createElement("div", {
                        ref: e,
                        className: u,
                        onMouseEnter: w,
                        onMouseLeave: O,
                        onMouseDownCapture: T,
                        onTouchStartCapture: E,
                        onClick: k,
                        style: i(i({}, a), K)
                    }, J))
                }))
            }));
            ne.displayName = "PopupInner";
            const oe = ne;
            var re = h.forwardRef((function(t, e) {
                var n = t.prefixCls,
                    o = t.visible,
                    r = t.zIndex,
                    u = t.children,
                    s = t.mobile,
                    c = (s = void 0 === s ? {} : s).popupClassName,
                    l = s.popupStyle,
                    f = s.popupMotion,
                    p = void 0 === f ? {} : f,
                    d = s.popupRender,
                    v = t.onClick,
                    m = h.useRef();
                h.useImperativeHandle(e, (function() {
                    return {
                        forceAlign: function() {},
                        getElement: function() {
                            return m.current
                        }
                    }
                }));
                var y = i({
                        zIndex: r
                    }, l),
                    g = u;
                return h.Children.count(u) > 1 && (g = h.createElement("div", {
                    className: "".concat(n, "-content")
                }, u)), d && (g = d(g)), h.createElement(_.default, a({
                    visible: o,
                    ref: m,
                    removeOnLeave: !0
                }, p), (function(t, e) {
                    var o = t.className,
                        r = t.style,
                        a = x()(n, c, o);
                    return h.createElement("div", {
                        ref: e,
                        className: a,
                        onClick: v,
                        style: i(i({}, r), y)
                    }, g)
                }))
            }));
            re.displayName = "MobilePopupInner";
            const ie = re;
            var ae = ["visible", "mobile"],
                ue = h.forwardRef((function(t, e) {
                    var n = t.visible,
                        o = t.mobile,
                        r = k(t, ae),
                        u = M((0, h.useState)(n), 2),
                        s = u[0],
                        c = u[1],
                        l = M((0, h.useState)(!1), 2),
                        f = l[0],
                        p = l[1],
                        d = i(i({}, r), {}, {
                            visible: s
                        });
                    (0, h.useEffect)((function() {
                        c(n), n && o && p((0, P.A)())
                    }), [n, o]);
                    var v = f ? h.createElement(ie, a({}, d, {
                        mobile: o,
                        ref: e
                    })) : h.createElement(oe, a({}, d, {
                        ref: e
                    }));
                    return h.createElement("div", null, h.createElement(S, d), v)
                }));
            ue.displayName = "Popup";
            const se = ue;
            const ce = h.createContext(null);

            function le() {}

            function fe() {
                return ""
            }

            function pe(t) {
                return t ? t.ownerDocument : window.document
            }
            var he = ["onClick", "onMouseDown", "onTouchStart", "onMouseEnter", "onMouseLeave", "onFocus", "onBlur", "onContextMenu"];
            const de = function(t) {
                var e = function(e) {
                    ! function(t, e) {
                        if ("function" !== typeof e && null !== e) throw new TypeError("Super expression must either be null or a function");
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                writable: !0,
                                configurable: !0
                            }
                        }), Object.defineProperty(t, "prototype", {
                            writable: !1
                        }), e && c(t, e)
                    }(w, e);
                    var n, r, l, f = p(w);

                    function w(t) {
                        var e, n;
                        return function(t, e) {
                            if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                        }(this, w), o(s(e = f.call(this, t)), "popupRef", h.createRef()), o(s(e), "triggerRef", h.createRef()), o(s(e), "portalContainer", void 0), o(s(e), "attachId", void 0), o(s(e), "clickOutsideHandler", void 0), o(s(e), "touchOutsideHandler", void 0), o(s(e), "contextMenuOutsideHandler1", void 0), o(s(e), "contextMenuOutsideHandler2", void 0), o(s(e), "mouseDownTimeout", void 0), o(s(e), "focusTime", void 0), o(s(e), "preClickTime", void 0), o(s(e), "preTouchTime", void 0), o(s(e), "delayTimer", void 0), o(s(e), "hasPopupMouseDown", void 0), o(s(e), "onMouseEnter", (function(t) {
                            var n = e.props.mouseEnterDelay;
                            e.fireEvents("onMouseEnter", t), e.delaySetPopupVisible(!0, n, n ? null : t)
                        })), o(s(e), "onMouseMove", (function(t) {
                            e.fireEvents("onMouseMove", t), e.setPoint(t)
                        })), o(s(e), "onMouseLeave", (function(t) {
                            e.fireEvents("onMouseLeave", t), e.delaySetPopupVisible(!1, e.props.mouseLeaveDelay)
                        })), o(s(e), "onPopupMouseEnter", (function() {
                            e.clearDelayTimer()
                        })), o(s(e), "onPopupMouseLeave", (function(t) {
                            var n;
                            t.relatedTarget && !t.relatedTarget.setTimeout && (0, m.A)(null === (n = e.popupRef.current) || void 0 === n ? void 0 : n.getElement(), t.relatedTarget) || e.delaySetPopupVisible(!1, e.props.mouseLeaveDelay)
                        })), o(s(e), "onFocus", (function(t) {
                            e.fireEvents("onFocus", t), e.clearDelayTimer(), e.isFocusToShow() && (e.focusTime = Date.now(), e.delaySetPopupVisible(!0, e.props.focusDelay))
                        })), o(s(e), "onMouseDown", (function(t) {
                            e.fireEvents("onMouseDown", t), e.preClickTime = Date.now()
                        })), o(s(e), "onTouchStart", (function(t) {
                            e.fireEvents("onTouchStart", t), e.preTouchTime = Date.now()
                        })), o(s(e), "onBlur", (function(t) {
                            e.fireEvents("onBlur", t), e.clearDelayTimer(), e.isBlurToHide() && e.delaySetPopupVisible(!1, e.props.blurDelay)
                        })), o(s(e), "onContextMenu", (function(t) {
                            t.preventDefault(), e.fireEvents("onContextMenu", t), e.setPopupVisible(!0, t)
                        })), o(s(e), "onContextMenuClose", (function() {
                            e.isContextMenuToShow() && e.close()
                        })), o(s(e), "onClick", (function(t) {
                            if (e.fireEvents("onClick", t), e.focusTime) {
                                var n;
                                if (e.preClickTime && e.preTouchTime ? n = Math.min(e.preClickTime, e.preTouchTime) : e.preClickTime ? n = e.preClickTime : e.preTouchTime && (n = e.preTouchTime), Math.abs(n - e.focusTime) < 20) return;
                                e.focusTime = 0
                            }
                            e.preClickTime = 0, e.preTouchTime = 0, e.isClickToShow() && (e.isClickToHide() || e.isBlurToHide()) && t && t.preventDefault && t.preventDefault();
                            var o = !e.state.popupVisible;
                            (e.isClickToHide() && !o || o && e.isClickToShow()) && e.setPopupVisible(!e.state.popupVisible, t)
                        })), o(s(e), "onPopupMouseDown", (function() {
                            var t;
                            (e.hasPopupMouseDown = !0, clearTimeout(e.mouseDownTimeout), e.mouseDownTimeout = window.setTimeout((function() {
                                e.hasPopupMouseDown = !1
                            }), 0), e.context) && (t = e.context).onPopupMouseDown.apply(t, arguments)
                        })), o(s(e), "onDocumentClick", (function(t) {
                            if (!e.props.mask || e.props.maskClosable) {
                                var n = t.target,
                                    o = e.getRootDomNode(),
                                    r = e.getPopupDomNode();
                                (0, m.A)(o, n) && !e.isContextMenuOnly() || (0, m.A)(r, n) || e.hasPopupMouseDown || e.close()
                            }
                        })), o(s(e), "getRootDomNode", (function() {
                            var t = e.props.getTriggerDOMNode;
                            if (t) return t(e.triggerRef.current);
                            try {
                                var n = (0, y.A)(e.triggerRef.current);
                                if (n) return n
                            } catch (o) {}
                            return d.findDOMNode(s(e))
                        })), o(s(e), "getPopupClassNameFromAlign", (function(t) {
                            var n = [],
                                o = e.props,
                                r = o.popupPlacement,
                                i = o.builtinPlacements,
                                a = o.prefixCls,
                                u = o.alignPoint,
                                s = o.getPopupClassNameFromAlign;
                            return r && i && n.push(function(t, e, n, o) {
                                for (var r = n.points, i = Object.keys(t), a = 0; a < i.length; a += 1) {
                                    var u = i[a];
                                    if (T(t[u].points, r, o)) return "".concat(e, "-placement-").concat(u)
                                }
                                return ""
                            }(i, a, t, u)), s && n.push(s(t)), n.join(" ")
                        })), o(s(e), "getComponent", (function() {
                            var t = e.props,
                                n = t.prefixCls,
                                o = t.destroyPopupOnHide,
                                r = t.popupClassName,
                                i = t.onPopupAlign,
                                u = t.popupMotion,
                                s = t.popupAnimation,
                                c = t.popupTransitionName,
                                l = t.popupStyle,
                                f = t.mask,
                                p = t.maskAnimation,
                                d = t.maskTransitionName,
                                v = t.maskMotion,
                                m = t.zIndex,
                                y = t.popup,
                                g = t.stretch,
                                b = t.alignPoint,
                                w = t.mobile,
                                O = t.forceRender,
                                x = t.onPopupClick,
                                T = e.state,
                                E = T.popupVisible,
                                M = T.point,
                                k = e.getPopupAlign(),
                                C = {};
                            return e.isMouseEnterToShow() && (C.onMouseEnter = e.onPopupMouseEnter), e.isMouseLeaveToHide() && (C.onMouseLeave = e.onPopupMouseLeave), C.onMouseDown = e.onPopupMouseDown, C.onTouchStart = e.onPopupMouseDown, h.createElement(se, a({
                                prefixCls: n,
                                destroyPopupOnHide: o,
                                visible: E,
                                point: b && M,
                                className: r,
                                align: k,
                                onAlign: i,
                                animation: s,
                                getClassNameFromAlign: e.getPopupClassNameFromAlign
                            }, C, {
                                stretch: g,
                                getRootDomNode: e.getRootDomNode,
                                style: l,
                                mask: f,
                                zIndex: m,
                                transitionName: c,
                                maskAnimation: p,
                                maskTransitionName: d,
                                maskMotion: v,
                                ref: e.popupRef,
                                motion: u,
                                mobile: w,
                                forceRender: O,
                                onClick: x
                            }), "function" === typeof y ? y() : y)
                        })), o(s(e), "attachParent", (function(t) {
                            v.A.cancel(e.attachId);
                            var n, o = e.props,
                                r = o.getPopupContainer,
                                i = o.getDocument,
                                a = e.getRootDomNode();
                            r ? (a || 0 === r.length) && (n = r(a)) : n = i(e.getRootDomNode()).body, n ? n.appendChild(t) : e.attachId = (0, v.A)((function() {
                                e.attachParent(t)
                            }))
                        })), o(s(e), "getContainer", (function() {
                            if (!e.portalContainer) {
                                var t = (0, e.props.getDocument)(e.getRootDomNode()).createElement("div");
                                t.style.position = "absolute", t.style.top = "0", t.style.left = "0", t.style.width = "100%", e.portalContainer = t
                            }
                            return e.attachParent(e.portalContainer), e.portalContainer
                        })), o(s(e), "setPoint", (function(t) {
                            e.props.alignPoint && t && e.setState({
                                point: {
                                    pageX: t.pageX,
                                    pageY: t.pageY
                                }
                            })
                        })), o(s(e), "handlePortalUpdate", (function() {
                            e.state.prevPopupVisible !== e.state.popupVisible && e.props.afterPopupVisibleChange(e.state.popupVisible)
                        })), o(s(e), "triggerContextValue", {
                            onPopupMouseDown: e.onPopupMouseDown
                        }), n = "popupVisible" in t ? !!t.popupVisible : !!t.defaultPopupVisible, e.state = {
                            prevPopupVisible: n,
                            popupVisible: n
                        }, he.forEach((function(t) {
                            e["fire".concat(t)] = function(n) {
                                e.fireEvents(t, n)
                            }
                        })), e
                    }
                    return n = w, r = [{
                        key: "componentDidMount",
                        value: function() {
                            this.componentDidUpdate()
                        }
                    }, {
                        key: "componentDidUpdate",
                        value: function() {
                            var t, e = this.props;
                            if (this.state.popupVisible) return this.clickOutsideHandler || !this.isClickToHide() && !this.isContextMenuToShow() || (t = e.getDocument(this.getRootDomNode()), this.clickOutsideHandler = (0, b.A)(t, "mousedown", this.onDocumentClick)), this.touchOutsideHandler || (t = t || e.getDocument(this.getRootDomNode()), this.touchOutsideHandler = (0, b.A)(t, "touchstart", this.onDocumentClick)), !this.contextMenuOutsideHandler1 && this.isContextMenuToShow() && (t = t || e.getDocument(this.getRootDomNode()), this.contextMenuOutsideHandler1 = (0, b.A)(t, "scroll", this.onContextMenuClose)), void(!this.contextMenuOutsideHandler2 && this.isContextMenuToShow() && (this.contextMenuOutsideHandler2 = (0, b.A)(window, "blur", this.onContextMenuClose)));
                            this.clearOutsideHandler()
                        }
                    }, {
                        key: "componentWillUnmount",
                        value: function() {
                            this.clearDelayTimer(), this.clearOutsideHandler(), clearTimeout(this.mouseDownTimeout), v.A.cancel(this.attachId)
                        }
                    }, {
                        key: "getPopupDomNode",
                        value: function() {
                            var t;
                            return (null === (t = this.popupRef.current) || void 0 === t ? void 0 : t.getElement()) || null
                        }
                    }, {
                        key: "getPopupAlign",
                        value: function() {
                            var t = this.props,
                                e = t.popupPlacement,
                                n = t.popupAlign,
                                o = t.builtinPlacements;
                            return e && o ? function(t, e, n) {
                                return i(i({}, t[e] || {}), n)
                            }(o, e, n) : n
                        }
                    }, {
                        key: "setPopupVisible",
                        value: function(t, e) {
                            var n = this.props.alignPoint,
                                o = this.state.popupVisible;
                            this.clearDelayTimer(), o !== t && ("popupVisible" in this.props || this.setState({
                                popupVisible: t,
                                prevPopupVisible: o
                            }), this.props.onPopupVisibleChange(t)), n && e && t && this.setPoint(e)
                        }
                    }, {
                        key: "delaySetPopupVisible",
                        value: function(t, e, n) {
                            var o = this,
                                r = 1e3 * e;
                            if (this.clearDelayTimer(), r) {
                                var i = n ? {
                                    pageX: n.pageX,
                                    pageY: n.pageY
                                } : null;
                                this.delayTimer = window.setTimeout((function() {
                                    o.setPopupVisible(t, i), o.clearDelayTimer()
                                }), r)
                            } else this.setPopupVisible(t, n)
                        }
                    }, {
                        key: "clearDelayTimer",
                        value: function() {
                            this.delayTimer && (clearTimeout(this.delayTimer), this.delayTimer = null)
                        }
                    }, {
                        key: "clearOutsideHandler",
                        value: function() {
                            this.clickOutsideHandler && (this.clickOutsideHandler.remove(), this.clickOutsideHandler = null), this.contextMenuOutsideHandler1 && (this.contextMenuOutsideHandler1.remove(), this.contextMenuOutsideHandler1 = null), this.contextMenuOutsideHandler2 && (this.contextMenuOutsideHandler2.remove(), this.contextMenuOutsideHandler2 = null), this.touchOutsideHandler && (this.touchOutsideHandler.remove(), this.touchOutsideHandler = null)
                        }
                    }, {
                        key: "createTwoChains",
                        value: function(t) {
                            var e = this.props.children.props,
                                n = this.props;
                            return e[t] && n[t] ? this["fire".concat(t)] : e[t] || n[t]
                        }
                    }, {
                        key: "isClickToShow",
                        value: function() {
                            var t = this.props,
                                e = t.action,
                                n = t.showAction;
                            return -1 !== e.indexOf("click") || -1 !== n.indexOf("click")
                        }
                    }, {
                        key: "isContextMenuOnly",
                        value: function() {
                            var t = this.props.action;
                            return "contextMenu" === t || 1 === t.length && "contextMenu" === t[0]
                        }
                    }, {
                        key: "isContextMenuToShow",
                        value: function() {
                            var t = this.props,
                                e = t.action,
                                n = t.showAction;
                            return -1 !== e.indexOf("contextMenu") || -1 !== n.indexOf("contextMenu")
                        }
                    }, {
                        key: "isClickToHide",
                        value: function() {
                            var t = this.props,
                                e = t.action,
                                n = t.hideAction;
                            return -1 !== e.indexOf("click") || -1 !== n.indexOf("click")
                        }
                    }, {
                        key: "isMouseEnterToShow",
                        value: function() {
                            var t = this.props,
                                e = t.action,
                                n = t.showAction;
                            return -1 !== e.indexOf("hover") || -1 !== n.indexOf("mouseEnter")
                        }
                    }, {
                        key: "isMouseLeaveToHide",
                        value: function() {
                            var t = this.props,
                                e = t.action,
                                n = t.hideAction;
                            return -1 !== e.indexOf("hover") || -1 !== n.indexOf("mouseLeave")
                        }
                    }, {
                        key: "isFocusToShow",
                        value: function() {
                            var t = this.props,
                                e = t.action,
                                n = t.showAction;
                            return -1 !== e.indexOf("focus") || -1 !== n.indexOf("focus")
                        }
                    }, {
                        key: "isBlurToHide",
                        value: function() {
                            var t = this.props,
                                e = t.action,
                                n = t.hideAction;
                            return -1 !== e.indexOf("focus") || -1 !== n.indexOf("blur")
                        }
                    }, {
                        key: "forcePopupAlign",
                        value: function() {
                            var t;
                            this.state.popupVisible && (null === (t = this.popupRef.current) || void 0 === t || t.forceAlign())
                        }
                    }, {
                        key: "fireEvents",
                        value: function(t, e) {
                            var n = this.props.children.props[t];
                            n && n(e);
                            var o = this.props[t];
                            o && o(e)
                        }
                    }, {
                        key: "close",
                        value: function() {
                            this.setPopupVisible(!1)
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this.state.popupVisible,
                                n = this.props,
                                o = n.children,
                                r = n.forceRender,
                                a = n.alignPoint,
                                u = n.className,
                                s = n.autoDestroy,
                                c = h.Children.only(o),
                                l = {
                                    key: "trigger"
                                };
                            this.isContextMenuToShow() ? l.onContextMenu = this.onContextMenu : l.onContextMenu = this.createTwoChains("onContextMenu"), this.isClickToHide() || this.isClickToShow() ? (l.onClick = this.onClick, l.onMouseDown = this.onMouseDown, l.onTouchStart = this.onTouchStart) : (l.onClick = this.createTwoChains("onClick"), l.onMouseDown = this.createTwoChains("onMouseDown"), l.onTouchStart = this.createTwoChains("onTouchStart")), this.isMouseEnterToShow() ? (l.onMouseEnter = this.onMouseEnter, a && (l.onMouseMove = this.onMouseMove)) : l.onMouseEnter = this.createTwoChains("onMouseEnter"), this.isMouseLeaveToHide() ? l.onMouseLeave = this.onMouseLeave : l.onMouseLeave = this.createTwoChains("onMouseLeave"), this.isFocusToShow() || this.isBlurToHide() ? (l.onFocus = this.onFocus, l.onBlur = this.onBlur) : (l.onFocus = this.createTwoChains("onFocus"), l.onBlur = this.createTwoChains("onBlur"));
                            var f = x()(c && c.props && c.props.className, u);
                            f && (l.className = f);
                            var p = i({}, l);
                            (0, g.f3)(c) && (p.ref = (0, g.K4)(this.triggerRef, c.ref));
                            var d, v = h.cloneElement(c, p);
                            return (e || this.popupRef.current || r) && (d = h.createElement(t, {
                                key: "portal",
                                getContainer: this.getContainer,
                                didUpdate: this.handlePortalUpdate
                            }, this.getComponent())), !e && s && (d = null), h.createElement(ce.Provider, {
                                value: this.triggerContextValue
                            }, v, d)
                        }
                    }], l = [{
                        key: "getDerivedStateFromProps",
                        value: function(t, e) {
                            var n = t.popupVisible,
                                o = {};
                            return void 0 !== n && e.popupVisible !== n && (o.popupVisible = n, o.prevPopupVisible = e.popupVisible), o
                        }
                    }], r && u(n.prototype, r), l && u(n, l), Object.defineProperty(n, "prototype", {
                        writable: !1
                    }), w
                }(h.Component);
                return o(e, "contextType", ce), o(e, "defaultProps", {
                    prefixCls: "rc-trigger-popup",
                    getPopupClassNameFromAlign: fe,
                    getDocument: pe,
                    onPopupVisibleChange: le,
                    afterPopupVisibleChange: le,
                    onPopupAlign: le,
                    popupClassName: "",
                    mouseEnterDelay: 0,
                    mouseLeaveDelay: .1,
                    focusDelay: 0,
                    blurDelay: .15,
                    popupStyle: {},
                    destroyPopupOnHide: !1,
                    popupAlign: {},
                    defaultPopupVisible: !1,
                    mask: !1,
                    maskClosable: !0,
                    action: [],
                    showAction: [],
                    hideAction: [],
                    autoDestroy: !1
                }), e
            }(w.A)
        },
        504903: (t, e, n) => {
            n.d(e, {
                A: () => r
            });
            var o = n(297950);

            function r(t, e, n, r) {
                var i = o.unstable_batchedUpdates ? function(t) {
                    o.unstable_batchedUpdates(n, t)
                } : n;
                return null !== t && void 0 !== t && t.addEventListener && t.addEventListener(e, i, r), {
                    remove: function() {
                        null !== t && void 0 !== t && t.removeEventListener && t.removeEventListener(e, i, r)
                    }
                }
            }
        },
        676590: (t, e, n) => {
            n.d(e, {
                A: () => o
            });
            const o = function(t) {
                if (!t) return !1;
                if (t instanceof Element) {
                    if (t.offsetParent) return !0;
                    if (t.getBBox) {
                        var e = t.getBBox(),
                            n = e.width,
                            o = e.height;
                        if (n || o) return !0
                    }
                    if (t.getBoundingClientRect) {
                        var r = t.getBoundingClientRect(),
                            i = r.width,
                            a = r.height;
                        if (i || a) return !0
                    }
                }
                return !1
            }
        },
        816765: (t, e, n) => {
            n.d(e, {
                A: () => o
            });
            const o = function() {
                if ("undefined" === typeof navigator || "undefined" === typeof window) return !1;
                var t = navigator.userAgent || navigator.vendor || window.opera;
                return /(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino|android|ipad|playbook|silk/i.test(t) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw-(n|u)|c55\/|capi|ccwa|cdm-|cell|chtm|cldc|cmd-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc-s|devi|dica|dmob|do(c|p)o|ds(12|-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(-|_)|g1 u|g560|gene|gf-5|g-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd-(m|p|t)|hei-|hi(pt|ta)|hp( i|ip)|hs-c|ht(c(-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i-(20|go|ma)|i230|iac( |-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|-[a-w])|libw|lynx|m1-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|-([1-8]|c))|phil|pire|pl(ay|uc)|pn-2|po(ck|rt|se)|prox|psio|pt-g|qa-a|qc(07|12|21|32|60|-[2-7]|i-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h-|oo|p-)|sdk\/|se(c(-|0|1)|47|mc|nd|ri)|sgh-|shar|sie(-|m)|sk-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h-|v-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl-|tdg-|tel(i|m)|tim-|t-mo|to(pl|sh)|ts(70|m-|m3|m5)|tx-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas-|your|zeto|zte-/i.test(null === t || void 0 === t ? void 0 : t.substr(0, 4))
            }
        },
        535820: (t, e, n) => {
            n.d(e, {
                A: () => E
            });
            var o = function() {
                    if ("undefined" !== typeof Map) return Map;

                    function t(t, e) {
                        var n = -1;
                        return t.some((function(t, o) {
                            return t[0] === e && (n = o, !0)
                        })), n
                    }
                    return function() {
                        function e() {
                            this.__entries__ = []
                        }
                        return Object.defineProperty(e.prototype, "size", {
                            get: function() {
                                return this.__entries__.length
                            },
                            enumerable: !0,
                            configurable: !0
                        }), e.prototype.get = function(e) {
                            var n = t(this.__entries__, e),
                                o = this.__entries__[n];
                            return o && o[1]
                        }, e.prototype.set = function(e, n) {
                            var o = t(this.__entries__, e);
                            ~o ? this.__entries__[o][1] = n : this.__entries__.push([e, n])
                        }, e.prototype.delete = function(e) {
                            var n = this.__entries__,
                                o = t(n, e);
                            ~o && n.splice(o, 1)
                        }, e.prototype.has = function(e) {
                            return !!~t(this.__entries__, e)
                        }, e.prototype.clear = function() {
                            this.__entries__.splice(0)
                        }, e.prototype.forEach = function(t, e) {
                            void 0 === e && (e = null);
                            for (var n = 0, o = this.__entries__; n < o.length; n++) {
                                var r = o[n];
                                t.call(e, r[1], r[0])
                            }
                        }, e
                    }()
                }(),
                r = "undefined" !== typeof window && "undefined" !== typeof document && window.document === document,
                i = "undefined" !== typeof n.g && n.g.Math === Math ? n.g : "undefined" !== typeof self && self.Math === Math ? self : "undefined" !== typeof window && window.Math === Math ? window : Function("return this")(),
                a = "function" === typeof requestAnimationFrame ? requestAnimationFrame.bind(i) : function(t) {
                    return setTimeout((function() {
                        return t(Date.now())
                    }), 1e3 / 60)
                };
            var u = ["top", "right", "bottom", "left", "width", "height", "size", "weight"],
                s = "undefined" !== typeof MutationObserver,
                c = function() {
                    function t() {
                        this.connected_ = !1, this.mutationEventsAdded_ = !1, this.mutationsObserver_ = null, this.observers_ = [], this.onTransitionEnd_ = this.onTransitionEnd_.bind(this), this.refresh = function(t, e) {
                            var n = !1,
                                o = !1,
                                r = 0;

                            function i() {
                                n && (n = !1, t()), o && s()
                            }

                            function u() {
                                a(i)
                            }

                            function s() {
                                var t = Date.now();
                                if (n) {
                                    if (t - r < 2) return;
                                    o = !0
                                } else n = !0, o = !1, setTimeout(u, e);
                                r = t
                            }
                            return s
                        }(this.refresh.bind(this), 20)
                    }
                    return t.prototype.addObserver = function(t) {
                        ~this.observers_.indexOf(t) || this.observers_.push(t), this.connected_ || this.connect_()
                    }, t.prototype.removeObserver = function(t) {
                        var e = this.observers_,
                            n = e.indexOf(t);
                        ~n && e.splice(n, 1), !e.length && this.connected_ && this.disconnect_()
                    }, t.prototype.refresh = function() {
                        this.updateObservers_() && this.refresh()
                    }, t.prototype.updateObservers_ = function() {
                        var t = this.observers_.filter((function(t) {
                            return t.gatherActive(), t.hasActive()
                        }));
                        return t.forEach((function(t) {
                            return t.broadcastActive()
                        })), t.length > 0
                    }, t.prototype.connect_ = function() {
                        r && !this.connected_ && (document.addEventListener("transitionend", this.onTransitionEnd_), window.addEventListener("resize", this.refresh), s ? (this.mutationsObserver_ = new MutationObserver(this.refresh), this.mutationsObserver_.observe(document, {
                            attributes: !0,
                            childList: !0,
                            characterData: !0,
                            subtree: !0
                        })) : (document.addEventListener("DOMSubtreeModified", this.refresh), this.mutationEventsAdded_ = !0), this.connected_ = !0)
                    }, t.prototype.disconnect_ = function() {
                        r && this.connected_ && (document.removeEventListener("transitionend", this.onTransitionEnd_), window.removeEventListener("resize", this.refresh), this.mutationsObserver_ && this.mutationsObserver_.disconnect(), this.mutationEventsAdded_ && document.removeEventListener("DOMSubtreeModified", this.refresh), this.mutationsObserver_ = null, this.mutationEventsAdded_ = !1, this.connected_ = !1)
                    }, t.prototype.onTransitionEnd_ = function(t) {
                        var e = t.propertyName,
                            n = void 0 === e ? "" : e;
                        u.some((function(t) {
                            return !!~n.indexOf(t)
                        })) && this.refresh()
                    }, t.getInstance = function() {
                        return this.instance_ || (this.instance_ = new t), this.instance_
                    }, t.instance_ = null, t
                }(),
                l = function(t, e) {
                    for (var n = 0, o = Object.keys(e); n < o.length; n++) {
                        var r = o[n];
                        Object.defineProperty(t, r, {
                            value: e[r],
                            enumerable: !1,
                            writable: !1,
                            configurable: !0
                        })
                    }
                    return t
                },
                f = function(t) {
                    return t && t.ownerDocument && t.ownerDocument.defaultView || i
                },
                p = g(0, 0, 0, 0);

            function h(t) {
                return parseFloat(t) || 0
            }

            function d(t) {
                for (var e = [], n = 1; n < arguments.length; n++) e[n - 1] = arguments[n];
                return e.reduce((function(e, n) {
                    return e + h(t["border-" + n + "-width"])
                }), 0)
            }

            function v(t) {
                var e = t.clientWidth,
                    n = t.clientHeight;
                if (!e && !n) return p;
                var o = f(t).getComputedStyle(t),
                    r = function(t) {
                        for (var e = {}, n = 0, o = ["top", "right", "bottom", "left"]; n < o.length; n++) {
                            var r = o[n],
                                i = t["padding-" + r];
                            e[r] = h(i)
                        }
                        return e
                    }(o),
                    i = r.left + r.right,
                    a = r.top + r.bottom,
                    u = h(o.width),
                    s = h(o.height);
                if ("border-box" === o.boxSizing && (Math.round(u + i) !== e && (u -= d(o, "left", "right") + i), Math.round(s + a) !== n && (s -= d(o, "top", "bottom") + a)), ! function(t) {
                        return t === f(t).document.documentElement
                    }(t)) {
                    var c = Math.round(u + i) - e,
                        l = Math.round(s + a) - n;
                    1 !== Math.abs(c) && (u -= c), 1 !== Math.abs(l) && (s -= l)
                }
                return g(r.left, r.top, u, s)
            }
            var m = "undefined" !== typeof SVGGraphicsElement ? function(t) {
                return t instanceof f(t).SVGGraphicsElement
            } : function(t) {
                return t instanceof f(t).SVGElement && "function" === typeof t.getBBox
            };

            function y(t) {
                return r ? m(t) ? function(t) {
                    var e = t.getBBox();
                    return g(0, 0, e.width, e.height)
                }(t) : v(t) : p
            }

            function g(t, e, n, o) {
                return {
                    x: t,
                    y: e,
                    width: n,
                    height: o
                }
            }
            var b = function() {
                    function t(t) {
                        this.broadcastWidth = 0, this.broadcastHeight = 0, this.contentRect_ = g(0, 0, 0, 0), this.target = t
                    }
                    return t.prototype.isActive = function() {
                        var t = y(this.target);
                        return this.contentRect_ = t, t.width !== this.broadcastWidth || t.height !== this.broadcastHeight
                    }, t.prototype.broadcastRect = function() {
                        var t = this.contentRect_;
                        return this.broadcastWidth = t.width, this.broadcastHeight = t.height, t
                    }, t
                }(),
                w = function(t, e) {
                    var n = function(t) {
                        var e = t.x,
                            n = t.y,
                            o = t.width,
                            r = t.height,
                            i = "undefined" !== typeof DOMRectReadOnly ? DOMRectReadOnly : Object,
                            a = Object.create(i.prototype);
                        return l(a, {
                            x: e,
                            y: n,
                            width: o,
                            height: r,
                            top: n,
                            right: e + o,
                            bottom: r + n,
                            left: e
                        }), a
                    }(e);
                    l(this, {
                        target: t,
                        contentRect: n
                    })
                },
                O = function() {
                    function t(t, e, n) {
                        if (this.activeObservations_ = [], this.observations_ = new o, "function" !== typeof t) throw new TypeError("The callback provided as parameter 1 is not a function.");
                        this.callback_ = t, this.controller_ = e, this.callbackCtx_ = n
                    }
                    return t.prototype.observe = function(t) {
                        if (!arguments.length) throw new TypeError("1 argument required, but only 0 present.");
                        if ("undefined" !== typeof Element && Element instanceof Object) {
                            if (!(t instanceof f(t).Element)) throw new TypeError('parameter 1 is not of type "Element".');
                            var e = this.observations_;
                            e.has(t) || (e.set(t, new b(t)), this.controller_.addObserver(this), this.controller_.refresh())
                        }
                    }, t.prototype.unobserve = function(t) {
                        if (!arguments.length) throw new TypeError("1 argument required, but only 0 present.");
                        if ("undefined" !== typeof Element && Element instanceof Object) {
                            if (!(t instanceof f(t).Element)) throw new TypeError('parameter 1 is not of type "Element".');
                            var e = this.observations_;
                            e.has(t) && (e.delete(t), e.size || this.controller_.removeObserver(this))
                        }
                    }, t.prototype.disconnect = function() {
                        this.clearActive(), this.observations_.clear(), this.controller_.removeObserver(this)
                    }, t.prototype.gatherActive = function() {
                        var t = this;
                        this.clearActive(), this.observations_.forEach((function(e) {
                            e.isActive() && t.activeObservations_.push(e)
                        }))
                    }, t.prototype.broadcastActive = function() {
                        if (this.hasActive()) {
                            var t = this.callbackCtx_,
                                e = this.activeObservations_.map((function(t) {
                                    return new w(t.target, t.broadcastRect())
                                }));
                            this.callback_.call(t, e, t), this.clearActive()
                        }
                    }, t.prototype.clearActive = function() {
                        this.activeObservations_.splice(0)
                    }, t.prototype.hasActive = function() {
                        return this.activeObservations_.length > 0
                    }, t
                }(),
                x = "undefined" !== typeof WeakMap ? new WeakMap : new o,
                T = function t(e) {
                    if (!(this instanceof t)) throw new TypeError("Cannot call a class as a function.");
                    if (!arguments.length) throw new TypeError("1 argument required, but only 0 present.");
                    var n = c.getInstance(),
                        o = new O(e, n, this);
                    x.set(this, o)
                };
            ["observe", "unobserve", "disconnect"].forEach((function(t) {
                T.prototype[t] = function() {
                    var e;
                    return (e = x.get(this))[t].apply(e, arguments)
                }
            }));
            const E = "undefined" !== typeof i.ResizeObserver ? i.ResizeObserver : T
        }
    }
]);
//# sourceMappingURL=31528.ea91d3d6.chunk.js.map