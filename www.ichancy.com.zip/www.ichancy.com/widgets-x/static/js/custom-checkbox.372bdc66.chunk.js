"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [51172], {
        777196: (s, e, a) => {
            a.r(e), a.d(e, {
                Checkbox: () => t
            });
            a(939307);
            var c = a(510641),
                o = a(570579);
            const t = s => {
                let {
                    className: e = "",
                    size: a = "default",
                    ...t
                } = s;
                return (0, o.jsx)(c.default, { ...t,
                    className: `${e} checkbox__${a}`
                })
            }
        }
    }
]);
//# sourceMappingURL=custom-checkbox.372bdc66.chunk.js.map