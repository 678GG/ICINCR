"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [11453], {
        999698: (e, t, a) => {
            a.r(t), a.d(t, {
                BetModalCheck: () => b
            });
            var n = a(365043),
                o = a(995392),
                s = a(140854),
                i = a.n(s),
                c = a(989618),
                r = a(384716),
                l = a(570579);
            const {
                BetTicketModal: d
            } = (0, c.R)((() => Promise.all([a.e(87161), a.e(34426), a.e(55608), a.e(84107), a.e(81927), a.e(35834), a.e(70136), a.e(28151), a.e(94574), a.e(51238), a.e(95561), a.e(90440), a.e(35905), a.e(58073), a.e(87154), a.e(40999), a.e(14971), a.e(97760), a.e(1162), a.e(54864), a.e(60465)]).then(a.bind(a, 102070)))), b = () => {
                const e = (0, r.o)(),
                    t = (0, o.W6)(),
                    [a, s] = (0, n.useState)(!1),
                    [c, b] = (0, n.useState)(null);
                (0, n.useEffect)((() => {
                    if (e.bet_id) {
                        var t;
                        const a = `${window.location.origin}/${(null===(t=window.currentLanguageObject)||void 0===t?void 0:t.prefix)||"en"}/get-sharing-data?bet_id=${e.bet_id}`;
                        (async () => {
                            const e = await i().get(a);
                            b(e.data.data), s(!0)
                        })().catch(console.error)
                    }
                }), [e.bet_id]);
                return a && c ? (0, l.jsx)(n.Suspense, {
                    children: (0, l.jsx)(d, {
                        visible: !0,
                        onCancel: () => {
                            const e = new URLSearchParams(window.location.search);
                            e.has("bet_id") && (e.delete("bet_id"), t.replace({
                                search: e.toString()
                            })), s(!1)
                        },
                        value: Number(e.bet_id),
                        data: {
                            params: c,
                            locale: ""
                        },
                        disableDownload: !0
                    })
                }) : null
            }
        }
    }
]);
//# sourceMappingURL=BetModalCheck.d34adbbb.chunk.js.map