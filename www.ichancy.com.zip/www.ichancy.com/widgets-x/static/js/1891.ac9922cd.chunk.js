"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [1891], {
        224272: (E, e, T) => {
            T.d(e, {
                j: () => G
            });
            const G = {
                GET_OPTIONS: "getOptions",
                GET_GAMES: "getGames",
                GET_PROMOTED_GAMES: "getPromotedGames",
                GET_TOURNAMENT_GAMES: "getTournamentGames",
                GET_GAME_TOURNAMENTS: "getTournaments",
                GET_GROUPED_PROVIDER_OPTIONS: "getGroupedProviderOptions",
                GET_DECENTRALIZED_GAMES: "games",
                GET_DECENTRALIZED_GAME: "game",
                GET_DECENTRALIZED_CATEGORIES: "categories"
            }
        }
    }
]);
//# sourceMappingURL=1891.ac9922cd.chunk.js.map