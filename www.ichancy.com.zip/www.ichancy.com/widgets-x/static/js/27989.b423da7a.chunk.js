"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [27989], {
        527989: (e, l, o) => {
            o.d(l, {
                c: () => u,
                l: () => p
            });
            o(956062);
            var n = o(215684),
                r = (o(482306), o(68488)),
                s = o(889181),
                t = o(365043),
                a = o(870905),
                d = o(735905),
                i = o(55418),
                c = o(570579);
            const u = r.default.Option,
                p = (0, t.memo)((e => {
                    var l;
                    let {
                        label: o,
                        wrapperClassName: u,
                        withoutMargin: p,
                        disabled: v,
                        children: h,
                        search: m = !0,
                        onSelect: f,
                        onApply: w,
                        ...b
                    } = e;
                    const _ = (0, t.useRef)(null),
                        x = Array.isArray(h) ? h : [h],
                        {
                            t: k
                        } = (0, a.B)(),
                        C = (0, t.useCallback)(((e, l) => {
                            "multiple" !== b.mode && m && _.current && _.current.blur(), f && f(e, l)
                        }), [m, f]),
                        j = !("undefined" !== typeof v || 1 !== (null === h || void 0 === h ? void 0 : h.length)) || v;
                    return (0, c.jsxs)("div", {
                        className: (0, s.A)(["x-select", {
                            "x-select__withoutMargin": p
                        }, u]),
                        children: [!!o && (0, c.jsx)("div", {
                            className: "x-select__label",
                            children: o
                        }), (0, c.jsx)(r.default, {
                            ref: _,
                            disabled: j,
                            suffixIcon: (0, c.jsx)(d.GlobalIcon, {
                                lib: "generic",
                                name: "caretDownSmall",
                                theme: "default",
                                size: 20,
                                skeleton: !0
                            }),
                            showAction: ["focus"],
                            showSearch: m && (null !== (l = null === x || void 0 === x ? void 0 : x.length) && void 0 !== l ? l : 0) > 5,
                            filterOption: (e, l) => {
                                var o;
                                return `${null!==(o=null===l||void 0===l?void 0:l.children)&&void 0!==o?o:""}`.toLowerCase().includes(e.toLowerCase())
                            },
                            onSelect: C,
                            dropdownRender: e => w ? (0, c.jsxs)("div", {
                                onMouseDown: e => {
                                    e.preventDefault(), e.stopPropagation()
                                },
                                children: [e, (0, c.jsx)("div", {
                                    className: "v3Select__overridden__buttonWrapper",
                                    children: (0, c.jsx)(n.default, {
                                        type: "primary",
                                        className: "v3Select__overridden",
                                        onClick: w,
                                        children: k("account.applyButton")
                                    })
                                })]
                            }) : e,
                            ...b,
                            dropdownClassName: (0, s.A)([b.dropdownClassName || "", {
                                "antdDropdown--mobile": (0, i.F)()
                            }]),
                            children: x
                        })]
                    })
                }))
        }
    }
]);
//# sourceMappingURL=27989.b423da7a.chunk.js.map