"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [40567], {
        240567: (e, t, l) => {
            l.r(t), l.d(t, {
                default: () => d
            });
            var r, n, a, i, C, o, s, p = l(365043);

            function c() {
                return c = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var l = arguments[t];
                        for (var r in l) Object.prototype.hasOwnProperty.call(l, r) && (e[r] = l[r])
                    }
                    return e
                }, c.apply(this, arguments)
            }

            function f(e, t) {
                let {
                    title: l,
                    titleId: f,
                    ...E
                } = e;
                return p.createElement("svg", c({
                    width: 32,
                    height: 32,
                    viewBox: "0 0 32 33",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    ref: t,
                    "aria-labelledby": f
                }, E), l ? p.createElement("title", {
                    id: f
                }, l) : null, r || (r = p.createElement("path", {
                    d: "M0 29.1799V25.3822C0 11.3662 11.3623 0.00390625 25.3783 0.00390625H29.176C30.7354 0.00390625 32 1.26848 32 2.82791V6.62562C32 20.6416 20.6377 32.0039 6.62171 32.0039H2.824C1.26457 32.0039 0 30.7393 0 29.1799Z",
                    fill: "#F2F2F2"
                })), n || (n = p.createElement("path", {
                    d: "M0 29.176V25.3783C0 11.3623 11.3623 0 25.3783 0H29.176C30.7354 0 32 1.26457 32 2.824V6.62171C32 20.6377 20.6377 32 6.62171 32H2.824C1.26457 32 0 30.7354 0 29.176Z",
                    fill: "url(#paint0_linear_226_2)"
                })), a || (a = p.createElement("path", {
                    d: "M31.7172 2.5452C30.7858 2.5452 30.0309 3.30005 30.0309 4.23148V4.65605C30.0309 18.6721 18.6686 30.0344 4.65264 30.0344H3.40121C2.46921 30.0344 1.71436 30.7898 1.71436 31.7212V31.7766C2.05493 31.9224 2.42978 32.0041 2.82407 32.0041H6.62178C20.6378 32.0041 32.0001 20.6418 32.0001 6.62579V2.82805C31.8898 2.71777 31.8269 2.65491 31.7172 2.5452Z",
                    fill: "#E0282E"
                })), i || (i = p.createElement("path", {
                    d: "M31.7172 2.54517C30.7858 2.54517 30.0309 3.30002 30.0309 4.23145V4.65602C30.0309 18.672 18.6686 30.0343 4.65264 30.0343H3.40121C2.46921 30.0343 1.71436 30.7898 1.71436 31.7212V31.7766C2.05493 31.9223 2.42978 32.004 2.82407 32.004H6.62178C20.6378 32.004 32.0001 20.6418 32.0001 6.62575V2.82802C31.8898 2.71774 31.8269 2.65488 31.7172 2.54517Z",
                    fill: "url(#paint1_linear_226_2)"
                })), C || (C = p.createElement("path", {
                    d: "M3.42848 27.7069C3.36848 27.7069 3.30734 27.6972 3.24734 27.6772C2.94848 27.5772 2.78677 27.2532 2.88677 26.9538C3.62277 24.7538 4.41077 22.7207 5.22963 20.9109C5.35992 20.6235 5.6982 20.4955 5.98564 20.6258C6.27307 20.7561 6.40107 21.0944 6.27078 21.3818C5.46848 23.1561 4.6942 25.1532 3.97077 27.3161C3.8902 27.5555 3.66734 27.7069 3.42848 27.7069Z",
                    fill: "#555A66"
                })), o || (o = p.createElement("path", {
                    d: "M8.14729 17.1468C8.04558 17.1468 7.94272 17.1199 7.84958 17.0628C7.58044 16.8982 7.49587 16.5462 7.66044 16.277C12.433 8.47476 18.7124 5.0753 26.673 2.37073C26.973 2.26959 27.2964 2.42959 27.3982 2.72788C27.4999 3.02673 27.3399 3.3513 27.041 3.45302C19.3153 6.07761 13.229 9.3639 8.63529 16.8736C8.52729 17.0496 8.33987 17.1468 8.14729 17.1468Z",
                    fill: "#555A66"
                })), s || (s = p.createElement("defs", null, p.createElement("linearGradient", {
                    id: "paint0_linear_226_2",
                    x1: 28,
                    y1: -2.5,
                    x2: .999999,
                    y2: 31.5,
                    gradientUnits: "userSpaceOnUse"
                }, p.createElement("stop", {
                    stopColor: "white",
                    stopOpacity: 0
                }), p.createElement("stop", {
                    offset: 1,
                    stopColor: "#E1E1E1"
                })), p.createElement("linearGradient", {
                    id: "paint1_linear_226_2",
                    x1: 30.5,
                    y1: 3,
                    x2: 3.5,
                    y2: 32,
                    gradientUnits: "userSpaceOnUse"
                }, p.createElement("stop", {
                    stopColor: "#E0282E",
                    stopOpacity: 0
                }), p.createElement("stop", {
                    offset: 1,
                    stopColor: "#BE181D"
                })))))
            }
            const E = p.forwardRef(f),
                d = (l.p, E)
        }
    }
]);
//# sourceMappingURL=40567.b99e09a8.chunk.js.map