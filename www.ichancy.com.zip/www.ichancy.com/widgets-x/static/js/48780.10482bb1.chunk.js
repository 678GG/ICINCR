"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [48780], {
        548780: (s, o, e) => {
            e.r(o), e.d(o, {
                default: () => k
            });
            const k = {}
        }
    }
]);
//# sourceMappingURL=48780.10482bb1.chunk.js.map