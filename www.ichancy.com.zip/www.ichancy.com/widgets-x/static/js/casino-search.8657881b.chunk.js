"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [90411], {
        454071: (s, e, o) => {
            o.r(e), o.d(e, {
                CasinoSearch: () => k
            });
            var n = o(365043),
                a = o(249662),
                r = o(989618),
                c = o(570579);
            const {
                CasinoSearchComponent: h
            } = (0, r.R)((() => Promise.all([o.e(43541), o.e(91052), o.e(27388)]).then(o.bind(o, 780723)))), k = s => (0, c.jsx)(n.Suspense, {
                fallback: (0, c.jsx)(a.Q, {}),
                children: (0, c.jsx)(h, { ...s
                })
            })
        }
    }
]);
//# sourceMappingURL=casino-search.8657881b.chunk.js.map