"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [88397], {
        188397: (e, t, n) => {
            n.d(t, {
                HM: () => A,
                gc: () => h,
                C3: () => p
            });
            n(678257);
            var a = n(144719),
                o = n(197262),
                c = n(365043),
                s = n(507712),
                i = n(679559),
                u = n(556785),
                l = n(123213),
                m = n(457250),
                d = n(735905),
                r = n(179177),
                y = n(570579);
            const b = "true" === l.A.getItem((0, u.U)("account", "LOYALTY_POINTS_AVAILABLE")),
                f = () => {
                    const e = (0, s.d4)(i.M0),
                        [t, n] = (0, c.useState)();
                    return (0, c.useEffect)((() => {
                        var t, a, o;
                        n(((null === e || void 0 === e || null === (t = e.casinoBonuses) || void 0 === t ? void 0 : t.length) || 0) + ((null === e || void 0 === e || null === (a = e.freeBonuses) || void 0 === a ? void 0 : a.length) || 0) + ((null === e || void 0 === e || null === (o = e.freeSpinBonuses) || void 0 === o ? void 0 : o.length) || 0))
                    }), [e]), t ? (0, y.jsx)(a.A, {
                        status: "error",
                        className: "profileInfo__bonuses__badge profileInfo__badge",
                        text: `${t} ${o.A.t("account.bonuses")}`
                    }) : null
                },
                h = [{
                    key: "accounts:settings:profile",
                    name: o.A.t("account.myProfile"),
                    icon: (0, y.jsx)(d.GlobalIcon, {
                        lib: "account",
                        name: "accountSettingsOutlined",
                        theme: "default",
                        size: 24
                    }),
                    query: {
                        accounts: "*",
                        settings: "*",
                        profile: "*"
                    },
                    hidden: !1,
                    formType: "tabEditProfile"
                }, {
                    key: "accounts:settings:password",
                    name: o.A.t("account.changePassword"),
                    icon: (0, y.jsx)(d.GlobalIcon, {
                        lib: "account",
                        name: "changePasswordOutlined",
                        theme: "default",
                        size: 24
                    }),
                    query: {
                        accounts: "*",
                        settings: "*",
                        password: "*"
                    },
                    hidden: !1,
                    formType: "tabChangePassword"
                }, {
                    key: "accounts:settings:documents",
                    name: o.A.t("account.documents"),
                    icon: (0, y.jsx)(d.GlobalIcon, {
                        lib: "account",
                        name: "documentsOutlined",
                        theme: "default",
                        size: 24
                    }),
                    query: {
                        accounts: "*",
                        settings: "*",
                        documents: "*"
                    },
                    hidden: !1,
                    formType: "tabDocuments"
                }, {
                    key: "accounts:settings:limits",
                    name: o.A.t("account.limits"),
                    icon: (0, y.jsx)(d.GlobalIcon, {
                        lib: "account",
                        name: "limitsOutlined",
                        theme: "default",
                        size: 24
                    }),
                    query: {
                        accounts: "*",
                        settings: "*",
                        limits: "*"
                    },
                    hidden: !1,
                    formType: "tabBetLimit"
                }, {
                    key: "accounts:settings:self-exclusion",
                    name: o.A.t("account.self-exclusion"),
                    icon: (0, y.jsx)(d.GlobalIcon, {
                        lib: "account",
                        name: "selfExclusionOutlined",
                        theme: "default",
                        size: 24
                    }),
                    query: {
                        accounts: "*",
                        settings: "*",
                        "self-exclusion": "*"
                    },
                    hidden: !1,
                    formType: "tabSelfExclusion"
                }, {
                    key: "accounts:settings:account-status",
                    name: o.A.t("account.account-status"),
                    icon: (0, y.jsx)(d.GlobalIcon, {
                        lib: "account",
                        name: "personalCardOutlined",
                        theme: "default",
                        size: 24
                    }),
                    query: {
                        accounts: "*",
                        settings: "*",
                        "account-status": "*"
                    },
                    hidden: !1,
                    formType: "accountStatus"
                }, {
                    key: "accounts:settings:timeout",
                    name: o.A.t("account.timeOut"),
                    icon: (0, y.jsx)(d.GlobalIcon, {
                        lib: "account",
                        name: "timeOutOutlined",
                        theme: "default",
                        size: 24
                    }),
                    query: {
                        accounts: "*",
                        settings: "*",
                        timeout: "*"
                    },
                    hidden: !1,
                    formType: "tabTimeOut"
                }, {
                    key: "accounts:settings:reality-check",
                    name: o.A.t("account.realityCheck"),
                    icon: (0, y.jsx)(d.GlobalIcon, {
                        lib: "account",
                        name: "realityCheckOutlined",
                        theme: "default",
                        size: 24
                    }),
                    query: {
                        accounts: "*",
                        settings: "*",
                        "reality-check": "*"
                    },
                    hidden: !1,
                    formType: "sessionTime"
                }, {
                    key: "accounts:settings:notification-settings",
                    name: o.A.t("account.notificationSettings"),
                    icon: (0, y.jsx)(d.GlobalIcon, {
                        lib: "account",
                        name: "notificationSettingsOutlined",
                        theme: "default",
                        size: 24
                    }),
                    query: {
                        accounts: "*",
                        settings: "*",
                        "notification-settings": "*"
                    },
                    hidden: !1,
                    formType: "tabNotifications"
                }, {
                    key: "accounts:settings:two-factor-auth",
                    name: o.A.t("account.two-factor-authentication"),
                    icon: (0, y.jsx)(d.GlobalIcon, {
                        lib: "account",
                        name: "twoFactorAuthenticationOutlined",
                        theme: "default",
                        size: 24
                    }),
                    query: {
                        accounts: "*",
                        settings: "*",
                        "two-factor-auth": "*"
                    },
                    hidden: !1,
                    formType: "twoFactorAuthentication"
                }, {
                    key: "accounts:settings:accumulated-profit",
                    name: o.A.t("account.accumulatedProfit"),
                    icon: (0, y.jsx)(d.GlobalIcon, {
                        lib: "account",
                        name: "accumulatedProfitWalletOutlined",
                        theme: "default",
                        size: 24
                    }),
                    query: {
                        accounts: "*",
                        settings: "*",
                        "accumulated-profit": "*"
                    },
                    hidden: !1,
                    formType: "tabAccumulatedLosses"
                }, {
                    key: "accounts:settings:verify-account",
                    name: o.A.t("account.verify-account"),
                    icon: (0, y.jsx)(d.GlobalIcon, {
                        lib: "account",
                        name: "verifyAccountOutlined",
                        theme: "default",
                        size: 24
                    }),
                    query: {
                        accounts: "*",
                        settings: "*",
                        "verify-account": "*"
                    },
                    hidden: !1,
                    formType: "tabVerifyAccount"
                }, {
                    key: "accounts:settings:gamstop",
                    name: o.A.t("account.gamstop"),
                    icon: (0, y.jsx)(d.GlobalIcon, {
                        lib: "account",
                        name: "gamstopOutlined",
                        theme: "default",
                        size: 24
                    }),
                    query: {
                        accounts: "*",
                        settings: "*",
                        gamstop: "*"
                    },
                    hidden: !1,
                    formType: "tabGamstop"
                }, {
                    key: "accounts:settings:login-limit",
                    name: o.A.t("account.loginLimit"),
                    icon: (0, y.jsx)(d.GlobalIcon, {
                        lib: "account",
                        name: "loginLimitOutlined",
                        theme: "default",
                        size: 24
                    }),
                    query: {
                        accounts: "*",
                        settings: "*",
                        "login-limit": "*"
                    },
                    hidden: !1,
                    formType: "loginLimit"
                }, {
                    key: "accounts:settings:sessions",
                    name: o.A.t("account.my-sessions"),
                    icon: (0, y.jsx)(d.GlobalIcon, {
                        lib: "account",
                        name: "mySessionsOutlined",
                        theme: "default",
                        size: 24
                    }),
                    query: {
                        accounts: "*",
                        settings: "*",
                        sessions: "*"
                    },
                    hidden: !1,
                    formType: "tabLoginHistory"
                }, ...r.Ay.SHOW_ACCOUNT_SESSION ? [{
                    key: "accounts:settings:session-information",
                    name: o.A.t("account.session-information"),
                    icon: (0, y.jsx)(d.GlobalIcon, {
                        lib: "account",
                        name: "sessionInfo",
                        theme: "default",
                        size: 24
                    }),
                    query: {
                        accounts: "*",
                        settings: "*",
                        "session-information": "*"
                    },
                    hidden: !1,
                    formType: "current-session-info"
                }] : [], {
                    key: "accounts:settings:safer-gambling",
                    name: o.A.t("account.saferGambling"),
                    icon: (0, y.jsx)(d.GlobalIcon, {
                        lib: "account",
                        name: "saferGambling",
                        theme: "default",
                        size: 24
                    }),
                    query: {
                        accounts: "*",
                        settings: "*",
                        "safer-gambling": "*"
                    },
                    hidden: !1,
                    formType: "saferGambling"
                }, {
                    key: "accounts:settings:availability-period",
                    name: o.A.t("account.availabilityPeriod"),
                    icon: (0, y.jsx)(d.GlobalIcon, {
                        lib: "account",
                        name: "availabilityPeriod",
                        theme: "default",
                        size: 24
                    }),
                    query: {
                        accounts: "*",
                        settings: "*",
                        "availability-period": "*"
                    },
                    hidden: !1,
                    formType: "availability-period"
                }],
                g = [{
                    key: "accounts:wallet:deposit",
                    name: o.A.t("account.deposit"),
                    icon: (0, y.jsx)(d.GlobalIcon, {
                        lib: "account",
                        name: "depositOutlined",
                        theme: "default",
                        size: 24
                    }),
                    query: {
                        accounts: "*",
                        wallet: "*",
                        deposit: "*"
                    },
                    hidden: !1
                }, {
                    key: "accounts:wallet:withdraw",
                    name: o.A.t("account.withdraw"),
                    icon: (0, y.jsx)(d.GlobalIcon, {
                        lib: "account",
                        name: "withdrawOutlined",
                        theme: "default",
                        size: 24
                    }),
                    query: {
                        accounts: "*",
                        wallet: "*",
                        withdraw: "*"
                    },
                    hidden: !1
                }, {
                    key: "accounts:wallet:stake-and-earn",
                    name: o.A.t("account.stake-and-earn"),
                    icon: (0, y.jsx)(d.GlobalIcon, {
                        lib: "account",
                        name: "stakeandearnOutlined",
                        theme: "default",
                        size: 24
                    }),
                    query: {
                        accounts: "*",
                        wallet: "*",
                        "stake-and-earn": "*"
                    },
                    hidden: !1
                }, {
                    key: "accounts:wallet:balance-history",
                    name: o.A.t("account.balance-history"),
                    icon: (0, y.jsx)(d.GlobalIcon, {
                        lib: "account",
                        name: "documentsOutlined",
                        theme: "default",
                        size: 24
                    }),
                    query: {
                        accounts: "*",
                        wallet: "*",
                        "balance-history": "*"
                    },
                    hidden: !1
                }, {
                    key: "accounts:wallet:my-cards",
                    name: o.A.t("account.myCards"),
                    icon: (0, y.jsx)(d.GlobalIcon, {
                        lib: "account",
                        name: "myCardsOutlined",
                        theme: "default",
                        size: 24
                    }),
                    query: {
                        accounts: "*",
                        wallet: "*",
                        "my-cards": "*"
                    },
                    alias: "myCards",
                    hidden: !1
                }, ...r.Ay.SHOW_ACCOUNT_STATEMENT ? [{
                    key: "accounts:wallet:statement",
                    name: o.A.t("account.statement"),
                    icon: (0, y.jsx)(d.GlobalIcon, {
                        lib: "account",
                        name: "statementOutlined",
                        theme: "default",
                        size: 24
                    }),
                    query: {
                        accounts: "*",
                        wallet: "*",
                        statement: "*"
                    },
                    alias: "statement",
                    hidden: !1
                }] : []],
                p = [{
                    key: "accounts:bonuses:bonus",
                    name: o.A.t("account.bonuses"),
                    icon: (0, y.jsx)(d.GlobalIcon, {
                        lib: "account",
                        name: "bonusesOutlined",
                        theme: "default",
                        size: 24
                    }),
                    extra: (0, y.jsx)(f, {}),
                    query: {
                        accounts: "*",
                        bonuses: "*",
                        bonus: "*"
                    },
                    hidden: !1
                }, {
                    key: "accounts:bonuses:refer-friend",
                    name: o.A.t("account.referFriend"),
                    icon: (0, y.jsx)(d.GlobalIcon, {
                        lib: "account",
                        name: "referFriendOutlined",
                        theme: "default",
                        size: 24
                    }),
                    query: {
                        accounts: "*",
                        bonuses: "*",
                        "refer-friend": "*"
                    },
                    hidden: !1
                }, {
                    key: "accounts:bonuses:management",
                    name: o.A.t("account.bonusManagement"),
                    icon: (0, y.jsx)(d.GlobalIcon, {
                        lib: "generic",
                        name: "maximizeAlt",
                        theme: "default",
                        size: 24
                    }),
                    query: {
                        accounts: "*",
                        bonuses: "*",
                        management: "*"
                    },
                    hidden: !1
                }],
                A = [{
                    key: "accounts:login",
                    name: o.A.t("account.login"),
                    icon: (0, y.jsx)(d.GlobalIcon, {
                        lib: "account",
                        name: "changePasswordOutlined",
                        theme: "default",
                        size: 24
                    }),
                    auth: !1,
                    query: {
                        accounts: "*",
                        login: "*"
                    },
                    hidden: !1,
                    formType: "login"
                }, {
                    key: "accounts:register",
                    name: o.A.t("account.register"),
                    icon: (0, y.jsx)(d.GlobalIcon, {
                        lib: "account",
                        name: "changePasswordOutlined",
                        theme: "default",
                        size: 24
                    }),
                    auth: !1,
                    query: {
                        accounts: "*",
                        register: "*"
                    },
                    hidden: !1,
                    formType: "register"
                }, {
                    key: "accounts:settings",
                    name: o.A.t("account.accountSettings"),
                    icon: (0, y.jsx)(d.GlobalIcon, {
                        lib: "account",
                        name: "accountSettingsOutlined",
                        theme: "default",
                        size: 24
                    }),
                    auth: !0,
                    query: {
                        accounts: "*",
                        settings: "*",
                        profile: "*"
                    },
                    queryMobile: {
                        accounts: "*",
                        settings: "*",
                        menu: "*"
                    },
                    children: h,
                    hidden: !1,
                    formType: "myProfile"
                }, {
                    key: "accounts:wallet",
                    name: o.A.t("account.wallet"),
                    auth: !0,
                    icon: (0, y.jsx)(d.GlobalIcon, {
                        lib: "account",
                        name: "walletOutlined",
                        theme: "default",
                        size: 24
                    }),
                    query: {
                        accounts: "*",
                        wallet: "*",
                        deposit: "*"
                    },
                    children: g,
                    hidden: !1,
                    formType: "myWallet"
                }, {
                    key: "accounts:bonuses",
                    name: o.A.t("account.bonuses"),
                    auth: !0,
                    icon: (0, y.jsx)(d.GlobalIcon, {
                        lib: "account",
                        name: "bonusesOutlined",
                        theme: "default",
                        size: 24
                    }),
                    query: {
                        accounts: "*",
                        bonuses: "*",
                        bonus: "*"
                    },
                    queryMenu: {
                        accounts: "*",
                        bonuses: "*",
                        menu: "*"
                    },
                    children: p,
                    hidden: !1,
                    formType: "bonuses"
                }, {
                    key: "accounts:bonus-iframe",
                    name: o.A.t("account.bonus-iframe"),
                    auth: !0,
                    icon: (0, y.jsx)(d.GlobalIcon, {
                        lib: "account",
                        name: "vip",
                        theme: "default",
                        color: "#A57B1B",
                        size: 24
                    }),
                    query: {
                        accounts: "*",
                        "bonus-iframe": "*"
                    },
                    hidden: !1,
                    formType: "accountBonusIframe"
                }, ...b ? [{
                    key: "accounts:loyalty-points",
                    name: o.A.t("account.loyaltyPoints"),
                    auth: !0,
                    icon: (0, y.jsx)(d.GlobalIcon, {
                        lib: "account",
                        name: "medal",
                        theme: "default",
                        size: 24
                    }),
                    query: {
                        accounts: "*",
                        "loyalty-points": "*"
                    },
                    hidden: !1,
                    formType: "loyalty-points"
                }] : [], {
                    key: "accounts:messages",
                    name: o.A.t("account.messages"),
                    auth: !0,
                    icon: (0, y.jsx)(d.GlobalIcon, {
                        lib: "account",
                        name: "messagesOutlined",
                        theme: "default",
                        size: 24
                    }),
                    query: {
                        accounts: "*",
                        messages: "*"
                    },
                    hidden: !1,
                    formType: "messages"
                }, ...m.nK ? [] : [{
                    key: "accounts:bet-history",
                    name: o.A.t("account.betHistory"),
                    auth: !0,
                    icon: (0, y.jsx)(d.GlobalIcon, {
                        lib: "account",
                        name: "betHistoryOutlined",
                        theme: "default",
                        size: 24
                    }),
                    query: {
                        accounts: "*",
                        "bet-history": "*"
                    },
                    hidden: !1,
                    formType: "myBets"
                }], {
                    key: "accounts:journey",
                    name: o.A.t("account.customerJourney"),
                    auth: !0,
                    icon: (0, y.jsx)(d.GlobalIcon, {
                        lib: "account",
                        name: "customerJourney",
                        theme: "default",
                        size: 24
                    }),
                    query: {
                        accounts: "*",
                        journey: "*"
                    },
                    hidden: !1,
                    formType: "customerJourney"
                }, {
                    key: "accounts:rewards",
                    name: o.A.t("account.rewards"),
                    auth: !0,
                    icon: (0, y.jsx)(d.GlobalIcon, {
                        lib: "account",
                        name: "rewardsOutlined",
                        theme: "default",
                        size: 24
                    }),
                    query: {
                        accounts: "*",
                        rewards: "*"
                    },
                    hidden: !1,
                    formType: "rewards"
                }]
        }
    }
]);
//# sourceMappingURL=88397.ee818f0f.chunk.js.map