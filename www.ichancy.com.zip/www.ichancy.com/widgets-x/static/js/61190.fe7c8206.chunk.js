"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [61190], {
        261190: (e, a, l) => {
            l.d(a, {
                LB: () => i,
                Mi: () => R,
                Nk: () => O,
                Wq: () => M,
                Xn: () => C,
                Yr: () => S,
                ZD: () => v,
                _w: () => h,
                f7: () => g,
                fY: () => N,
                jh: () => E,
                oJ: () => A,
                vO: () => y
            });
            var n = l(197262),
                o = l(254639),
                r = l(179177);
            const t = o.d.map((e => ({
                    label: e.translationName,
                    value: e.code,
                    name: e.name,
                    currencyCountries: e.currency,
                    alpha3Code: e.alpha3Code
                }))),
                i = [{
                    label: n.A.t("account.identityCard"),
                    value: "1"
                }, {
                    label: n.A.t("account.drivingLicense"),
                    value: "2"
                }, {
                    label: n.A.t("account.passport"),
                    value: "3"
                }, {
                    label: n.A.t("account.tesseraAt"),
                    value: "4"
                }, {
                    label: n.A.t("account.tesseraBt"),
                    value: "5"
                }, {
                    label: n.A.t("account.firearmsLicense"),
                    value: "6"
                }, {
                    label: n.A.t("account.other"),
                    value: "10"
                }],
                c = [{
                    label: n.A.t("account.incomeSourceSalary"),
                    value: "1"
                }, {
                    label: n.A.t("account.incomeSourceSelfEmployed"),
                    value: "2"
                }, {
                    label: n.A.t("account.incomeSourceInheritance"),
                    value: "3"
                }, {
                    label: n.A.t("account.incomeSourceSavings"),
                    value: "4"
                }, {
                    label: n.A.t("account.incomeSourceInvestments"),
                    value: "5"
                }, {
                    label: n.A.t("account.incomeSourcePension"),
                    value: "6"
                }, {
                    label: n.A.t("account.incomeSourceBusinessActivity"),
                    value: "7"
                }, {
                    label: n.A.t("account.incomeSourceCompetitions"),
                    value: "8"
                }, {
                    label: n.A.t("account.incomeSourceDonation"),
                    value: "9"
                }, {
                    label: n.A.t("account.incomeSourceLoan"),
                    value: "10"
                }, {
                    label: n.A.t("account.incomeSourceCapital"),
                    value: "11"
                }],
                u = [{
                    label: n.A.t("account.selectOption"),
                    value: ""
                }, {
                    label: "B\xe9nodet",
                    value: 21692
                }, {
                    label: "Biarritz",
                    value: 21694
                }, {
                    label: "Blotzheim",
                    value: 21695
                }, {
                    label: "Bordeaux",
                    value: 21696
                }, {
                    label: "Cannes Le Croisette",
                    value: 21697
                }, {
                    label: "Cap d'Adge",
                    value: 21698
                }, {
                    label: "Carry-le-Rouet",
                    value: 21699
                }, {
                    label: "Cassis",
                    value: 21700
                }, {
                    label: "Deauville",
                    value: 21701
                }, {
                    label: "Dinard",
                    value: 21702
                }, {
                    label: "Enghien-les-Bains",
                    value: 21703
                }, {
                    label: "La Baule",
                    value: 21704
                }, {
                    label: "La Rochelle",
                    value: 21705
                }, {
                    label: "Le Ruhl - Nice",
                    value: 21706
                }, {
                    label: "Le Touquet",
                    value: 21707
                }, {
                    label: "Lille",
                    value: 21708
                }, {
                    label: "Menton",
                    value: 21709
                }, {
                    label: "Niederbronn",
                    value: 21710
                }, {
                    label: "Ouistreham",
                    value: 21711
                }, {
                    label: "Ribeauvill\xe9",
                    value: 21712
                }, {
                    label: "Royan",
                    value: 21713
                }, {
                    label: "Sainte-Maxime",
                    value: 21714
                }, {
                    label: "Saint-Malo",
                    value: 21715
                }, {
                    label: "Saint-Rapha\xebl",
                    value: 21716
                }, {
                    label: "Toulouse",
                    value: 21717
                }, {
                    label: "Trouville",
                    value: 21718
                }, {
                    label: "Club Barri\xe8re Paris",
                    value: 21719
                }, {
                    label: "Fribourg",
                    value: 21720
                }, {
                    label: "Courrendlin",
                    value: 21721
                }, {
                    label: "Montreux",
                    value: 21722
                }],
                s = {
                    FR: [{
                        value: "",
                        label: n.A.t("account.birthDepartmentPlaceholder")
                    }, {
                        value: "01",
                        label: "Ain"
                    }, {
                        value: "02",
                        label: "Aisne"
                    }, {
                        value: "03",
                        label: "Allier"
                    }, {
                        value: "04",
                        label: "Alpes-de-Haute-Provence"
                    }, {
                        value: "05",
                        label: "Hautes-Alpes"
                    }, {
                        value: "06",
                        label: "Alpes-Maritimes"
                    }, {
                        value: "07",
                        label: "Ard\xe8che"
                    }, {
                        value: "08",
                        label: "Ardennes"
                    }, {
                        value: "09",
                        label: "Ari\xe8ge"
                    }, {
                        value: "10",
                        label: "Aube"
                    }, {
                        value: "11",
                        label: "Aude"
                    }, {
                        value: "12",
                        label: "Aveyron"
                    }, {
                        value: "13",
                        label: "Bouches-du-Rh\xf4ne"
                    }, {
                        value: "14",
                        label: "Calvados"
                    }, {
                        value: "15",
                        label: "Cantal"
                    }, {
                        value: "16",
                        label: "Charente"
                    }, {
                        value: "17",
                        label: "Charente-Maritime"
                    }, {
                        value: "18",
                        label: "Cher"
                    }, {
                        value: "19",
                        label: "Corr\xe8ze"
                    }, {
                        value: "21",
                        label: "C\xf4te-d'Or"
                    }, {
                        value: "22",
                        label: "C\xf4tes-dArmor"
                    }, {
                        value: "23",
                        label: "Creuse"
                    }, {
                        value: "24",
                        label: "Dordogne"
                    }, {
                        value: "25",
                        label: "Doubs"
                    }, {
                        value: "26",
                        label: "Dr\xf4me"
                    }, {
                        value: "27",
                        label: "Eure"
                    }, {
                        value: "28",
                        label: "Eure-et-Loir"
                    }, {
                        value: "29",
                        label: "Finist\xe8re"
                    }, {
                        value: "2A",
                        label: "Corse-du-Sud"
                    }, {
                        value: "2B",
                        label: "Haute-Corse"
                    }, {
                        value: "30",
                        label: "Gard"
                    }, {
                        value: "31",
                        label: "Haute-Garonne"
                    }, {
                        value: "32",
                        label: "Gers"
                    }, {
                        value: "33",
                        label: "Gironde"
                    }, {
                        value: "34",
                        label: "H\xe9rault"
                    }, {
                        value: "35",
                        label: "Ille-et-Vilaine"
                    }, {
                        value: "36",
                        label: "Indre"
                    }, {
                        value: "37",
                        label: "Indre-et-Loire"
                    }, {
                        value: "38",
                        label: "Is\xe8re"
                    }, {
                        value: "39",
                        label: "Jura"
                    }, {
                        value: "40",
                        label: "Landes"
                    }, {
                        value: "41",
                        label: "Loir-et-Cher"
                    }, {
                        value: "42",
                        label: "Loire"
                    }, {
                        value: "43",
                        label: "Haute-Loire"
                    }, {
                        value: "44",
                        label: "Loire-Atlantique"
                    }, {
                        value: "45",
                        label: "Loiret"
                    }, {
                        value: "46",
                        label: "Lot"
                    }, {
                        value: "47",
                        label: "Lot-et-Garonne"
                    }, {
                        value: "48",
                        label: "Loz\xe8re"
                    }, {
                        value: "49",
                        label: "Maine-et-Loire"
                    }, {
                        value: "50",
                        label: "Manche"
                    }, {
                        value: "51",
                        label: "Marne"
                    }, {
                        value: "52",
                        label: "Haute-Marne"
                    }, {
                        value: "53",
                        label: "Mayenne"
                    }, {
                        value: "54",
                        label: "Meurthe-et-Moselle"
                    }, {
                        value: "55",
                        label: "Meuse"
                    }, {
                        value: "56",
                        label: "Morbihan"
                    }, {
                        value: "57",
                        label: "Moselle"
                    }, {
                        value: "58",
                        label: "Ni\xe8vre"
                    }, {
                        value: "59",
                        label: "Nord"
                    }, {
                        value: "60",
                        label: "Oise"
                    }, {
                        value: "61",
                        label: "Orne"
                    }, {
                        value: "62",
                        label: "Pas-de-Calais"
                    }, {
                        value: "63",
                        label: "Puy-de-D\xf4me"
                    }, {
                        value: "64",
                        label: "Pyr\xe9n\xe9es-Atlantiques"
                    }, {
                        value: "65",
                        label: "Hautes-Pyr\xe9n\xe9es"
                    }, {
                        value: "66",
                        label: "Pyr\xe9n\xe9es-Orientales"
                    }, {
                        value: "67",
                        label: "Bas-Rhin"
                    }, {
                        value: "68",
                        label: "Haut-Rhin"
                    }, {
                        value: "69",
                        label: "Rh\xf4ne"
                    }, {
                        value: "70",
                        label: "Haute-Sa\xf4ne"
                    }, {
                        value: "71",
                        label: "Sa\xf4ne-et-Loire"
                    }, {
                        value: "72",
                        label: "Sarthe"
                    }, {
                        value: "73",
                        label: "Savoie"
                    }, {
                        value: "74",
                        label: "Haute-Savoie"
                    }, {
                        value: "75",
                        label: "Paris"
                    }, {
                        value: "76",
                        label: "Seine-Maritime"
                    }, {
                        value: "77",
                        label: "Seine-et-Marne"
                    }, {
                        value: "78",
                        label: "Yvelines"
                    }, {
                        value: "79",
                        label: "Deux-S\xe8vres"
                    }, {
                        value: "80",
                        label: "Somme"
                    }, {
                        value: "81",
                        label: "Tarn"
                    }, {
                        value: "82",
                        label: "Tarn-et-Garonne"
                    }, {
                        value: "83",
                        label: "Var"
                    }, {
                        value: "84",
                        label: "Vaucluse"
                    }, {
                        value: "85",
                        label: "Vend\xe9e"
                    }, {
                        value: "86",
                        label: "Vienne"
                    }, {
                        value: "87",
                        label: "Haute-Vienne"
                    }, {
                        value: "88",
                        label: "Vosges"
                    }, {
                        value: "89",
                        label: "Yonne"
                    }, {
                        value: "90",
                        label: "Territoire de Belfort"
                    }, {
                        value: "91",
                        label: "Essonne"
                    }, {
                        value: "92",
                        label: "Hauts-de-Seine"
                    }, {
                        value: "93",
                        label: "Seine-Saint-Denis"
                    }, {
                        value: "94",
                        label: "Val-de-Marne"
                    }, {
                        value: "95",
                        label: "Val-d'Oise"
                    }, {
                        value: "971",
                        label: "Guadeloupe"
                    }, {
                        value: "972",
                        label: "Martinique"
                    }, {
                        value: "973",
                        label: "Guyane"
                    }, {
                        value: "974",
                        label: "R\xe9union"
                    }, {
                        value: "976",
                        label: "Mayotte"
                    }, {
                        value: "99",
                        label: n.A.t("account.other")
                    }],
                    IT: [{
                        value: "",
                        label: n.A.t("account.birthDepartmentPlaceholder")
                    }, {
                        value: "AG",
                        label: "AGRIGENTO"
                    }, {
                        value: "AL",
                        label: "ALESSANDRIA"
                    }, {
                        value: "AN",
                        label: "ANCONA"
                    }, {
                        value: "AO",
                        label: "AOSTA"
                    }, {
                        value: "AP",
                        label: "ASCOLI-PICENO"
                    }, {
                        value: "AQ",
                        label: "L'AQUILA"
                    }, {
                        value: "AR",
                        label: "AREZZO"
                    }, {
                        value: "AT",
                        label: "ASTI"
                    }, {
                        value: "AV",
                        label: "AVELLINO"
                    }, {
                        value: "BA",
                        label: "BARI"
                    }, {
                        value: "BG",
                        label: "BERGAMO"
                    }, {
                        value: "BI",
                        label: "BIELLA"
                    }, {
                        value: "BL",
                        label: "BELLUNO"
                    }, {
                        value: "BN",
                        label: "BENEVENTO"
                    }, {
                        value: "BO",
                        label: "BOLOGNA"
                    }, {
                        value: "BR",
                        label: "BRINDISI"
                    }, {
                        value: "BS",
                        label: "BRESCIA"
                    }, {
                        value: "BT",
                        label: "BARLETTA-ANDRIA-TRANI"
                    }, {
                        value: "BZ",
                        label: "BOLZANO"
                    }, {
                        value: "CA",
                        label: "CAGLIARI"
                    }, {
                        value: "CB",
                        label: "CAMPOBASSO"
                    }, {
                        value: "CE",
                        label: "CASERTA"
                    }, {
                        value: "CH",
                        label: "CHIETI"
                    }, {
                        value: "CI",
                        label: "CARBONIA IGLESIAS"
                    }, {
                        value: "CL",
                        label: "CALTANISSETTA"
                    }, {
                        value: "CN",
                        label: "CUNEO"
                    }, {
                        value: "CO",
                        label: "COMO"
                    }, {
                        value: "CR",
                        label: "CREMONA"
                    }, {
                        value: "CS",
                        label: "COSENZA"
                    }, {
                        value: "CT",
                        label: "CATANIA"
                    }, {
                        value: "CZ",
                        label: "CATANZARO"
                    }, {
                        value: "EN",
                        label: "ENNA"
                    }, {
                        value: "FC",
                        label: "FORLI-CESENA"
                    }, {
                        value: "FE",
                        label: "FERRARA"
                    }, {
                        value: "FG",
                        label: "FOGGIA"
                    }, {
                        value: "FI",
                        label: "FIRENZE"
                    }, {
                        value: "FM",
                        label: "FERMO"
                    }, {
                        value: "FR",
                        label: "FROSINONE"
                    }, {
                        value: "GE",
                        label: "GENOVA"
                    }, {
                        value: "GO",
                        label: "GORIZIA"
                    }, {
                        value: "GR",
                        label: "GROSSETO"
                    }, {
                        value: "IM",
                        label: "IMPERIA"
                    }, {
                        value: "IS",
                        label: "ISERNIA"
                    }, {
                        value: "KR",
                        label: "CROTONE"
                    }, {
                        value: "LC",
                        label: "LECCO"
                    }, {
                        value: "LE",
                        label: "LECCE"
                    }, {
                        value: "LI",
                        label: "LIVORNO"
                    }, {
                        value: "LO",
                        label: "LODI"
                    }, {
                        value: "LT",
                        label: "LATINA"
                    }, {
                        value: "LU",
                        label: "LUCCA"
                    }, {
                        value: "MB",
                        label: "MONZA-BRIANZA"
                    }, {
                        value: "MC",
                        label: "MACERATA"
                    }, {
                        value: "ME",
                        label: "MESSINA"
                    }, {
                        value: "MI",
                        label: "MILANO"
                    }, {
                        value: "MN",
                        label: "MANTOVA"
                    }, {
                        value: "MO",
                        label: "MODENA"
                    }, {
                        value: "MS",
                        label: "MASSA-CARRARA"
                    }, {
                        value: "MT",
                        label: "MATERA"
                    }, {
                        value: "NA",
                        label: "NAPOLI"
                    }, {
                        value: "NO",
                        label: "NOVARA"
                    }, {
                        value: "NU",
                        label: "NUORO"
                    }, {
                        value: "OG",
                        label: "OGLIASTRA"
                    }, {
                        value: "OR",
                        label: "ORISTANO"
                    }, {
                        value: "OT",
                        label: "OLBIA TEMPIO"
                    }, {
                        value: "PA",
                        label: "PALERMO"
                    }, {
                        value: "PC",
                        label: "PIACENZA"
                    }, {
                        value: "PD",
                        label: "PADOVA"
                    }, {
                        value: "PE",
                        label: "PESCARA"
                    }, {
                        value: "PG",
                        label: "PERUGIA"
                    }, {
                        value: "PI",
                        label: "PISA"
                    }, {
                        value: "PN",
                        label: "PORDENONE"
                    }, {
                        value: "PO",
                        label: "PRATO"
                    }, {
                        value: "PR",
                        label: "PARMA"
                    }, {
                        value: "PT",
                        label: "PISTOIA"
                    }, {
                        value: "PU",
                        label: "PESARO-URBINO"
                    }, {
                        value: "PV",
                        label: "PAVIA"
                    }, {
                        value: "PZ",
                        label: "POTENZA"
                    }, {
                        value: "RA",
                        label: "RAVENNA"
                    }, {
                        value: "RC",
                        label: "REGGIO-CALABRIA"
                    }, {
                        value: "RE",
                        label: "REGGIO-EMILIA"
                    }, {
                        value: "RG",
                        label: "RAGUSA"
                    }, {
                        value: "RI",
                        label: "RIETI"
                    }, {
                        value: "RN",
                        label: "RIMINI"
                    }, {
                        value: "RM",
                        label: "ROMA"
                    }, {
                        value: "RO",
                        label: "ROVIGO"
                    }, {
                        value: "SP",
                        label: "LA-SPEZIA"
                    }, {
                        value: "SS",
                        label: "SASSARI"
                    }, {
                        value: "SA",
                        label: "SALERNO"
                    }, {
                        value: "SV",
                        label: "SAVONA"
                    }, {
                        value: "SI",
                        label: "SIENA"
                    }, {
                        value: "SR",
                        label: "SIRACUSA"
                    }, {
                        value: "SO",
                        label: "SONDRIO"
                    }, {
                        value: "SU",
                        label: "SUD SARDEGNA"
                    }, {
                        value: "TA",
                        label: "TARANTO"
                    }, {
                        value: "TE",
                        label: "TERAMO"
                    }, {
                        value: "TR",
                        label: "TERNI"
                    }, {
                        value: "TO",
                        label: "TORINO"
                    }, {
                        value: "TP",
                        label: "TRAPANI"
                    }, {
                        value: "TN",
                        label: "TRENTO"
                    }, {
                        value: "TV",
                        label: "TREVISO"
                    }, {
                        value: "TS",
                        label: "TRIESTE"
                    }, {
                        value: "UD",
                        label: "UDINE"
                    }, {
                        value: "VA",
                        label: "VARESE"
                    }, {
                        value: "VE",
                        label: "VENEZIA"
                    }, {
                        value: "VBC",
                        label: "VERBANO-CUSIO-OSSOLA"
                    }, {
                        value: "VC",
                        label: "VERCELLI"
                    }, {
                        value: "VB",
                        label: "VERBANIA"
                    }, {
                        value: "VR",
                        label: "VERONA"
                    }, {
                        value: "VI",
                        label: "VICENZA"
                    }, {
                        value: "VT",
                        label: "VITERBO"
                    }, {
                        value: "VS",
                        label: "MEDIO CAMPIDANO"
                    }, {
                        value: "VV",
                        label: "VIBO-VALENTIA"
                    }, {
                        value: "other",
                        label: n.A.t("account.other")
                    }],
                    none: [{
                        value: "99",
                        label: "Other"
                    }]
                },
                d = [{
                    Name: n.A.t("countries.Alberta"),
                    Code: "AB"
                }, {
                    Name: n.A.t("countries.BritishColumbia"),
                    Code: "BC"
                }, {
                    Name: n.A.t("countries.Manitoba"),
                    Code: "MB"
                }, {
                    Name: n.A.t("countries.NewBrunswick"),
                    Code: "NB"
                }, {
                    Name: n.A.t("countries.NewfoundlandAndLabrador"),
                    Code: "NL"
                }, {
                    Name: n.A.t("countries.NorthwestTerritories"),
                    Code: "NT"
                }, {
                    Name: n.A.t("countries.NovaScotia"),
                    Code: "NS"
                }, {
                    Name: n.A.t("countries.Nunavut"),
                    Code: "NU"
                }, {
                    Name: n.A.t("countries.Ontario"),
                    Code: "ON"
                }, {
                    Name: n.A.t("countries.PrinceEdwardIsland"),
                    Code: "PE"
                }, {
                    Name: n.A.t("countries.Quebec"),
                    Code: "QC"
                }, {
                    Name: n.A.t("countries.Saskatchewan"),
                    Code: "SK"
                }, {
                    Name: n.A.t("countries.Yukon"),
                    Code: "YT"
                }],
                m = [{
                    Code: "AG",
                    Name: n.A.t("countries.agrigento")
                }, {
                    Code: "AL",
                    Name: n.A.t("countries.alessandria")
                }, {
                    Code: "AN",
                    Name: n.A.t("countries.ancona")
                }, {
                    Code: "AO",
                    Name: n.A.t("countries.aosta")
                }, {
                    Code: "AP",
                    Name: n.A.t("countries.ascoliPiceno")
                }, {
                    Code: "AQ",
                    Name: n.A.t("countries.lAquila")
                }, {
                    Code: "AR",
                    Name: n.A.t("countries.arezzo")
                }, {
                    Code: "AT",
                    Name: n.A.t("countries.asti")
                }, {
                    Code: "AV",
                    Name: n.A.t("countries.avellino")
                }, {
                    Code: "BA",
                    Name: n.A.t("countries.bari")
                }, {
                    Code: "BG",
                    Name: n.A.t("countries.bergamo")
                }, {
                    Code: "BI",
                    Name: n.A.t("countries.biella")
                }, {
                    Code: "BL",
                    Name: n.A.t("countries.belluno")
                }, {
                    Code: "BN",
                    Name: n.A.t("countries.benevento")
                }, {
                    Code: "BO",
                    Name: n.A.t("countries.bologna")
                }, {
                    Code: "BR",
                    Name: n.A.t("countries.brindisi")
                }, {
                    Code: "BS",
                    Name: n.A.t("countries.brescia")
                }, {
                    Code: "BT",
                    Name: n.A.t("countries.barlettaAndriaTrani")
                }, {
                    Code: "BZ",
                    Name: n.A.t("countries.bolzano")
                }, {
                    Code: "CA",
                    Name: n.A.t("countries.cagliari")
                }, {
                    Code: "CB",
                    Name: n.A.t("countries.campobasso")
                }, {
                    Code: "CE",
                    Name: n.A.t("countries.caserta")
                }, {
                    Code: "CH",
                    Name: n.A.t("countries.chieti")
                }, {
                    Code: "CI",
                    Name: n.A.t("countries.carboniaIglesias")
                }, {
                    Code: "CL",
                    Name: n.A.t("countries.caltanissetta")
                }, {
                    Code: "CN",
                    Name: n.A.t("countries.cuneo")
                }, {
                    Code: "CO",
                    Name: n.A.t("countries.como")
                }, {
                    Code: "CR",
                    Name: n.A.t("countries.cremona")
                }, {
                    Code: "CS",
                    Name: n.A.t("countries.cosenza")
                }, {
                    Code: "CT",
                    Name: n.A.t("countries.catania")
                }, {
                    Code: "CZ",
                    Name: n.A.t("countries.catanzaro")
                }, {
                    Code: "EN",
                    Name: n.A.t("countries.enna")
                }, {
                    Code: "FC",
                    Name: n.A.t("countries.forliCesena")
                }, {
                    Code: "FE",
                    Name: n.A.t("countries.ferrara")
                }, {
                    Code: "FG",
                    Name: n.A.t("countries.foggia")
                }, {
                    Code: "FI",
                    Name: n.A.t("countries.firenze")
                }, {
                    Code: "FM",
                    Name: n.A.t("countries.fermo")
                }, {
                    Code: "FR",
                    Name: n.A.t("countries.frosinone")
                }, {
                    Code: "GE",
                    Name: n.A.t("countries.genova")
                }, {
                    Code: "GO",
                    Name: n.A.t("countries.gorizia")
                }, {
                    Code: "GR",
                    Name: n.A.t("countries.grosseto")
                }, {
                    Code: "IM",
                    Name: n.A.t("countries.imperia")
                }, {
                    Code: "IS",
                    Name: n.A.t("countries.isernia")
                }, {
                    Code: "KR",
                    Name: n.A.t("countries.crotone")
                }, {
                    Code: "LC",
                    Name: n.A.t("countries.lecco")
                }, {
                    Code: "LE",
                    Name: n.A.t("countries.lecce")
                }, {
                    Code: "LI",
                    Name: n.A.t("countries.livorno")
                }, {
                    Code: "LO",
                    Name: n.A.t("countries.lodi")
                }, {
                    Code: "LT",
                    Name: n.A.t("countries.latina")
                }, {
                    Code: "LU",
                    Name: n.A.t("countries.lucca")
                }, {
                    Code: "MB",
                    Name: n.A.t("countries.monzaBrianza")
                }, {
                    Code: "MC",
                    Name: n.A.t("countries.macerata")
                }, {
                    Code: "ME",
                    Name: n.A.t("countries.messina")
                }, {
                    Code: "MI",
                    Name: n.A.t("countries.milano")
                }, {
                    Code: "MN",
                    Name: n.A.t("countries.mantova")
                }, {
                    Code: "MO",
                    Name: n.A.t("countries.modena")
                }, {
                    Code: "MS",
                    Name: n.A.t("countries.massaCarrara")
                }, {
                    Code: "MT",
                    Name: n.A.t("countries.matera")
                }, {
                    Code: "NA",
                    Name: n.A.t("countries.napoli")
                }, {
                    Code: "NO",
                    Name: n.A.t("countries.novara")
                }, {
                    Code: "NU",
                    Name: n.A.t("countries.nuoro")
                }, {
                    Code: "OG",
                    Name: n.A.t("countries.ogliastra")
                }, {
                    Code: "OR",
                    Name: n.A.t("countries.oristano")
                }, {
                    Code: "OT",
                    Name: n.A.t("countries.olbiaTempio")
                }, {
                    Code: "PA",
                    Name: n.A.t("countries.palermo")
                }, {
                    Code: "PC",
                    Name: n.A.t("countries.piacenza")
                }, {
                    Code: "PD",
                    Name: n.A.t("countries.padova")
                }, {
                    Code: "PE",
                    Name: n.A.t("countries.pescara")
                }, {
                    Code: "PG",
                    Name: n.A.t("countries.perugia")
                }, {
                    Code: "PI",
                    Name: n.A.t("countries.pisa")
                }, {
                    Code: "PN",
                    Name: n.A.t("countries.pordenone")
                }, {
                    Code: "PO",
                    Name: n.A.t("countries.prato")
                }, {
                    Code: "PR",
                    Name: n.A.t("countries.parma")
                }, {
                    Code: "PT",
                    Name: n.A.t("countries.pistoia")
                }, {
                    Code: "PU",
                    Name: n.A.t("countries.pesaroUrbino")
                }, {
                    Code: "PV",
                    Name: n.A.t("countries.pavia")
                }, {
                    Code: "PZ",
                    Name: n.A.t("countries.potenza")
                }, {
                    Code: "RA",
                    Name: n.A.t("countries.ravenna")
                }, {
                    Code: "RC",
                    Name: n.A.t("countries.reggioCalabria")
                }, {
                    Code: "RE",
                    Name: n.A.t("countries.reggioEmilia")
                }, {
                    Code: "RG",
                    Name: n.A.t("countries.ragusa")
                }, {
                    Code: "RI",
                    Name: n.A.t("countries.rieti")
                }, {
                    Code: "RN",
                    Name: n.A.t("countries.rimini")
                }, {
                    Code: "RM",
                    Name: n.A.t("countries.roma")
                }, {
                    Code: "RO",
                    Name: n.A.t("countries.rovigo")
                }, {
                    Code: "SP",
                    Name: n.A.t("countries.laSpezia")
                }, {
                    Code: "SS",
                    Name: n.A.t("countries.sassari")
                }, {
                    Code: "SA",
                    Name: n.A.t("countries.salerno")
                }, {
                    Code: "SV",
                    Name: n.A.t("countries.savona")
                }, {
                    Code: "SI",
                    Name: n.A.t("countries.siena")
                }, {
                    Code: "SR",
                    Name: n.A.t("countries.siracusa")
                }, {
                    Code: "SO",
                    Name: n.A.t("countries.sondrio")
                }, {
                    Code: "SU",
                    Name: n.A.t("countries.sudSardegna")
                }, {
                    Code: "TA",
                    Name: n.A.t("countries.taranto")
                }, {
                    Code: "TE",
                    Name: n.A.t("countries.teramo")
                }, {
                    Code: "TR",
                    Name: n.A.t("countries.terni")
                }, {
                    Code: "TO",
                    Name: n.A.t("countries.torino")
                }, {
                    Code: "TP",
                    Name: n.A.t("countries.trapani")
                }, {
                    Cod: "TN",
                    Name: n.A.t("countries.trento")
                }, {
                    Cod: "TV",
                    Name: n.A.t("countries.treviso")
                }, {
                    Cod: "TS",
                    Name: n.A.t("countries.trieste")
                }, {
                    Cod: "UD",
                    Name: n.A.t("countries.udine")
                }, {
                    Cod: "VA",
                    Name: n.A.t("countries.varese")
                }, {
                    Cod: "VE",
                    Name: n.A.t("countries.venezia")
                }, {
                    Cod: "VB",
                    Name: n.A.t("countries.verbanoCusioOssola")
                }, {
                    Code: "VC",
                    Name: n.A.t("countries.vercelli")
                }, {
                    Code: "VB",
                    Name: n.A.t("countries.verbania")
                }, {
                    Code: "VR",
                    Name: n.A.t("countries.verona")
                }, {
                    Code: "VI",
                    Name: n.A.t("countries.vicenza")
                }, {
                    Code: "VS",
                    Name: n.A.t("countries.medioCampidano")
                }, {
                    Code: "VT",
                    Name: n.A.t("countries.viterbo")
                }, {
                    Code: "VV",
                    Name: n.A.t("countries.viboValentia")
                }],
                p = [{
                    value: "Administrative/Executive",
                    label: n.A.t("account.occupationRoleAdministrativeExecutive")
                }, {
                    value: "Agricultural",
                    label: n.A.t("account.occupationRoleAgricultural")
                }, {
                    value: "Armed forces",
                    label: n.A.t("account.occupationRoleArmedForces")
                }, {
                    value: "Art worker",
                    label: n.A.t("account.occupationRoleArtWorker")
                }, {
                    value: "Banking industry",
                    label: n.A.t("account.occupationRoleBankingIndustry")
                }, {
                    value: "Barber",
                    label: n.A.t("account.occupationRoleBarber")
                }, {
                    value: "Butcher",
                    label: n.A.t("account.occupationRoleButcher")
                }, {
                    value: "Clerical",
                    label: n.A.t("account.occupationRoleClerical")
                }, {
                    value: "Coach",
                    label: n.A.t("account.occupationRoleCoach")
                }, {
                    value: "Construction",
                    label: n.A.t("account.occupationRoleConstruction")
                }, {
                    value: "Cook",
                    label: n.A.t("account.occupationRoleCook")
                }, {
                    value: "Doctor",
                    label: n.A.t("account.occupationRoleDoctor")
                }, {
                    value: "Dentist",
                    label: n.A.t("account.occupationRoleDentist")
                }, {
                    value: "Economist",
                    label: n.A.t("account.occupationRoleEconomist")
                }, {
                    value: "Teacher",
                    label: n.A.t("account.occupationRoleTeacher")
                }, {
                    value: "Engineer",
                    label: n.A.t("account.occupationRoleEngineer")
                }, {
                    value: "Financial Services",
                    label: n.A.t("account.occupationRoleFinancialServices")
                }, {
                    value: "Gambling industry",
                    label: n.A.t("account.occupationRoleGamblingIndustry")
                }, {
                    value: "IT technology",
                    label: n.A.t("account.occupationRoleITTechnology")
                }, {
                    value: "Legal Services",
                    label: n.A.t("account.occupationRoleLegalServices")
                }, {
                    value: "Mining",
                    label: n.A.t("account.occupationRoleMining")
                }, {
                    value: "Nurse",
                    label: n.A.t("account.occupationRoleNurse")
                }, {
                    value: "Police",
                    label: n.A.t("account.occupationRolePolice")
                }, {
                    value: "Politician",
                    label: n.A.t("account.occupationRolePolitician")
                }, {
                    value: "Professional/Senior administrative",
                    label: n.A.t("account.occupationRoleProfessionalSeniorAdministrative")
                }, {
                    value: "Public Services",
                    label: n.A.t("account.occupationRolePublicServices")
                }, {
                    value: "Retired",
                    label: n.A.t("account.occupationRoleRetired")
                }, {
                    value: "Self-employed",
                    label: n.A.t("account.occupationRoleSelfEmployed")
                }, {
                    value: "Self-employed professional",
                    label: n.A.t("account.occupationRoleSelfEmployedProfessional")
                }, {
                    value: "Shipping Services",
                    label: n.A.t("account.occupationRoleShippingServices")
                }, {
                    value: "Skilled Manual",
                    label: n.A.t("account.occupationRoleSkilledManual")
                }, {
                    value: "Student",
                    label: n.A.t("account.occupationRoleStudent")
                }, {
                    value: "Transport Services",
                    label: n.A.t("account.occupationRoleTransportServices")
                }, {
                    value: "Unemployed",
                    label: n.A.t("account.occupationRoleUnemployed")
                }, {
                    value: "Unskilled manual",
                    label: n.A.t("account.occupationRoleUnskilledManual")
                }, {
                    value: "Veterinarian",
                    label: n.A.t("account.occupationRoleVeterinarian")
                }],
                h = [{
                    key: 12,
                    value: "Student",
                    label: n.A.t("account.occupationRoleStudent")
                }, {
                    key: 13,
                    value: "Retired",
                    label: n.A.t("account.occupationRoleRetired")
                }, {
                    key: 14,
                    value: "Homemaker",
                    label: n.A.t("account.occupationRoleHomemaker")
                }, {
                    key: 15,
                    value: "Unemployed",
                    label: n.A.t("account.occupationRoleUnemployed")
                }, {
                    key: 1,
                    value: "Employed or Self-Employed",
                    label: n.A.t("account.occupationRoleEmployedSelfEmployed")
                }],
                v = [{
                    label: n.A.t("account.artsCultureEntertainmentAndMedia"),
                    key: "artsCultureEntertainmentAndMedia",
                    value: "Arts, Culture, Entertainment & Media"
                }, {
                    label: n.A.t("account.travelRecreationLeisureAndSports"),
                    key: "travelRecreationLeisureAndSports",
                    value: "Travel, Recreation, Leisure, & Sports"
                }, {
                    label: n.A.t("account.foodHospitalityAndEvents"),
                    key: "foodHospitalityAndEvents",
                    value: "Food, Hospitality & Events"
                }, {
                    label: n.A.t("account.healthcareSciencesAndMedicine"),
                    key: "healthcareSciencesAndMedicine",
                    value: "Healthcare, Sciences & Medicine"
                }, {
                    label: n.A.t("account.transportLogisticsWarehousingAndDistribution"),
                    key: "transportLogisticsWarehousingAndDistribution",
                    value: "Transport, Logistics, Warehousing & Distribution"
                }, {
                    label: n.A.t("account.businessFinanceAndAdministration"),
                    key: "businessFinanceAndAdministration",
                    value: "Business, Finance & Administration"
                }, {
                    label: n.A.t("account.salesRetailAndServices"),
                    key: "salesRetailAndServices",
                    value: "Sales, Retail & Services"
                }, {
                    label: n.A.t("account.educationCommunityGovernmentAndLegalServices"),
                    key: "educationCommunityGovernmentAndLegalServices",
                    value: "Education, Community, Government & Legal Services"
                }, {
                    label: n.A.t("account.constructionTradesMaintenanceAndRepair"),
                    key: "constructionTradesMaintenanceAndRepair",
                    value: "Construction, Trades, Maintenance & Repair"
                }, {
                    label: n.A.t("account.manufacturing"),
                    key: "manufacturing",
                    value: "Manufacturing"
                }, {
                    label: n.A.t("account.informationTechnology"),
                    key: "informationTechnology",
                    value: "Information Technology"
                }, {
                    label: n.A.t("account.energyEnvironmentAgricultureAndAnimal"),
                    key: "energyEnvironmentAgricultureAndAnimal",
                    value: "Energy, Environment, Agriculture & Animal"
                }],
                A = {
                    artsCultureEntertainmentAndMedia: [{
                        label: "actorOrComedian",
                        value: "Actor or Comedian"
                    }, {
                        label: "animator",
                        value: "Animator"
                    }, {
                        label: "announcerOrBroadcaster",
                        value: "Announcer or broadcaster"
                    }, {
                        label: "technicianOrSimilar",
                        value: "Technician or similar"
                    }, {
                        label: "authorOrWriter",
                        value: "Author or writer"
                    }, {
                        label: "conductorComposerOrArranger",
                        value: "Conductor, composer, or arranger"
                    }, {
                        label: "conservatorOrCurator",
                        value: "Conservator or curator"
                    }, {
                        label: "creativeDesigner",
                        value: "Creative designer"
                    }, {
                        label: "dancer",
                        value: "Dancer"
                    }, {
                        label: "digitalContentOrSocialMedia",
                        value: "Digital content or social media"
                    }, {
                        label: "digitalMarketing",
                        value: "Digital marketing"
                    }, {
                        label: "editor",
                        value: "Editor"
                    }, {
                        label: "fashionOrCostumeDesign",
                        value: "Fashion or costume design"
                    }, {
                        label: "filmOrVideoCameraOpertator",
                        value: "Film or video camera opertator"
                    }, {
                        label: "graphicDesignOrIllustrator",
                        value: "Graphic design or illustrator"
                    }, {
                        label: "instructor",
                        value: "Instructor"
                    }, {
                        label: "journalist",
                        value: "Journalist"
                    }, {
                        label: "makeupArtist",
                        value: "Make-up artist"
                    }, {
                        label: "model",
                        value: "Model"
                    }, {
                        label: "musicianOrSinger",
                        value: "Musician or singer"
                    }, {
                        label: "otherPerformerOrArtsEmployee",
                        value: "Other performer or arts employee"
                    }, {
                        label: "otherCultureAndEntertainmentEmployee",
                        value: "Other culture and entertainment employee"
                    }, {
                        label: "otherMediaEmployee",
                        value: "Other media employee"
                    }, {
                        label: "painterSculptorOrOtherVisualArtists",
                        value: "Painter, sculptor or other visual artists"
                    }, {
                        label: "photographerOrVideographer",
                        value: "Photographer or videographer"
                    }, {
                        label: "presenterOrHost",
                        value: "Presenter or host"
                    }, {
                        label: "producerDirectorChoreographerOrSimilar",
                        value: "Producer, director, choreographer or similar"
                    }, {
                        label: "tatooArtistOrSimilar",
                        value: "Tatoo artist or similar"
                    }, {
                        label: "translatorOrInterpreter",
                        value: "Translator or interpreter"
                    }],
                    travelRecreationLeisureAndSports: [{
                        label: "airportWorker",
                        value: "Airport worker"
                    }, {
                        label: "amusementRecreationOrSportEmployee",
                        value: "Amusement, recreation or sport employee"
                    }, {
                        label: "athlete",
                        value: "Athlete"
                    }, {
                        label: "casinoEmployee",
                        value: "Casino employee"
                    }, {
                        label: "sportsCoach",
                        value: "Sports coach"
                    }, {
                        label: "flightCrew",
                        value: "Flight crew"
                    }, {
                        label: "instructor",
                        value: "Instructor"
                    }, {
                        label: "lifeguard",
                        value: "Lifeguard"
                    }, {
                        label: "personalTrainer",
                        value: "Personal trainer"
                    }, {
                        label: "programLeader",
                        value: "Program leader"
                    }, {
                        label: "otherRecreationSportsOrFitnessEmployee",
                        value: "Other recreation, sports or fitness employee"
                    }, {
                        label: "sportsOfficialOrReferee",
                        value: "Sports official or referee"
                    }, {
                        label: "sportsPsychologist",
                        value: "Sports psychologist"
                    }, {
                        label: "ticketingAgent",
                        value: "Ticketing Agent"
                    }, {
                        label: "tourOrTravelGuide",
                        value: "Tour or travel guide"
                    }, {
                        label: "travelAgentOrCounsellor",
                        value: "Travel agent or counsellor"
                    }, {
                        label: "otherTravelTourismOrRelatedEmployee",
                        value: "Other travel, tourism or related employee"
                    }, {
                        label: "pilot",
                        value: "Pilot"
                    }],
                    foodHospitalityAndEvents: [{
                        label: "accommodationServiceEmployee",
                        value: "Accommodation service employee"
                    }, {
                        label: "baker",
                        value: "Baker"
                    }, {
                        label: "bartender",
                        value: "Bartender"
                    }, {
                        label: "butcherMeatCutterOrFishmonger",
                        value: "Butcher, meat cutter or fishmonger"
                    }, {
                        label: "chef",
                        value: "Chef"
                    }, {
                        label: "housekeepingOrOtherDomesticServicesEmployee",
                        value: "Housekeeping or other domestic services employee"
                    }, {
                        label: "conferenceOrEventPlanner",
                        value: "Conference or event planner"
                    }, {
                        label: "otherCateringOrFoodServiceEmployee",
                        value: "Other catering or food service employee"
                    }, {
                        label: "otherHospitalityOrEventsEmployee",
                        value: "Other hospitality or events employee"
                    }, {
                        label: "restaurantOwner",
                        value: "Restaurant owner"
                    }, {
                        label: "securityOrRelatedServices",
                        value: "Security or related services"
                    }],
                    healthcareSciencesAndMedicine: [{
                        label: "acupuncturist",
                        value: "Acupuncturist"
                    }, {
                        label: "alliedPrimaryHealthPractitioner",
                        value: "Allied primary health practitioner"
                    }, {
                        label: "archeologist",
                        value: "Archeologist"
                    }, {
                        label: "audiologistOrSpeechTherapist",
                        value: "Audiologist or speech therapist"
                    }, {
                        label: "biologistOrRelatedScientist",
                        value: "Biologist or related scientist"
                    }, {
                        label: "cardiologyTechnologist",
                        value: "Cardiology technologist"
                    }, {
                        label: "chemicalEngineer",
                        value: "Chemical engineer"
                    }, {
                        label: "chemicalTechnologistOrTechnician",
                        value: "Chemical technologist or technician"
                    }, {
                        label: "chemist",
                        value: "Chemist"
                    }, {
                        label: "chiropractor",
                        value: "Chiropractor"
                    }, {
                        label: "coroner",
                        value: "Coroner"
                    }, {
                        label: "dentalHygienist",
                        value: "Dental hygienist"
                    }, {
                        label: "dentist",
                        value: "Dentist"
                    }, {
                        label: "dietitianOrNutritionist",
                        value: "Dietitian or nutritionist"
                    }, {
                        label: "generalPractitionerOrFamilyPhysician",
                        value: "General practitioner or family physician"
                    }, {
                        label: "healthConsultant",
                        value: "Health consultant"
                    }, {
                        label: "homeSupportAssistantOrRelatedOccupation",
                        value: "Home support assistant or related occupation"
                    }, {
                        label: "consultant",
                        value: "Consultant"
                    }, {
                        label: "messageTherapist",
                        value: "Message therapist"
                    }, {
                        label: "meteorologistAndClimatologist",
                        value: "Meteorologist and climatologist"
                    }, {
                        label: "midwife",
                        value: "Midwife"
                    }, {
                        label: "mortician",
                        value: "Mortician"
                    }, {
                        label: "policyResearcherConsultantOrProgramOfficer",
                        value: "Policy researcher, consultant or program officer"
                    }, {
                        label: "nurse",
                        value: "Nurse"
                    }, {
                        label: "occupationalTherapist",
                        value: "Occupational therapist"
                    }, {
                        label: "optician",
                        value: "Optician"
                    }, {
                        label: "optometrist",
                        value: "Optometrist"
                    }, {
                        label: "otherOccupationInHealthServices",
                        value: "Other occupation in health services"
                    }, {
                        label: "otherOccupationInSciences",
                        value: "Other occupation in sciences"
                    }, {
                        label: "paramedic",
                        value: "Paramedic"
                    }, {
                        label: "pharmacist",
                        value: "Pharmacist"
                    }, {
                        label: "physicistOrAstronomer",
                        value: "Physicist or astronomer"
                    }, {
                        label: "physiotherapist",
                        value: "Physiotherapist"
                    }, {
                        label: "podiatrist",
                        value: "Podiatrist"
                    }, {
                        label: "psychologist",
                        value: "Psychologist"
                    }, {
                        label: "radiologist",
                        value: "Radiologist"
                    }, {
                        label: "surgeon",
                        value: "Surgeon"
                    }, {
                        label: "technicianOrSimilar",
                        value: "Technician or similar"
                    }],
                    transportLogisticsWarehousingAndDistribution: [{
                        label: "airTrafficControllerOrRelatedOccupation",
                        value: "Air traffic controller or related occupation"
                    }, {
                        label: "aircraftMechanicAircraftInspector",
                        value: "Aircraft mechanic aircraft inspector"
                    }, {
                        label: "busDriverSubwayOperatorOrOtherTransportOperator",
                        value: "Bus driver, subway operator or other transport operator"
                    }, {
                        label: "customsShipOrOtherBroker",
                        value: "Customs, ship or other broker"
                    }, {
                        label: "deliveryOrCourierServiceDriver",
                        value: "Delivery or courier service driver"
                    }, {
                        label: "mineralOrMetalProcessingEmployee",
                        value: "Mineral or metal processing employee"
                    }, {
                        label: "patroleumGasOrChemicalProcessingEmployee",
                        value: "Patroleum, gas or chemical processing employee"
                    }, {
                        label: "postalOrCourierServiceEmployee",
                        value: "Postal or courier service employee"
                    }, {
                        label: "productionLogisticsCoordinator",
                        value: "Production logistics coordinator"
                    }, {
                        label: "railwayTransportEmployee",
                        value: "Railway transport employee"
                    }, {
                        label: "shippingAndReceivingEmployee",
                        value: "Shipping and receiving employee"
                    }, {
                        label: "supplyChainTrackingOrSchedulingEmployee",
                        value: "Supply chain, tracking or scheduling employee"
                    }, {
                        label: "supportOccupationInPublicTransport",
                        value: "Support occupation in public transport"
                    }, {
                        label: "taxiDriverOrChauffeurs",
                        value: "Taxi driver or chauffeurs"
                    }, {
                        label: "transportPlanner",
                        value: "Transport planner"
                    }, {
                        label: "transportationRouteOrCrewScheduler",
                        value: "Transportation route or crew scheduler"
                    }, {
                        label: "truckDriver",
                        value: "Truck driver"
                    }, {
                        label: "warehouseEmployee",
                        value: "Warehouse employee"
                    }, {
                        label: "waterTransportEmployee",
                        value: "Water transport employee"
                    }],
                    businessFinanceAndAdministration: [{
                        label: "accountantOrSimilar",
                        value: "Accountant or similar"
                    }, {
                        label: "actuary",
                        value: "Actuary"
                    }, {
                        label: "administrativeEmployee",
                        value: "Administrative employee"
                    }, {
                        label: "advertisingMarketingOrPublicRelationsEmployee",
                        value: "Advertising, marketing or public relations employee"
                    }, {
                        label: "auditor",
                        value: "Auditor"
                    }, {
                        label: "bankingCreditOrOtherInvestmentEmployee",
                        value: "Banking, credit or other investment employee"
                    }, {
                        label: "businessAdvisorOrConsultant",
                        value: "Business advisor or consultant"
                    }, {
                        label: "collector",
                        value: "Collector"
                    }, {
                        label: "communicationsEmployee",
                        value: "Communications employee"
                    }, {
                        label: "complianceOfficerOrSimilar",
                        value: "Compliance officer or similar"
                    }, {
                        label: "correspondencePublicationOrRegulatoryClerk",
                        value: "Correspondence, publication or regulatory clerk"
                    }, {
                        label: "economist",
                        value: "Economist"
                    }, {
                        label: "policyResearcherConsultantOrProgramOfficer",
                        value: "Policy researcher, consultant or program officer"
                    }, {
                        label: "employmentCounsellor",
                        value: "Employment counsellor"
                    }, {
                        label: "financialServicesEmployee",
                        value: "Financial services employee"
                    }, {
                        label: "foreignExchange",
                        value: "Foreign exchange"
                    }, {
                        label: "graphicDesignerOrSimilar",
                        value: "Graphic designer or similar"
                    }, {
                        label: "healthPolicyResearcherConsultantOrProgramOfficer",
                        value: "Health policy researcher, consultant or program officer"
                    }, {
                        label: "humanResourcesOrRecruitmentEmployee",
                        value: "Human resources or recruitment employee"
                    }, {
                        label: "insuranceAgentOrBroker",
                        value: "Insurance agent or broker"
                    }, {
                        label: "insuranceUnderwriter",
                        value: "Insurance underwriter"
                    }, {
                        label: "insuranceRealEstateOrFinancialBrokerageEmployee",
                        value: "Insurance, real estate or financial brokerage employee"
                    }, {
                        label: "investor",
                        value: "Investor"
                    }, {
                        label: "mathematicianOrStatistician",
                        value: "Mathematician or statistician"
                    }, {
                        label: "moneyTransmitter",
                        value: "Money transmitter"
                    }, {
                        label: "mortgageBroker",
                        value: "Mortgage broker"
                    }, {
                        label: "officeWorker",
                        value: "Office worker"
                    }, {
                        label: "businessAnalyst",
                        value: "Business analyst"
                    }, {
                        label: "payrollAdministrator",
                        value: "Payroll administrator"
                    }, {
                        label: "personnelClerk",
                        value: "Personnel clerk"
                    }, {
                        label: "privatelyOwnedAutomatedTellerMachine",
                        value: "Privately owned automated teller machine"
                    }, {
                        label: "projectManager",
                        value: "Project manager"
                    }, {
                        label: "receptionist",
                        value: "Receptionist"
                    }, {
                        label: "securitiesAgentInvestmentDealerOrBroker",
                        value: "Securities agent, investment dealer or broker"
                    }, {
                        label: "surveyInterviewerOrStatisticalClerk",
                        value: "Survey interviewer or statistical clerk"
                    }, {
                        label: "underwriter",
                        value: "Underwriter"
                    }, {
                        label: "otherBusinessFinanceAndAdministrationEmployee",
                        value: "Other business, finance & administration employee"
                    }],
                    salesRetailAndServices: [{
                        label: "antiqueDealer",
                        value: "Antique dealer"
                    }, {
                        label: "assessorValuatorOrAppraiser",
                        value: "Assessor, valuator or appraiser"
                    }, {
                        label: "auctioneer",
                        value: "Auctioneer"
                    }, {
                        label: "automotiveDealer",
                        value: "Automotive dealer"
                    }, {
                        label: "beautician",
                        value: "Beautician"
                    }, {
                        label: "makeupArtist",
                        value: "Make-up artist"
                    }, {
                        label: "butcherMeatCutterOrFishmonger",
                        value: "Butcher, meat cutter or fishmonger"
                    }, {
                        label: "cannabisStoreOwner",
                        value: "Cannabis store owner"
                    }, {
                        label: "cashier",
                        value: "Cashier"
                    }, {
                        label: "cleaningServicesEmployee",
                        value: "Cleaning services employee"
                    }, {
                        label: "convenienceStoreOwner",
                        value: "Convenience store owner"
                    }, {
                        label: "corporateSalesRepresentative",
                        value: "Corporate sales representative"
                    }, {
                        label: "customerOrInformationServiceEmployee",
                        value: "Customer or information service employee"
                    }, {
                        label: "dryCleaningAndLaundryServices",
                        value: "Dry cleaning and laundry services"
                    }, {
                        label: "estheticianElectrologistOrRelatedOccupation",
                        value: "Esthetician, electrologist or related occupation"
                    }, {
                        label: "financialSalesRepresentative",
                        value: "Financial sales representative"
                    }, {
                        label: "funeralDirector",
                        value: "Funeral director"
                    }, {
                        label: "hairstylistOrBarber",
                        value: "Hairstylist or barber"
                    }, {
                        label: "homeChildCareProvider",
                        value: "Home child care provider"
                    }, {
                        label: "housekeeper",
                        value: "Housekeeper"
                    }, {
                        label: "interiorDesignerOrInteriorDecorator",
                        value: "Interior designer or interior decorator"
                    }, {
                        label: "janitorCaretakerOrBuildingSuperintendent",
                        value: "Janitor, caretaker or building superintendent"
                    }, {
                        label: "otherSalesRelatedOccupation",
                        value: "Other sales related occupation"
                    }, {
                        label: "patternmaker",
                        value: "Patternmaker"
                    }, {
                        label: "privatelyOwnedAutomatedTellerMachine",
                        value: "Privately owned automated teller machine"
                    }, {
                        label: "propertyAdministrator",
                        value: "Property administrator"
                    }, {
                        label: "purchasingOrInventoryEmployee",
                        value: "Purchasing or inventory employee"
                    }, {
                        label: "realEstateAgent",
                        value: "Real estate agent"
                    }, {
                        label: "realEstateBroker",
                        value: "Real estate broker"
                    }, {
                        label: "retailAndWholesaleBuyer",
                        value: "Retail and wholesale buyer"
                    }, {
                        label: "retailSalesRepresentative",
                        value: "Retail sales representative"
                    }, {
                        label: "retailStoreOwner",
                        value: "Retail store owner"
                    }, {
                        label: "salesperson",
                        value: "Salesperson"
                    }, {
                        label: "storeEmployee",
                        value: "Store employee"
                    }, {
                        label: "technicalSalesSpecialist",
                        value: "Technical sales specialist"
                    }, {
                        label: "tobaccoDistributor",
                        value: "Tobacco distributor"
                    }, {
                        label: "translatorTerminologistOrInterpreter",
                        value: "Translator, terminologist or interpreter"
                    }, {
                        label: "vendingMachineOperator",
                        value: "Vending machine operator"
                    }],
                    educationCommunityGovernmentAndLegalServices: [{
                        label: "bylawEnforcementOrOtherRegulatoryOfficer",
                        value: "By-law enforcement or other regulatory officer"
                    }, {
                        label: "coach",
                        value: "Coach"
                    }, {
                        label: "collegeInstructor",
                        value: "College instructor"
                    }, {
                        label: "commissionedOfficerOfTheCanadianArmedForces",
                        value: "Commissioned officer of the Canadian Armed Forces"
                    }, {
                        label: "policeOfficer",
                        value: "Police officer"
                    }, {
                        label: "correctionalServiceOfficer",
                        value: "Correctional service officer"
                    }, {
                        label: "courtEmployee",
                        value: "Court employee"
                    }, {
                        label: "counsellor",
                        value: "Counsellor"
                    }, {
                        label: "customsOfficer",
                        value: "Customs officer"
                    }, {
                        label: "earlyChildhoodEducator",
                        value: "Early childhood educator"
                    }, {
                        label: "socialAndCommunityServicesWorker",
                        value: "Social and community services worker"
                    }, {
                        label: "firefighter",
                        value: "Firefighter"
                    }, {
                        label: "governmentOfficial",
                        value: "Government official"
                    }, {
                        label: "healthAndSafetyInspector",
                        value: "Health and safety inspector"
                    }, {
                        label: "historian",
                        value: "Historian"
                    }, {
                        label: "immigrationBorderServicesOrRevenueOfficer",
                        value: "Immigration, border services or revenue officer"
                    }, {
                        label: "judge",
                        value: "Judge"
                    }, {
                        label: "lawyer",
                        value: "Lawyer"
                    }, {
                        label: "legalAdministrativeAssistant",
                        value: "Legal administrative assistant"
                    }, {
                        label: "legalRepresentative",
                        value: "Legal representative"
                    }, {
                        label: "legislator",
                        value: "Legislator"
                    }, {
                        label: "libraryArchiveMuseumOrArtGalleryEmployee",
                        value: "Library, archive, museum or art gallery employee"
                    }, {
                        label: "memberOfParliament",
                        value: "Member of parliament"
                    }, {
                        label: "noncommissionedRanksOfTheCanadianArmedForces",
                        value: "Non-commissioned ranks of the Canadian Armed Forces"
                    }, {
                        label: "notary",
                        value: "Notary"
                    }, {
                        label: "paralegal",
                        value: "Paralegal"
                    }, {
                        label: "paramedicalOccupations",
                        value: "Paramedical occupations"
                    }, {
                        label: "policyResearcherConsultantOrProgramOfficer",
                        value: "Policy researcher, consultant or program officer"
                    }, {
                        label: "postsecondaryTeacher",
                        value: "Post-secondary teacher"
                    }, {
                        label: "probationparoleOfficer",
                        value: "Probation/parole officer"
                    }, {
                        label: "recordsManagementTechnician",
                        value: "Records management technician"
                    }, {
                        label: "registrar",
                        value: "Registrar"
                    }, {
                        label: "religiousOccupation",
                        value: "Religious occupation"
                    }, {
                        label: "schoolPrincipalOrAdministrator",
                        value: "School principal or administrator"
                    }, {
                        label: "schoolTeacherOrAssistant",
                        value: "School teacher or assistant"
                    }, {
                        label: "sheriffOrBailiff",
                        value: "Sheriff or bailiff"
                    }, {
                        label: "statisticalOfficerOrRelatedResearchSupportOccupation",
                        value: "Statistical officer or related research support occupation"
                    }, {
                        label: "universityProfessorOrLecturer",
                        value: "University professor or lecturer"
                    }],
                    constructionTradesMaintenanceAndRepair: [{
                        label: "aerospaceEngineer",
                        value: "Aerospace engineer"
                    }, {
                        label: "aircraftMechanicTechnicianOrInspector",
                        value: "Aircraft mechanic, technician or inspector"
                    }, {
                        label: "architect",
                        value: "Architect"
                    }, {
                        label: "blacksmith",
                        value: "Blacksmith"
                    }, {
                        label: "maintenanceTechnician",
                        value: "Maintenance technician"
                    }, {
                        label: "carpenter",
                        value: "Carpenter"
                    }, {
                        label: "constructionWorker",
                        value: "Construction worker"
                    }, {
                        label: "draftingTechnologistOrTechnician",
                        value: "Drafting technologist or technician"
                    }, {
                        label: "drillerOrBlaster",
                        value: "Driller or blaster"
                    }, {
                        label: "electricianOrRelatedOccupation",
                        value: "Electrician or related occupation"
                    }, {
                        label: "engineeringEmployee",
                        value: "Engineering employee"
                    }, {
                        label: "facilityOperationOrMaintenanceWorker",
                        value: "Facility operation or maintenance worker"
                    }, {
                        label: "floorCoveringInstaller",
                        value: "Floor covering installer"
                    }, {
                        label: "gasFitter",
                        value: "Gas fitter"
                    }, {
                        label: "glazier",
                        value: "Glazier"
                    }, {
                        label: "heavyEquipmentOperator",
                        value: "Heavy equipment operator"
                    }, {
                        label: "industrialDesigner",
                        value: "Industrial designer"
                    }, {
                        label: "industrialOrManufacturingEngineerOrSimilar",
                        value: "Industrial or manufacturing engineer or similar"
                    }, {
                        label: "jewelleryAndWatchRepairer",
                        value: "Jewellery and watch repairer"
                    }, {
                        label: "landSurveyor",
                        value: "Land surveyor"
                    }, {
                        label: "landscapingAndGroundsMaintenanceOrRelatedOccupation",
                        value: "Landscaping and grounds maintenance or related occupation"
                    }, {
                        label: "locksmith",
                        value: "Locksmith"
                    }, {
                        label: "machineFitter",
                        value: "Machine fitter"
                    }, {
                        label: "machinist",
                        value: "Machinist"
                    }, {
                        label: "mechanicalEngineer",
                        value: "Mechanical engineer"
                    }, {
                        label: "metalFormingShapingErectingTradesAndRelatedOccupations",
                        value: "Metal forming, shaping, erecting trades and related occupations"
                    }, {
                        label: "miningEmployee",
                        value: "Mining employee"
                    }, {
                        label: "oilAndGasDrillingServicingTesterOrRelatedWorker",
                        value: "Oil and gas drilling, servicing, tester or related worker"
                    }, {
                        label: "otherProfessionalEngineer",
                        value: "Other professional engineer"
                    }, {
                        label: "otherRepairerOrServicer",
                        value: "Other repairer or servicer"
                    }, {
                        label: "painterOrDecorator",
                        value: "Painter or decorator"
                    }, {
                        label: "plasterer",
                        value: "Plasterer"
                    }, {
                        label: "plumber",
                        value: "Plumber"
                    }, {
                        label: "projectManager",
                        value: "Project manager"
                    }, {
                        label: "publicWorksEquipmentOperatorOrRelatedWorker",
                        value: "Public works equipment operator or related worker"
                    }, {
                        label: "quarryWorker",
                        value: "Quarry worker"
                    }, {
                        label: "railwayYardOrTrackWorker",
                        value: "Railway yard or track worker"
                    }, {
                        label: "residentialOrCommercialInstallerOrServicer",
                        value: "Residential or commercial installer or servicer"
                    }, {
                        label: "telecommunicationsWorker",
                        value: "Telecommunications worker"
                    }, {
                        label: "urbanAndLandUserPlanner",
                        value: "Urban and land user planner"
                    }, {
                        label: "vehicleRepairMaintenanceOrServicingEmployee",
                        value: "Vehicle repair, maintenance or servicing employee"
                    }, {
                        label: "waterworksOrGasMaintenanceWorker",
                        value: "Waterworks or gas maintenance worker"
                    }],
                    manufacturing: [{
                        label: "artisanOrCraftsperson",
                        value: "Artisan or craftsperson"
                    }, {
                        label: "assemblerFabricatorOrInspector",
                        value: "Assembler, fabricator or inspector"
                    }, {
                        label: "concreteClayOrStoneFormingOperator",
                        value: "Concrete, clay or stone forming operator"
                    }, {
                        label: "desktopPublishingOperatorOrRelatedOccupation",
                        value: "Desktop publishing operator or related occupation"
                    }, {
                        label: "fabricFurOrLeatherCutter",
                        value: "Fabric, fur or leather cutter"
                    }, {
                        label: "fishAndSeafoodPlantWorker",
                        value: "Fish and seafood plant worker"
                    }, {
                        label: "foodProcessingEmployee",
                        value: "Food processing employee"
                    }, {
                        label: "furnitureFinisherOrRefinisher",
                        value: "Furniture finisher or refinisher"
                    }, {
                        label: "helperOrLabourer",
                        value: "Helper or labourer"
                    }, {
                        label: "industrialButcherMeatCutterPoultryPreparerOrRelatedWorker",
                        value: "Industrial butcher, meat cutter, poultry preparer or related worker"
                    }, {
                        label: "industrialPainterCoaterOrMetalFinishingOperator",
                        value: "Industrial painter, coater or metal finishing operator"
                    }, {
                        label: "industrialMachinist",
                        value: "Industrial machinist"
                    }, {
                        label: "otherManufacturingEmployee",
                        value: "Other manufacturing employee"
                    }, {
                        label: "materialHandler",
                        value: "Material handler"
                    }, {
                        label: "materialEngineer",
                        value: "Material engineer"
                    }, {
                        label: "mineralOrMetalProcessingOperator",
                        value: "Mineral or metal processing operator"
                    }, {
                        label: "packer",
                        value: "Packer"
                    }, {
                        label: "patroleumGasOrChemicalProcessingOperator",
                        value: "Patroleum, gas or chemical processing operator"
                    }, {
                        label: "photographicOrFilmProcessor",
                        value: "Photographic or film processor"
                    }, {
                        label: "otherProcessingEmployee",
                        value: "Other processing employee"
                    }, {
                        label: "pulpingPapermakingAndCoatingControlOperator",
                        value: "Pulping, papermaking and coating control operator"
                    }, {
                        label: "sheetMetalWorker",
                        value: "Sheet metal worker"
                    }, {
                        label: "shoemakerOrRepairer",
                        value: "Shoemaker or repairer"
                    }, {
                        label: "structuralMetalAndPlateworkFabricatorOrFitter",
                        value: "Structural metal and platework fabricator or fitter"
                    }, {
                        label: "tailorOrDressmaker",
                        value: "Tailor or dressmaker"
                    }, {
                        label: "testerOrGraderFoodAndBeverageProcessor",
                        value: "Tester or grader, food and beverage processor"
                    }, {
                        label: "textileProcessingWorker",
                        value: "Textile processing worker"
                    }, {
                        label: "toolOrDieMaker",
                        value: "Tool or die maker"
                    }, {
                        label: "upholsterer",
                        value: "Upholsterer"
                    }, {
                        label: "waterAndWasteManagementPlantOperator",
                        value: "Water and waste management plant operator"
                    }, {
                        label: "weaverKnitterOrOtherFabricMakingOccupation",
                        value: "Weaver, knitter or other fabric making occupation"
                    }, {
                        label: "welder",
                        value: "Welder"
                    }],
                    informationTechnology: [{
                        label: "computerAndInformationsSystemsManager",
                        value: "Computer and informations systems manager"
                    }, {
                        label: "hardwareEngineer",
                        value: "Hardware engineer"
                    }, {
                        label: "networkTechnician",
                        value: "Network technician"
                    }, {
                        label: "dataAnalystOrDataAdministrator",
                        value: "Data analyst or data administrator"
                    }, {
                        label: "dataCenterManager",
                        value: "Data center manager"
                    }, {
                        label: "dataEntryClerk",
                        value: "Data entry clerk"
                    }, {
                        label: "informationSystemAnalystOrConsultant",
                        value: "Information system analyst or consultant"
                    }, {
                        label: "testingTechnician",
                        value: "Testing technician"
                    }, {
                        label: "productManager",
                        value: "Product manager"
                    }, {
                        label: "serviceDeskTechnician",
                        value: "Service desk technician"
                    }, {
                        label: "softwareEngineerOrDesigner",
                        value: "Software engineer or designer"
                    }, {
                        label: "userSupportAgent",
                        value: "User support agent"
                    }, {
                        label: "webDesignerOrDeveloper",
                        value: "Web designer or developer"
                    }, {
                        label: "telecommunicationsWorker",
                        value: "Telecommunications worker"
                    }],
                    energyEnvironmentAgricultureAndAnimal: [{
                        label: "agriculturalAndFishProductInspector",
                        value: "Agricultural and fish product inspector"
                    }, {
                        label: "agriculturalRepresentativeConsultantOrSpecialist",
                        value: "Agricultural representative, consultant, or specialist"
                    }, {
                        label: "agriculturalServiceContractorFarmSpecialistWorker",
                        value: "Agricultural service contractor, farm specialist worker"
                    }, {
                        label: "animalHealthTechnologistOrVeterinaryTechnician",
                        value: "Animal health technologist or veterinary technician"
                    }, {
                        label: "animalTrainer",
                        value: "Animal trainer"
                    }, {
                        label: "aquacultureOrMarineHarvestLabourer",
                        value: "Aquaculture or marine harvest labourer"
                    }, {
                        label: "breeder",
                        value: "Breeder"
                    }, {
                        label: "chainSawOrSkidderOperator",
                        value: "Chain saw or skidder operator"
                    }, {
                        label: "conservationOrFisheryOfficer",
                        value: "Conservation or fishery officer"
                    }, {
                        label: "fisherman/woman",
                        value: "Fisherman/woman"
                    }, {
                        label: "florist",
                        value: "Florist"
                    }, {
                        label: "forestryWorker",
                        value: "Forestry worker"
                    }, {
                        label: "farmWorker",
                        value: "Farm worker"
                    }, {
                        label: "geologicalAndMineralTechnologistOrTechnician",
                        value: "Geological and mineral technologist or technician"
                    }, {
                        label: "geologicalEngineer",
                        value: "Geological engineer"
                    }, {
                        label: "geoscientistOrOceanographer",
                        value: "Geoscientist or oceanographer"
                    }, {
                        label: "havestingLabourer",
                        value: "Havesting labourer"
                    }, {
                        label: "landSurveyTechnologistOrTechnician",
                        value: "Land survey technologist or technician"
                    }, {
                        label: "landSurveyor",
                        value: "Land surveyor"
                    }, {
                        label: "landscapeAndHorticultureTechnicianOrSpecialist",
                        value: "Landscape and horticulture technician or specialist"
                    }, {
                        label: "landscapeArchitect",
                        value: "Landscape architect"
                    }, {
                        label: "meteorologistAndClimatologist",
                        value: "Meteorologist and climatologist"
                    }, {
                        label: "nurseryOrGreenhouseWorker",
                        value: "Nursery or greenhouse worker"
                    }, {
                        label: "pestControlOrFumigator",
                        value: "Pest control or fumigator"
                    }, {
                        label: "petGroomerOrAnimalCareWorker",
                        value: "Pet groomer or animal care worker"
                    }, {
                        label: "petroleumEngineer",
                        value: "Petroleum engineer"
                    }, {
                        label: "powerEngineerOrPowerSystemsOperator",
                        value: "Power engineer or power systems operator"
                    }, {
                        label: "silvicultureWorker",
                        value: "Silviculture worker"
                    }, {
                        label: "employeeInArgriculture",
                        value: "Employee in argriculture"
                    }, {
                        label: "employeeInAquaculture",
                        value: "Employee in aquaculture"
                    }, {
                        label: "employeeInHorticulture",
                        value: "Employee in horticulture"
                    }, {
                        label: "employeeInNaturalResourceProductionOrFishing",
                        value: "Employee in natural resource production or fishing"
                    }, {
                        label: "techincalOccupationInGeomaticsAndMeteorology",
                        value: "Techincal occupation in geomatics and meteorology"
                    }, {
                        label: "trapperOrHunter",
                        value: "Trapper or hunter"
                    }, {
                        label: "urbanOrLandUsePlanner",
                        value: "Urban or land use planner"
                    }, {
                        label: "utilitiesEmployee",
                        value: "Utilities employee"
                    }, {
                        label: "veterinarian",
                        value: "Veterinarian"
                    }]
                },
                b = r.Ay.CANADIAN_ACCOUNT_TYPE ? h : c,
                g = {
                    countries: t,
                    docType: i,
                    incomeSource: b,
                    industry: v,
                    salaryLevels: [{
                        label1: "0",
                        label2: "20,000",
                        value: "0,20000"
                    }, {
                        label1: "20.000",
                        label2: "40,000",
                        value: "20000,40000"
                    }, {
                        label1: "40,000",
                        label2: "60,000",
                        value: "40000,60000"
                    }, {
                        label1: "60,000",
                        label2: "80.000",
                        value: "60000,80000"
                    }, {
                        label1: "80,000",
                        label2: "100,000",
                        value: "80000,100000"
                    }, {
                        label1: "100.000",
                        label2: "150,000",
                        value: "100000,150000"
                    }, {
                        label: "150,000",
                        value: "150000,500000"
                    }],
                    departments: s,
                    cashdeskIdData: u,
                    occupations: p,
                    canadaProvinces: d,
                    italyProvinces: m
                },
                C = e => e.trimLeft().replace(/\s{2,}/, " "),
                N = {
                    TUS: "USDT"
                },
                y = {
                    TUS: 3,
                    BTC: 8,
                    LTC: 5,
                    ETH: 7,
                    FTN: 3
                },
                S = "FTN",
                O = "stFTN",
                R = "TUS",
                M = "USDT",
                E = !1
        },
        254639: (e, a, l) => {
            l.d(a, {
                d: () => o
            });
            var n = l(197262);
            const o = [{
                code: "AF",
                alpha3Code: "AFG",
                name: "Afghanistan",
                translationName: n.A.t("countries.Afghanistan"),
                phone_code: "93",
                lang: "tur",
                currency: "AFN",
                alias: "afghanistan"
            }, {
                code: "AX",
                alpha3Code: "ALA",
                name: "Aland Islands",
                translationName: n.A.t("countries.AlandIslands"),
                phone_code: "358 18",
                lang: "",
                currency: "",
                alias: "aland-islands"
            }, {
                code: "AL",
                alpha3Code: "ALB",
                name: "Albania",
                translationName: n.A.t("countries.Albania"),
                phone_code: "355",
                lang: "",
                currency: "ALL",
                alias: "albania"
            }, {
                code: "DZ",
                alpha3Code: "DZA",
                name: "Algeria",
                translationName: n.A.t("countries.Algeria"),
                phone_code: "213",
                lang: "fre",
                currency: "DZD",
                alias: "algeria"
            }, {
                code: "AS",
                alpha3Code: "ASM",
                name: "American Samoa",
                translationName: n.A.t("countries.AmericanSamoa"),
                phone_code: "1 684",
                lang: "",
                currency: "USD",
                alias: "american-samoa"
            }, {
                code: "AD",
                alpha3Code: "AND",
                name: "Andorra",
                translationName: n.A.t("countries.Andorra"),
                phone_code: "376",
                lang: "fre",
                currency: "EUR",
                alias: "andorra"
            }, {
                code: "AO",
                alpha3Code: "AGO",
                name: "Angola",
                translationName: n.A.t("countries.Angola"),
                phone_code: "244",
                lang: "por",
                currency: "AOA",
                alias: "angola"
            }, {
                code: "AI",
                alpha3Code: "AIA",
                name: "Anguilla",
                translationName: n.A.t("countries.Anguilla"),
                phone_code: "1 264",
                lang: "",
                currency: "XCD",
                alias: "anguilla"
            }, {
                code: "AG",
                alpha3Code: "ATG",
                name: "Antigua and Barbuda",
                translationName: n.A.t("countries.AntiguaandBarbuda"),
                phone_code: "1 268",
                lang: "",
                currency: "XCD",
                alias: "antigua-and-barbuda"
            }, {
                code: "AR",
                alpha3Code: "ARG",
                name: "Argentina",
                translationName: n.A.t("countries.Argentina"),
                phone_code: "54",
                lang: "spa",
                currency: "ARS",
                alias: "argentina"
            }, {
                code: "AM",
                alpha3Code: "ARM",
                name: "Armenia",
                translationName: n.A.t("countries.Armenia"),
                phone_code: "374",
                lang: "arm",
                currency: "AMD",
                alias: "armenia"
            }, {
                code: "AW",
                alpha3Code: "ABW",
                name: "Aruba",
                translationName: n.A.t("countries.Aruba"),
                phone_code: "297",
                lang: "",
                currency: "AWG",
                alias: "aruba"
            }, {
                code: "AU",
                alpha3Code: "AUS",
                name: "Australia",
                translationName: n.A.t("countries.Australia"),
                phone_code: "61",
                lang: "",
                currency: "AUD",
                alias: "australia"
            }, {
                code: "AT",
                alpha3Code: "AUT",
                name: "Austria",
                translationName: n.A.t("countries.Austria"),
                phone_code: "43",
                lang: "ger",
                currency: "EUR",
                alias: "austria"
            }, {
                code: "AZ",
                alpha3Code: "AZE",
                name: "Azerbaijan",
                translationName: n.A.t("countries.Azerbaijan"),
                phone_code: "994",
                lang: "tur",
                currency: "AZN",
                alias: "azerbaijan"
            }, {
                code: "BS",
                alpha3Code: "BHS",
                name: "Bahamas",
                translationName: n.A.t("countries.Bahamas"),
                phone_code: "1 242",
                lang: "",
                currency: "BSD",
                alias: "bahamas"
            }, {
                code: "BH",
                alpha3Code: "BHR",
                name: "Bahrain",
                translationName: n.A.t("countries.Bahrain"),
                phone_code: "973",
                lang: "",
                currency: "BHD",
                alias: "bahrain"
            }, {
                code: "BD",
                alpha3Code: "BGD",
                name: "Bangladesh",
                translationName: n.A.t("countries.Bangladesh"),
                phone_code: "880",
                lang: "",
                currency: "BDT",
                alias: "bangladesh"
            }, {
                code: "BB",
                alpha3Code: "BRB",
                name: "Barbados",
                translationName: n.A.t("countries.Barbados"),
                phone_code: "1 246",
                lang: "",
                currency: "BBD",
                alias: "barbados"
            }, {
                code: "BY",
                alpha3Code: "BLR",
                name: "Belarus",
                translationName: n.A.t("countries.Belarus"),
                phone_code: "375",
                lang: "rus",
                currency: "BYR",
                alias: "belarus"
            }, {
                code: "BE",
                alpha3Code: "BEL",
                name: "Belgium",
                translationName: n.A.t("countries.Belgium"),
                phone_code: "32",
                lang: "fre",
                currency: "EUR",
                alias: "belgium"
            }, {
                code: "BZ",
                alpha3Code: "BLZ",
                name: "Belize",
                translationName: n.A.t("countries.Belize"),
                phone_code: "501",
                lang: "",
                currency: "BZD",
                alias: "belize"
            }, {
                code: "BJ",
                alpha3Code: "BEN",
                name: "Benin",
                translationName: n.A.t("countries.Benin"),
                phone_code: "229",
                lang: "fre",
                currency: "XOF",
                alias: "benin"
            }, {
                code: "BM",
                alpha3Code: "BMU",
                name: "Bermuda",
                translationName: n.A.t("countries.Bermuda"),
                phone_code: "1 441",
                lang: "",
                currency: "BMD",
                alias: "bermuda"
            }, {
                code: "BT",
                alpha3Code: "BTN",
                name: "Bhutan",
                translationName: n.A.t("countries.Bhutan"),
                phone_code: "975",
                lang: "",
                currency: "BTN",
                alias: "bhutan"
            }, {
                code: "BO",
                alpha3Code: "BOL",
                name: "Bolivia",
                translationName: n.A.t("countries.Bolivia"),
                phone_code: "591",
                lang: "spa",
                currency: "BOB",
                alias: "bolivia"
            }, {
                code: "BQ",
                alpha3Code: "BES",
                name: "Bonaire",
                translationName: n.A.t("countries.Bonaire"),
                phone_code: "599 7",
                lang: "",
                currency: "",
                alias: "bonaire"
            }, {
                code: "BA",
                alpha3Code: "BIH",
                name: "Bosnia and Herzegovina",
                translationName: n.A.t("countries.BosniaandHerzegovina"),
                phone_code: "387",
                lang: "",
                currency: "BAM",
                alias: "bosnia-and-herzegovina"
            }, {
                code: "BW",
                alpha3Code: "BWA",
                name: "Botswana",
                translationName: n.A.t("countries.Botswana"),
                phone_code: "267",
                lang: "",
                currency: "BWP",
                alias: "botswana"
            }, {
                code: "BR",
                alpha3Code: "BRA",
                name: "Brazil",
                translationName: n.A.t("countries.Brazil"),
                phone_code: "55",
                lang: "por",
                currency: "BRL",
                alias: "brazil"
            }, {
                code: "IO",
                alpha3Code: "IOT",
                name: "British Indian Ocean Territory",
                translationName: n.A.t("countries.BritishIndianOceanTerritory"),
                phone_code: "246",
                lang: "",
                currency: "USD",
                alias: "british-indian-ocean-territory"
            }, {
                code: "BN",
                alpha3Code: "BRN",
                name: "Brunei Darussalam",
                translationName: n.A.t("countries.BruneiDarussalam"),
                phone_code: "673",
                lang: "",
                currency: "BND",
                alias: "brunei"
            }, {
                code: "BG",
                alpha3Code: "BGR",
                name: "Bulgaria",
                translationName: n.A.t("countries.Bulgaria"),
                phone_code: "359",
                lang: "",
                currency: "BGN",
                alias: "bulgaria"
            }, {
                code: "BF",
                alpha3Code: "BFA",
                name: "Burkina Faso",
                translationName: n.A.t("countries.BurkinaFaso"),
                phone_code: "226",
                lang: "fre",
                currency: "XOF",
                alias: "burkina-faso"
            }, {
                code: "BI",
                alpha3Code: "BDI",
                name: "Burundi",
                translationName: n.A.t("countries.Burundi"),
                phone_code: "257",
                lang: "fre",
                currency: "BIF",
                alias: "burundi"
            }, {
                code: "CV",
                alpha3Code: "CPV",
                name: "Cabo Verde",
                translationName: n.A.t("countries.CaboVerde"),
                phone_code: "238",
                lang: "por",
                currency: "CVE",
                alias: "cape-verde"
            }, {
                code: "KH",
                alpha3Code: "KHM",
                name: "Cambodia",
                translationName: n.A.t("countries.Cambodia"),
                phone_code: "855",
                lang: "",
                currency: "KHR",
                alias: "cambodia"
            }, {
                code: "CM",
                alpha3Code: "CMR",
                name: "Cameroon",
                translationName: n.A.t("countries.Cameroon"),
                phone_code: "237",
                lang: "",
                currency: "XAF",
                alias: "cameroon"
            }, {
                code: "CA",
                alpha3Code: "CAN",
                name: "Canada",
                translationName: n.A.t("countries.Canada"),
                phone_code: "1",
                lang: "",
                currency: "CAD",
                alias: "canada"
            }, {
                code: "KY",
                alpha3Code: "CYM",
                name: "Cayman Islands",
                translationName: n.A.t("countries.CaymanIslands"),
                phone_code: "1 345",
                lang: "",
                currency: "KYD",
                alias: "cayman-islands"
            }, {
                code: "CF",
                alpha3Code: "CAF",
                name: "Central African Republic",
                translationName: n.A.t("countries.CentralAfricanRepublic"),
                phone_code: "236",
                lang: "",
                currency: "XAF",
                alias: "central-african-republic"
            }, {
                code: "TD",
                alpha3Code: "TCD",
                name: "Chad",
                translationName: n.A.t("countries.Chad"),
                phone_code: "235",
                lang: "",
                currency: "XAF",
                alias: "chad"
            }, {
                code: "CL",
                alpha3Code: "CHL",
                name: "Chile",
                translationName: n.A.t("countries.Chile"),
                phone_code: "56",
                lang: "spa",
                currency: "CLP",
                alias: "chile"
            }, {
                code: "CN",
                alpha3Code: "CHN",
                name: "China",
                translationName: n.A.t("countries.China"),
                phone_code: "86",
                lang: "",
                currency: "CNY",
                alias: "china"
            }, {
                code: "CX",
                alpha3Code: "CXR",
                name: "Christmas Island",
                translationName: n.A.t("countries.ChristmasIsland"),
                phone_code: "61 89164",
                lang: "",
                currency: "AUD",
                alias: "christmas-island"
            }, {
                code: "CC",
                alpha3Code: "CCK",
                name: "Cocos (Keeling) Islands",
                translationName: n.A.t("countries.CocosKeelingIslands"),
                phone_code: "61 89162",
                lang: "",
                currency: "AUD",
                alias: "cocos-island"
            }, {
                code: "CO",
                alpha3Code: "COL",
                name: "Colombia",
                translationName: n.A.t("countries.Colombia"),
                phone_code: "57",
                lang: "spa",
                currency: "COP",
                alias: "colombia"
            }, {
                code: "KM",
                alpha3Code: "COM",
                name: "Comoros",
                translationName: n.A.t("countries.Comoros"),
                phone_code: "269",
                lang: "",
                currency: "KMF",
                alias: "comoros"
            }, {
                code: "CG",
                alpha3Code: "COG",
                name: "Congo",
                translationName: n.A.t("countries.Congo"),
                phone_code: "242",
                lang: "",
                currency: "XAF",
                alias: "republic-of-the-congo"
            }, {
                code: "CD",
                alpha3Code: "COD",
                name: "Congo, Democratic Republic of the (Zaire)",
                translationName: n.A.t("countries.CongoDemocraticRepublicoftheZaire"),
                phone_code: "243",
                lang: "",
                currency: "CDF",
                alias: "democratic-republic-of-congo"
            }, {
                code: "CK",
                alpha3Code: "COK",
                name: "Cook Islands",
                translationName: n.A.t("countries.CookIslands"),
                phone_code: "682",
                lang: "",
                currency: "NZD",
                alias: "cook-islands"
            }, {
                code: "CR",
                alpha3Code: "CRI",
                name: "Costa Rica",
                translationName: n.A.t("countries.CostaRica"),
                phone_code: "506",
                lang: "spa",
                currency: "CRC",
                alias: "costa-rica"
            }, {
                code: "CI",
                alpha3Code: "CIV",
                name: "Cote d'Ivoire",
                translationName: n.A.t("countries.CotedIvoire"),
                phone_code: "225",
                lang: "",
                currency: "XOF",
                alias: "cotedivoire"
            }, {
                code: "HR",
                alpha3Code: "HRV",
                name: "Croatia",
                translationName: n.A.t("countries.Croatia"),
                phone_code: "385",
                lang: "",
                currency: "HRK",
                alias: "croatia"
            }, {
                code: "CU",
                alpha3Code: "CUB",
                name: "Cuba",
                translationName: n.A.t("countries.Cuba"),
                phone_code: "53",
                lang: "spa",
                currency: "CUP",
                alias: "cuba"
            }, {
                code: "CW",
                alpha3Code: "CUW",
                name: "Curacao",
                translationName: n.A.t("countries.Curacao"),
                phone_code: "599 9",
                lang: "",
                currency: "",
                alias: "curacao"
            }, {
                code: "CY",
                alpha3Code: "CYP",
                name: "Cyprus",
                translationName: n.A.t("countries.Cyprus"),
                phone_code: "357",
                lang: "tur",
                currency: "EUR",
                alias: "cyprus"
            }, {
                code: "CZ",
                alpha3Code: "CZE",
                name: "Czech Republic",
                translationName: n.A.t("countries.CzechRepublic"),
                phone_code: "420",
                lang: "",
                currency: "CZK",
                alias: "czech-republic"
            }, {
                code: "DK",
                alpha3Code: "DNK",
                name: "Denmark",
                translationName: n.A.t("countries.Denmark"),
                phone_code: "45",
                lang: "",
                currency: "DKK",
                alias: "denmark"
            }, {
                code: "DJ",
                alpha3Code: "DJI",
                name: "Djibouti",
                translationName: n.A.t("countries.Djibouti"),
                phone_code: "253",
                lang: "",
                currency: "DJF",
                alias: "djibouti"
            }, {
                code: "DM",
                alpha3Code: "DMA",
                name: "Dominica",
                translationName: n.A.t("countries.Dominica"),
                phone_code: "1 767",
                lang: "",
                currency: "XCD",
                alias: "dominica"
            }, {
                code: "DO",
                alpha3Code: "DOM",
                name: "Dominican Republic",
                translationName: n.A.t("countries.DominicanRepublic"),
                phone_code: "1 809",
                lang: "spa",
                currency: "DOP",
                alias: "dominican-republic"
            }, {
                code: "EC",
                alpha3Code: "ECU",
                name: "Ecuador",
                translationName: n.A.t("countries.Ecuador"),
                phone_code: "593",
                lang: "",
                currency: "ECS",
                alias: "ecuador"
            }, {
                code: "EG",
                alpha3Code: "EGY",
                name: "Egypt",
                translationName: n.A.t("countries.Egypt"),
                phone_code: "20",
                lang: "",
                currency: "EGP",
                alias: "egypt"
            }, {
                code: "SV",
                alpha3Code: "SLV",
                name: "El Salvador",
                translationName: n.A.t("countries.ElSalvador"),
                phone_code: "503",
                lang: "spa",
                currency: "SVC",
                alias: "el-salvador"
            }, {
                code: "GQ",
                alpha3Code: "GNQ",
                name: "Equatorial Guinea",
                translationName: n.A.t("countries.EquatorialGuinea"),
                phone_code: "240",
                lang: "",
                currency: "XAF",
                alias: "equatorial-guinea"
            }, {
                code: "ER",
                alpha3Code: "ERI",
                name: "Eritrea",
                translationName: n.A.t("countries.Eritrea"),
                phone_code: "291",
                lang: "",
                currency: "ERN",
                alias: "eritrea"
            }, {
                code: "EE",
                alpha3Code: "EST",
                name: "Estonia",
                translationName: n.A.t("countries.Estonia"),
                phone_code: "372",
                lang: "rus",
                currency: "EUR",
                alias: "estonia"
            }, {
                code: "ET",
                alpha3Code: "ETH",
                name: "Ethiopia",
                translationName: n.A.t("countries.Ethiopia"),
                phone_code: "251",
                lang: "",
                currency: "ETB",
                alias: "ethiopia"
            }, {
                code: "FK",
                alpha3Code: "FLK",
                name: "Falkland Islands",
                translationName: n.A.t("countries.FalklandIslands"),
                phone_code: "500",
                lang: "",
                currency: "FKP",
                alias: "falkland-islands"
            }, {
                code: "FO",
                alpha3Code: "FRO",
                name: "Faroe Islands",
                translationName: n.A.t("countries.FaroeIslands"),
                phone_code: "298",
                lang: "",
                currency: "DKK",
                alias: "faroe-islands"
            }, {
                code: "FJ",
                alpha3Code: "FJI",
                name: "Fiji",
                translationName: n.A.t("countries.Fiji"),
                phone_code: "679",
                lang: "",
                currency: "FJD",
                alias: "fiji"
            }, {
                code: "FI",
                alpha3Code: "FIN",
                name: "Finland",
                translationName: n.A.t("countries.Finland"),
                phone_code: "358",
                lang: "",
                currency: "EUR",
                alias: "finland"
            }, {
                code: "FR",
                alpha3Code: "FRA",
                name: "France",
                translationName: n.A.t("countries.France"),
                phone_code: "33",
                lang: "fre",
                currency: "EUR",
                alias: "france"
            }, {
                code: "GF",
                alpha3Code: "GUF",
                name: "French Guiana",
                translationName: n.A.t("countries.FrenchGuiana"),
                phone_code: "594",
                lang: "fre",
                currency: "EUR",
                alias: "french-guiana"
            }, {
                code: "PF",
                alpha3Code: "PYF",
                name: "French Polynesia",
                translationName: n.A.t("countries.FrenchPolynesia"),
                phone_code: "689",
                lang: "",
                currency: "XPF",
                alias: "french-polynesia"
            }, {
                code: "GA",
                alpha3Code: "GAB",
                name: "Gabon",
                translationName: n.A.t("countries.Gabon"),
                phone_code: "241",
                lang: "",
                currency: "XAF",
                alias: "gabon"
            }, {
                code: "GM",
                alpha3Code: "GMB",
                name: "Gambia",
                translationName: n.A.t("countries.Gambia"),
                phone_code: "220",
                lang: "",
                currency: "GMD",
                alias: "gambia"
            }, {
                code: "GE",
                alpha3Code: "GEO",
                name: "Georgia",
                translationName: n.A.t("countries.Georgia"),
                phone_code: "995",
                lang: "rus",
                currency: "GEL",
                alias: "georgia"
            }, {
                code: "DE",
                alpha3Code: "DEU",
                name: "Germany",
                translationName: n.A.t("countries.Germany"),
                phone_code: "49",
                lang: "ger",
                currency: "EUR",
                alias: "germany"
            }, {
                code: "GH",
                alpha3Code: "GHA",
                name: "Ghana",
                translationName: n.A.t("countries.Ghana"),
                phone_code: "233",
                lang: "",
                currency: "GHS",
                alias: "ghana"
            }, {
                code: "GI",
                alpha3Code: "GIB",
                name: "Gibraltar",
                translationName: n.A.t("countries.Gibraltar"),
                phone_code: "350",
                lang: "",
                currency: "GIP",
                alias: "gibraltar"
            }, {
                code: "GR",
                alpha3Code: "GRC",
                name: "Greece",
                translationName: n.A.t("countries.Greece"),
                phone_code: "30",
                lang: "gre",
                currency: "EUR",
                alias: "greece"
            }, {
                code: "GL",
                alpha3Code: "GRL",
                name: "Greenland",
                translationName: n.A.t("countries.Greenland"),
                phone_code: "299",
                lang: "",
                currency: "DKK",
                alias: "greenland"
            }, {
                code: "GD",
                alpha3Code: "GRD",
                name: "Grenada",
                translationName: n.A.t("countries.Grenada"),
                phone_code: "1 473",
                lang: "",
                currency: "XCD",
                alias: "grenada"
            }, {
                code: "GP",
                alpha3Code: "GLP",
                name: "Guadeloupe",
                translationName: n.A.t("countries.Guadeloupe"),
                phone_code: "590",
                lang: "fre",
                currency: "EUR",
                alias: "france-guadeloupe"
            }, {
                code: "GU",
                alpha3Code: "GUM",
                name: "Guam",
                translationName: n.A.t("countries.Guam"),
                phone_code: "1 671",
                lang: "",
                currency: "USD",
                alias: "guam"
            }, {
                code: "GT",
                alpha3Code: "GTM",
                name: "Guatemala",
                translationName: n.A.t("countries.Guatemala"),
                phone_code: "502",
                lang: "spa",
                currency: "QTQ",
                alias: "guatemala"
            }, {
                code: "GG",
                alpha3Code: "GGY",
                name: "Guernsey",
                translationName: n.A.t("countries.Guernsey"),
                phone_code: "44 1481",
                lang: "",
                currency: "GGP",
                alias: "guernsey"
            }, {
                code: "GN",
                alpha3Code: "GIN",
                name: "Guinea",
                translationName: n.A.t("countries.Guinea"),
                phone_code: "224",
                lang: "",
                currency: "GNF",
                alias: "guinea"
            }, {
                code: "GW",
                alpha3Code: "GNB",
                name: "Guinea-Bissau",
                translationName: n.A.t("countries.GuineaBissau"),
                phone_code: "245",
                lang: "",
                currency: "GWP",
                alias: "guinea-bissau"
            }, {
                code: "GY",
                alpha3Code: "GUY",
                name: "Guyana",
                translationName: n.A.t("countries.Guyana"),
                phone_code: "592",
                lang: "",
                currency: "GYD",
                alias: "guyana"
            }, {
                code: "HT",
                alpha3Code: "HTI",
                name: "Haiti",
                translationName: n.A.t("countries.Haiti"),
                phone_code: "509",
                lang: "",
                currency: "HTG",
                alias: "haiti"
            }, {
                code: "VA",
                alpha3Code: "VAT",
                name: "Holy See",
                translationName: n.A.t("countries.HolySee"),
                phone_code: "379",
                lang: "",
                currency: "EUR",
                alias: "vatican-city"
            }, {
                code: "HN",
                alpha3Code: "HND",
                name: "Honduras",
                translationName: n.A.t("countries.Honduras"),
                phone_code: "504",
                lang: "spa",
                currency: "HNL",
                alias: "honduras"
            }, {
                code: "HK",
                alpha3Code: "HKG",
                name: "Hong Kong",
                translationName: n.A.t("countries.HongKong"),
                phone_code: "852",
                lang: "",
                currency: "HKD",
                alias: "hong-kong"
            }, {
                code: "HU",
                alpha3Code: "HUN",
                name: "Hungary",
                translationName: n.A.t("countries.Hungary"),
                phone_code: "36",
                lang: "",
                currency: "HUF",
                alias: "hungary"
            }, {
                code: "IS",
                alpha3Code: "ISL",
                name: "Iceland",
                translationName: n.A.t("countries.Iceland"),
                phone_code: "354",
                lang: "",
                currency: "ISK",
                alias: "iceland"
            }, {
                code: "IN",
                alpha3Code: "IND",
                name: "India",
                translationName: n.A.t("countries.India"),
                phone_code: "91",
                lang: "",
                currency: "INR",
                alias: "india"
            }, {
                code: "ID",
                alpha3Code: "IDN",
                name: "Indonesia",
                translationName: n.A.t("countries.Indonesia"),
                phone_code: "62",
                lang: "",
                currency: "IDR",
                alias: "indonesia"
            }, {
                code: "IR",
                alpha3Code: "IRN",
                name: "Iran",
                translationName: n.A.t("countries.Iran"),
                phone_code: "98",
                lang: "",
                currency: "IRR",
                alias: "iran"
            }, {
                code: "IQ",
                alpha3Code: "IRQ",
                name: "Iraq",
                translationName: n.A.t("countries.Iraq"),
                phone_code: "964",
                lang: "",
                currency: "IQD",
                alias: "iraq"
            }, {
                code: "IE",
                alpha3Code: "IRL",
                name: "Ireland",
                translationName: n.A.t("countries.Ireland"),
                phone_code: "353",
                lang: "",
                currency: "EUR",
                alias: "ireland"
            }, {
                code: "IM",
                alpha3Code: "IMN",
                name: "Isle of Man",
                translationName: n.A.t("countries.IsleofMan"),
                phone_code: "44 1624",
                lang: "",
                currency: "GBP",
                alias: "isle-of-man"
            }, {
                code: "IL",
                alpha3Code: "ISR",
                name: "Israel",
                translationName: n.A.t("countries.Israel"),
                phone_code: "972",
                lang: "",
                currency: "ILS",
                alias: "israel"
            }, {
                code: "IT",
                alpha3Code: "ITA",
                name: "Italy",
                translationName: n.A.t("countries.Italy"),
                phone_code: "39",
                lang: "ita",
                currency: "EUR",
                alias: "italy"
            }, {
                code: "JM",
                alpha3Code: "JAM",
                name: "Jamaica",
                translationName: n.A.t("countries.Jamaica"),
                phone_code: "1 876",
                lang: "",
                currency: "JMD",
                alias: "jamaica"
            }, {
                code: "JP",
                alpha3Code: "JPN",
                name: "Japan",
                translationName: n.A.t("countries.Japan"),
                phone_code: "81",
                lang: "",
                currency: "JPY",
                alias: "japan"
            }, {
                code: "JE",
                alpha3Code: "JEY",
                name: "Jersey",
                translationName: n.A.t("countries.Jersey"),
                phone_code: "44 1534",
                lang: "",
                currency: "GBP",
                alias: "jersey"
            }, {
                code: "JO",
                alpha3Code: "JOR",
                name: "Jordan",
                translationName: n.A.t("countries.Jordan"),
                phone_code: "962",
                lang: "",
                currency: "JOD",
                alias: "jordan"
            }, {
                code: "KZ",
                alpha3Code: "KAZ",
                name: "Kazakhstan",
                translationName: n.A.t("countries.Kazakhstan"),
                phone_code: "7",
                lang: "rus",
                currency: "KZT",
                alias: "kazakhstan"
            }, {
                code: "KE",
                alpha3Code: "KEN",
                name: "Kenya",
                translationName: n.A.t("countries.Kenya"),
                phone_code: "254",
                lang: "",
                currency: "KES",
                alias: "kenya"
            }, {
                code: "KI",
                alpha3Code: "KIR",
                name: "Kiribati",
                translationName: n.A.t("countries.Kiribati"),
                phone_code: "686",
                lang: "",
                currency: "AUD",
                alias: "kiribati"
            }, {
                code: "KP",
                alpha3Code: "PRK",
                name: "Korea, North",
                translationName: n.A.t("countries.KoreaNorth"),
                phone_code: "850",
                lang: "",
                currency: "KPW",
                alias: "north-korea"
            }, {
                code: "KW",
                alpha3Code: "KWT",
                name: "Kuwait",
                translationName: n.A.t("countries.Kuwait"),
                phone_code: "965",
                lang: "",
                currency: "KWD",
                alias: "kuwait"
            }, {
                code: "KG",
                alpha3Code: "KGZ",
                name: "Kyrgyzstan",
                translationName: n.A.t("countries.Kyrgyzstan"),
                phone_code: "996",
                lang: "rus",
                currency: "KGS",
                alias: "kyrgyzstan"
            }, {
                code: "LA",
                alpha3Code: "LAO",
                name: "Laos",
                translationName: n.A.t("countries.Laos"),
                phone_code: "856",
                lang: "",
                currency: "LAK",
                alias: "laos"
            }, {
                code: "LV",
                alpha3Code: "LVA",
                name: "Latvia",
                translationName: n.A.t("countries.Latvia"),
                phone_code: "371",
                lang: "rus",
                currency: "LVL",
                alias: "latvia"
            }, {
                code: "LB",
                alpha3Code: "LBN",
                name: "Lebanon",
                translationName: n.A.t("countries.Lebanon"),
                phone_code: "961",
                lang: "",
                currency: "LBP",
                alias: "lebanon"
            }, {
                code: "LS",
                alpha3Code: "LSO",
                name: "Lesotho",
                translationName: n.A.t("countries.Lesotho"),
                phone_code: "266",
                lang: "",
                currency: "LSL",
                alias: "lesotho"
            }, {
                code: "LR",
                alpha3Code: "LBR",
                name: "Liberia",
                translationName: n.A.t("countries.Liberia"),
                phone_code: "231",
                lang: "",
                currency: "LRD",
                alias: "liberia"
            }, {
                code: "LY",
                alpha3Code: "LBY",
                name: "Libya",
                translationName: n.A.t("countries.Libya"),
                phone_code: "218",
                lang: "ita",
                currency: "LYD",
                alias: "libya"
            }, {
                code: "LI",
                alpha3Code: "LIE",
                name: "Liechtenstein",
                translationName: n.A.t("countries.Liechtenstein"),
                phone_code: "423",
                lang: "",
                currency: "CHF",
                alias: "liechtenstein"
            }, {
                code: "LT",
                alpha3Code: "LTU",
                name: "Lithuania",
                translationName: n.A.t("countries.Lithuania"),
                phone_code: "370",
                lang: "rus",
                currency: "LTL",
                alias: "lithuania"
            }, {
                code: "LU",
                alpha3Code: "LUX",
                name: "Luxembourg",
                translationName: n.A.t("countries.Luxembourg"),
                phone_code: "352",
                lang: "fre",
                currency: "EUR",
                alias: "luxembourg"
            }, {
                code: "MO",
                alpha3Code: "MAC",
                name: "Macao",
                translationName: n.A.t("countries.Macao"),
                phone_code: "853",
                lang: "",
                currency: "MOP",
                alias: "macao"
            }, {
                code: "MK",
                alpha3Code: "MKD",
                name: "Macedonia",
                translationName: n.A.t("countries.Macedonia"),
                phone_code: "389",
                lang: "",
                currency: "MKD",
                alias: "republic-of-macedonia"
            }, {
                code: "MG",
                alpha3Code: "MDG",
                name: "Madagascar",
                translationName: n.A.t("countries.Madagascar"),
                phone_code: "261",
                lang: "",
                currency: "MGF",
                alias: "madagascar"
            }, {
                code: "MW",
                alpha3Code: "MWI",
                name: "Malawi",
                translationName: n.A.t("countries.Malawi"),
                phone_code: "265",
                lang: "",
                currency: "MWK",
                alias: "malawi"
            }, {
                code: "MY",
                alpha3Code: "MYS",
                name: "Malaysia",
                translationName: n.A.t("countries.Malaysia"),
                phone_code: "60",
                lang: "",
                currency: "MYR",
                alias: "malaysia"
            }, {
                code: "MV",
                alpha3Code: "MDV",
                name: "Maldives",
                translationName: n.A.t("countries.Maldives"),
                phone_code: "960",
                lang: "",
                currency: "MVR",
                alias: "maldives"
            }, {
                code: "ML",
                alpha3Code: "MLI",
                name: "Mali",
                translationName: n.A.t("countries.Mali"),
                phone_code: "223",
                lang: "",
                currency: "XOF",
                alias: "mali"
            }, {
                code: "MT",
                alpha3Code: "MLT",
                name: "Malta",
                translationName: n.A.t("countries.Malta"),
                phone_code: "356",
                lang: "eng",
                currency: "EUR",
                alias: "malta"
            }, {
                code: "MH",
                alpha3Code: "MHL",
                name: "Marshall Islands",
                translationName: n.A.t("countries.MarshallIslands"),
                phone_code: "692",
                lang: "",
                currency: "USD",
                alias: "marshall-island"
            }, {
                code: "MQ",
                alpha3Code: "MTQ",
                name: "Martinique",
                translationName: n.A.t("countries.Martinique"),
                phone_code: "596",
                lang: "fre",
                currency: "EUR",
                alias: "martinique"
            }, {
                code: "MR",
                alpha3Code: "MRT",
                name: "Mauritania",
                translationName: n.A.t("countries.Mauritania"),
                phone_code: "222",
                lang: "",
                currency: "MRO",
                alias: "mauritania"
            }, {
                code: "MU",
                alpha3Code: "MUS",
                name: "Mauritius",
                translationName: n.A.t("countries.Mauritius"),
                phone_code: "230",
                lang: "",
                currency: "MUR",
                alias: "mauritius"
            }, {
                code: "YT",
                alpha3Code: "MYT",
                name: "Mayotte",
                translationName: n.A.t("countries.Mayotte"),
                phone_code: "262",
                lang: "",
                currency: "EUR",
                alias: "mayotte"
            }, {
                code: "MX",
                alpha3Code: "MEX",
                name: "Mexico",
                translationName: n.A.t("countries.Mexico"),
                phone_code: "52",
                lang: "spa",
                currency: "MXN",
                alias: "mexico"
            }, {
                code: "FM",
                alpha3Code: "FSM",
                name: "Micronesia, Federated States of",
                translationName: n.A.t("countries.MicronesiaFederatedStatesof"),
                phone_code: "691",
                lang: "",
                currency: "USD",
                alias: "micronesia"
            }, {
                code: "MD",
                alpha3Code: "MDA",
                name: "Moldova",
                translationName: n.A.t("countries.Moldova"),
                phone_code: "373",
                lang: "rus",
                currency: "MDL",
                alias: "moldova"
            }, {
                code: "MC",
                alpha3Code: "MCO",
                name: "Monaco",
                translationName: n.A.t("countries.Monaco"),
                phone_code: "377",
                lang: "",
                currency: "EUR",
                alias: "monaco"
            }, {
                code: "MN",
                alpha3Code: "MNG",
                name: "Mongolia",
                translationName: n.A.t("countries.Mongolia"),
                phone_code: "976",
                lang: "rus",
                currency: "MNT",
                alias: "mongolia"
            }, {
                code: "ME",
                alpha3Code: "MNE",
                name: "Montenegro",
                translationName: n.A.t("countries.Montenegro"),
                phone_code: "382",
                lang: "",
                currency: "EUR",
                alias: "montenegro"
            }, {
                code: "MS",
                alpha3Code: "MSR",
                name: "Montserrat",
                translationName: n.A.t("countries.Montserrat"),
                phone_code: "1 664",
                lang: "",
                currency: "XCD",
                alias: "montserrat"
            }, {
                code: "MA",
                alpha3Code: "MAR",
                name: "Morocco",
                translationName: n.A.t("countries.Morocco"),
                phone_code: "212",
                lang: "",
                currency: "MAD",
                alias: "morocco"
            }, {
                code: "MZ",
                alpha3Code: "MOZ",
                name: "Mozambique",
                translationName: n.A.t("countries.Mozambique"),
                phone_code: "258",
                lang: "",
                currency: "MZN",
                alias: "mozambique"
            }, {
                code: "MM",
                alpha3Code: "MMR",
                name: "Myanmar",
                translationName: n.A.t("countries.Myanmar"),
                phone_code: "95",
                lang: "",
                currency: "MMK",
                alias: "myanmar"
            }, {
                code: "NA",
                alpha3Code: "NAM",
                name: "Namibia",
                translationName: n.A.t("countries.Namibia"),
                phone_code: "264",
                lang: "",
                currency: "NAD",
                alias: "namibia"
            }, {
                code: "NR",
                alpha3Code: "NRU",
                name: "Nauru",
                translationName: n.A.t("countries.Nauru"),
                phone_code: "674",
                lang: "",
                currency: "AUD",
                alias: "nauru"
            }, {
                code: "NP",
                alpha3Code: "NPL",
                name: "Nepal",
                translationName: n.A.t("countries.Nepal"),
                phone_code: "977",
                lang: "",
                currency: "NPR",
                alias: "nepal"
            }, {
                code: "NL",
                alpha3Code: "NLD",
                name: "Netherlands",
                translationName: n.A.t("countries.Netherlands"),
                phone_code: "31",
                lang: "",
                currency: "EUR",
                alias: "netherlands"
            }, {
                code: "NC",
                alpha3Code: "NCL",
                name: "New Caledonia",
                translationName: n.A.t("countries.NewCaledonia"),
                phone_code: "687",
                lang: "",
                currency: "XPF",
                alias: "new-caledonia"
            }, {
                code: "NZ",
                alpha3Code: "NZL",
                name: "New Zealand",
                translationName: n.A.t("countries.NewZealand"),
                phone_code: "64",
                lang: "",
                currency: "NZD",
                alias: "new-zealand"
            }, {
                code: "NI",
                alpha3Code: "NIC",
                name: "Nicaragua",
                translationName: n.A.t("countries.Nicaragua"),
                phone_code: "505",
                lang: "spa",
                currency: "NIO",
                alias: "nicaragua"
            }, {
                code: "NE",
                alpha3Code: "NER",
                name: "Niger",
                translationName: n.A.t("countries.Niger"),
                phone_code: "227",
                lang: "",
                currency: "XOF",
                alias: "niger"
            }, {
                code: "NG",
                alpha3Code: "NGA",
                name: "Nigeria",
                translationName: n.A.t("countries.Nigeria"),
                phone_code: "234",
                lang: "",
                currency: "NGN",
                alias: "nigeria"
            }, {
                code: "NU",
                alpha3Code: "NIU",
                name: "Niue",
                translationName: n.A.t("countries.Niue"),
                phone_code: "683",
                lang: "",
                currency: "NZD",
                alias: "niue"
            }, {
                code: "NF",
                alpha3Code: "NFK",
                name: "Norfolk Island",
                translationName: n.A.t("countries.NorfolkIsland"),
                phone_code: "672 3",
                lang: "",
                currency: "AUD",
                alias: "norfolk-island"
            }, {
                code: "MP",
                alpha3Code: "MNP",
                name: "Northern Mariana Islands",
                translationName: n.A.t("countries.NorthernMarianaIslands"),
                phone_code: "1 670",
                lang: "",
                currency: "USD",
                alias: "northern-marianas-islands"
            }, {
                code: "NO",
                alpha3Code: "NOR",
                name: "Norway",
                translationName: n.A.t("countries.Norway"),
                phone_code: "47",
                lang: "",
                currency: "NOK",
                alias: "norway"
            }, {
                code: "OM",
                alpha3Code: "OMN",
                name: "Oman",
                translationName: n.A.t("countries.Oman"),
                phone_code: "968",
                lang: "",
                currency: "OMR",
                alias: "oman"
            }, {
                code: "PK",
                alpha3Code: "PAK",
                name: "Pakistan",
                translationName: n.A.t("countries.Pakistan"),
                phone_code: "92",
                lang: "",
                currency: "PKR",
                alias: "pakistan"
            }, {
                code: "PW",
                alpha3Code: "PLW",
                name: "Palau",
                translationName: n.A.t("countries.Palau"),
                phone_code: "680",
                lang: "",
                currency: "USD",
                alias: "palau"
            }, {
                code: "PS",
                alpha3Code: "PSE",
                name: "Palestine, State of",
                translationName: n.A.t("countries.PalestineStateof"),
                phone_code: "970",
                lang: "",
                currency: "",
                alias: "palestine"
            }, {
                code: "PA",
                alpha3Code: "PAN",
                name: "Panama",
                translationName: n.A.t("countries.Panama"),
                phone_code: "507",
                lang: "spa",
                currency: "PAB",
                alias: "panama"
            }, {
                code: "PG",
                alpha3Code: "PNG",
                name: "Papua New Guinea",
                translationName: n.A.t("countries.PapuaNewGuinea"),
                phone_code: "675",
                lang: "",
                currency: "PGK",
                alias: "papua-new-guinea"
            }, {
                code: "PY",
                alpha3Code: "PRY",
                name: "Paraguay",
                translationName: n.A.t("countries.Paraguay"),
                phone_code: "595",
                lang: "spa",
                currency: "PYG",
                alias: "paraguay"
            }, {
                code: "PE",
                alpha3Code: "PER",
                name: "Peru",
                translationName: n.A.t("countries.Peru"),
                phone_code: "51",
                lang: "spa",
                currency: "PEN",
                alias: "peru"
            }, {
                code: "PH",
                alpha3Code: "PHL",
                name: "Philippines",
                translationName: n.A.t("countries.Philippines"),
                phone_code: "63",
                lang: "",
                currency: "PHP",
                alias: "philippines"
            }, {
                code: "PL",
                alpha3Code: "POL",
                name: "Poland",
                translationName: n.A.t("countries.Poland"),
                phone_code: "48",
                lang: "",
                currency: "PLN",
                alias: "poland"
            }, {
                code: "PT",
                alpha3Code: "PRT",
                name: "Portugal",
                translationName: n.A.t("countries.Portugal"),
                phone_code: "351",
                lang: "por",
                currency: "EUR",
                alias: "portugal"
            }, {
                code: "PR",
                alpha3Code: "PRI",
                name: "Puerto Rico",
                translationName: n.A.t("countries.PuertoRico"),
                phone_code: "1 787",
                lang: "",
                currency: "USD",
                alias: "puerto-rico"
            }, {
                code: "QA",
                alpha3Code: "QAT",
                name: "Qatar",
                translationName: n.A.t("countries.Qatar"),
                phone_code: "974",
                lang: "",
                currency: "QAR",
                alias: "qatar"
            }, {
                code: "RE",
                alpha3Code: "REU",
                name: "Reunion",
                translationName: n.A.t("countries.Reunion"),
                phone_code: "262",
                lang: "fre",
                currency: "EUR",
                alias: "reunion"
            }, {
                code: "RO",
                alpha3Code: "ROU",
                name: "Romania",
                translationName: n.A.t("countries.Romania"),
                phone_code: "40",
                lang: "",
                currency: "RON",
                alias: "romania"
            }, {
                code: "RU",
                alpha3Code: "RUS",
                name: "Russia",
                translationName: n.A.t("countries.Russia"),
                phone_code: "7",
                lang: "rus",
                currency: "RUB",
                alias: "russia"
            }, {
                code: "RW",
                alpha3Code: "RWA",
                name: "Rwanda",
                translationName: n.A.t("countries.Rwanda"),
                phone_code: "250",
                lang: "",
                currency: "RWF",
                alias: "rwanda"
            }, {
                code: "BL",
                alpha3Code: "BLM",
                name: "Saint Barthelemy",
                translationName: n.A.t("countries.SaintBarthelemy"),
                phone_code: "590",
                lang: "",
                currency: "",
                alias: "st-barts"
            }, {
                code: "SH",
                alpha3Code: "SHN",
                name: "Saint Helena",
                translationName: n.A.t("countries.SaintHelena"),
                phone_code: "290",
                lang: "",
                currency: "SHP",
                alias: "flag_of_saint_helena"
            }, {
                code: "KN",
                alpha3Code: "KNA",
                name: "Saint Kitts and Nevis",
                translationName: n.A.t("countries.SaintKittsandNevis"),
                phone_code: "1 869",
                lang: "",
                currency: "XCD",
                alias: "saint-kitts-and-nevis"
            }, {
                code: "LC",
                alpha3Code: "LCA",
                name: "Saint Lucia",
                translationName: n.A.t("countries.SaintLucia"),
                phone_code: "1 758",
                lang: "",
                currency: "XCD",
                alias: "saint-lucia"
            }, {
                code: "MF",
                alpha3Code: "MAF",
                name: "Saint Martin (France)",
                translationName: n.A.t("countries.SaintMartinFrance"),
                phone_code: "590",
                lang: "",
                currency: "",
                alias: "france-saint-martin"
            }, {
                code: "PM",
                alpha3Code: "SPM",
                name: "Saint Pierre and Miquelon",
                translationName: n.A.t("countries.SaintPierreandMiquelon"),
                phone_code: "508",
                lang: "",
                currency: "EUR",
                alias: "france-miquelon"
            }, {
                code: "VC",
                alpha3Code: "VCT",
                name: "Saint Vincent and the Grenadines",
                translationName: n.A.t("countries.SaintVincentandtheGrenadines"),
                phone_code: "1 784",
                lang: "",
                currency: "XCD",
                alias: "flag_of_saint_vincent"
            }, {
                code: "WS",
                alpha3Code: "WSM",
                name: "Samoa",
                translationName: n.A.t("countries.Samoa"),
                phone_code: "685",
                lang: "",
                currency: "WST",
                alias: "samoa"
            }, {
                code: "SM",
                alpha3Code: "SMR",
                name: "San Marino",
                translationName: n.A.t("countries.SanMarino"),
                phone_code: "378",
                lang: "ita",
                currency: "EUR",
                alias: "san-marino"
            }, {
                code: "ST",
                alpha3Code: "STP",
                name: "Sao Tome and Principe",
                translationName: n.A.t("countries.SaoTomeandPrincipe"),
                phone_code: "239",
                lang: "",
                currency: "STD",
                alias: "sao-tome-and-principe"
            }, {
                code: "SA",
                alpha3Code: "SAU",
                name: "Saudi Arabia",
                translationName: n.A.t("countries.SaudiArabia"),
                phone_code: "966",
                lang: "",
                currency: "SAR",
                alias: "saudi-arabia"
            }, {
                code: "SN",
                alpha3Code: "SEN",
                name: "Senegal",
                translationName: n.A.t("countries.Senegal"),
                phone_code: "221",
                lang: "",
                currency: "XOF",
                alias: "senegal"
            }, {
                code: "RS",
                alpha3Code: "SRB",
                name: "Serbia",
                translationName: n.A.t("countries.Serbia"),
                phone_code: "381",
                lang: "",
                currency: "RSD",
                alias: "serbia"
            }, {
                code: "SC",
                alpha3Code: "SYC",
                name: "Seychelles",
                translationName: n.A.t("countries.Seychelles"),
                phone_code: "248",
                lang: "",
                currency: "SCR",
                alias: "seychelles"
            }, {
                code: "SL",
                alpha3Code: "SLE",
                name: "Sierra Leone",
                translationName: n.A.t("countries.SierraLeone"),
                phone_code: "232",
                lang: "",
                currency: "SLL",
                alias: "sierra-leone"
            }, {
                code: "SG",
                alpha3Code: "SGP",
                name: "Singapore",
                translationName: n.A.t("countries.Singapore"),
                phone_code: "65",
                lang: "",
                currency: "SGD",
                alias: "singapore"
            }, {
                code: "SX",
                alpha3Code: "SXM",
                name: "Sint Maarten (Netherlands)",
                translationName: n.A.t("countries.SintMaartenNetherlands"),
                phone_code: "1 721",
                lang: "",
                currency: "",
                alias: "sint-maarten"
            }, {
                code: "SK",
                alpha3Code: "SVK",
                name: "Slovakia",
                translationName: n.A.t("countries.Slovakia"),
                phone_code: "421",
                lang: "",
                currency: "EUR",
                alias: "slovakia"
            }, {
                code: "SI",
                alpha3Code: "SVN",
                name: "Slovenia",
                translationName: n.A.t("countries.Slovenia"),
                phone_code: "386",
                lang: "",
                currency: "EUR",
                alias: "slovenia"
            }, {
                code: "SB",
                alpha3Code: "SLB",
                name: "Solomon Islands",
                translationName: n.A.t("countries.SolomonIslands"),
                phone_code: "677",
                lang: "",
                currency: "SBD",
                alias: "solomon-islands"
            }, {
                code: "SO",
                alpha3Code: "SOM",
                name: "Somalia",
                translationName: n.A.t("countries.Somalia"),
                phone_code: "252",
                lang: "",
                currency: "SOS",
                alias: "somalia"
            }, {
                code: "ZA",
                alpha3Code: "ZAF",
                name: "South Africa",
                translationName: n.A.t("countries.SouthAfrica"),
                phone_code: "27",
                lang: "",
                currency: "ZAR",
                alias: "south-africa"
            }, {
                code: "SS",
                alpha3Code: "SSD",
                name: "South Sudan",
                translationName: n.A.t("countries.SouthSudan"),
                phone_code: "211",
                lang: "",
                currency: "SSP",
                alias: "south-sudan"
            }, {
                code: "KR",
                alpha3Code: "KOR",
                name: "South Korea",
                translationName: n.A.t("countries.SouthKorea"),
                phone_code: "82",
                lang: "",
                currency: "KRW",
                alias: "south-korea"
            }, {
                code: "ES",
                alpha3Code: "ESP",
                name: "Spain",
                translationName: n.A.t("countries.Spain"),
                phone_code: "34",
                lang: "spa",
                currency: "EUR",
                alias: "spain"
            }, {
                code: "LK",
                alpha3Code: "LKA",
                name: "Sri Lanka",
                translationName: n.A.t("countries.SriLanka"),
                phone_code: "94",
                lang: "",
                currency: "LKR",
                alias: "sri-lanka"
            }, {
                code: "SD",
                alpha3Code: "SDN",
                name: "Sudan",
                translationName: n.A.t("countries.Sudan"),
                phone_code: "249",
                lang: "",
                currency: "SDG",
                alias: "sudan"
            }, {
                code: "SR",
                alpha3Code: "SUR",
                name: "Suriname",
                translationName: n.A.t("countries.Suriname"),
                phone_code: "597",
                lang: "",
                currency: "SRD",
                alias: "suriname"
            }, {
                code: "SJ",
                alpha3Code: "SJM",
                name: "Svalbard and Jan Mayen",
                translationName: n.A.t("countries.SvalbardandJanMayen"),
                phone_code: "47",
                lang: "",
                currency: "NOK",
                alias: "svalbard_and_jan_mayen"
            }, {
                code: "SZ",
                name: "Swaziland",
                alpha3Code: "SWZ",
                translationName: n.A.t("countries.Swaziland"),
                phone_code: "268",
                lang: "",
                currency: "SZL",
                alias: "swaziland"
            }, {
                code: "SE",
                alpha3Code: "SWE",
                name: "Sweden",
                translationName: n.A.t("countries.Sweden"),
                phone_code: "46",
                lang: "swe",
                currency: "SEK",
                alias: "sweden"
            }, {
                code: "CH",
                alpha3Code: "CHE",
                name: "Switzerland",
                translationName: n.A.t("countries.Switzerland"),
                phone_code: "41",
                lang: "fre",
                currency: "CHF",
                alias: "switzerland"
            }, {
                code: "SY",
                alpha3Code: "SYR",
                name: "Syria",
                translationName: n.A.t("countries.Syria"),
                phone_code: "963",
                lang: "",
                currency: "SYP",
                alias: "syria"
            }, {
                code: "TW",
                alpha3Code: "TWN",
                name: "Taiwan",
                translationName: n.A.t("countries.Taiwan"),
                phone_code: "886",
                lang: "",
                currency: "TWD",
                alias: "taiwan"
            }, {
                code: "TJ",
                alpha3Code: "TJK",
                name: "Tajikistan",
                translationName: n.A.t("countries.Tajikistan"),
                phone_code: "992",
                lang: "rus",
                currency: "TJS",
                alias: "tajikistan"
            }, {
                code: "TZ",
                alpha3Code: "TZA",
                name: "Tanzania",
                translationName: n.A.t("countries.Tanzania"),
                phone_code: "255",
                lang: "",
                currency: "TZS",
                alias: "united-republic-of-tanzania"
            }, {
                code: "TH",
                alpha3Code: "THA",
                name: "Thailand",
                translationName: n.A.t("countries.Thailand"),
                phone_code: "66",
                lang: "",
                currency: "THB",
                alias: "thailand"
            }, {
                code: "TL",
                alpha3Code: "TLS",
                name: "Timor-Leste",
                translationName: n.A.t("countries.TimorLeste"),
                phone_code: "670",
                lang: "",
                currency: "",
                alias: "timor-leste"
            }, {
                code: "TG",
                alpha3Code: "TGO",
                name: "Togo",
                translationName: n.A.t("countries.Togo"),
                phone_code: "228",
                lang: "",
                currency: "XOF",
                alias: "togo"
            }, {
                code: "TK",
                alpha3Code: "TKL",
                name: "Tokelau",
                translationName: n.A.t("countries.Tokelau"),
                phone_code: "690",
                lang: "",
                currency: "NZD",
                alias: "tokelau"
            }, {
                code: "TO",
                alpha3Code: "TON",
                name: "Tonga",
                translationName: n.A.t("countries.Tonga"),
                phone_code: "676",
                lang: "",
                currency: "TOP",
                alias: "tonga"
            }, {
                code: "TT",
                alpha3Code: "TTO",
                name: "Trinidad and Tobago",
                translationName: n.A.t("countries.TrinidadandTobago"),
                phone_code: "1 868",
                lang: "",
                currency: "TTD",
                alias: "trinidad-and-tobago"
            }, {
                code: "TN",
                alpha3Code: "TUN",
                name: "Tunisia",
                translationName: n.A.t("countries.Tunisia"),
                phone_code: "216",
                lang: "",
                currency: "TND",
                alias: "tunisia"
            }, {
                code: "TR",
                alpha3Code: "TUR",
                name: "Turkey",
                translationName: n.A.t("countries.Turkey"),
                phone_code: "90",
                lang: "",
                currency: "TRY",
                alias: "turkey"
            }, {
                code: "TM",
                alpha3Code: "TKM",
                name: "Turkmenistan",
                translationName: n.A.t("countries.Turkmenistan"),
                phone_code: "993",
                lang: "tur",
                currency: "TMT",
                alias: "turkmenistan"
            }, {
                code: "TC",
                alpha3Code: "TCA",
                name: "Turks and Caicos Islands",
                translationName: n.A.t("countries.TurksandCaicosIslands"),
                phone_code: "1 649",
                lang: "",
                currency: "USD",
                alias: "turks-and-caicos"
            }, {
                code: "TV",
                alpha3Code: "TUV",
                name: "Tuvalu",
                translationName: n.A.t("countries.Tuvalu"),
                phone_code: "688",
                lang: "",
                currency: "AUD",
                alias: "tuvalu"
            }, {
                code: "UG",
                alpha3Code: "UGA",
                name: "Uganda",
                translationName: n.A.t("countries.Uganda"),
                phone_code: "256",
                lang: "",
                currency: "UGX",
                alias: "uganda"
            }, {
                code: "UA",
                alpha3Code: "UKR",
                name: "Ukraine",
                translationName: n.A.t("countries.Ukraine"),
                phone_code: "380",
                lang: "ukr",
                currency: "UAH",
                alias: "ukraine"
            }, {
                code: "AE",
                alpha3Code: "ARE",
                name: "United Arab Emirates",
                translationName: n.A.t("countries.UnitedArabEmirates"),
                phone_code: "971",
                lang: "",
                currency: "AED",
                alias: "united-arab-emirates"
            }, {
                code: "GB",
                alpha3Code: "GBR",
                name: "United Kingdom",
                translationName: n.A.t("countries.UnitedKingdom"),
                phone_code: "44",
                lang: "",
                currency: "GBP",
                alias: "united-kingdom"
            }, {
                code: "US",
                alpha3Code: "USA",
                name: "United States",
                translationName: n.A.t("countries.UnitedStates"),
                phone_code: "1",
                lang: "",
                currency: "USD",
                alias: "usa"
            }, {
                code: "UY",
                alpha3Code: "URY",
                name: "Uruguay",
                translationName: n.A.t("countries.Uruguay"),
                phone_code: "598",
                lang: "spa",
                currency: "UYU",
                alias: "uruguay"
            }, {
                code: "UZ",
                alpha3Code: "UZB",
                name: "Uzbekistan",
                translationName: n.A.t("countries.Uzbekistan"),
                phone_code: "998",
                lang: "rus",
                currency: "UZS",
                alias: "uzbekistan"
            }, {
                code: "VU",
                alpha3Code: "VUT",
                name: "Vanuatu",
                translationName: n.A.t("countries.Vanuatu"),
                phone_code: "678",
                lang: "",
                currency: "VUV",
                alias: "vanuatu"
            }, {
                code: "VE",
                alpha3Code: "VEN",
                name: "Venezuela",
                translationName: n.A.t("countries.Venezuela"),
                phone_code: "58",
                lang: "spa",
                currency: "VEF",
                alias: "venezuela"
            }, {
                code: "VN",
                alpha3Code: "VNM",
                name: "Vietnam",
                translationName: n.A.t("countries.Vietnam"),
                phone_code: "84",
                lang: "",
                currency: "VND",
                alias: "vietnam"
            }, {
                code: "VG",
                name: "Virgin Islands, British",
                alpha3Code: "VGB",
                translationName: n.A.t("countries.VirginIslandsBritish"),
                phone_code: "1",
                lang: "",
                currency: "USD",
                alias: "british-virgin-islands"
            }, {
                code: "VI",
                alpha3Code: "VIR",
                name: "Virgin Islands, U.S.",
                translationName: n.A.t("countries.VirginIslandsUS"),
                phone_code: "1",
                lang: "",
                currency: "USD",
                alias: "virgin-islands"
            }, {
                code: "WF",
                alpha3Code: "WLF",
                name: "Wallis and Futuna",
                translationName: n.A.t("countries.WallisandFutuna"),
                phone_code: "681",
                lang: "",
                currency: "XPF",
                alias: "wallis-and-futuna"
            }, {
                code: "EH",
                alpha3Code: "ESH",
                name: "Western Sahara",
                translationName: n.A.t("countries.WesternSahara"),
                phone_code: "212",
                lang: "",
                currency: "MAD",
                alias: "western-sahara"
            }, {
                code: "YE",
                alpha3Code: "YEM",
                name: "Yemen",
                translationName: n.A.t("countries.Yemen"),
                phone_code: "967",
                lang: "",
                currency: "YER",
                alias: "yemen"
            }, {
                code: "ZM",
                alpha3Code: "ZMB",
                name: "Zambia",
                translationName: n.A.t("countries.Zambia"),
                phone_code: "260",
                lang: "",
                currency: "ZMW",
                alias: "zambia"
            }, {
                code: "ZW",
                alpha3Code: "ZWE",
                name: "Zimbabwe",
                translationName: n.A.t("countries.Zimbabwe"),
                phone_code: "263",
                lang: "",
                currency: "ZWD",
                alias: "zimbabwe"
            }]
        }
    }
]);
//# sourceMappingURL=61190.fe7c8206.chunk.js.map