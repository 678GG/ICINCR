"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [72887], {
        672887: (t, e, r) => {
            r.r(e), r.d(e, {
                default: () => i
            });
            var n, l = r(365043);

            function a() {
                return a = Object.assign ? Object.assign.bind() : function(t) {
                    for (var e = 1; e < arguments.length; e++) {
                        var r = arguments[e];
                        for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (t[n] = r[n])
                    }
                    return t
                }, a.apply(this, arguments)
            }

            function o(t, e) {
                let {
                    title: r,
                    titleId: o,
                    ...s
                } = t;
                return l.createElement("svg", a({
                    width: 32,
                    height: 32,
                    viewBox: "0 0 32 32",
                    fill: "currentColor",
                    xmlns: "http://www.w3.org/2000/svg",
                    ref: e,
                    "aria-labelledby": o
                }, s), r ? l.createElement("title", {
                    id: o
                }, r) : null, n || (n = l.createElement("path", {
                    d: "M22.5331 12.2662C21.9997 11.7329 21.1997 11.7329 20.6664 12.2662L15.9997 16.9329L11.3331 12.2662C10.7997 11.7329 9.99974 11.7329 9.46641 12.2662C8.93307 12.7995 8.93307 13.5995 9.46641 14.1329L15.0664 19.7329C15.3331 19.9995 15.5997 20.1329 15.9997 20.1329C16.3997 20.1329 16.6664 19.9995 16.9331 19.7329L22.5331 14.1329C23.0664 13.5995 23.0664 12.7995 22.5331 12.2662Z"
                })))
            }
            const s = l.forwardRef(o),
                i = (r.p, s)
        }
    }
]);
//# sourceMappingURL=72887.d774ca35.chunk.js.map