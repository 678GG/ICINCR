"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [5256], {
        957019: (e, t) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            t.default = {
                icon: {
                    tag: "svg",
                    attrs: {
                        viewBox: "64 64 896 896",
                        focusable: "false"
                    },
                    children: [{
                        tag: "path",
                        attrs: {
                            d: "M482 152h60q8 0 8 8v704q0 8-8 8h-60q-8 0-8-8V160q0-8 8-8z"
                        }
                    }, {
                        tag: "path",
                        attrs: {
                            d: "M192 474h672q8 0 8 8v60q0 8-8 8H160q-8 0-8-8v-60q0-8 8-8z"
                        }
                    }]
                },
                name: "plus",
                theme: "outlined"
            }
        },
        695033: (e, t, n) => {
            var r;
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = (r = n(488414)) && r.__esModule ? r : {
                default: r
            };
            t.default = a, e.exports = a
        },
        488414: (e, t, n) => {
            var r = n(245288),
                a = n(310684);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = r(n(601459)),
                i = function(e, t) {
                    if (!t && e && e.__esModule) return e;
                    if (null === e || "object" != a(e) && "function" != typeof e) return {
                        default: e
                    };
                    var n = u(t);
                    if (n && n.has(e)) return n.get(e);
                    var r = {
                            __proto__: null
                        },
                        o = Object.defineProperty && Object.getOwnPropertyDescriptor;
                    for (var i in e)
                        if ("default" !== i && Object.prototype.hasOwnProperty.call(e, i)) {
                            var c = o ? Object.getOwnPropertyDescriptor(e, i) : null;
                            c && (c.get || c.set) ? Object.defineProperty(r, i, c) : r[i] = e[i]
                        }
                    return r.default = e, n && n.set(e, r), r
                }(n(365043)),
                c = r(n(957019)),
                l = r(n(942740));

            function u(e) {
                if ("function" != typeof WeakMap) return null;
                var t = new WeakMap,
                    n = new WeakMap;
                return (u = function(e) {
                    return e ? n : t
                })(e)
            }
            var f = function(e, t) {
                    return i.createElement(l.default, (0, o.default)((0, o.default)({}, e), {}, {
                        ref: t,
                        icon: c.default
                    }))
                },
                s = i.forwardRef(f);
            t.default = s
        },
        548672: (e, t, n) => {
            function r() {
                return r = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }, r.apply(this, arguments)
            }

            function a(e, t, n) {
                return t in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }

            function o(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                return r
            }

            function i(e, t) {
                if (e) {
                    if ("string" === typeof e) return o(e, t);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? o(e, t) : void 0
                }
            }

            function c(e, t) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, t) {
                    var n = null == e ? null : "undefined" !== typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                    if (null != n) {
                        var r, a, o = [],
                            i = !0,
                            c = !1;
                        try {
                            for (n = n.call(e); !(i = (r = n.next()).done) && (o.push(r.value), !t || o.length !== t); i = !0);
                        } catch (l) {
                            c = !0, a = l
                        } finally {
                            try {
                                i || null == n.return || n.return()
                            } finally {
                                if (c) throw a
                            }
                        }
                        return o
                    }
                }(e, t) || i(e, t) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function l(e) {
                return l = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                    return typeof e
                } : function(e) {
                    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                }, l(e)
            }

            function u(e, t) {
                if (null == e) return {};
                var n, r, a = function(e, t) {
                    if (null == e) return {};
                    var n, r, a = {},
                        o = Object.keys(e);
                    for (r = 0; r < o.length; r++) n = o[r], t.indexOf(n) >= 0 || (a[n] = e[n]);
                    return a
                }(e, t);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(e);
                    for (r = 0; r < o.length; r++) n = o[r], t.indexOf(n) >= 0 || Object.prototype.propertyIsEnumerable.call(e, n) && (a[n] = e[n])
                }
                return a
            }

            function f(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, r)
                }
                return n
            }

            function s(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? f(Object(n), !0).forEach((function(t) {
                        a(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : f(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }
            n.r(t), n.d(t, {
                TabPane: () => G,
                default: () => X
            });
            var d = n(365043),
                v = n(498139),
                b = n.n(v),
                p = n(462149),
                m = n(816765),
                h = n(628678);

            function y(e) {
                return function(e) {
                    if (Array.isArray(e)) return o(e)
                }(e) || function(e) {
                    if ("undefined" !== typeof Symbol && null != e[Symbol.iterator] || null != e["@@iterator"]) return Array.from(e)
                }(e) || i(e) || function() {
                    throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }
            var g = n(445818),
                E = n(770289);

            function w(e) {
                var t = (0, d.useRef)(),
                    n = (0, d.useRef)(!1);
                return (0, d.useEffect)((function() {
                        return function() {
                            n.current = !0, g.A.cancel(t.current)
                        }
                    }), []),
                    function() {
                        for (var r = arguments.length, a = new Array(r), o = 0; o < r; o++) a[o] = arguments[o];
                        n.current || (g.A.cancel(t.current), t.current = (0, g.A)((function() {
                            e.apply(void 0, a)
                        })))
                    }
            }
            var k = n(25001);

            function x(e, t) {
                var n, r = e.prefixCls,
                    o = e.id,
                    i = e.active,
                    c = e.tab,
                    l = c.key,
                    u = c.tab,
                    f = c.disabled,
                    s = c.closeIcon,
                    v = e.closable,
                    p = e.renderWrapper,
                    m = e.removeAriaLabel,
                    h = e.editable,
                    y = e.onClick,
                    g = e.onRemove,
                    E = e.onFocus,
                    w = e.style,
                    x = "".concat(r, "-tab");
                d.useEffect((function() {
                    return g
                }), []);
                var P = h && !1 !== v && !f;

                function S(e) {
                    f || y(e)
                }
                var C = d.createElement("div", {
                    key: l,
                    ref: t,
                    className: b()(x, (n = {}, a(n, "".concat(x, "-with-remove"), P), a(n, "".concat(x, "-active"), i), a(n, "".concat(x, "-disabled"), f), n)),
                    style: w,
                    onClick: S
                }, d.createElement("div", {
                    role: "tab",
                    "aria-selected": i,
                    id: o && "".concat(o, "-tab-").concat(l),
                    className: "".concat(x, "-btn"),
                    "aria-controls": o && "".concat(o, "-panel-").concat(l),
                    "aria-disabled": f,
                    tabIndex: f ? null : 0,
                    onClick: function(e) {
                        e.stopPropagation(), S(e)
                    },
                    onKeyDown: function(e) {
                        [k.A.SPACE, k.A.ENTER].includes(e.which) && (e.preventDefault(), S(e))
                    },
                    onFocus: E
                }, u), P && d.createElement("button", {
                    type: "button",
                    "aria-label": m || "remove",
                    tabIndex: 0,
                    className: "".concat(x, "-remove"),
                    onClick: function(e) {
                        var t;
                        e.stopPropagation(), (t = e).preventDefault(), t.stopPropagation(), h.onEdit("remove", {
                            key: l,
                            event: t
                        })
                    }
                }, s || h.removeIcon || "\xd7"));
                return p ? p(C) : C
            }
            const P = d.forwardRef(x);
            var S = {
                width: 0,
                height: 0,
                left: 0,
                top: 0
            };
            var C = {
                width: 0,
                height: 0,
                left: 0,
                top: 0,
                right: 0
            };
            var A = n(263088),
                O = n(685109);

            function T(e, t) {
                var n = e.prefixCls,
                    r = e.editable,
                    a = e.locale,
                    o = e.style;
                return r && !1 !== r.showAdd ? d.createElement("button", {
                    ref: t,
                    type: "button",
                    className: "".concat(n, "-nav-add"),
                    style: o,
                    "aria-label": (null === a || void 0 === a ? void 0 : a.addAriaLabel) || "Add tab",
                    onClick: function(e) {
                        r.onEdit("add", {
                            event: e
                        })
                    }
                }, r.addIcon || "+") : null
            }
            const I = d.forwardRef(T);

            function j(e, t) {
                var n = e.prefixCls,
                    r = e.id,
                    o = e.tabs,
                    i = e.locale,
                    l = e.mobile,
                    u = e.moreIcon,
                    f = void 0 === u ? "More" : u,
                    s = e.moreTransitionName,
                    v = e.style,
                    p = e.className,
                    m = e.editable,
                    h = e.tabBarGutter,
                    y = e.rtl,
                    g = e.removeAriaLabel,
                    E = e.onTabClick,
                    w = c((0, d.useState)(!1), 2),
                    x = w[0],
                    P = w[1],
                    S = c((0, d.useState)(null), 2),
                    C = S[0],
                    T = S[1],
                    j = "".concat(r, "-more-popup"),
                    M = "".concat(n, "-dropdown"),
                    N = null !== C ? "".concat(j, "-").concat(C) : null,
                    R = null === i || void 0 === i ? void 0 : i.dropdownAriaLabel;
                var D = d.createElement(A.default, {
                    onClick: function(e) {
                        var t = e.key,
                            n = e.domEvent;
                        E(t, n), P(!1)
                    },
                    id: j,
                    tabIndex: -1,
                    role: "listbox",
                    "aria-activedescendant": N,
                    selectedKeys: [C],
                    "aria-label": void 0 !== R ? R : "expanded dropdown"
                }, o.map((function(e) {
                    var t = m && !1 !== e.closable && !e.disabled;
                    return d.createElement(A.MenuItem, {
                        key: e.key,
                        id: "".concat(j, "-").concat(e.key),
                        role: "option",
                        "aria-controls": r && "".concat(r, "-panel-").concat(e.key),
                        disabled: e.disabled
                    }, d.createElement("span", null, e.tab), t && d.createElement("button", {
                        type: "button",
                        "aria-label": g || "remove",
                        tabIndex: 0,
                        className: "".concat(M, "-menu-item-remove"),
                        onClick: function(t) {
                            var n, r;
                            t.stopPropagation(), n = t, r = e.key, n.preventDefault(), n.stopPropagation(), m.onEdit("remove", {
                                key: r,
                                event: n
                            })
                        }
                    }, e.closeIcon || m.removeIcon || "\xd7"))
                })));

                function _(e) {
                    for (var t = o.filter((function(e) {
                            return !e.disabled
                        })), n = t.findIndex((function(e) {
                            return e.key === C
                        })) || 0, r = t.length, a = 0; a < r; a += 1) {
                        var i = t[n = (n + e + r) % r];
                        if (!i.disabled) return void T(i.key)
                    }
                }(0, d.useEffect)((function() {
                    var e = document.getElementById(N);
                    e && e.scrollIntoView && e.scrollIntoView(!1)
                }), [C]), (0, d.useEffect)((function() {
                    x || T(null)
                }), [x]);
                var L = a({}, y ? "marginRight" : "marginLeft", h);
                o.length || (L.visibility = "hidden", L.order = 1);
                var B = b()(a({}, "".concat(M, "-rtl"), y)),
                    K = l ? null : d.createElement(O.default, {
                        prefixCls: M,
                        overlay: D,
                        trigger: ["hover"],
                        visible: x,
                        transitionName: s,
                        onVisibleChange: P,
                        overlayClassName: B,
                        mouseEnterDelay: .1,
                        mouseLeaveDelay: .1
                    }, d.createElement("button", {
                        type: "button",
                        className: "".concat(n, "-nav-more"),
                        style: L,
                        tabIndex: -1,
                        "aria-hidden": "true",
                        "aria-haspopup": "listbox",
                        "aria-controls": j,
                        id: "".concat(r, "-more"),
                        "aria-expanded": x,
                        onKeyDown: function(e) {
                            var t = e.which;
                            if (x) switch (t) {
                                case k.A.UP:
                                    _(-1), e.preventDefault();
                                    break;
                                case k.A.DOWN:
                                    _(1), e.preventDefault();
                                    break;
                                case k.A.ESC:
                                    P(!1);
                                    break;
                                case k.A.SPACE:
                                case k.A.ENTER:
                                    null !== C && E(C, e)
                            } else [k.A.DOWN, k.A.SPACE, k.A.ENTER].includes(t) && (P(!0), e.preventDefault())
                        }
                    }, f));
                return d.createElement("div", {
                    className: b()("".concat(n, "-nav-operations"), p),
                    style: v,
                    ref: t
                }, K, d.createElement(I, {
                    prefixCls: n,
                    locale: i,
                    editable: m
                }))
            }
            const M = d.memo(d.forwardRef(j), (function(e, t) {
                    return t.tabMoving
                })),
                N = (0, d.createContext)(null);
            var R = .1,
                D = .01,
                _ = 20,
                L = Math.pow(.995, _);

            function B(e, t) {
                var n = d.useRef(e),
                    r = c(d.useState({}), 2)[1];
                return [n.current, function(e) {
                    var a = "function" === typeof e ? e(n.current) : e;
                    a !== n.current && t(a, n.current), n.current = a, r({})
                }]
            }
            var K = function(e) {
                var t, n = e.position,
                    r = e.prefixCls,
                    a = e.extra;
                if (!a) return null;
                var o = {};
                return a && "object" === l(a) && !d.isValidElement(a) ? o = a : o.right = a, "right" === n && (t = o.right), "left" === n && (t = o.left), t ? d.createElement("div", {
                    className: "".concat(r, "-extra-content")
                }, t) : null
            };

            function W(e, t) {
                var n, o = d.useContext(N),
                    i = o.prefixCls,
                    l = o.tabs,
                    u = e.className,
                    f = e.style,
                    v = e.id,
                    p = e.animated,
                    m = e.activeKey,
                    h = e.rtl,
                    k = e.extra,
                    x = e.editable,
                    A = e.locale,
                    O = e.tabPosition,
                    T = e.tabBarGutter,
                    j = e.children,
                    W = e.onTabClick,
                    q = e.onTabScroll,
                    V = (0, d.useRef)(),
                    G = (0, d.useRef)(),
                    H = (0, d.useRef)(),
                    z = (0, d.useRef)(),
                    Y = c(function() {
                        var e = (0, d.useRef)(new Map);
                        return [function(t) {
                            return e.current.has(t) || e.current.set(t, d.createRef()), e.current.get(t)
                        }, function(t) {
                            e.current.delete(t)
                        }]
                    }(), 2),
                    F = Y[0],
                    X = Y[1],
                    U = "top" === O || "bottom" === O,
                    $ = c(B(0, (function(e, t) {
                        U && q && q({
                            direction: e > t ? "left" : "right"
                        })
                    })), 2),
                    J = $[0],
                    Q = $[1],
                    Z = c(B(0, (function(e, t) {
                        !U && q && q({
                            direction: e > t ? "top" : "bottom"
                        })
                    })), 2),
                    ee = Z[0],
                    te = Z[1],
                    ne = c((0, d.useState)(0), 2),
                    re = ne[0],
                    ae = ne[1],
                    oe = c((0, d.useState)(0), 2),
                    ie = oe[0],
                    ce = oe[1],
                    le = c((0, d.useState)(null), 2),
                    ue = le[0],
                    fe = le[1],
                    se = c((0, d.useState)(null), 2),
                    de = se[0],
                    ve = se[1],
                    be = c((0, d.useState)(0), 2),
                    pe = be[0],
                    me = be[1],
                    he = c((0, d.useState)(0), 2),
                    ye = he[0],
                    ge = he[1],
                    Ee = function(e) {
                        var t = (0, d.useRef)([]),
                            n = c((0, d.useState)({}), 2)[1],
                            r = (0, d.useRef)("function" === typeof e ? e() : e),
                            a = w((function() {
                                var e = r.current;
                                t.current.forEach((function(t) {
                                    e = t(e)
                                })), t.current = [], r.current = e, n({})
                            }));
                        return [r.current, function(e) {
                            t.current.push(e), a()
                        }]
                    }(new Map),
                    we = c(Ee, 2),
                    ke = we[0],
                    xe = we[1],
                    Pe = function(e, t, n) {
                        return (0, d.useMemo)((function() {
                            for (var n, r = new Map, a = t.get(null === (n = e[0]) || void 0 === n ? void 0 : n.key) || S, o = a.left + a.width, i = 0; i < e.length; i += 1) {
                                var c, l = e[i].key,
                                    u = t.get(l);
                                u || (u = t.get(null === (c = e[i - 1]) || void 0 === c ? void 0 : c.key) || S);
                                var f = r.get(l) || s({}, u);
                                f.right = o - f.left - f.width, r.set(l, f)
                            }
                            return r
                        }), [e.map((function(e) {
                            return e.key
                        })).join("_"), t, n])
                    }(l, ke, re),
                    Se = "".concat(i, "-nav-operations-hidden"),
                    Ce = 0,
                    Ae = 0;

                function Oe(e) {
                    return e < Ce ? Ce : e > Ae ? Ae : e
                }
                U ? h ? (Ce = 0, Ae = Math.max(0, re - ue)) : (Ce = Math.min(0, ue - re), Ae = 0) : (Ce = Math.min(0, de - ie), Ae = 0);
                var Te = (0, d.useRef)(),
                    Ie = c((0, d.useState)(), 2),
                    je = Ie[0],
                    Me = Ie[1];

                function Ne() {
                    Me(Date.now())
                }

                function Re() {
                    window.clearTimeout(Te.current)
                }

                function De() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : m,
                        t = Pe.get(e) || {
                            width: 0,
                            height: 0,
                            left: 0,
                            right: 0,
                            top: 0
                        };
                    if (U) {
                        var n = J;
                        h ? t.right < J ? n = t.right : t.right + t.width > J + ue && (n = t.right + t.width - ue) : t.left < -J ? n = -t.left : t.left + t.width > -J + ue && (n = -(t.left + t.width - ue)), te(0), Q(Oe(n))
                    } else {
                        var r = ee;
                        t.top < -ee ? r = -t.top : t.top + t.height > -ee + de && (r = -(t.top + t.height - de)), Q(0), te(Oe(r))
                    }
                }! function(e, t) {
                    var n = c((0, d.useState)(), 2),
                        r = n[0],
                        a = n[1],
                        o = c((0, d.useState)(0), 2),
                        i = o[0],
                        l = o[1],
                        u = c((0, d.useState)(0), 2),
                        f = u[0],
                        s = u[1],
                        v = c((0, d.useState)(), 2),
                        b = v[0],
                        p = v[1],
                        m = (0, d.useRef)(),
                        h = (0, d.useRef)(),
                        y = (0, d.useRef)(null);
                    y.current = {
                        onTouchStart: function(e) {
                            var t = e.touches[0],
                                n = t.screenX,
                                r = t.screenY;
                            a({
                                x: n,
                                y: r
                            }), window.clearInterval(m.current)
                        },
                        onTouchMove: function(e) {
                            if (r) {
                                e.preventDefault();
                                var n = e.touches[0],
                                    o = n.screenX,
                                    c = n.screenY;
                                a({
                                    x: o,
                                    y: c
                                });
                                var u = o - r.x,
                                    f = c - r.y;
                                t(u, f);
                                var d = Date.now();
                                l(d), s(d - i), p({
                                    x: u,
                                    y: f
                                })
                            }
                        },
                        onTouchEnd: function() {
                            if (r && (a(null), p(null), b)) {
                                var e = b.x / f,
                                    n = b.y / f,
                                    o = Math.abs(e),
                                    i = Math.abs(n);
                                if (Math.max(o, i) < R) return;
                                var c = e,
                                    l = n;
                                m.current = window.setInterval((function() {
                                    Math.abs(c) < D && Math.abs(l) < D ? window.clearInterval(m.current) : t((c *= L) * _, (l *= L) * _)
                                }), _)
                            }
                        },
                        onWheel: function(e) {
                            var n = e.deltaX,
                                r = e.deltaY,
                                a = 0,
                                o = Math.abs(n),
                                i = Math.abs(r);
                            o === i ? a = "x" === h.current ? n : r : o > i ? (a = n, h.current = "x") : (a = r, h.current = "y"), t(-a, -a) && e.preventDefault()
                        }
                    }, d.useEffect((function() {
                        function t(e) {
                            y.current.onTouchMove(e)
                        }

                        function n(e) {
                            y.current.onTouchEnd(e)
                        }
                        return document.addEventListener("touchmove", t, {
                                passive: !1
                            }), document.addEventListener("touchend", n, {
                                passive: !1
                            }), e.current.addEventListener("touchstart", (function(e) {
                                y.current.onTouchStart(e)
                            }), {
                                passive: !1
                            }), e.current.addEventListener("wheel", (function(e) {
                                y.current.onWheel(e)
                            })),
                            function() {
                                document.removeEventListener("touchmove", t), document.removeEventListener("touchend", n)
                            }
                    }), [])
                }(V, (function(e, t) {
                    function n(e, t) {
                        e((function(e) {
                            return Oe(e + t)
                        }))
                    }
                    if (U) {
                        if (ue >= re) return !1;
                        n(Q, e)
                    } else {
                        if (de >= ie) return !1;
                        n(te, t)
                    }
                    return Re(), Ne(), !0
                })), (0, d.useEffect)((function() {
                    return Re(), je && (Te.current = window.setTimeout((function() {
                        Me(0)
                    }), 100)), Re
                }), [je]);
                var _e = function(e, t, n, r, a) {
                        var o, i, c, l = a.tabs,
                            u = a.tabPosition,
                            f = a.rtl;
                        ["top", "bottom"].includes(u) ? (o = "width", i = f ? "right" : "left", c = Math.abs(t.left)) : (o = "height", i = "top", c = -t.top);
                        var s = t[o],
                            v = n[o],
                            b = r[o],
                            p = s;
                        return v + b > s && v < s && (p = s - b), (0, d.useMemo)((function() {
                            if (!l.length) return [0, 0];
                            for (var t = l.length, n = t, r = 0; r < t; r += 1) {
                                var a = e.get(l[r].key) || C;
                                if (a[i] + a[o] > c + p) {
                                    n = r - 1;
                                    break
                                }
                            }
                            for (var u = 0, f = t - 1; f >= 0; f -= 1)
                                if ((e.get(l[f].key) || C)[i] < c) {
                                    u = f + 1;
                                    break
                                }
                            return [u, n]
                        }), [e, c, p, u, l.map((function(e) {
                            return e.key
                        })).join("_"), f])
                    }(Pe, {
                        width: ue,
                        height: de,
                        left: J,
                        top: ee
                    }, {
                        width: re,
                        height: ie
                    }, {
                        width: pe,
                        height: ye
                    }, s(s({}, e), {}, {
                        tabs: l
                    })),
                    Le = c(_e, 2),
                    Be = Le[0],
                    Ke = Le[1],
                    We = {};
                "top" === O || "bottom" === O ? We[h ? "marginRight" : "marginLeft"] = T : We.marginTop = T;
                var qe = l.map((function(e, t) {
                        var n = e.key;
                        return d.createElement(P, {
                            id: v,
                            prefixCls: i,
                            key: n,
                            tab: e,
                            style: 0 === t ? void 0 : We,
                            closable: e.closable,
                            editable: x,
                            active: n === m,
                            renderWrapper: j,
                            removeAriaLabel: null === A || void 0 === A ? void 0 : A.removeAriaLabel,
                            ref: F(n),
                            onClick: function(e) {
                                W(n, e)
                            },
                            onRemove: function() {
                                X(n)
                            },
                            onFocus: function() {
                                De(n), Ne(), V.current && (h || (V.current.scrollLeft = 0), V.current.scrollTop = 0)
                            }
                        })
                    })),
                    Ve = w((function() {
                        var e, t, n, r, a, o, i = (null === (e = V.current) || void 0 === e ? void 0 : e.offsetWidth) || 0,
                            c = (null === (t = V.current) || void 0 === t ? void 0 : t.offsetHeight) || 0,
                            u = (null === (n = z.current) || void 0 === n ? void 0 : n.offsetWidth) || 0,
                            f = (null === (r = z.current) || void 0 === r ? void 0 : r.offsetHeight) || 0;
                        fe(i), ve(c), me(u), ge(f);
                        var s = ((null === (a = G.current) || void 0 === a ? void 0 : a.offsetWidth) || 0) - u,
                            d = ((null === (o = G.current) || void 0 === o ? void 0 : o.offsetHeight) || 0) - f;
                        ae(s), ce(d), xe((function() {
                            var e = new Map;
                            return l.forEach((function(t) {
                                var n = t.key,
                                    r = F(n).current;
                                r && e.set(n, {
                                    width: r.offsetWidth,
                                    height: r.offsetHeight,
                                    left: r.offsetLeft,
                                    top: r.offsetTop
                                })
                            })), e
                        }))
                    })),
                    Ge = l.slice(0, Be),
                    He = l.slice(Ke + 1),
                    ze = [].concat(y(Ge), y(He)),
                    Ye = c((0, d.useState)(), 2),
                    Fe = Ye[0],
                    Xe = Ye[1],
                    Ue = Pe.get(m),
                    $e = (0, d.useRef)();

                function Je() {
                    g.A.cancel($e.current)
                }(0, d.useEffect)((function() {
                    var e = {};
                    return Ue && (U ? (h ? e.right = Ue.right : e.left = Ue.left, e.width = Ue.width) : (e.top = Ue.top, e.height = Ue.height)), Je(), $e.current = (0, g.A)((function() {
                        Xe(e)
                    })), Je
                }), [Ue, U, h]), (0, d.useEffect)((function() {
                    De()
                }), [m, Ue, Pe, U]), (0, d.useEffect)((function() {
                    Ve()
                }), [h, T, m, l.map((function(e) {
                    return e.key
                })).join("_")]);
                var Qe, Ze, et, tt, nt = !!ze.length,
                    rt = "".concat(i, "-nav-wrap");
                return U ? h ? (Ze = J > 0, Qe = J + ue < re) : (Qe = J < 0, Ze = -J + ue < re) : (et = ee < 0, tt = -ee + de < ie), d.createElement("div", {
                    ref: t,
                    role: "tablist",
                    className: b()("".concat(i, "-nav"), u),
                    style: f,
                    onKeyDown: function() {
                        Ne()
                    }
                }, d.createElement(K, {
                    position: "left",
                    extra: k,
                    prefixCls: i
                }), d.createElement(E.default, {
                    onResize: Ve
                }, d.createElement("div", {
                    className: b()(rt, (n = {}, a(n, "".concat(rt, "-ping-left"), Qe), a(n, "".concat(rt, "-ping-right"), Ze), a(n, "".concat(rt, "-ping-top"), et), a(n, "".concat(rt, "-ping-bottom"), tt), n)),
                    ref: V
                }, d.createElement(E.default, {
                    onResize: Ve
                }, d.createElement("div", {
                    ref: G,
                    className: "".concat(i, "-nav-list"),
                    style: {
                        transform: "translate(".concat(J, "px, ").concat(ee, "px)"),
                        transition: je ? "none" : void 0
                    }
                }, qe, d.createElement(I, {
                    ref: z,
                    prefixCls: i,
                    locale: A,
                    editable: x,
                    style: s(s({}, 0 === qe.length ? void 0 : We), {}, {
                        visibility: nt ? "hidden" : null
                    })
                }), d.createElement("div", {
                    className: b()("".concat(i, "-ink-bar"), a({}, "".concat(i, "-ink-bar-animated"), p.inkBar)),
                    style: Fe
                }))))), d.createElement(M, r({}, e, {
                    removeAriaLabel: null === A || void 0 === A ? void 0 : A.removeAriaLabel,
                    ref: H,
                    prefixCls: i,
                    tabs: ze,
                    className: !nt && Se,
                    tabMoving: !!je
                })), d.createElement(K, {
                    position: "right",
                    extra: k,
                    prefixCls: i
                }))
            }
            const q = d.forwardRef(W);

            function V(e) {
                var t = e.id,
                    n = e.activeKey,
                    r = e.animated,
                    o = e.tabPosition,
                    i = e.rtl,
                    c = e.destroyInactiveTabPane,
                    l = d.useContext(N),
                    u = l.prefixCls,
                    f = l.tabs,
                    s = r.tabPane,
                    v = f.findIndex((function(e) {
                        return e.key === n
                    }));
                return d.createElement("div", {
                    className: b()("".concat(u, "-content-holder"))
                }, d.createElement("div", {
                    className: b()("".concat(u, "-content"), "".concat(u, "-content-").concat(o), a({}, "".concat(u, "-content-animated"), s)),
                    style: v && s ? a({}, i ? "marginRight" : "marginLeft", "-".concat(v, "00%")) : null
                }, f.map((function(e) {
                    return d.cloneElement(e.node, {
                        key: e.key,
                        prefixCls: u,
                        tabKey: e.key,
                        id: t,
                        animated: s,
                        active: e.key === n,
                        destroyInactiveTabPane: c
                    })
                }))))
            }

            function G(e) {
                var t = e.prefixCls,
                    n = e.forceRender,
                    r = e.className,
                    a = e.style,
                    o = e.id,
                    i = e.active,
                    l = e.animated,
                    u = e.destroyInactiveTabPane,
                    f = e.tabKey,
                    v = e.children,
                    p = c(d.useState(n), 2),
                    m = p[0],
                    h = p[1];
                d.useEffect((function() {
                    i ? h(!0) : u && h(!1)
                }), [i, u]);
                var y = {};
                return i || (l ? (y.visibility = "hidden", y.height = 0, y.overflowY = "hidden") : y.display = "none"), d.createElement("div", {
                    id: o && "".concat(o, "-panel-").concat(f),
                    role: "tabpanel",
                    tabIndex: i ? 0 : -1,
                    "aria-labelledby": o && "".concat(o, "-tab-").concat(f),
                    "aria-hidden": !i,
                    style: s(s({}, y), a),
                    className: b()("".concat(t, "-tabpane"), i && "".concat(t, "-tabpane-active"), r)
                }, (i || m || n) && v)
            }
            var H = ["id", "prefixCls", "className", "children", "direction", "activeKey", "defaultActiveKey", "editable", "animated", "tabPosition", "tabBarGutter", "tabBarStyle", "tabBarExtraContent", "locale", "moreIcon", "moreTransitionName", "destroyInactiveTabPane", "renderTabBar", "onChange", "onTabClick", "onTabScroll"],
                z = 0;

            function Y(e, t) {
                var n, o, i = e.id,
                    f = e.prefixCls,
                    v = void 0 === f ? "rc-tabs" : f,
                    y = e.className,
                    g = e.children,
                    E = e.direction,
                    w = e.activeKey,
                    k = e.defaultActiveKey,
                    x = e.editable,
                    P = e.animated,
                    S = void 0 === P ? {
                        inkBar: !0,
                        tabPane: !1
                    } : P,
                    C = e.tabPosition,
                    A = void 0 === C ? "top" : C,
                    O = e.tabBarGutter,
                    T = e.tabBarStyle,
                    I = e.tabBarExtraContent,
                    j = e.locale,
                    M = e.moreIcon,
                    R = e.moreTransitionName,
                    D = e.destroyInactiveTabPane,
                    _ = e.renderTabBar,
                    L = e.onChange,
                    B = e.onTabClick,
                    K = e.onTabScroll,
                    W = u(e, H),
                    G = function(e) {
                        return (0, p.A)(e).map((function(e) {
                            return d.isValidElement(e) ? s(s({
                                key: void 0 !== e.key ? String(e.key) : void 0
                            }, e.props), {}, {
                                node: e
                            }) : null
                        })).filter((function(e) {
                            return e
                        }))
                    }(g),
                    Y = "rtl" === E;
                o = !1 === S ? {
                    inkBar: !1,
                    tabPane: !1
                } : !0 === S ? {
                    inkBar: !0,
                    tabPane: !0
                } : s({
                    inkBar: !0,
                    tabPane: !1
                }, "object" === l(S) ? S : {});
                var F = c((0, d.useState)(!1), 2),
                    X = F[0],
                    U = F[1];
                (0, d.useEffect)((function() {
                    U((0, m.A)())
                }), []);
                var $ = c((0, h.A)((function() {
                        var e;
                        return null === (e = G[0]) || void 0 === e ? void 0 : e.key
                    }), {
                        value: w,
                        defaultValue: k
                    }), 2),
                    J = $[0],
                    Q = $[1],
                    Z = c((0, d.useState)((function() {
                        return G.findIndex((function(e) {
                            return e.key === J
                        }))
                    })), 2),
                    ee = Z[0],
                    te = Z[1];
                (0, d.useEffect)((function() {
                    var e, t = G.findIndex((function(e) {
                        return e.key === J
                    })); - 1 === t && (t = Math.max(0, Math.min(ee, G.length - 1)), Q(null === (e = G[t]) || void 0 === e ? void 0 : e.key));
                    te(t)
                }), [G.map((function(e) {
                    return e.key
                })).join("_"), J, ee]);
                var ne = c((0, h.A)(null, {
                        value: i
                    }), 2),
                    re = ne[0],
                    ae = ne[1],
                    oe = A;
                X && !["left", "right"].includes(A) && (oe = "top"), (0, d.useEffect)((function() {
                    i || (ae("rc-tabs-".concat(z)), z += 1)
                }), []);
                var ie, ce = {
                        id: re,
                        activeKey: J,
                        animated: o,
                        tabPosition: oe,
                        rtl: Y,
                        mobile: X
                    },
                    le = s(s({}, ce), {}, {
                        editable: x,
                        locale: j,
                        moreIcon: M,
                        moreTransitionName: R,
                        tabBarGutter: O,
                        onTabClick: function(e, t) {
                            null === B || void 0 === B || B(e, t);
                            var n = e !== J;
                            Q(e), n && (null === L || void 0 === L || L(e))
                        },
                        onTabScroll: K,
                        extra: I,
                        style: T,
                        panes: g
                    });
                return ie = _ ? _(le, q) : d.createElement(q, le), d.createElement(N.Provider, {
                    value: {
                        tabs: G,
                        prefixCls: v
                    }
                }, d.createElement("div", r({
                    ref: t,
                    id: i,
                    className: b()(v, "".concat(v, "-").concat(oe), (n = {}, a(n, "".concat(v, "-mobile"), X), a(n, "".concat(v, "-editable"), x), a(n, "".concat(v, "-rtl"), Y), n), y)
                }, W), ie, d.createElement(V, r({
                    destroyInactiveTabPane: D
                }, ce, {
                    animated: o
                }))))
            }
            var F = d.forwardRef(Y);
            F.TabPane = G;
            const X = F
        }
    }
]);
//# sourceMappingURL=5256.80cf15a3.chunk.js.map