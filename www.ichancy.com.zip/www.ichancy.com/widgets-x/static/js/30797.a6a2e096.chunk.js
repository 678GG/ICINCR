"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [30797], {
        930797: (e, a, s) => {
            s.d(a, {
                V: () => t
            });
            var d = s(365043),
                i = s(179177),
                r = s(55418),
                o = s(48070),
                l = (s(183215), s(570579));
            const t = e => {
                let {
                    id: a,
                    icon_1: s,
                    icon_2: t,
                    icon_3: c,
                    name: n,
                    badge: _,
                    children: m
                } = e;
                const [p, v] = (0, d.useState)(!0);
                return (0, l.jsxs)("div", {
                    className: "x-casinoGameCardImageWrapper",
                    "data-testid": n,
                    children: [p && (0, l.jsx)(o.D, {
                        extraStyle: !0
                    }), (0, l.jsx)("img", {
                        className: "x-casinoGameCardImageWrapper__image",
                        src: `${i.Ay.CASINO_HIGH_QUALITY_PICTURES&&c?c:(0,r.F)()&&s?s:t}?v=${i.Ay.VERSION}`,
                        alt: n,
                        loading: "lazy",
                        onLoad: () => {
                            v(!1)
                        }
                    }, a), _ ? (0, l.jsx)("div", {
                        className: (0, r.F)() ? "provider_badgeMob" : "provider_badge",
                        children: (0, l.jsx)("div", {
                            className: "text__badge",
                            children: null === _ || void 0 === _ ? void 0 : _.title
                        })
                    }) : null, m]
                })
            }
        }
    }
]);
//# sourceMappingURL=30797.a6a2e096.chunk.js.map