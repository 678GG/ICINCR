"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [36046], {
        436046: (e, r, o) => {
            var t = o(924297).default;
            Object.defineProperty(r, "__esModule", {
                value: !0
            }), r.default = function e(r) {
                var o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                    t = [];
                return a.default.Children.forEach(r, (function(r) {
                    (void 0 !== r && null !== r || o.keepEmpty) && (Array.isArray(r) ? t = t.concat(e(r)) : (0, n.isFragment)(r) && r.props ? t = t.concat(e(r.props.children, o)) : t.push(r))
                })), t
            };
            var a = t(o(365043)),
                n = o(136816)
        }
    }
]);
//# sourceMappingURL=36046.f9b33cc8.chunk.js.map