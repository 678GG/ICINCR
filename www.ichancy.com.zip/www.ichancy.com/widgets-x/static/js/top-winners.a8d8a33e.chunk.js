"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [68055], {
        537653: (e, n, s) => {
            s.r(n), s.d(n, {
                TopWinners: () => k
            });
            var i = s(804376),
                a = s(365043),
                t = s(889181),
                r = s(893662),
                l = s(989618),
                o = s(55418),
                d = s(185762),
                c = s(870905),
                _ = s(197262),
                p = s(735905),
                m = s(23725),
                u = s(570579);
            const h = {
                    index: 0,
                    key: "0",
                    keyWithName: "topWinners",
                    value: `\ud83d\udd25 ${_.A.t("casino.topWinners")}`
                },
                v = {
                    index: 1,
                    key: "1",
                    keyWithName: "recentWinners",
                    value: `\u26a1\ufe0f ${_.A.t("casino.recentWinners")}`
                },
                x = e => {
                    let {
                        activeTab: n,
                        setActiveTab: s,
                        visibleTabs: r,
                        topWinnersLayout: l
                    } = e;
                    const {
                        t: d
                    } = (0, c.B)(), _ = (0, a.useMemo)((() => {
                        const e = [],
                            n = r === i.d.all;
                        return (r === i.d.topWinners || n) && e.push(h), (r === i.d.recentWinners || n) && e.push(v), e
                    }), [r]);
                    return (0, u.jsx)("div", {
                        className: (0, t.A)(["menu__wrapper", {
                            "menu__wrapper--singleItem": 1 === (null === _ || void 0 === _ ? void 0 : _.length)
                        }]),
                        children: l === i.l.slider ? (0, u.jsx)(m.CustomMenu, {
                            fullWidth: (0, o.F)(),
                            items: _,
                            activeItem: n.toString(),
                            setActiveItem: s
                        }) : _.map((e => (0, u.jsxs)("div", {
                            className: (0, t.A)(["menu-item", {
                                "menu-item--active": n === e.index && (null === _ || void 0 === _ ? void 0 : _.length) > 1
                            }]),
                            onClick: () => s(e.index),
                            children: [(0, u.jsx)(p.GlobalIcon, {
                                skeleton: !0,
                                lib: "generic",
                                name: e.keyWithName,
                                theme: "colored",
                                size: 20
                            }), (0, u.jsx)("div", {
                                className: "menu-item__title",
                                children: d(`casino.${e.keyWithName}`)
                            })]
                        }, e.index)))
                    })
                },
                W = () => {
                    const {
                        t: e
                    } = (0, c.B)();
                    return (0, u.jsx)("div", {
                        className: "emptyView",
                        children: (0, u.jsx)("div", {
                            className: "emptyView__content",
                            children: e("emptyMessages.noWinnersData")
                        })
                    })
                };
            var b = s(187334),
                A = s(745574),
                N = s(218130),
                g = (s(270757), s(694227));
            s(63695);
            const y = () => (0, u.jsx)("div", {
                className: (0, t.A)(["topWinners__cardSlider topWinners__cardSlider--loading", {
                    "topWinners__cardSlider--mobile": (0, o.F)()
                }]),
                children: (0, u.jsx)("div", {
                    className: "x-casinoGameCardImageWrapper x-casinoGameCardImageWrapper__skeleton",
                    children: (0, u.jsx)(g.A.Image, {
                        className: "x-casinoGameCardImageSkeleton",
                        style: {
                            position: "absolute",
                            left: 0,
                            top: 0,
                            right: 0,
                            bottom: 0,
                            width: "100%",
                            height: "100%"
                        }
                    })
                })
            });
            var j = s(179177),
                T = s(242828);
            j.Ay.IS_RTL && s.e(55336).then(s.bind(s, 955336));
            const {
                TopWinnersContentMobile: S
            } = (0, l.R)((() => Promise.all([s.e(24757), s.e(84716), s.e(95459), s.e(42146), s.e(10795), s.e(90286), s.e(71139), s.e(17893), s.e(97760), s.e(62330), s.e(89910), s.e(68392), s.e(96771), s.e(18056), s.e(6327), s.e(48070), s.e(6683), s.e(13900), s.e(44148), s.e(30797), s.e(8246), s.e(99931)]).then(s.bind(s, 724179)))), {
                TopWinnersContentDesktop: f
            } = (0, l.R)((() => Promise.all([s.e(24757), s.e(84716), s.e(95459), s.e(42146), s.e(10795), s.e(90286), s.e(71139), s.e(17893), s.e(97760), s.e(62330), s.e(89910), s.e(68392), s.e(96771), s.e(18056), s.e(6327), s.e(48070), s.e(6683), s.e(13900), s.e(44148), s.e(30797), s.e(8246), s.e(92711)]).then(s.bind(s, 126431)))), {
                TopWinnerSliderCard: E
            } = (0, l.R)((() => Promise.all([s.e(94574), s.e(80192), s.e(24757), s.e(84716), s.e(95459), s.e(42146), s.e(65506), s.e(10795), s.e(90286), s.e(71139), s.e(17893), s.e(83573), s.e(97760), s.e(62330), s.e(89910), s.e(68392), s.e(96771), s.e(18056), s.e(6327), s.e(48070), s.e(6683), s.e(13900), s.e(44148), s.e(30797), s.e(46741)]).then(s.bind(s, 733917)))), I = e => {
                let {
                    configs: {
                        visibleTabs: n = i.d.all,
                        winnersTitle: s = !0,
                        topWinnersLayout: l = i.l.default,
                        topWinnersAutoPlay: c = !1
                    }
                } = e;
                const [_, p] = (0, a.useState)(n === i.d.all ? 0 : n - 2), {
                    data: m,
                    isLoading: h
                } = (0, b.g)(+_), v = (0, a.useMemo)((() => !h && !m.length), [h, m.length]), g = (0, a.useMemo)((() => !s && n !== i.d.all), [s, n]);
                return l === i.l.slider ? (0, u.jsxs)("div", {
                    className: (0, t.A)(["topWinners__carousel", {
                        "topWinners__carousel--mobile": (0, o.F)(),
                        "topWinners__carousel--withTitle": !g,
                        "topWinners__carousel--autoSlide": c
                    }]),
                    children: [g ? null : (0, u.jsx)(x, {
                        activeTab: _,
                        setActiveTab: p,
                        visibleTabs: n,
                        topWinnersLayout: l
                    }), (0, u.jsx)("div", {
                        className: (0, t.A)(["topWinners__carousel__container", {
                            "topWinners__carousel__container--skeleton": h
                        }]),
                        children: v ? (0, u.jsx)(W, {}) : h ? (0, u.jsx)("div", {
                            className: (0, t.A)(["topWinners__cardSlider__skeleton", {
                                "topWinners__cardSlider__skeleton--mobile": (0, o.F)()
                            }]),
                            children: (0, T.K)(7).map((e => (0, u.jsx)(y, {}, e)))
                        }) : (0, u.jsx)(r.SwiperSlider, {
                            drawableTabs: m.map(((e, n) => (0, u.jsx)(a.Suspense, {
                                fallback: (0, u.jsx)(y, {}),
                                children: (0, u.jsx)(E, {
                                    cardData: e
                                })
                            }, n))),
                            activeSlide: 0,
                            bodyArrows: !(0, o.F)(),
                            autoplay: c || !1,
                            delay: 1500
                        })
                    })]
                }) : (0, u.jsxs)("div", {
                    className: (0, t.A)(["topWinners", {
                        "topWinners--mobile": (0, o.F)(),
                        "topWinners--noTitle": g
                    }]),
                    children: [g ? null : (0, u.jsx)(x, {
                        activeTab: _,
                        setActiveTab: p,
                        visibleTabs: n
                    }), (0, u.jsx)("div", {
                        className: "topWinners__content",
                        children: v ? (0, u.jsx)(W, {}) : (0, u.jsx)(d.L, {
                            mobile: S,
                            desktop: f,
                            innerProps: {
                                isLoading: h,
                                data: m
                            },
                            fallback: (0, o.F)() ? (0, u.jsx)(A.K, {}) : (0, u.jsx)(N.c, {})
                        })
                    })]
                })
            }, C = {
                visibleTabs: i.d.all,
                winnersTitle: !0,
                topWinnersLayout: i.l.default,
                topWinnersAutoPlay: !1
            }, k = e => {
                let {
                    configs: n = C
                } = e;
                return (0, u.jsx)(I, {
                    configs: n
                })
            }
        },
        818261: (e, n, s) => {
            s.d(n, {
                Y: () => r
            });
            s(270757);
            var i = s(694227),
                a = s(365043),
                t = (s(826090), s(570579));
            const r = e => {
                let {
                    isMobile: n = !1
                } = e;
                const s = (0, a.useCallback)((e => (0, t.jsx)(i.A, {
                    active: !0,
                    paragraph: !1,
                    title: {
                        width: e || "100px",
                        style: {
                            margin: "2px 0",
                            width: e || "100px",
                            height: "12px"
                        }
                    }
                })), []);
                return (0, t.jsxs)("div", {
                    className: "topWinners__card " + (n ? "topWinners__card__mobile" : ""),
                    children: [(0, t.jsx)("div", {
                        className: "topWinners__card__game",
                        children: (0, t.jsx)(i.A, {
                            active: !0,
                            avatar: {
                                shape: "square",
                                style: {
                                    width: "64px",
                                    height: "52px"
                                }
                            }
                        })
                    }), (0, t.jsxs)("div", {
                        className: "topWinners__card__info",
                        children: [(0, t.jsx)("div", {
                            className: "topWinners__card__info--name",
                            children: s("120px")
                        }), (0, t.jsx)("div", {
                            className: "topWinners__card__info--player",
                            children: s()
                        }), (0, t.jsx)("div", {
                            className: "topWinners__card__info--win-amount",
                            children: s("40px")
                        })]
                    })]
                })
            }
        },
        218130: (e, n, s) => {
            s.d(n, {
                c: () => l
            });
            var i = s(55418),
                a = s(818261),
                t = s(187334),
                r = s(570579);
            const l = () => (0, r.jsx)("div", {
                className: "topWinners-cards-container " + ((0, i.F)() ? "topWinners-cards-container--mobile" : ""),
                children: new Array(t.P).fill("").map(((e, n) => (0, r.jsx)(a.Y, {}, n)))
            })
        },
        745574: (e, n, s) => {
            s.d(n, {
                K: () => r
            });
            s(365043);
            var i = s(818261),
                a = s(187334),
                t = s(570579);
            const r = () => (0, t.jsx)("div", {
                className: "topWinners-cards-container topWinners-cards-container--mobile",
                children: new Array(a.P).fill("").map(((e, n) => (0, t.jsx)(i.Y, {
                    isMobile: !0
                }, n)))
            })
        },
        187334: (e, n, s) => {
            s.d(n, {
                P: () => c,
                g: () => _
            });
            var i = s(365043),
                a = s(870905),
                t = s(500223),
                r = s(930911),
                l = s(320308),
                o = s(179177),
                d = s(737536);
            const c = 10,
                _ = e => {
                    const {
                        t: n
                    } = (0, a.B)(), [_, p] = (0, i.useState)(!0), [m, u] = (0, i.useState)(null), [h, v] = (0, i.useState)([]), x = (0, i.useCallback)((e => e.map((e => ({ ...e,
                        get game() {
                            return m && m.find((e => +e.extearnal_game_id === +this.game_id)) || null
                        }
                    })))), [m]);
                    (0, i.useLayoutEffect)((() => {
                        m && v((e => x(e)))
                    }), [m]);
                    const W = (0, i.useMemo)((() => 0 === e ? d.y.GET_CASINO_TOP_WINNERS : d.y.GET_CASINO_RECENT_WINNERS), [e]),
                        b = (0, i.useCallback)((e => {
                            v(e.map((e => ({ ...e,
                                game: null
                            }))));
                            const n = e.flat().map((e => {
                                    let {
                                        game_id: n
                                    } = e;
                                    return n
                                })),
                                s = Array.from(new Set(n));
                            (0, r.b)(s, !1, !0).then(u).finally((() => p(!1)))
                        }), []);
                    return (0, i.useLayoutEffect)((() => {
                        if (o.Ay.MOCKED_DATA) return s.e(66714).then(s.bind(s, 684492)).then((e => {
                            const n = +(W === d.y.GET_CASINO_RECENT_WINNERS);
                            v(e.CASINO_TOP_WINNERS_MOCK[n].map((e => ({ ...e,
                                game: null
                            }))))
                        })), void s.e(57399).then(s.bind(s, 363112)).then((e => {
                            p(!1), u([...e.CASINO_GAMES_MOCK[51].all || []])
                        }));
                        W && (p(!0), (0, t.qE)(W, {
                            count: c
                        }, (e => {
                            b(e.details)
                        }), null, (() => {
                            (0, l.$)(n("swarm.sorryWrong")), p(!1)
                        })))
                    }), [W, b]), {
                        isLoading: _,
                        data: h
                    }
                }
        },
        804376: (e, n, s) => {
            s.d(n, {
                d: () => i,
                l: () => a
            });
            let i = function(e) {
                    return e[e.topWinners = 2] = "topWinners", e[e.recentWinners = 3] = "recentWinners", e[e.all = 1] = "all", e
                }({}),
                a = function(e) {
                    return e[e.default = 0] = "default", e[e.slider = 1] = "slider", e
                }({})
        },
        930911: (e, n, s) => {
            s.d(n, {
                b: () => _
            });
            var i = s(140854),
                a = s.n(i),
                t = s(664833),
                r = s(179177),
                l = s(224272),
                o = s(55418),
                d = s(320308),
                c = s(457250);
            const _ = function(e) {
                let n, s = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
                    i = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
                    _ = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
                if (_) n = {
                    partnerId: r.Ay.DECENTRALIZED_CASINO_PARTNER_ID,
                    gameId: e[0]
                };
                else if (n = {
                        partner_id: r.Ay.PARTNER_ID,
                        is_mobile: Number((0, o.F)()),
                        lang: c.Ic,
                        by_key: t.d.Id,
                        use_webp: Number(r.Ay.IS_WEBP_SUPPORTED)
                    }, i && null !== e && void 0 !== e && e.length) n.external_id = e;
                else if (1 === (null === e || void 0 === e ? void 0 : e.length)) n.id = e[0];
                else {
                    if (!((null === e || void 0 === e ? void 0 : e.length) > 1)) return new Promise((e => e([])));
                    n.external_id = e
                }
                const p = null !== r.Ay && void 0 !== r.Ay && r.Ay.DECENTRALIZED_CASINO_URL ? `${r.Ay.DECENTRALIZED_CASINO_URL}${l.j.GET_DECENTRALIZED_GAME}` : `${r.Ay.CASINO_URL}/${l.j.GET_GAMES}`;
                return a().get(p, {
                    params: n
                }).then((e => 200 === e.status && e.data && ("ok" === e.data.status || _) ? _ ? [{
                    extearnal_game_id: e.data.externalGameId,
                    types: {
                        realMode: 0,
                        funMode: 0
                    },
                    icon_1: e.data.icon1,
                    icon_2: e.data.icon2,
                    icon_3: e.data.icon3,
                    provider: "ALL",
                    provider_badge: null,
                    provider_title: "ALL",
                    show_as_provider: "ALL",
                    cats: e.data.categories,
                    ...e.data
                }] : Object.values(e.data.games) : (s && (0, d.$)(e.statusText), []))).catch((e => (s && (0, d.$)(e.toString()), [])))
            }
        },
        826090: () => {},
        63695: () => {}
    }
]);
//# sourceMappingURL=top-winners.a8d8a33e.chunk.js.map