"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [78878, 26038], {
        319166: (e, n, t) => {
            t.r(n), t.d(n, {
                Generic: () => oe
            });
            var s = t(365043),
                i = t(995392),
                o = t(796410),
                a = t(605060),
                r = t(797760),
                d = t(115408),
                l = t(179177),
                c = t(384716),
                u = t(123213),
                _ = t(556785),
                A = t(989618),
                g = t(570579);
            const {
                AddToBetslipLink: p
            } = (0, A.R)((() => Promise.all([t.e(35820), t.e(13695)]).then(t.bind(t, 539425)))), I = () => {
                const e = (0, c.o)(),
                    n = (0, i.zy)(),
                    t = (0, d.A)(),
                    [A, I] = (0, s.useState)(!1);
                return (0, s.useEffect)((() => {
                    if (l.Ay.IFRAME_SPORTSBOOK && e.odds_type) {
                        const n = { ...(0, o.A)(a.z, "value", e.odds_type, !1)
                            },
                            {
                                id: s,
                                value: i
                            } = n;
                        t(s, i)
                    }
                    if ((n.pathname === r.L.addToBetslip || u.A.getItem((0, _.U)("betslip", "ADD_TO_BETSLIP_DATA"))) && I(!0), n.pathname.includes(r.L.deposit)) {
                        const e = n.pathname.replace(r.L.deposit, "");
                        window.location.href = `${window.location.origin}${e}?accounts=%2A&wallet=%2A&deposit=%2A`
                    }
                }), []), A ? (0, g.jsx)(s.Suspense, {
                    fallback: null,
                    children: (0, g.jsx)(p, {})
                }) : null
            };
            var h = t(679559),
                m = t(841591),
                w = t(507712);
            const {
                SumSubKYCVerification: v
            } = (0, A.R)((() => Promise.all([t.e(87161), t.e(34426), t.e(55608), t.e(84107), t.e(81927), t.e(35834), t.e(70136), t.e(28151), t.e(94574), t.e(51238), t.e(90440), t.e(35905), t.e(87154), t.e(40999), t.e(14971), t.e(30275)]).then(t.bind(t, 714198)))), S = () => {
                const e = (0, w.d4)(h.x8),
                    n = (0, w.d4)(m.gh),
                    t = (0, w.d4)(h.wz);
                return !Number(null === n || void 0 === n ? void 0 : n.sumSubWithdrawalAction) && 37 === t.active_step && 5 === t.active_step_state || e ? (0, g.jsx)(s.Suspense, {
                    children: (0, g.jsx)(v, {})
                }) : null
            }, {
                DeRealityCheck: f
            } = (0, A.R)((() => Promise.all([t.e(87161), t.e(34426), t.e(55608), t.e(84107), t.e(81927), t.e(35834), t.e(70136), t.e(28151), t.e(94574), t.e(51238), t.e(90440), t.e(35905), t.e(87154), t.e(40999), t.e(14971), t.e(52056), t.e(22022)]).then(t.bind(t, 773871)))), T = () => {
                const e = (0, w.d4)(h.eP);
                return l.Ay.SHOW_REALITY_CHECK && e ? (0, g.jsx)(s.Suspense, {
                    fallback: null,
                    children: (0, g.jsx)(f, {})
                }) : null
            };
            var E = t(930911),
                y = t(906327);
            const R = () => {
                const e = (0, y.b)();
                return (n, t) => {
                    (0, E.b)([n], !0, !0).then((n => {
                        if (n.length) {
                            const s = n[0];
                            e(t, s)
                        }
                    }))
                }
            };
            var O = t(446987),
                b = t(282695),
                N = t(393738);
            const P = () => {
                const e = (0, i.W6)(),
                    [n, t] = (0, s.useState)(""),
                    [o, a] = (0, s.useState)(""),
                    {
                        loginCallback: r
                    } = (0, b.S)({
                        rememberMe: !0,
                        username: n,
                        password: o
                    });
                return window.SB = {
                    openCasinoGame: R(),
                    historyPush: n => {
                        e.push(n)
                    },
                    login: (e, n) => {
                        t(e), a(n)
                    },
                    markAsReadNotification: N.h
                }, (0, s.useEffect)((() => {
                    n && o && (0, O.iD)({
                        username: n,
                        password: o
                    }, r)
                }), [n, o]), null
            };
            var L = t(880279),
                C = t(701616),
                j = t(424541);
            var x = t(816343),
                U = t(294137);
            const k = () => {
                (() => {
                    const {
                        currencyId: e
                    } = (0, j.H)(), n = (0, w.wA)();
                    (0, s.useEffect)((() => {
                        e && (n((0, C.zt)(!0)), (0, L.p7)(e, (e => {
                            if (null !== e && void 0 !== e && e.data) {
                                const s = e.data.currency;
                                if (s) {
                                    var t;
                                    const e = null === (t = s[Object.keys(s)[0]]) || void 0 === t ? void 0 : t.rounding;
                                    n((0, C.pH)(e))
                                }
                            }
                            n((0, C.zt)(!1))
                        }), (() => {
                            n((0, C.zt)(!1))
                        })))
                    }), [e])
                })();
                const e = (0, i.W6)(),
                    n = (0, w.d4)(h.eP),
                    t = (0, w.d4)(h.wz);
                return (0, s.useEffect)((() => {
                    if (!t.pending) {
                        const t = t => {
                            "switchCurrency" === t.data.action && t.data.currencyId === U.d.FTNF.currency && (n ? e.push((0, x.U7)({
                                selected_wallet: U.d.FTNF.currency
                            })) : (e.push((0, x.U7)({
                                selected_wallet: U.d.FTNF.currency
                            })), (0, x.qx)("login", `${window.getPathname()}?selected_wallet=${U.d.FTNF.currency}`), e.push((0, x.U7)({
                                accounts: "*",
                                login: "*"
                            }))))
                        };
                        return window.addEventListener("message", t, !1), () => {
                            window.removeEventListener("message", t)
                        }
                    }
                }), [t.pending, n]), null
            };
            var D = t(322908),
                F = t.n(D);
            const M = () => ((0, s.useEffect)((() => {
                const e = F().parse(window.location.search, {
                    ignoreQueryPrefix: !0
                });
                e && e.message && "external" === e.mode && window.opener && window.opener.postMessage({
                    status: e.message
                }, "*")
            }), []), null);
            var B = t(457250),
                G = t(261988),
                $ = t(424757);
            const W = () => ((0, s.useEffect)((() => {
                if (window.location.hash.includes(B.py)) {
                    const e = F().parse(window.location.hash.slice(window.location.hash.indexOf("?")), {
                        ignoreQueryPrefix: !0
                    });
                    if (u.A.setItem((0, _.U)("sportsbook", "FROM_STATISTICS"), JSON.stringify(e)), e) {
                        const n = Object.keys(G.ld).find((n => G.ld[n] === e.language)) || "";
                        null !== e && void 0 !== e && e.type && 1 === +(null === e || void 0 === e ? void 0 : e.type) ? window.location.href = (0, $.Vv)(`${l.Ay.PAGE_URLS.live}`, n) : window.location.href = (0, $.Vv)(`${l.Ay.PAGE_URLS.prematch}`, n)
                    }
                }
            }), []), null);
            var V = t(291372),
                H = t(117893),
                z = t(238605);
            const K = () => ((0, s.useEffect)((() => {
                try {
                    if (l.Ay.WRAPPER_APP) {
                        const e = (0, z.Ri)("X_FCM_TOKEN");
                        e && "string" === typeof e && V.A.dispatch((0, H.LOZ)(e))
                    } else Promise.all([t.e(80955), t.e(16889)]).then(t.bind(t, 870997)).then((async e => {
                        const {
                            initAndGetFirebaseToken: n
                        } = e, t = await n();
                        t && V.A.dispatch((0, H.LOZ)(t))
                    }))
                } catch (e) {
                    console.error(e)
                }
            }), []), null);
            var Z = t(595459);
            const {
                RedirectToSingleGameViewContent: Y
            } = (0, A.R)((() => Promise.all([t.e(90440), t.e(2546), t.e(85319)]).then(t.bind(t, 352601)))), X = () => {
                const {
                    path: e
                } = (0, Z.d)();
                return (0, g.jsx)(i.qh, {
                    path: `${(0,$.nm)(e)}/(${B.EI})/:game`,
                    children: (0, g.jsx)(s.Suspense, {
                        fallback: null,
                        children: (0, g.jsx)(Y, {})
                    })
                })
            }, {
                NotificationsRedirectionsHandler: J
            } = (0, A.R)((() => Promise.all([t.e(80955), t.e(24044)]).then(t.bind(t, 694394)))), {
                HooryRelatedLogic: q
            } = (0, A.R)((() => t.e(46972).then(t.bind(t, 426398)))), {
                BetModalCheck: Q
            } = (0, A.R)((() => t.e(11453).then(t.bind(t, 999698)))), {
                Iovation: ee
            } = (0, A.R)((() => t.e(21594).then(t.bind(t, 476013)))), {
                GamblingAreas: ne
            } = (0, A.R)((() => Promise.all([t.e(87161), t.e(34426), t.e(55608), t.e(84107), t.e(81927), t.e(35834), t.e(70136), t.e(28151), t.e(94574), t.e(51238), t.e(90440), t.e(35905), t.e(87154), t.e(40999), t.e(14971), t.e(33471), t.e(16292), t.e(49599)]).then(t.bind(t, 83017)))), {
                CheckHomeworkData: te
            } = (0, A.R)((() => Promise.all([t.e(89910), t.e(9119), t.e(34417)]).then(t.bind(t, 574830)))), {
                LogoutRelatedLogic: se
            } = (0, A.R)((() => t.e(2748).then(t.bind(t, 412239)))), {
                IframeSportsbookLogic: ie
            } = (0, A.R)((() => t.e(23069).then(t.bind(t, 943634)))), oe = () => (0, g.jsxs)(g.Fragment, {
                children: [l.Ay.PUSH_NOTIFICATIONS_ENABLED && (0, g.jsx)(s.Suspense, {
                    children: (0, g.jsx)(x.Wy, {
                        includes: ["notificationRoute"],
                        component: J
                    })
                }), l.Ay.GAMBLING_AREAS && !l.Ay.MOCKED_DATA && (0, g.jsx)(s.Suspense, {
                    children: (0, g.jsx)(ne, {})
                }), l.Ay.IFRAME_SPORTSBOOK && (0, g.jsx)(s.Suspense, {
                    children: (0, g.jsx)(ie, {})
                }), l.Ay.IS_BET_SHARING_AVAILABLE && (0, g.jsx)(s.Suspense, {
                    children: (0, g.jsx)(Q, {})
                }), !!l.Ay.SESSION_LIFE_TIME && (0, g.jsx)(s.Suspense, {
                    children: (0, g.jsx)(se, {})
                }), l.Ay.FIREBASE_ENABLED && (0, g.jsx)(s.Suspense, {
                    children: (0, g.jsx)(K, {})
                }), l.Ay.HOMEWORK_ENABLED && (0, g.jsx)(s.Suspense, {
                    children: (0, g.jsx)(te, {})
                }), l.Ay.HOORY_ENABLED && (0, g.jsx)(s.Suspense, {
                    children: (0, g.jsx)(q, {})
                }), l.Ay.IOVATION_ENABLED && (0, g.jsx)(s.Suspense, {
                    children: (0, g.jsx)(ee, {})
                }), (0, g.jsx)(S, {}), (0, g.jsx)(X, {}), (0, g.jsx)(M, {}), (0, g.jsx)(W, {}), (0, g.jsx)(I, {}), (0, g.jsx)(k, {}), (0, g.jsx)(T, {}), (0, g.jsx)(P, {})]
            })
        },
        282695: (e, n, t) => {
            t.d(n, {
                S: () => T
            });
            var s = t(365043),
                i = t(507712),
                o = t(446987),
                a = t(117893),
                r = t(995392),
                d = t(701616),
                l = t(841591),
                c = t(124634),
                u = t(123213),
                _ = t(49770),
                A = t(171224),
                g = t(596771),
                p = t(816343),
                I = t(179177),
                h = t(115837),
                m = t(556785),
                w = t(954947),
                v = t(485138),
                S = t(849944),
                f = t(302258);
            const T = e => {
                let {
                    rememberMe: n,
                    userGroups: t
                } = e;
                const T = (0, s.useRef)(),
                    [E, y] = (0, s.useState)(!1),
                    [R, O] = (0, s.useState)(),
                    b = (0, i.wA)(),
                    N = (0, r.W6)(),
                    P = (0, i.d4)(l.h0),
                    L = null === P || void 0 === P ? void 0 : P.find((e => e && "personalId" === e.formType)),
                    C = () => {
                        u.A.setItem((0, m.U)("account", "AUTH_DATA"), JSON.stringify(T.current)), (0, o.wz)(x, j, "login", !1, !(null === L || void 0 === L || !L.editForm.showOnEditProfile || "2" !== L.editForm.personalIdType || "1" !== (null === L || void 0 === L ? void 0 : L.editForm.sendCPFAsDocNumber))), I.Ay.PUSH_NOTIFICATIONS_ENABLED && (0, c.f)()
                    },
                    {
                        updateUser: j
                    } = (0, h.Q)(),
                    x = e => {
                        var s;
                        (0, A.c)("loginCredentials", {
                            rememberMe: n,
                            userGroups: t || "",
                            jwe_token: (null === T || void 0 === T || null === (s = T.current) || void 0 === s ? void 0 : s.jwe_token) || ""
                        }), b((0, a.sX7)({ ...e,
                            last_login_date: e.last_login_date || Math.floor((new Date).getTime() / 1e3)
                        })), b((0, a.hB6)(60 * (e.session_duration || 0))), e.active_time_in_casino && _.A.setItem((0, m.U)("account", "ACTIVE_TIME_IN_CASINO"), `${e.active_time_in_casino}`);
                        const i = g.y.getAfterSignIn();
                        "function" === typeof i ? (g.y.setAfterSignIn(null), (0, p.XZ)(), i()) : (b((0, a.Xz$)(!e.is_verified)), N.push((0, p.XZ)())), b((0, a.VoE)(!0)), u.A.setItem((0, m.U)("account", "PARENT_ACCOUNT_CURRENCY"), e.currency), (0, A.c)("sbuser", {
                            rememberMe: n,
                            userGroups: t && t || ""
                        }, 15), window.refreshWhenLoggedIn && (N.push((0, p.oR)({
                            accounts: void 0,
                            login: void 0
                        })), window.mustRefreshForSessionVisibility = !0, window.location.reload())
                    };
                return {
                    loginCallback: e => {
                        const {
                            auth_token: n,
                            user_id: t,
                            qr_code_origin: s,
                            authentication_status: i,
                            jwe_token: o
                        } = e;
                        if (T.current = {
                                auth_token: n,
                                user_id: t,
                                qr_code_origin: s,
                                jwe_token: o
                            }, 4 === i) return y(!0), void O(s);
                        I.Ay.ADD_INFO_AFTER_LOGIN && b((0, d.rY)(!0)), (0, w.A)(), C(), (0, v.y)({
                            type: "userId",
                            value: e.user_id
                        }), window.popupIframe && window.parent.postMessage({
                            action: "login",
                            credentials: {
                                auth_token: e.auth_token,
                                user_id: e.user_id
                            }
                        }, "*"), I.Ay.IFRAME_SPORTSBOOK && (0, S.$i)("loggedIn"), I.Ay.LOGIN_LIMIT_POPUP && (0, f.as)()
                    },
                    updateAuthData: C,
                    isTwoFactorPopupVisible: E,
                    qrCodeOrigin: R
                }
            }
        },
        626038: (e, n, t) => {
            t.d(n, {
                N: () => p
            });
            var s = t(507712),
                i = t(995392),
                o = t(307022),
                a = t(841591),
                r = t(446987),
                d = t(93907),
                l = t(816343),
                c = t(123213),
                u = t(556785),
                _ = t(238605),
                A = t(179177),
                g = t(849944);
            const p = e => {
                const n = (0, s.wA)(),
                    t = (0, i.W6)(),
                    p = (0, s.d4)(a.V7);
                return s => {
                    (0, r.ri)((() => (e => {
                        var s;
                        e && t.push((0, l.XZ)()), n((0, o.Sl)()), n((0, o.XO)(null)), n((0, d.sV)({})), c.A.removeItem((0, u.U)("account", "LOGIN_LIMIT_START_TIME")), c.A.removeItem((0, u.U)("account", "LOGIN_LIMIT_POPUP_START_TIME")), c.A.removeItem((0, u.U)("account", "IS_LOGOUT")), (0, _.Yj)("sbuser"), (0, _.Yj)("loginCredentials"), c.A.removeItem((0, u.U)("account", "ADDITIONAL_INFO_POPUP")), c.A.removeItem((0, u.U)("account", "PARENT_ACCOUNT_CURRENCY")), window.refreshWhenLoggedIn && (window.mustRefreshForSessionVisibility = !0, window.location.reload()), A.Ay.IFRAME_SPORTSBOOK && (0, g.$i)("loggedOut"), A.Ay.WRAPPER_APP && null !== (s = window.median) && void 0 !== s && s.auth && window.median.auth.delete()
                    })(s)), {
                        fcm_token: p || void 0,
                        ...e
                    })
                }
            }
        },
        115837: (e, n, t) => {
            t.d(n, {
                Q: () => _
            });
            var s = t(507712),
                i = t(117893),
                o = t(464418),
                a = t(365043),
                r = t(841591),
                d = t(626038),
                l = t(123213),
                c = t(556785),
                u = t(179177);
            const _ = () => {
                const e = (0, s.wA)(),
                    n = (0, s.d4)(r.gh),
                    t = (0, d.N)(),
                    _ = (0, a.useCallback)((s => {
                        const a = l.A.getItem((0, c.U)("account", "SWITCH_MULTI_ACCOUNT"));
                        l.A.removeItem((0, c.U)("account", "SWITCH_MULTI_ACCOUNT")), s.logout && !JSON.parse(a) ? (+(null === n || void 0 === n ? void 0 : n.singleSignIn) || u.Ay.IS_MULTI_ACCOUNT_DISABLED) && t(!0) : (e((0, i.b6U)(s)), s.super_bet && (e((0, i.$5h)(s.super_bet)), e((0, o.wF)())))
                    }), [null === n || void 0 === n ? void 0 : n.singleSignIn]);
                return (0, a.useMemo)((() => ({
                    updateUser: _
                })), [_])
            }
        },
        393738: (e, n, t) => {
            t.d(n, {
                h: () => u,
                p: () => _
            });
            var s = t(365043),
                i = t(507712),
                o = t(446987),
                a = t(464418),
                r = t(679559),
                d = t(423400),
                l = t(123213),
                c = t(737536);
            const u = e => {
                    (0, o.sd)({
                        command: c.y.MARK_AS_READ_NOTIFICATION,
                        params: {
                            notification_id: e
                        },
                        rid: d.A.gForCommand()
                    }, null)
                },
                _ = () => {
                    const e = (0, i.d4)(r.eP),
                        n = (0, i.d4)(r.wz),
                        t = (0, i.wA)(),
                        c = d.A.gForSubscribe(),
                        [_, A] = (0, s.useState)(!1);
                    (0, s.useEffect)((() => {
                        e && !_ && (0, o.Jv)((e => {
                            A(!0), (e => {
                                if (window.refreshWhenLoggedIn && window.mustRefreshForSessionVisibility) return !1;
                                const t = [];
                                let s = !1;
                                const i = {
                                    1: "is",
                                    2: "isNot",
                                    3: "startsWith",
                                    4: "endsWith",
                                    5: "contains",
                                    6: "doesNotContains"
                                };
                                for (const A in e) {
                                    var o;
                                    const c = {};
                                    if (e[A].ClientId === n.id && e[A].Id && (null === (o = e[A].Page) || void 0 === o || !o.Value)) {
                                        var a;
                                        let n = l.A.getItem("openedPopupsListByLanguage");
                                        const t = null === (a = window.currentLanguageObject) || void 0 === a ? void 0 : a.id;
                                        if (n = n ? JSON.parse(n) : {}, !(n && t && n[t] && n[t].length && n[t].indexOf(e[A].Id) + 1)) {
                                            var r, d;
                                            null === (r = (d = window).openPopup) || void 0 === r || r.call(d, e[A].Alias), u(+A), s = !0;
                                            break
                                        }
                                        s = !1
                                    }
                                    e[A].ClientId === n.id && e[A].Id && e[A].Page.Comparison && e[A].Page.Value && (c.triggeringUrlValue = e[A].Page.Value, c.triggeringUrlRule = i[e[A].Page.Comparison], c.alias = e[A].Alias, c.id = e[A].Id, c.enableTriggeringRule = 1, c.triggeringTime = 0, c.key = +A, t.push(c))
                                }
                                var c, _;
                                s || !t.length || window.triggeringRuleIsWorked || (window.popupTriggeringRules = t, null === (c = (_ = window).popupTriggering) || void 0 === c || c.call(_, !0))
                            })(e)
                        }), (e => {
                            if (e && e.cashout) {
                                const n = Object.keys(e.cashout).map((n => ({
                                    id: +n,
                                    amount: e.cashout[n].amount
                                })));
                                t((0, a.wZ)(n))
                            }
                        }), c)
                    }), [e])
                }
        },
        930911: (e, n, t) => {
            t.d(n, {
                b: () => u
            });
            var s = t(140854),
                i = t.n(s),
                o = t(664833),
                a = t(179177),
                r = t(224272),
                d = t(55418),
                l = t(320308),
                c = t(457250);
            const u = function(e) {
                let n, t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
                    s = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
                    u = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
                if (u) n = {
                    partnerId: a.Ay.DECENTRALIZED_CASINO_PARTNER_ID,
                    gameId: e[0]
                };
                else if (n = {
                        partner_id: a.Ay.PARTNER_ID,
                        is_mobile: Number((0, d.F)()),
                        lang: c.Ic,
                        by_key: o.d.Id,
                        use_webp: Number(a.Ay.IS_WEBP_SUPPORTED)
                    }, s && null !== e && void 0 !== e && e.length) n.external_id = e;
                else if (1 === (null === e || void 0 === e ? void 0 : e.length)) n.id = e[0];
                else {
                    if (!((null === e || void 0 === e ? void 0 : e.length) > 1)) return new Promise((e => e([])));
                    n.external_id = e
                }
                const _ = null !== a.Ay && void 0 !== a.Ay && a.Ay.DECENTRALIZED_CASINO_URL ? `${a.Ay.DECENTRALIZED_CASINO_URL}${r.j.GET_DECENTRALIZED_GAME}` : `${a.Ay.CASINO_URL}/${r.j.GET_GAMES}`;
                return i().get(_, {
                    params: n
                }).then((e => 200 === e.status && e.data && ("ok" === e.data.status || u) ? u ? [{
                    extearnal_game_id: e.data.externalGameId,
                    types: {
                        realMode: 0,
                        funMode: 0
                    },
                    icon_1: e.data.icon1,
                    icon_2: e.data.icon2,
                    icon_3: e.data.icon3,
                    provider: "ALL",
                    provider_badge: null,
                    provider_title: "ALL",
                    show_as_provider: "ALL",
                    cats: e.data.categories,
                    ...e.data
                }] : Object.values(e.data.games) : (t && (0, l.$)(e.statusText), []))).catch((e => (t && (0, l.$)(e.toString()), [])))
            }
        },
        954947: (e, n, t) => {
            t.d(n, {
                A: () => o
            });
            var s = t(446987),
                i = t(291372);
            const o = () => {
                const e = i.A.getState().appData.fireBaseToken;
                e && (0, s.NQ)(e)
            }
        },
        302258: (e, n, t) => {
            t.d(n, {
                Av: () => l,
                J3: () => r,
                as: () => c,
                ki: () => d
            });
            var s = t(860446),
                i = t.n(s),
                o = t(123213),
                a = t(556785);
            const r = e => (null !== e.first_name && null !== e.last_name ? `${e.first_name} ${e.last_name}` : e.username) || "",
                d = e => r(e).substr(0, 2).toUpperCase(),
                l = ["bonuses", "messages"],
                c = () => o.A.setItem((0, a.U)("account", "LOGIN_LIMIT_POPUP_START_TIME"), String(i()().unix()))
        }
    }
]);
//# sourceMappingURL=generic.bac98dcd.chunk.js.map