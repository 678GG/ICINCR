import { createSelector } from 'reselect';

import { getSelectorRoot } from 'utils/selectors';

const getBetSlip = getSelectorRoot('betSlip');

export const getSubscriptions = getBetSlip('subscriptions');
export const getQuickBetEnabled = getBetSlip('quickBetEnabled');
export const getQuickBetPopup = getBetSlip('quickBetPopup');
export const getQuickBetStake = getBetSlip('quickBetStake');
export const getBettedTrigger = getBetSlip('bettedTrigger');
export const getUpdateOpenBetsTrigger = getBetSlip('updateOpenBetsTrigger');
export const getUpdatedBetTickets = getBetSlip('updatedBetTickets');
export const getLadderLoaded = getBetSlip('ladderLoaded');
export const getOddFormat = getBetSlip('oddFormat');
export const getBetslipType = getBetSlip('betslipType');
export const getType = getBetSlip('type');
export const getAllLsBets = getBetSlip('allLsBets');
export const getStakes = getBetSlip('stakes');
export const getOddsOffers = getBetSlip('oddsOffers');
export const getInProgress = getBetSlip('inProgress');
export const getSelected = getBetSlip('selected');
export const getSelectedOddOffer = getBetSlip('selectedOddOffer');
export const getSelectedType = getBetSlip('selectedType');
export const getSystem = getBetSlip('system');
export const getMustOpen = getBetSlip('mustOpen');
export const getMustClose = getBetSlip('mustClose');
export const getPredefinedStakes = getBetSlip('predefinedStakes');
export const getBetTypesConf = getBetSlip('betTypesConf');
export const getSelectedBetType = getBetSlip('selectedBetType');
export const getTotalOddsReturn = getBetSlip('totalOddsReturn');
export const getTotalBetStake = getBetSlip('totalBetStake');
export const getSuperBets = getBetSlip('superBets');
export const getSentCounterOffersCount = getBetSlip('sentCounterOffersCount');
export const getSentSuperBetCount = getBetSlip('sentSuperBetCount');
export const getEditBet = getBetSlip('editBet');
export const getCashoutFrom = getBetSlip('cashoutFrom');
export const getConflictingGameIds = getBetSlip('conflictingGameIds');
export const getActiveTabPage = getBetSlip('activeTabPage');
export const getFreezeTabChange = getBetSlip('freezeTabChange');
export const getSportBonuses = getBetSlip('sportBonuses');
export const getUseBonusBalance = getBetSlip('useBonusBalance');
export const getBetslipOpen = getBetSlip('betslipOpen');
export const getQuickSingleBetslipOpen = getBetSlip('singleQuickBetslipOpen');
export const getActiveMarketOdd = getBetSlip('activeMarketOdd');
export const getTicketsChanged = getBetSlip('ticketsChanged');
export const getSingleReturn = getBetSlip('singleReturn');
export const getIsCalculating = getBetSlip('isCalculating');
export const getCalculationLoading = getBetSlip('calculationLoading');
export const getSubscribedEvents = getBetSlip('subscribedEvents');
export const getOpenBetsCount = getBetSlip('openBetsCount');
export const getQuickBetInProcessCount = getBetSlip('quickBetInProcessCount');
export const getOpenBetsCountAfterCashout = getBetSlip(
  'openBetsCountAfterCashout'
);
export const getOpenBetsData = getBetSlip('openBetsData');
export const getOpenBetsLoading = getBetSlip('openBetsLoading');
export const getTabs = getBetSlip('tabs');
export const getCashoutTicket = getBetSlip('cashoutTicket');
export const getBookBetId = getBetSlip('bookBetId');
export const getTaxAmounRanges = getBetSlip('taxAmountRanges');
export const getBasicEw = getBetSlip('basicEw');
export const getProfitBoost = getBetSlip('profitBoost');
export const getProfitBoostAdvanced = getBetSlip('profitBoostAdvanced');
export const getFreeBets = getBetSlip('freeBets');
const getEventPrevOdds = getBetSlip('eventsPrevOdds');
export const getCurrentStake = getBetSlip('currentStake');
export const getMaxStakeLoading = getBetSlip('maxStakeLoading');
export const getTotalStake = getBetSlip('totalStake');
export const getTotalSingleWin = getBetSlip('totalSingleWin');
export const getAdvancedSelectedTab = getBetSlip('advancedSelectedTab');
export const getCounterOffers = getBetSlip('counterOffers');
export const getIsAccumulatorBonusCalculating = getBetSlip(
  'isAccumulatorBonusCalculating'
);
export const getBetsTotalOdds = getBetSlip('betsTotalOdds');

export const getEventIds = createSelector([getSubscriptions], subscriptions =>
  subscriptions.map(subscription => subscription.eventId)
);

export const getEventPrevOddById = (eventId: number) =>
  createSelector([getEventPrevOdds], prevOdds => prevOdds[eventId]);
