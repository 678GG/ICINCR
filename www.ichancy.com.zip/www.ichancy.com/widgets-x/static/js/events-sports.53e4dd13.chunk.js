"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [89136], {
        84541: (d, e, l) => {
            l.r(e), l.d(e, {
                Sports: () => M
            });
            var o = l(365043),
                i = l(507712),
                u = l(218660),
                t = l(685527),
                n = l(133230),
                v = l(608407),
                s = l(390648),
                r = l(927012),
                c = l(504647),
                m = l(335232),
                I = l(724131),
                a = l(490440),
                f = l(423400),
                p = l(482463),
                h = l(179177),
                b = l(256694),
                A = l(950694),
                E = l(570579);
            const _ = {},
                M = (0, o.memo)((() => {
                    var d, e;
                    const [l, M] = (0, o.useState)(!0), T = (0, b.A)(), k = (0, i.wA)(), C = (0, i.d4)(u.Vt)[(null === T || void 0 === T ? void 0 : T.moduleId) || ""], O = null === (d = (0, i.d4)(u.e)[(null === T || void 0 === T ? void 0 : T.moduleId) || ""]) || void 0 === d ? void 0 : d[C], S = null === (e = (0, i.d4)(u.wR)[(null === T || void 0 === T ? void 0 : T.moduleId) || ""]) || void 0 === e ? void 0 : e[C], g = (0, i.d4)(u.KI)[(null === T || void 0 === T ? void 0 : T.moduleId) || ""], w = (0, i.d4)(s.$P), {
                        mounted: H
                    } = (0, a.q)(), j = g || +((null === T || void 0 === T ? void 0 : T.defaultEventsMinutes) || 0) || n.hA.HALF_HOUR;
                    return (0, o.useEffect)((() => {
                        if (h.Ay.MOCKED_DATA) return void k((0, t.eM)({
                            [(null === T || void 0 === T ? void 0 : T.moduleId) || ""]: {
                                [C]: (0, p.I)(Object.values(m.e))
                            }
                        }));
                        if (C === n.s8.BOOSTED && !w) return;
                        if (_[(null === T || void 0 === T ? void 0 : T.moduleId) || ""]) return;
                        const d = f.A.gForSubscribe("sports"),
                            e = (d, e) => {
                                if (!H.current) return;
                                const o = Object.values(d.sport || {}),
                                    i = C === n.s8.PREMATCH;
                                if (l && !o.length && i || !e && i && !o.length) {
                                    M(!1);
                                    const d = A.HC.findIndex((d => d === j)) + 1;
                                    if (M(!!d), d) return void k((0, t.Mz)({
                                        [(null === T || void 0 === T ? void 0 : T.moduleId) || ""]: A.HC[d]
                                    }));
                                    M(!1)
                                }
                                M(!i), i || k((0, t.eM)({
                                    [(null === T || void 0 === T ? void 0 : T.moduleId) || ""]: {
                                        prematch: void 0
                                    }
                                })), k((0, t.eM)({
                                    [(null === T || void 0 === T ? void 0 : T.moduleId) || ""]: {
                                        [C]: (0, p.I)(o)
                                    }
                                })), e && (_[(null === T || void 0 === T ? void 0 : T.moduleId) || ""] = !0)
                            };
                        return (0, c.RS)(d, I.q1, (0, v.TT)({
                            sport: null,
                            selectedEventsType: C,
                            activeTimeFilter: j,
                            boostedGameIds: w
                        }), (d => e(d, !0)), !0, (d => e(d, !1))), () => {
                            (0, c.lx)(d)
                        }
                    }), [C, w, j]), (0, o.useEffect)((() => {
                        C && O && (!S && O.length || !O.some((d => {
                            let {
                                id: e
                            } = d;
                            return e === (null === S || void 0 === S ? void 0 : S.id)
                        }))) && k((0, t.cl)({
                            [(null === T || void 0 === T ? void 0 : T.moduleId) || ""]: {
                                [C]: O[0]
                            }
                        }))
                    }), [C, S, O, j]), (0, o.useEffect)((() => () => {
                        _[(null === T || void 0 === T ? void 0 : T.moduleId) || ""] = !1
                    }), [C, j]), O && !O.length ? null : (0, E.jsx)("div", {
                        className: "events-wrapper__sports",
                        children: (0, E.jsx)(r.W, {
                            layout: "fill",
                            items: O || null,
                            selectedItem: S,
                            onSelectItem: d => {
                                d.alias !== (null === S || void 0 === S ? void 0 : S.alias) && k((0, t.cl)({
                                    [(null === T || void 0 === T ? void 0 : T.moduleId) || ""]: {
                                        [C]: d
                                    }
                                }))
                            }
                        })
                    })
                }))
        }
    }
]);
//# sourceMappingURL=events-sports.53e4dd13.chunk.js.map