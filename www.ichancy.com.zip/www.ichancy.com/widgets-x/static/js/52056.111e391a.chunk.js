"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [52056], {
        329675: (e, s, t) => {
            t.d(s, {
                BH: () => l,
                Dc: () => n,
                SP: () => g,
                hO: () => C,
                iU: () => d,
                jZ: () => p,
                ld: () => i,
                oC: () => v,
                py: () => c,
                xx: () => u
            });
            var o = t(280192);
            const r = (0, t(534977).g)("newCasinoStore"),
                a = r("categories"),
                i = (0, o.Mz)([a], (e => e.original)),
                n = (0, o.Mz)([a], (e => e.custom)),
                c = (0, o.Mz)([a], (e => e.originalSet)),
                d = (0, o.Mz)([a], (e => e.originalSetLeftSideBar)),
                g = r("providers"),
                u = (r("casinoCategoriesProviderIds"), r("providersInIntersection"), r("currentGame")),
                l = r("canRequestCategoriesNestedData"),
                p = r("canRequestProvidersNestedData"),
                C = r("lastPlayedCatSettings"),
                v = r("categoryCustomIds")
        }
    }
]);
//# sourceMappingURL=52056.111e391a.chunk.js.map