"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [85925], {
        785925: (e, t, r) => {
            r.r(t), r.d(t, {
                default: () => f
            });
            var l, a, n, i = r(365043);

            function C() {
                return C = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = arguments[t];
                        for (var l in r) Object.prototype.hasOwnProperty.call(r, l) && (e[l] = r[l])
                    }
                    return e
                }, C.apply(this, arguments)
            }

            function o(e, t) {
                let {
                    title: r,
                    titleId: o,
                    ...c
                } = e;
                return i.createElement("svg", C({
                    width: 32,
                    height: 32,
                    viewBox: "0 0 32 32",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    ref: t,
                    "aria-labelledby": o
                }, c), r ? i.createElement("title", {
                    id: o
                }, r) : null, l || (l = i.createElement("circle", {
                    cx: 16,
                    cy: 16,
                    r: 16,
                    fill: "#EE940D"
                })), a || (a = i.createElement("g", {
                    filter: "url(#filter0_d_226_2518)"
                }, i.createElement("path", {
                    d: "M23.9471 18.9105C24.0531 18.6088 24.1407 18.3009 24.2096 17.9886C24.3601 17.3032 24.4179 16.6007 24.3814 15.8999C24.3138 14.6334 23.9622 13.4521 23.3189 12.3594C22.6109 11.1567 21.6506 10.2085 20.438 9.51472C19.7949 9.14432 19.1006 8.87099 18.3775 8.70358C18.3262 8.69175 18.304 8.67434 18.3042 8.61446C18.3073 8.06952 18.3073 7.52459 18.3042 6.97965C18.3042 6.91977 18.3191 6.90817 18.3761 6.91931C19.9406 7.22914 21.3468 7.88061 22.585 8.88554C24.5425 10.4675 25.7967 12.758 26.0751 15.2593C26.1551 15.974 26.1523 16.6955 26.0668 17.4096C26.0082 17.8979 25.9135 18.3812 25.7834 18.8555C25.7732 18.8935 25.7639 18.9195 25.7119 18.9193C25.1317 18.917 24.5515 18.9177 23.9727 18.9174C23.964 18.9158 23.9555 18.9134 23.9471 18.9105Z",
                    fill: "white"
                }), i.createElement("path", {
                    d: "M8.73138 21.7799C7.6059 20.1798 7.00129 18.2716 7 16.3154C6.99871 14.3592 7.60081 12.4501 8.72419 10.8486C8.74252 10.9097 8.75065 21.5789 8.73138 21.7799Z",
                    fill: "white"
                }), i.createElement("path", {
                    d: "M26.9939 20.6563H26.8899C23.4838 20.6563 20.0778 20.6571 16.6719 20.6586C16.5791 20.6586 16.5628 20.6324 16.5628 20.5456C16.5651 15.3974 16.5665 10.2493 16.567 5.10119C16.567 5.01578 16.5456 5 16.4637 5C13.696 5.00232 10.9283 5.00302 8.16061 5.00209H8.06546C8.06546 5.03876 8.08867 5.05918 8.10306 5.08262C8.87668 6.3396 9.65029 7.59619 10.4239 8.85239C10.4605 8.91048 10.4794 8.97799 10.4782 9.04665C10.4768 13.2961 10.4768 17.5456 10.4782 21.7951C10.4796 21.8778 10.4553 21.9589 10.4086 22.0272C9.58392 23.2857 8.76048 24.5456 7.93827 25.8067C7.92574 25.8258 7.89743 25.8415 7.91158 25.874H13.234C16.4776 25.874 19.7213 25.874 22.9649 25.874C23.0157 25.874 23.054 25.868 23.0898 25.8209C24.3854 24.114 25.6822 22.4074 26.9802 20.7013C26.9895 20.689 27.0106 20.679 26.9939 20.6563ZM22.2232 24.0912C22.1907 24.1343 22.1535 24.1346 22.1106 24.1343H11.1204C11.1487 24.0598 11.1958 24.002 11.2364 23.941C11.5512 23.4564 11.8669 22.9727 12.1838 22.4898C12.2077 22.454 12.2201 22.4118 12.2191 22.3688C12.2191 17.7513 12.2191 13.1337 12.2191 8.5161C12.2193 8.4731 12.2068 8.43099 12.1834 8.39495C11.86 7.87152 11.5375 7.3477 11.2158 6.8235C11.2012 6.80029 11.1872 6.77569 11.1666 6.74088H11.2624C12.419 6.74088 13.5756 6.74018 14.7321 6.73879C14.8124 6.73879 14.8289 6.76014 14.8289 6.83742C14.827 11.9883 14.8258 17.1393 14.8252 22.2902C14.8252 22.3763 14.8433 22.3974 14.9313 22.3974C17.7547 22.3946 20.5784 22.3938 23.4024 22.3951H23.5117C23.0749 22.9681 22.6476 23.529 22.2232 24.0918V24.0912Z",
                    fill: "white"
                }))), n || (n = i.createElement("defs", null, i.createElement("filter", {
                    id: "filter0_d_226_2518",
                    x: 3,
                    y: 5,
                    width: 28.0002,
                    height: 28.874,
                    filterUnits: "userSpaceOnUse",
                    colorInterpolationFilters: "sRGB"
                }, i.createElement("feFlood", {
                    floodOpacity: 0,
                    result: "BackgroundImageFix"
                }), i.createElement("feColorMatrix", { in: "SourceAlpha",
                    type: "matrix",
                    values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",
                    result: "hardAlpha"
                }), i.createElement("feOffset", {
                    dy: 4
                }), i.createElement("feGaussianBlur", {
                    stdDeviation: 2
                }), i.createElement("feComposite", {
                    in2: "hardAlpha",
                    operator: "out"
                }), i.createElement("feColorMatrix", {
                    type: "matrix",
                    values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.04 0"
                }), i.createElement("feBlend", {
                    mode: "normal",
                    in2: "BackgroundImageFix",
                    result: "effect1_dropShadow_226_2518"
                }), i.createElement("feBlend", {
                    mode: "normal",
                    in: "SourceGraphic",
                    in2: "effect1_dropShadow_226_2518",
                    result: "shape"
                })))))
            }
            const c = i.forwardRef(o),
                f = (r.p, c)
        }
    }
]);
//# sourceMappingURL=85925.b94180e6.chunk.js.map