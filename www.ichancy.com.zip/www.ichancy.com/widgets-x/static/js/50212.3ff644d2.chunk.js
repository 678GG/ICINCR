"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [50212], {
        350212: (t, e, r) => {
            r.r(e), r.d(e, {
                default: () => i
            });
            var n, l = r(365043);

            function a() {
                return a = Object.assign ? Object.assign.bind() : function(t) {
                    for (var e = 1; e < arguments.length; e++) {
                        var r = arguments[e];
                        for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (t[n] = r[n])
                    }
                    return t
                }, a.apply(this, arguments)
            }

            function o(t, e) {
                let {
                    title: r,
                    titleId: o,
                    ...s
                } = t;
                return l.createElement("svg", a({
                    xmlns: "http://www.w3.org/2000/svg",
                    width: 32,
                    height: 32,
                    viewBox: "0 0 32 32",
                    fill: "currentColor",
                    ref: e,
                    "aria-labelledby": o
                }, s), r ? l.createElement("title", {
                    id: o
                }, r) : null, n || (n = l.createElement("path", {
                    d: "M29.3346 13.4663C29.468 12.7996 28.9346 11.9996 28.268 11.9996L20.668 10.9329L17.2013 3.99959C17.068 3.73293 16.9346 3.59959 16.668 3.46626C16.0013 3.06626 15.2013 3.33293 14.8013 3.99959L11.468 10.9329L3.86797 11.9996C3.46797 11.9996 3.2013 12.1329 3.06797 12.3996C2.53464 12.9329 2.53464 13.7329 3.06797 14.2663L8.53464 19.5996L7.2013 27.1996C7.2013 27.4663 7.2013 27.7329 7.33464 27.9996C7.73464 28.6663 8.53464 28.9329 9.2013 28.5329L16.0013 24.9329L22.8013 28.5329C22.9346 28.6663 23.2013 28.6663 23.468 28.6663C23.6013 28.6663 23.6013 28.6663 23.7346 28.6663C24.4013 28.5329 24.9346 27.8663 24.8013 27.0663L23.468 19.4663L28.9346 14.1329C29.2013 13.9996 29.3346 13.7329 29.3346 13.4663Z"
                })))
            }
            const s = l.forwardRef(o),
                i = (r.p, s)
        }
    }
]);
//# sourceMappingURL=50212.3ff644d2.chunk.js.map