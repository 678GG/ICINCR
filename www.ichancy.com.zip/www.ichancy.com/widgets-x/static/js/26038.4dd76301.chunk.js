"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [26038], {
        626038: (e, o, n) => {
            n.d(o, {
                N: () => m
            });
            var t = n(507712),
                s = n(995392),
                i = n(307022),
                r = n(841591),
                I = n(446987),
                _ = n(93907),
                u = n(816343),
                c = n(123213),
                A = n(556785),
                a = n(238605),
                d = n(179177),
                l = n(849944);
            const m = e => {
                const o = (0, t.wA)(),
                    n = (0, s.W6)(),
                    m = (0, t.d4)(r.V7);
                return t => {
                    (0, I.ri)((() => (e => {
                        var t;
                        e && n.push((0, u.XZ)()), o((0, i.Sl)()), o((0, i.XO)(null)), o((0, _.sV)({})), c.A.removeItem((0, A.U)("account", "LOGIN_LIMIT_START_TIME")), c.A.removeItem((0, A.U)("account", "LOGIN_LIMIT_POPUP_START_TIME")), c.A.removeItem((0, A.U)("account", "IS_LOGOUT")), (0, a.Yj)("sbuser"), (0, a.Yj)("loginCredentials"), c.A.removeItem((0, A.U)("account", "ADDITIONAL_INFO_POPUP")), c.A.removeItem((0, A.U)("account", "PARENT_ACCOUNT_CURRENCY")), window.refreshWhenLoggedIn && (window.mustRefreshForSessionVisibility = !0, window.location.reload()), d.Ay.IFRAME_SPORTSBOOK && (0, l.$i)("loggedOut"), d.Ay.WRAPPER_APP && null !== (t = window.median) && void 0 !== t && t.auth && window.median.auth.delete()
                    })(t)), {
                        fcm_token: m || void 0,
                        ...e
                    })
                }
            }
        }
    }
]);
//# sourceMappingURL=26038.4dd76301.chunk.js.map