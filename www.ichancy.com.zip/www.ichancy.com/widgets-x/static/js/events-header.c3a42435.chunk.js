"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [26158], {
        615911: (e, s, l) => {
            l.r(s), l.d(s, {
                Header: () => k
            });
            var d = l(365043),
                i = l(133230),
                o = l(507712),
                r = l(218660),
                a = l(608407),
                n = l(870905),
                t = l(80489),
                v = l(256694),
                p = l(735905),
                c = l(55418),
                u = l(902546),
                h = l(989618),
                _ = l(450431),
                m = l(570579);
            const {
                EventsTimeFilterDesktop: b
            } = (0, h.R)((() => Promise.all([l.e(22093), l.e(31139), l.e(31528), l.e(36273), l.e(60503), l.e(1162), l.e(96282)]).then(l.bind(l, 785843)))), k = (0, d.memo)((() => {
                var e;
                const {
                    t: s
                } = (0, n.B)(), l = (0, v.A)(), h = (0, o.d4)(r.Vt)[(null === l || void 0 === l ? void 0 : l.moduleId) || ""], k = null === (e = (0, o.d4)(r.wR)[(null === l || void 0 === l ? void 0 : l.moduleId) || ""]) || void 0 === e ? void 0 : e[h], w = (0, d.useCallback)((() => {
                    (0, u.C)(h, void 0, void 0, void 0, h === i.s8.BOOSTED ? "boostedOdds" : (null === k || void 0 === k ? void 0 : k.alias) || "")
                }), [h, null === k || void 0 === k ? void 0 : k.alias]), x = !(null === l || void 0 === l || !l.defaultEventsMinutes) && h === i.s8.PREMATCH && !(0, c.F)();
                return (0, m.jsxs)("div", {
                    className: (null !== l && void 0 !== l && l.showAllSportsWithSlid ? "events-wrapper__header-slider" : "") + " events-wrapper__header",
                    children: [(0, m.jsxs)("div", {
                        className: "events-wrapper__header--title",
                        children: [(null === l || void 0 === l ? void 0 : l.type) === i.s8.LIVE && (0, m.jsx)(p.GlobalIcon, {
                            lib: "generic",
                            size: 8,
                            name: "dot",
                            theme: "default",
                            className: "events-wrapper__header--title--icon"
                        }), (0, a.xO)(h)]
                    }), (0, m.jsxs)("div", {
                        className: "events-wrapper__header--right-bar",
                        children: [x && (0, m.jsx)(d.Suspense, {
                            fallback: (0, m.jsx)(_.d, {}),
                            children: (0, m.jsx)(b, {})
                        }), (0, m.jsx)(t.$, {
                            onClick: w,
                            type: "linkPrimary",
                            children: s("sportsbook.seeAll")
                        })]
                    })]
                })
            }))
        }
    }
]);
//# sourceMappingURL=events-header.c3a42435.chunk.js.map