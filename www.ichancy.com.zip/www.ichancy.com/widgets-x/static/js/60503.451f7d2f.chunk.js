"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [60503], {
        259993: (e, t) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            t.default = {
                icon: {
                    tag: "svg",
                    attrs: {
                        viewBox: "64 64 896 896",
                        focusable: "false"
                    },
                    children: [{
                        tag: "path",
                        attrs: {
                            d: "M765.7 486.8L314.9 134.7A7.97 7.97 0 00302 141v77.3c0 4.9 2.3 9.6 6.1 12.6l360 281.1-360 281.1c-3.9 3-6.1 7.7-6.1 12.6V883c0 6.7 7.7 10.4 12.9 6.3l450.8-352.1a31.96 31.96 0 000-50.4z"
                        }
                    }]
                },
                name: "right",
                theme: "outlined"
            }
        },
        360503: (e, t, r) => {
            var a;
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var u = (a = r(915878)) && a.__esModule ? a : {
                default: a
            };
            t.default = u, e.exports = u
        },
        915878: (e, t, r) => {
            var a = r(245288),
                u = r(310684);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = a(r(601459)),
                n = function(e, t) {
                    if (!t && e && e.__esModule) return e;
                    if (null === e || "object" != u(e) && "function" != typeof e) return {
                        default: e
                    };
                    var r = c(t);
                    if (r && r.has(e)) return r.get(e);
                    var a = {
                            __proto__: null
                        },
                        o = Object.defineProperty && Object.getOwnPropertyDescriptor;
                    for (var n in e)
                        if ("default" !== n && Object.prototype.hasOwnProperty.call(e, n)) {
                            var l = o ? Object.getOwnPropertyDescriptor(e, n) : null;
                            l && (l.get || l.set) ? Object.defineProperty(a, n, l) : a[n] = e[n]
                        }
                    return a.default = e, r && r.set(e, a), a
                }(r(365043)),
                l = a(r(259993)),
                f = a(r(942740));

            function c(e) {
                if ("function" != typeof WeakMap) return null;
                var t = new WeakMap,
                    r = new WeakMap;
                return (c = function(e) {
                    return e ? r : t
                })(e)
            }
            var d = function(e, t) {
                    return n.createElement(f.default, (0, o.default)((0, o.default)({}, e), {}, {
                        ref: t,
                        icon: l.default
                    }))
                },
                i = n.forwardRef(d);
            t.default = i
        }
    }
]);
//# sourceMappingURL=60503.451f7d2f.chunk.js.map