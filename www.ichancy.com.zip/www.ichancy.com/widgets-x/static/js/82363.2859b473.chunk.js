"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [82363], {
        442451: (e, t, r) => {
            var n = r(50130),
                o = r(487066);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = n(r(319290)),
                l = n(r(329085)),
                u = function(e, t) {
                    if (!t && e && e.__esModule) return e;
                    if (null === e || "object" !== o(e) && "function" !== typeof e) return {
                        default: e
                    };
                    var r = i(t);
                    if (r && r.has(e)) return r.get(e);
                    var n = {},
                        a = Object.defineProperty && Object.getOwnPropertyDescriptor;
                    for (var l in e)
                        if ("default" !== l && Object.prototype.hasOwnProperty.call(e, l)) {
                            var u = a ? Object.getOwnPropertyDescriptor(e, l) : null;
                            u && (u.get || u.set) ? Object.defineProperty(n, l, u) : n[l] = e[l]
                        }
                    n.default = e, r && r.set(e, n);
                    return n
                }(r(365043)),
                c = n(r(498139)),
                s = r(445600),
                f = r(144138);

            function i(e) {
                if ("function" !== typeof WeakMap) return null;
                var t = new WeakMap,
                    r = new WeakMap;
                return (i = function(e) {
                    return e ? r : t
                })(e)
            }
            var d = function(e) {
                var t, r = e.className,
                    n = e.prefixCls,
                    o = e.style,
                    i = e.color,
                    d = e.children,
                    p = e.text,
                    v = e.placement,
                    m = void 0 === v ? "end" : v,
                    y = u.useContext(s.ConfigContext),
                    b = y.getPrefixCls,
                    O = y.direction,
                    P = b("ribbon", n),
                    w = (0, f.isPresetColor)(i),
                    g = (0, c.default)(P, "".concat(P, "-placement-").concat(m), (t = {}, (0, l.default)(t, "".concat(P, "-rtl"), "rtl" === O), (0, l.default)(t, "".concat(P, "-color-").concat(i), w), t), r),
                    C = {},
                    j = {};
                return i && !w && (C.background = i, j.color = i), u.createElement("div", {
                    className: "".concat(P, "-wrapper")
                }, d, u.createElement("div", {
                    className: g,
                    style: (0, a.default)((0, a.default)({}, C), o)
                }, u.createElement("span", {
                    className: "".concat(P, "-text")
                }, p), u.createElement("div", {
                    className: "".concat(P, "-corner"),
                    style: j
                })))
            };
            t.default = d
        },
        291151: (e, t, r) => {
            var n = r(50130),
                o = r(487066);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = n(r(319290)),
                l = function(e, t) {
                    if (!t && e && e.__esModule) return e;
                    if (null === e || "object" !== o(e) && "function" !== typeof e) return {
                        default: e
                    };
                    var r = i(t);
                    if (r && r.has(e)) return r.get(e);
                    var n = {},
                        a = Object.defineProperty && Object.getOwnPropertyDescriptor;
                    for (var l in e)
                        if ("default" !== l && Object.prototype.hasOwnProperty.call(e, l)) {
                            var u = a ? Object.getOwnPropertyDescriptor(e, l) : null;
                            u && (u.get || u.set) ? Object.defineProperty(n, l, u) : n[l] = e[l]
                        }
                    n.default = e, r && r.set(e, n);
                    return n
                }(r(365043)),
                u = n(r(498139)),
                c = r(445600),
                s = r(853590),
                f = n(r(615114));

            function i(e) {
                if ("function" !== typeof WeakMap) return null;
                var t = new WeakMap,
                    r = new WeakMap;
                return (i = function(e) {
                    return e ? r : t
                })(e)
            }
            var d = function(e, t) {
                    var r = {};
                    for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && t.indexOf(n) < 0 && (r[n] = e[n]);
                    if (null != e && "function" === typeof Object.getOwnPropertySymbols) {
                        var o = 0;
                        for (n = Object.getOwnPropertySymbols(e); o < n.length; o++) t.indexOf(n[o]) < 0 && Object.prototype.propertyIsEnumerable.call(e, n[o]) && (r[n[o]] = e[n[o]])
                    }
                    return r
                },
                p = function(e) {
                    var t = e.prefixCls,
                        r = e.count,
                        n = e.className,
                        o = e.motionClassName,
                        i = e.style,
                        p = e.title,
                        v = e.show,
                        m = e.component,
                        y = void 0 === m ? "sup" : m,
                        b = e.children,
                        O = d(e, ["prefixCls", "count", "className", "motionClassName", "style", "title", "show", "component", "children"]),
                        P = (0, l.useContext(c.ConfigContext).getPrefixCls)("scroll-number", t),
                        w = (0, a.default)((0, a.default)({}, O), {
                            "data-show": v,
                            style: i,
                            className: (0, u.default)(P, n, o),
                            title: p
                        }),
                        g = r;
                    if (r && Number(r) % 1 === 0) {
                        var C = String(r).split("");
                        g = C.map((function(e, t) {
                            return l.createElement(f.default, {
                                prefixCls: P,
                                count: Number(r),
                                value: e,
                                key: C.length - t
                            })
                        }))
                    }
                    return i && i.borderColor && (w.style = (0, a.default)((0, a.default)({}, i), {
                        boxShadow: "0 0 0 1px ".concat(i.borderColor, " inset")
                    })), b ? (0, s.cloneElement)(b, (function(e) {
                        return {
                            className: (0, u.default)("".concat(P, "-custom-component"), null === e || void 0 === e ? void 0 : e.className, o)
                        }
                    })) : l.createElement(y, w, g)
                };
            t.default = p
        },
        615114: (e, t, r) => {
            var n = r(50130),
                o = r(487066);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                var t, r, n = e.prefixCls,
                    o = e.count,
                    c = e.value,
                    s = Number(c),
                    d = Math.abs(o),
                    p = u.useState(s),
                    v = (0, l.default)(p, 2),
                    m = v[0],
                    y = v[1],
                    b = u.useState(d),
                    O = (0, l.default)(b, 2),
                    P = O[0],
                    w = O[1],
                    g = function() {
                        y(s), w(d)
                    };
                if (u.useEffect((function() {
                        var e = setTimeout((function() {
                            g()
                        }), 1e3);
                        return function() {
                            clearTimeout(e)
                        }
                    }), [s]), m === s || Number.isNaN(s) || Number.isNaN(m)) t = [u.createElement(f, (0, a.default)({}, e, {
                    key: s,
                    current: !0
                }))], r = {
                    transition: "none"
                };
                else {
                    t = [];
                    for (var C = s + 10, j = [], N = s; N <= C; N += 1) j.push(N);
                    var x = j.findIndex((function(e) {
                        return e % 10 === m
                    }));
                    t = j.map((function(t, r) {
                        var n = t % 10;
                        return u.createElement(f, (0, a.default)({}, e, {
                            key: t,
                            value: n,
                            offset: r - x,
                            current: r === x
                        }))
                    })), r = {
                        transform: "translateY(".concat(-i(m, s, P < d ? 1 : -1), "00%)")
                    }
                }
                return u.createElement("span", {
                    className: "".concat(n, "-only"),
                    style: r,
                    onTransitionEnd: g
                }, t)
            };
            var a = n(r(319290)),
                l = n(r(579459)),
                u = function(e, t) {
                    if (!t && e && e.__esModule) return e;
                    if (null === e || "object" !== o(e) && "function" !== typeof e) return {
                        default: e
                    };
                    var r = s(t);
                    if (r && r.has(e)) return r.get(e);
                    var n = {},
                        a = Object.defineProperty && Object.getOwnPropertyDescriptor;
                    for (var l in e)
                        if ("default" !== l && Object.prototype.hasOwnProperty.call(e, l)) {
                            var u = a ? Object.getOwnPropertyDescriptor(e, l) : null;
                            u && (u.get || u.set) ? Object.defineProperty(n, l, u) : n[l] = e[l]
                        }
                    n.default = e, r && r.set(e, n);
                    return n
                }(r(365043)),
                c = n(r(498139));

            function s(e) {
                if ("function" !== typeof WeakMap) return null;
                var t = new WeakMap,
                    r = new WeakMap;
                return (s = function(e) {
                    return e ? r : t
                })(e)
            }

            function f(e) {
                var t, r = e.prefixCls,
                    n = e.value,
                    o = e.current,
                    a = e.offset,
                    l = void 0 === a ? 0 : a;
                return l && (t = {
                    position: "absolute",
                    top: "".concat(l, "00%"),
                    left: 0
                }), u.createElement("span", {
                    style: t,
                    className: (0, c.default)("".concat(r, "-only-unit"), {
                        current: o
                    })
                }, n)
            }

            function i(e, t, r) {
                for (var n = e, o = 0;
                    (n + 10) % 10 !== t;) n += r, o += r;
                return o
            }
        },
        144719: (e, t, r) => {
            var n = r(50130),
                o = r(487066);
            t.A = void 0;
            var a = n(r(329085)),
                l = n(r(487066)),
                u = n(r(319290)),
                c = function(e, t) {
                    if (!t && e && e.__esModule) return e;
                    if (null === e || "object" !== o(e) && "function" !== typeof e) return {
                        default: e
                    };
                    var r = y(t);
                    if (r && r.has(e)) return r.get(e);
                    var n = {},
                        a = Object.defineProperty && Object.getOwnPropertyDescriptor;
                    for (var l in e)
                        if ("default" !== l && Object.prototype.hasOwnProperty.call(e, l)) {
                            var u = a ? Object.getOwnPropertyDescriptor(e, l) : null;
                            u && (u.get || u.set) ? Object.defineProperty(n, l, u) : n[l] = e[l]
                        }
                    n.default = e, r && r.set(e, n);
                    return n
                }(r(365043)),
                s = n(r(85301)),
                f = n(r(498139)),
                i = n(r(291151)),
                d = n(r(442451)),
                p = r(445600),
                v = r(853590),
                m = r(144138);

            function y(e) {
                if ("function" !== typeof WeakMap) return null;
                var t = new WeakMap,
                    r = new WeakMap;
                return (y = function(e) {
                    return e ? r : t
                })(e)
            }
            var b = function(e, t) {
                    var r = {};
                    for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && t.indexOf(n) < 0 && (r[n] = e[n]);
                    if (null != e && "function" === typeof Object.getOwnPropertySymbols) {
                        var o = 0;
                        for (n = Object.getOwnPropertySymbols(e); o < n.length; o++) t.indexOf(n[o]) < 0 && Object.prototype.propertyIsEnumerable.call(e, n[o]) && (r[n[o]] = e[n[o]])
                    }
                    return r
                },
                O = function(e) {
                    var t, r, n = e.prefixCls,
                        o = e.scrollNumberPrefixCls,
                        d = e.children,
                        y = e.status,
                        O = e.text,
                        P = e.color,
                        w = e.count,
                        g = void 0 === w ? null : w,
                        C = e.overflowCount,
                        j = void 0 === C ? 99 : C,
                        N = e.dot,
                        x = void 0 !== N && N,
                        h = e.size,
                        k = void 0 === h ? "default" : h,
                        E = e.title,
                        M = e.offset,
                        _ = e.style,
                        W = e.className,
                        D = e.showZero,
                        S = void 0 !== D && D,
                        I = b(e, ["prefixCls", "scrollNumberPrefixCls", "children", "status", "text", "color", "count", "overflowCount", "dot", "size", "title", "offset", "style", "className", "showZero"]),
                        T = c.useContext(p.ConfigContext),
                        R = T.getPrefixCls,
                        z = T.direction,
                        A = R("badge", n),
                        Z = g > j ? "".concat(j, "+") : g,
                        Y = null !== y && void 0 !== y || null !== P && void 0 !== P,
                        q = "0" === Z || 0 === Z,
                        B = x && !q,
                        F = B ? "" : Z,
                        G = (0, c.useMemo)((function() {
                            return (null === F || void 0 === F || "" === F || q && !S) && !B
                        }), [F, q, S, B]),
                        H = (0, c.useRef)(g);
                    G || (H.current = g);
                    var J = H.current,
                        K = (0, c.useRef)(F);
                    G || (K.current = F);
                    var L = K.current,
                        Q = (0, c.useRef)(B);
                    G || (Q.current = B);
                    var U = (0, c.useMemo)((function() {
                            if (!M) return (0, u.default)({}, _);
                            var e = {
                                marginTop: M[1]
                            };
                            return "rtl" === z ? e.left = parseInt(M[0], 10) : e.right = -parseInt(M[0], 10), (0, u.default)((0, u.default)({}, e), _)
                        }), [z, M, _]),
                        V = null !== E && void 0 !== E ? E : "string" === typeof J || "number" === typeof J ? J : void 0,
                        X = G || !O ? null : c.createElement("span", {
                            className: "".concat(A, "-status-text")
                        }, O),
                        $ = J && "object" === (0, l.default)(J) ? (0, v.cloneElement)(J, (function(e) {
                            return {
                                style: (0, u.default)((0, u.default)({}, U), e.style)
                            }
                        })) : void 0,
                        ee = (0, f.default)((t = {}, (0, a.default)(t, "".concat(A, "-status-dot"), Y), (0, a.default)(t, "".concat(A, "-status-").concat(y), !!y), (0, a.default)(t, "".concat(A, "-status-").concat(P), (0, m.isPresetColor)(P)), t)),
                        te = {};
                    P && !(0, m.isPresetColor)(P) && (te.background = P);
                    var re = (0, f.default)(A, (r = {}, (0, a.default)(r, "".concat(A, "-status"), Y), (0, a.default)(r, "".concat(A, "-not-a-wrapper"), !d), (0, a.default)(r, "".concat(A, "-rtl"), "rtl" === z), r), W);
                    if (!d && Y) {
                        var ne = U.color;
                        return c.createElement("span", (0, u.default)({}, I, {
                            className: re,
                            style: U
                        }), c.createElement("span", {
                            className: ee,
                            style: te
                        }), c.createElement("span", {
                            style: {
                                color: ne
                            },
                            className: "".concat(A, "-status-text")
                        }, O))
                    }
                    return c.createElement("span", (0, u.default)({}, I, {
                        className: re
                    }), d, c.createElement(s.default, {
                        visible: !G,
                        motionName: "".concat(A, "-zoom"),
                        motionAppear: !1,
                        motionDeadline: 1e3
                    }, (function(e) {
                        var t, r = e.className,
                            n = R("scroll-number", o),
                            l = Q.current,
                            s = (0, f.default)((t = {}, (0, a.default)(t, "".concat(A, "-dot"), l), (0, a.default)(t, "".concat(A, "-count"), !l), (0, a.default)(t, "".concat(A, "-count-sm"), "small" === k), (0, a.default)(t, "".concat(A, "-multiple-words"), !l && L && L.toString().length > 1), (0, a.default)(t, "".concat(A, "-status-").concat(y), !!y), (0, a.default)(t, "".concat(A, "-status-").concat(P), (0, m.isPresetColor)(P)), t)),
                            d = (0, u.default)({}, U);
                        return P && !(0, m.isPresetColor)(P) && ((d = d || {}).background = P), c.createElement(i.default, {
                            prefixCls: n,
                            show: !G,
                            motionClassName: r,
                            className: s,
                            count: L,
                            title: V,
                            style: d,
                            key: "scrollNumber"
                        }, $)
                    })), X)
                };
            O.Ribbon = d.default;
            var P = O;
            t.A = P
        },
        678257: (e, t, r) => {
            r(628035), r(134138)
        },
        144138: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.isPresetColor = function(e) {
                return -1 !== n.PresetColorTypes.indexOf(e)
            };
            var n = r(199701)
        },
        134138: (e, t, r) => {
            r.r(t), r.d(t, {
                default: () => n
            });
            const n = {}
        }
    }
]);
//# sourceMappingURL=82363.2859b473.chunk.js.map