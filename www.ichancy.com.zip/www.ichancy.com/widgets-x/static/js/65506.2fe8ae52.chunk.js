"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [65506], {
        365506: (n, e, o) => {
            o.d(e, {
                H: () => a
            });
            var i = o(365043),
                t = o(489595),
                r = o(570579);
            const a = i.forwardRef(((n, e) => {
                let {
                    icon: o,
                    dataTestid: i,
                    ...a
                } = n;
                return (0, r.jsx)(t.m, { ...a,
                    "data-testid": i,
                    className: a.className,
                    ref: e,
                    children: o
                })
            }))
        },
        489595: (n, e, o) => {
            o.d(e, {
                m: () => i
            });
            const i = o(294574).Ay.span.withConfig({
                displayName: "style__Container",
                componentId: "sc-gq0272-0"
            })(["border-radius:6px;", " ", " justify-content:center;align-items:center;display:flex;gap:4px;cursor:pointer;flex-shrink:0;", ""], (n => !n.ghost && "\n      background-color: var(--v3-black-4);\n  "), (n => n.active ? "\n          color: var(--v3-primary-color) !important;\n        " : " \n          color: var(--v3-black-45) !important;\n  "), (n => `width: ${20===n.iconContainerSize?"20px":0===n.iconContainerSize?0:32===n.iconContainerSize?"32px":"24px"};\n     height: ${20===n.iconContainerSize?"20px":0===n.iconContainerSize?0:32===n.iconContainerSize?"32px":"24px"};\n     \n     font-size: ${"sm"===n.size?"12px":"16px"};\n     \n  `))
        }
    }
]);
//# sourceMappingURL=65506.2fe8ae52.chunk.js.map