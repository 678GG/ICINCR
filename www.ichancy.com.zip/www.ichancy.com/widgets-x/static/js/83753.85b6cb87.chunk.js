"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [83753], {
        683753: (n, e, a) => {
            a.d(e, {
                Bk: () => l,
                Mp: () => s,
                e7: () => c
            });
            var o = a(179177);
            const l = function(n) {
                    var e;
                    let a = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
                        l = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : o.Ay.PRICE_ROUNDING,
                        s = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : o.Ay.PRICE_SEPARATOR,
                        c = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : o.Ay.HIDE_TRAILING_ZEROES,
                        t = ((null !== (e = n.balance) && void 0 !== e ? e : 0) - a).toFixed(l);
                    if (o.Ay.CASINO_BALANCE_IN_USER_BALANCE && !n.isBonus && n.casinoBalance) switch (o.Ay.CASINO_SPORTSBOOK_SWITCHER) {
                        case 0:
                            t = (parseFloat(t) + n.casinoBalance).toFixed(l);
                            break;
                        case 2:
                            t = (n.casinoBalance - a).toFixed(l)
                    }
                    const i = +t - parseInt(t);
                    if (s) {
                        const n = t.toString().split(".");
                        n[0] = n[0].replace(/\B(?=(\d{3})+(?!\d))/g, s), t = n.join(".")
                    }
                    return c && 0 === i ? t.toString().split(".")[0] : t
                },
                s = function(n) {
                    let e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : o.Ay.PRICE_ROUNDING;
                    return (null !== n && void 0 !== n ? n : 0).toFixed(e)
                },
                c = n => {
                    let e = 0;
                    return n.bonus_win_balance && Number(n.bonus_win_balance) && (e += n.bonus_win_balance), n.frozen_balance && Number(n.frozen_balance) && !o.Ay.SHOULD_IGNORE_USER_FROZEN_BALANCE && (e += n.frozen_balance), n.bonus_balance && Number(n.bonus_balance) && (e += n.bonus_balance), l({
                        balance: e,
                        isBonus: !0,
                        casinoBalance: n.casino_balance
                    })
                }
        }
    }
]);
//# sourceMappingURL=83753.85b6cb87.chunk.js.map