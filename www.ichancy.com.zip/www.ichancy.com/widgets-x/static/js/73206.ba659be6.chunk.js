"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [73206], {
        573206: (e, l, i) => {
            i.d(l, {
                y: () => t
            });
            var m = i(889181),
                n = i(55418),
                s = i(735905),
                a = i(570579);
            const t = e => {
                let {
                    active: l,
                    onClick: i,
                    item: t
                } = e;
                return (0, a.jsxs)("div", {
                    onClick: i,
                    className: (0, m.A)([(0, n.F)() ? "menuItemFillMobile" : "menuItemFill", {
                        "menuItemFill--active": l && !(0, n.F)(),
                        "menuItemFillMobile--active": l && (0, n.F)()
                    }]),
                    children: [(0, a.jsx)(s.GlobalIcon, {
                        lib: "sports",
                        size: 24,
                        name: t.alias
                    }), (0, a.jsx)("span", {
                        className: (0, m.A)([(0, n.F)() ? "menuItemFillMobile__name" : "menuItemFill__name", {
                            "menuItemFill--active__name": l && !(0, n.F)(),
                            "menuItemFillMobile--active__name": l && (0, n.F)()
                        }]),
                        children: t.name
                    })]
                })
            }
        }
    }
]);
//# sourceMappingURL=73206.ba659be6.chunk.js.map