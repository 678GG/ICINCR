"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [11149], {
        11149: (e, t, r) => {
            r.r(t), r.d(t, {
                default: () => s
            });
            var n, l = r(365043);

            function o() {
                return o = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = arguments[t];
                        for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n])
                    }
                    return e
                }, o.apply(this, arguments)
            }

            function a(e, t) {
                let {
                    title: r,
                    titleId: a,
                    ...i
                } = e;
                return l.createElement("svg", o({
                    xmlns: "http://www.w3.org/2000/svg",
                    width: 11,
                    height: 8,
                    viewBox: "0 0 11 8",
                    fill: "none",
                    ref: t,
                    "aria-labelledby": a
                }, i), r ? l.createElement("title", {
                    id: a
                }, r) : null, n || (n = l.createElement("path", {
                    d: "M10.4 1.20002C9.99999 0.800024 9.39999 0.800024 8.99999 1.20002L5.49999 4.70002L1.99999 1.20002C1.59999 0.800024 0.999988 0.800024 0.599988 1.20002C0.199988 1.60002 0.199988 2.20002 0.599988 2.60002L4.79999 6.80002C4.99999 7.00002 5.19999 7.10003 5.49999 7.10003C5.79999 7.10003 5.99999 7.00002 6.19999 6.80002L10.4 2.60002C10.8 2.20002 10.8 1.60002 10.4 1.20002Z",
                    fill: "currentColor"
                })))
            }
            const i = l.forwardRef(a),
                s = (r.p, i)
        }
    }
]);
//# sourceMappingURL=11149.ddc822ec.chunk.js.map