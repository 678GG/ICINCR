"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [49662], {
        249662: (s, e, c) => {
            c.d(e, {
                Q: () => k
            });
            var o = c(703532),
                a = (c(244261), c(570579));
            const k = () => (0, a.jsx)("div", {
                className: "searchElement",
                children: (0, a.jsx)(o.d, {})
            })
        }
    }
]);
//# sourceMappingURL=49662.5f113268.chunk.js.map