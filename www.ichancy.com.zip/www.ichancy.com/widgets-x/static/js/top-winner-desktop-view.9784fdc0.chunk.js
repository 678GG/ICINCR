"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [92711], {
        126431: (s, n, a) => {
            a.r(n), a.d(n, {
                TopWinnersContentDesktop: () => r
            });
            var e = a(708246),
                t = a(218130),
                o = a(570579);
            const r = s => {
                let {
                    data: n,
                    isLoading: a
                } = s;
                return a ? (0, o.jsx)(t.c, {}) : (0, o.jsx)("div", {
                    className: "topWinners-cards-container",
                    children: n.map(((s, n) => (0, o.jsx)(e.n, {
                        cardData: s
                    }, n)))
                })
            }
        }
    }
]);
//# sourceMappingURL=top-winner-desktop-view.9784fdc0.chunk.js.map