"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [55606], {
        855606: (o, t, a) => {
            a.d(t, {
                z: () => u
            });
            var s = a(365043),
                n = a(889181),
                i = a(294574);
            const e = {
                    toLeft: (0, i.i7)(["{0%{transform:translateX(100%);}100%{transform:translateX(0);}}"]),
                    toRight: (0, i.i7)(["{0%{transform:translateX(-100%);}100%{transform:translateX(0);}}"]),
                    toTop: (0, i.i7)(["{0%{transform:translateY(100%);}100%{transform:translateY(0);}}"]),
                    toBottom: (0, i.i7)(["{0%{transform:translateY(-100%);}100%{transform:translateY(0);}}"])
                },
                r = {
                    toLeft: (0, i.i7)(["{0%{transform:translateX(0);}100%{transform:translateX(100%);}}"]),
                    toRight: (0, i.i7)(["{0%{transform:translateX(0);}100%{transform:translateX(-100%);}}"]),
                    toTop: (0, i.i7)(["{0%{transform:translateY(0);}100%{transform:translateY(100%);}}"]),
                    toBottom: (0, i.i7)(["{0%{transform:translateY(0);}100%{transform:translateY(-100%);}}"])
                },
                m = i.Ay.div.withConfig({
                    displayName: "style__CustomMask",
                    componentId: "sc-g7ftgu-0"
                })(["position:fixed;top:0;left:0;right:0;height:100%;background:", ";z-index:1;"], (o => o.maskBackground ? o.maskBackground : "rgba(0,0,0,0.3)")),
                l = i.Ay.div.withConfig({
                    displayName: "style__Container",
                    componentId: "sc-g7ftgu-1"
                })(["position:fixed;height:-webkit-fill-available;height:-moz-available;height:fill-available;top:", ";left:0;right:0;opacity:", ";z-index:11;pointer-events:", ";overflow:hidden;transition:opacity ", ";", "{top:", ";}"], (o => o.$maskPosTop ? o.$maskPosTop : 0), (o => o.show ? 1 : 0), (o => o.show ? "all" : "none"), (o => o.animationTime ? o.animationTime : "0.3s"), m, (o => o.$maskPosTop ? o.$maskPosTop : 0)),
                p = i.Ay.div.withConfig({
                    displayName: "style__CustomData",
                    componentId: "sc-g7ftgu-2"
                })(["position:absolute;height:100%;bottom:", ";top:", ";left:", ";right:", ";display:flex;flex-direction:column;z-index:3;background:var(--v3-black-0);&.customPopup--open{animation:", " ", " ease forwards;}&.customPopup--close{animation:", " ", " ease forwards;}"], (o => o.posBottom ? o.posBottom : 0), (o => o.posTop ? o.posTop : 0), (o => o.posLeft ? o.posLeft : 0), (o => o.posRight ? o.posRight : 0), (o => e[o.animationType]), (o => o.animationTime ? o.animationTime : "0.3s"), (o => r[o.animationType]), (o => o.animationTime ? o.animationTime : "0.3s"));
            var f = a(120376),
                c = a(179177),
                d = a(570579);
            const u = (0, s.memo)((o => {
                let {
                    open: t,
                    children: a,
                    onMaskClick: i,
                    mask: e,
                    animationType: r,
                    animationTime: u,
                    className: h,
                    posBottom: g,
                    posLeft: k,
                    posRight: T,
                    posTop: v,
                    maskPosTop: y,
                    maskBackground: b,
                    style: w = {},
                    onBeforeOpen: x,
                    onAfterOpen: B,
                    initiallyLoaded: C = !1
                } = o;
                const P = (0, s.useRef)(C),
                    _ = (0, s.useMemo)((() => r || "toLeft"), [r]);
                return (0, s.useLayoutEffect)((() => {
                    null === x || void 0 === x || x()
                }), []), (0, s.useEffect)((() => {
                    t && (P.current = !0)
                }), [t]), c.Ay.MOCKED_DATA ? null : (0, d.jsx)(f.Z, {
                    children: (0, d.jsxs)(l, {
                        show: t,
                        animationTime: u,
                        className: h,
                        style: w,
                        $maskPosTop: null !== y && void 0 !== y && y.usePosTop ? v : null === y || void 0 === y ? void 0 : y.posTop,
                        children: [e && (0, d.jsx)(m, {
                            className: "customMask",
                            maskBackground: b,
                            onClick: () => null === i || void 0 === i ? void 0 : i(!0)
                        }), (0, d.jsx)(p, {
                            className: (0, n.A)(["custom-data", {
                                "customPopup--open": t,
                                "customPopup--close": !t
                            }]),
                            animationType: _,
                            animationTime: u,
                            posTop: v,
                            posRight: T,
                            posLeft: k,
                            posBottom: g,
                            onAnimationEnd: () => null === B || void 0 === B ? void 0 : B(t),
                            children: (t || P.current) && a
                        })]
                    })
                })
            }))
        }
    }
]);
//# sourceMappingURL=55606.4867d7e3.chunk.js.map