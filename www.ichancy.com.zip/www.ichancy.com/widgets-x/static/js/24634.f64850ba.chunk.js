"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [24634], {
        124634: (s, n, a) => {
            a.d(n, {
                Q: () => i,
                f: () => _
            });
            var e = a(93907),
                o = a(291372),
                d = a(737536),
                m = a(423400),
                t = a(704270);
            const i = (s, n, a, e) => {
                    const o = {
                        command: d.y.SET_GAMES_NOTIFICATIONS,
                        params: {
                            game_list: [s],
                            events: [{
                                event_name: "MatchFinished",
                                is_subscribed: n
                            }]
                        },
                        rid: m.A.gForCommand()
                    };
                    t.l.then((s => {
                        s.sendCommand(o, "", a, null, e)
                    }))
                },
                _ = () => {
                    const s = {
                            command: d.y.GET_USER_ALL_NOTIFICATIONS,
                            params: {},
                            rid: m.A.gForCommand()
                        },
                        n = s => {
                            null !== s && void 0 !== s && s.details && o.A.dispatch((0, e.sV)(s.details))
                        };
                    t.l.then((a => {
                        a.sendCommand(s, "", n)
                    }))
                }
        }
    }
]);
//# sourceMappingURL=24634.f64850ba.chunk.js.map