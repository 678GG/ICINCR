"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [81643], {
        181643: (e, t, r) => {
            function n() {
                return n = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = arguments[t];
                        for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n])
                    }
                    return e
                }, n.apply(this, arguments)
            }

            function o(e, t, r) {
                return t in e ? Object.defineProperty(e, t, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = r, e
            }

            function i(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function a(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? i(Object(r), !0).forEach((function(t) {
                        o(e, t, r[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : i(Object(r)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    }))
                }
                return e
            }

            function l(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
                return n
            }

            function u(e, t) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, t) {
                    var r = null == e ? null : "undefined" !== typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                    if (null != r) {
                        var n, o, i = [],
                            a = !0,
                            l = !1;
                        try {
                            for (r = r.call(e); !(a = (n = r.next()).done) && (i.push(n.value), !t || i.length !== t); a = !0);
                        } catch (u) {
                            l = !0, o = u
                        } finally {
                            try {
                                a || null == r.return || r.return()
                            } finally {
                                if (l) throw o
                            }
                        }
                        return i
                    }
                }(e, t) || function(e, t) {
                    if (e) {
                        if ("string" === typeof e) return l(e, t);
                        var r = Object.prototype.toString.call(e).slice(8, -1);
                        return "Object" === r && e.constructor && (r = e.constructor.name), "Map" === r || "Set" === r ? Array.from(e) : "Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r) ? l(e, t) : void 0
                    }
                }(e, t) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function s(e, t) {
                if (null == e) return {};
                var r, n, o = function(e, t) {
                    if (null == e) return {};
                    var r, n, o = {},
                        i = Object.keys(e);
                    for (n = 0; n < i.length; n++) r = i[n], t.indexOf(r) >= 0 || (o[r] = e[r]);
                    return o
                }(e, t);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    for (n = 0; n < i.length; n++) r = i[n], t.indexOf(r) >= 0 || Object.prototype.propertyIsEnumerable.call(e, r) && (o[r] = e[r])
                }
                return o
            }
            r.d(t, {
                A: () => T
            });
            var c = r(365043),
                f = r(498139),
                d = r.n(f),
                m = r(770289),
                v = r(152664),
                p = ["prefixCls", "invalidate", "item", "renderItem", "responsive", "responsiveDisabled", "registerSize", "itemKey", "className", "style", "children", "display", "order", "component"],
                y = void 0;

            function b(e, t) {
                var r = e.prefixCls,
                    o = e.invalidate,
                    i = e.item,
                    l = e.renderItem,
                    u = e.responsive,
                    f = e.responsiveDisabled,
                    v = e.registerSize,
                    b = e.itemKey,
                    h = e.className,
                    g = e.style,
                    O = e.children,
                    w = e.display,
                    E = e.order,
                    S = e.component,
                    N = void 0 === S ? "div" : S,
                    j = s(e, p),
                    C = u && !w;

                function I(e) {
                    v(b, e)
                }
                c.useEffect((function() {
                    return function() {
                        I(null)
                    }
                }), []);
                var R, x = l && i !== y ? l(i) : O;
                o || (R = {
                    opacity: C ? 0 : 1,
                    height: C ? 0 : y,
                    overflowY: C ? "hidden" : y,
                    order: u ? E : y,
                    pointerEvents: C ? "none" : y,
                    position: C ? "absolute" : y
                });
                var A = {};
                C && (A["aria-hidden"] = !0);
                var P = c.createElement(N, n({
                    className: d()(!o && r, h),
                    style: a(a({}, R), g)
                }, A, j, {
                    ref: t
                }), x);
                return u && (P = c.createElement(m.default, {
                    onResize: function(e) {
                        I(e.offsetWidth)
                    },
                    disabled: f
                }, P)), P
            }
            var h = c.forwardRef(b);
            h.displayName = "Item";
            const g = h;
            var O = r(32375),
                w = r(297950),
                E = r(445818);

            function S() {
                var e = c.useRef(null);
                return function(t) {
                    e.current || (e.current = [], function(e) {
                        if ("undefined" === typeof MessageChannel)(0, E.A)(e);
                        else {
                            var t = new MessageChannel;
                            t.port1.onmessage = function() {
                                return e()
                            }, t.port2.postMessage(void 0)
                        }
                    }((function() {
                        (0, w.unstable_batchedUpdates)((function() {
                            e.current.forEach((function(e) {
                                e()
                            })), e.current = null
                        }))
                    }))), e.current.push(t)
                }
            }

            function N(e, t) {
                var r = u(c.useState(t), 2),
                    n = r[0],
                    o = r[1];
                return [n, (0, O.A)((function(t) {
                    e((function() {
                        o(t)
                    }))
                }))]
            }
            var j = c.createContext(null),
                C = ["component"],
                I = ["className"],
                R = ["className"],
                x = function(e, t) {
                    var r = c.useContext(j);
                    if (!r) {
                        var o = e.component,
                            i = void 0 === o ? "div" : o,
                            a = s(e, C);
                        return c.createElement(i, n({}, a, {
                            ref: t
                        }))
                    }
                    var l = r.className,
                        u = s(r, I),
                        f = e.className,
                        m = s(e, R);
                    return c.createElement(j.Provider, {
                        value: null
                    }, c.createElement(g, n({
                        ref: t,
                        className: d()(l, f)
                    }, u, m)))
                },
                A = c.forwardRef(x);
            A.displayName = "RawItem";
            const P = A;
            var k = ["prefixCls", "data", "renderItem", "renderRawItem", "itemKey", "itemWidth", "ssr", "style", "className", "maxCount", "renderRest", "renderRawRest", "suffix", "component", "itemComponent", "onVisibleChange"],
                M = "responsive",
                _ = "invalidate";

            function z(e) {
                return "+ ".concat(e.length, " ...")
            }

            function D(e, t) {
                var r = e.prefixCls,
                    o = void 0 === r ? "rc-overflow" : r,
                    i = e.data,
                    l = void 0 === i ? [] : i,
                    f = e.renderItem,
                    p = e.renderRawItem,
                    y = e.itemKey,
                    b = e.itemWidth,
                    h = void 0 === b ? 10 : b,
                    O = e.ssr,
                    w = e.style,
                    E = e.className,
                    C = e.maxCount,
                    I = e.renderRest,
                    R = e.renderRawRest,
                    x = e.suffix,
                    A = e.component,
                    P = void 0 === A ? "div" : A,
                    D = e.itemComponent,
                    K = e.onVisibleChange,
                    T = s(e, k),
                    V = "full" === O,
                    W = S(),
                    F = u(N(W, null), 2),
                    G = F[0],
                    U = F[1],
                    X = G || 0,
                    L = u(N(W, new Map), 2),
                    Y = L[0],
                    $ = L[1],
                    q = u(N(W, 0), 2),
                    B = q[0],
                    H = q[1],
                    J = u(N(W, 0), 2),
                    Q = J[0],
                    Z = J[1],
                    ee = u(N(W, 0), 2),
                    te = ee[0],
                    re = ee[1],
                    ne = u((0, c.useState)(null), 2),
                    oe = ne[0],
                    ie = ne[1],
                    ae = u((0, c.useState)(null), 2),
                    le = ae[0],
                    ue = ae[1],
                    se = c.useMemo((function() {
                        return null === le && V ? Number.MAX_SAFE_INTEGER : le || 0
                    }), [le, G]),
                    ce = u((0, c.useState)(!1), 2),
                    fe = ce[0],
                    de = ce[1],
                    me = "".concat(o, "-item"),
                    ve = Math.max(B, Q),
                    pe = C === M,
                    ye = l.length && pe,
                    be = C === _,
                    he = ye || "number" === typeof C && l.length > C,
                    ge = (0, c.useMemo)((function() {
                        var e = l;
                        return ye ? e = null === G && V ? l : l.slice(0, Math.min(l.length, X / h)) : "number" === typeof C && (e = l.slice(0, C)), e
                    }), [l, h, G, C, ye]),
                    Oe = (0, c.useMemo)((function() {
                        return ye ? l.slice(se + 1) : l.slice(ge.length)
                    }), [l, ge, ye, se]),
                    we = (0, c.useCallback)((function(e, t) {
                        var r;
                        return "function" === typeof y ? y(e) : null !== (r = y && (null === e || void 0 === e ? void 0 : e[y])) && void 0 !== r ? r : t
                    }), [y]),
                    Ee = (0, c.useCallback)(f || function(e) {
                        return e
                    }, [f]);

                function Se(e, t, r) {
                    (le !== e || void 0 !== t && t !== oe) && (ue(e), r || (de(e < l.length - 1), null === K || void 0 === K || K(e)), void 0 !== t && ie(t))
                }

                function Ne(e, t) {
                    $((function(r) {
                        var n = new Map(r);
                        return null === t ? n.delete(e) : n.set(e, t), n
                    }))
                }

                function je(e) {
                    return Y.get(we(ge[e], e))
                }(0, v.A)((function() {
                    if (X && "number" === typeof ve && ge) {
                        var e = te,
                            t = ge.length,
                            r = t - 1;
                        if (!t) return void Se(0, null);
                        for (var n = 0; n < t; n += 1) {
                            var o = je(n);
                            if (V && (o = o || 0), void 0 === o) {
                                Se(n - 1, void 0, !0);
                                break
                            }
                            if (e += o, 0 === r && e <= X || n === r - 1 && e + je(r) <= X) {
                                Se(r, null);
                                break
                            }
                            if (e + ve > X) {
                                Se(n - 1, e - o - te + Q);
                                break
                            }
                        }
                        x && je(0) + te > X && ie(null)
                    }
                }), [X, Y, Q, te, we, ge]);
                var Ce = fe && !!Oe.length,
                    Ie = {};
                null !== oe && ye && (Ie = {
                    position: "absolute",
                    left: oe,
                    top: 0
                });
                var Re, xe = {
                        prefixCls: me,
                        responsive: ye,
                        component: D,
                        invalidate: be
                    },
                    Ae = p ? function(e, t) {
                        var r = we(e, t);
                        return c.createElement(j.Provider, {
                            key: r,
                            value: a(a({}, xe), {}, {
                                order: t,
                                item: e,
                                itemKey: r,
                                registerSize: Ne,
                                display: t <= se
                            })
                        }, p(e, t))
                    } : function(e, t) {
                        var r = we(e, t);
                        return c.createElement(g, n({}, xe, {
                            order: t,
                            key: r,
                            item: e,
                            renderItem: Ee,
                            itemKey: r,
                            registerSize: Ne,
                            display: t <= se
                        }))
                    },
                    Pe = {
                        order: Ce ? se : Number.MAX_SAFE_INTEGER,
                        className: "".concat(me, "-rest"),
                        registerSize: function(e, t) {
                            Z(t), H(Q)
                        },
                        display: Ce
                    };
                if (R) R && (Re = c.createElement(j.Provider, {
                    value: a(a({}, xe), Pe)
                }, R(Oe)));
                else {
                    var ke = I || z;
                    Re = c.createElement(g, n({}, xe, Pe), "function" === typeof ke ? ke(Oe) : ke)
                }
                var Me = c.createElement(P, n({
                    className: d()(!be && o, E),
                    style: w,
                    ref: t
                }, T), ge.map(Ae), he ? Re : null, x && c.createElement(g, n({}, xe, {
                    responsive: pe,
                    responsiveDisabled: !ye,
                    order: se,
                    className: "".concat(me, "-suffix"),
                    registerSize: function(e, t) {
                        re(t)
                    },
                    display: !0,
                    style: Ie
                }), x));
                return pe && (Me = c.createElement(m.default, {
                    onResize: function(e, t) {
                        U(t.clientWidth)
                    },
                    disabled: !ye
                }, Me)), Me
            }
            var K = c.forwardRef(D);
            K.displayName = "Overflow", K.Item = P, K.RESPONSIVE = M, K.INVALIDATE = _;
            const T = K
        }
    }
]);
//# sourceMappingURL=81643.4f846ca2.chunk.js.map