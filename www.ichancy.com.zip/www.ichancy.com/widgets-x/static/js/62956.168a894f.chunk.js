"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [62956], {
        462956: (s, o, e) => {
            e.d(o, {
                Ot: () => n,
                es: () => c,
                gU: () => k
            });
            const t = (0, e(534977).g)("socket"),
                k = t("partnerConfigs"),
                c = t("jackpots"),
                n = t("isConnected")
        }
    }
]);
//# sourceMappingURL=62956.168a894f.chunk.js.map