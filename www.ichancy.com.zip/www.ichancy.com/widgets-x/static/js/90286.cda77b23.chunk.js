"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [90286], {
        890286: (_, T, E) => {
            E.d(T, {
                $s: () => P,
                C: () => D,
                MU: () => y,
                P: () => A,
                S5: () => l,
                XS: () => o,
                YH: () => s,
                Zr: () => p,
                e_: () => d,
                gS: () => R,
                h4: () => I,
                lk: () => v,
                m1: () => O,
                p0: () => t,
                qH: () => e,
                u0: () => N,
                u2: () => C,
                uV: () => a
            });
            var S = E(560529);
            const O = _ => ({
                    type: S.v.SET_CASINO_OPTIONS,
                    payload: _
                }),
                p = () => ({
                    type: S.v.RESET_CASINO_OPTIONS
                }),
                A = _ => ({
                    type: S.v.TOGGLE_ACTIVE_CATEGORY,
                    payload: _
                }),
                a = _ => ({
                    type: S.v.SET_CASINO_GAME_TOURNAMENTS,
                    payload: _
                }),
                y = _ => ({
                    type: S.v.SET_IS_LOADED,
                    payload: _
                }),
                e = _ => ({
                    type: S.v.SET_CASINO_JACKPOT,
                    payload: _
                }),
                t = _ => ({
                    type: S.v.SET_SPORTSBOOK_JACKPOT,
                    payload: _
                }),
                C = _ => ({
                    type: S.v.SET_CASINO_GAME_JACKPOT,
                    payload: _
                }),
                o = () => ({
                    type: S.v.RESET_CASINO_JACKPOT
                }),
                N = () => ({
                    type: S.v.RESET_SPORTSBOOK_JACKPOT
                }),
                v = () => ({
                    type: S.v.RESET_CASINO_GAME_JACKPOT
                }),
                I = function(_) {
                    let T = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
                    return {
                        type: S.v.SET_ACTIVE_OPTIONS,
                        payload: { ..._,
                            shouldUpdateUID: T
                        }
                    }
                },
                l = _ => ({
                    type: S.v.SET_CASHED_TOURNAMENTS_DATA,
                    payload: _
                }),
                d = _ => ({
                    type: S.v.SET_CASHED_TOURNAMENTS_OPTIONS,
                    payload: _
                }),
                P = _ => ({
                    type: S.v.SET_SELECTED_CASINO_GAME,
                    payload: _
                }),
                R = _ => ({
                    type: S.v.SET_JOINED_TOURNAMENTS,
                    payload: _
                }),
                s = _ => ({
                    type: S.v.SET_SELECTED_CASINO_CATEGORY_ID,
                    payload: _
                }),
                D = _ => ({
                    type: S.v.SET_TOURNAMENT_ACTIVE_PRODUCT_TYPE_ID,
                    payload: _
                })
        }
    }
]);
//# sourceMappingURL=90286.cda77b23.chunk.js.map