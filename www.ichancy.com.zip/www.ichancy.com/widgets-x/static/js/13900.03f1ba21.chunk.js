"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [13900], {
        513900: (s, o, e) => {
            e.d(o, {
                A: () => t,
                H: () => k
            });
            const k = "uncategorized",
                t = 28
        }
    }
]);
//# sourceMappingURL=13900.03f1ba21.chunk.js.map