"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [95459], {
        595459: (s, a, o) => {
            o.d(a, {
                d: () => t
            });
            var p = o(995392);
            const t = s => (0, p.W5)(s) || {
                url: "",
                path: "",
                params: {},
                isExact: !1
            }
        }
    }
]);
//# sourceMappingURL=95459.b709adaf.chunk.js.map