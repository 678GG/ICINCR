"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [6635], {
        509609: (t, e, n) => {
            var r = n(50130),
                a = n(487066);
            e.A = void 0;
            var o = r(n(319290)),
                i = r(n(329085)),
                l = function(t, e) {
                    if (!e && t && t.__esModule) return t;
                    if (null === t || "object" !== a(t) && "function" !== typeof t) return {
                        default: t
                    };
                    var n = u(e);
                    if (n && n.has(t)) return n.get(t);
                    var r = {},
                        o = Object.defineProperty && Object.getOwnPropertyDescriptor;
                    for (var i in t)
                        if ("default" !== i && Object.prototype.hasOwnProperty.call(t, i)) {
                            var l = o ? Object.getOwnPropertyDescriptor(t, i) : null;
                            l && (l.get || l.set) ? Object.defineProperty(r, i, l) : r[i] = t[i]
                        }
                    r.default = t, n && n.set(t, r);
                    return r
                }(n(365043)),
                c = r(n(498139)),
                f = n(445600);

            function u(t) {
                if ("function" !== typeof WeakMap) return null;
                var e = new WeakMap,
                    n = new WeakMap;
                return (u = function(t) {
                    return t ? n : e
                })(t)
            }
            var s = function(t, e) {
                    var n = {};
                    for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && e.indexOf(r) < 0 && (n[r] = t[r]);
                    if (null != t && "function" === typeof Object.getOwnPropertySymbols) {
                        var a = 0;
                        for (r = Object.getOwnPropertySymbols(t); a < r.length; a++) e.indexOf(r[a]) < 0 && Object.prototype.propertyIsEnumerable.call(t, r[a]) && (n[r[a]] = t[r[a]])
                    }
                    return n
                },
                d = function(t) {
                    var e, n = l.useContext(f.ConfigContext),
                        r = n.getPrefixCls,
                        a = n.direction,
                        u = t.prefixCls,
                        d = t.type,
                        p = void 0 === d ? "horizontal" : d,
                        y = t.orientation,
                        g = void 0 === y ? "center" : y,
                        h = t.orientationMargin,
                        v = t.className,
                        b = t.children,
                        O = t.dashed,
                        m = t.plain,
                        w = s(t, ["prefixCls", "type", "orientation", "orientationMargin", "className", "children", "dashed", "plain"]),
                        j = r("divider", u),
                        x = g.length > 0 ? "-".concat(g) : g,
                        k = !!b,
                        P = "left" === g && null != h,
                        C = "right" === g && null != h,
                        M = (0, c.default)(j, "".concat(j, "-").concat(p), (e = {}, (0, i.default)(e, "".concat(j, "-with-text"), k), (0, i.default)(e, "".concat(j, "-with-text").concat(x), k), (0, i.default)(e, "".concat(j, "-dashed"), !!O), (0, i.default)(e, "".concat(j, "-plain"), !!m), (0, i.default)(e, "".concat(j, "-rtl"), "rtl" === a), (0, i.default)(e, "".concat(j, "-no-default-orientation-margin-left"), P), (0, i.default)(e, "".concat(j, "-no-default-orientation-margin-right"), C), e), v),
                        _ = (0, o.default)((0, o.default)({}, P && {
                            marginLeft: h
                        }), C && {
                            marginRight: h
                        });
                    return l.createElement("div", (0, o.default)({
                        className: M
                    }, w, {
                        role: "separator"
                    }), b && l.createElement("span", {
                        className: "".concat(j, "-inner-text"),
                        style: _
                    }, b))
                };
            e.A = d
        },
        731059: (t, e, n) => {
            n(628035), n(766172)
        },
        766172: (t, e, n) => {
            n.r(e), n.d(e, {
                default: () => r
            });
            const r = {}
        }
    }
]);
//# sourceMappingURL=6635.7237d6da.chunk.js.map