"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [22491], {
        494303: (e, t) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.getRenderPropValue = void 0;
            t.getRenderPropValue = function(e) {
                return e ? "function" === typeof e ? e() : e : null
            }
        },
        69661: (e, t, r) => {
            var n = r(50130),
                o = r(487066);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = n(r(319290)),
                l = function(e, t) {
                    if (!t && e && e.__esModule) return e;
                    if (null === e || "object" !== o(e) && "function" !== typeof e) return {
                        default: e
                    };
                    var r = p(t);
                    if (r && r.has(e)) return r.get(e);
                    var n = {},
                        a = Object.defineProperty && Object.getOwnPropertyDescriptor;
                    for (var l in e)
                        if ("default" !== l && Object.prototype.hasOwnProperty.call(e, l)) {
                            var u = a ? Object.getOwnPropertyDescriptor(e, l) : null;
                            u && (u.get || u.set) ? Object.defineProperty(n, l, u) : n[l] = e[l]
                        }
                    n.default = e, r && r.set(e, n);
                    return n
                }(r(365043)),
                u = n(r(945375)),
                i = r(445600),
                f = r(494303),
                c = r(272391);

            function p(e) {
                if ("function" !== typeof WeakMap) return null;
                var t = new WeakMap,
                    r = new WeakMap;
                return (p = function(e) {
                    return e ? r : t
                })(e)
            }
            var s = function(e, t) {
                    var r = {};
                    for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && t.indexOf(n) < 0 && (r[n] = e[n]);
                    if (null != e && "function" === typeof Object.getOwnPropertySymbols) {
                        var o = 0;
                        for (n = Object.getOwnPropertySymbols(e); o < n.length; o++) t.indexOf(n[o]) < 0 && Object.prototype.propertyIsEnumerable.call(e, n[o]) && (r[n[o]] = e[n[o]])
                    }
                    return r
                },
                d = l.forwardRef((function(e, t) {
                    var r = e.prefixCls,
                        n = e.title,
                        o = e.content,
                        p = s(e, ["prefixCls", "title", "content"]),
                        d = l.useContext(i.ConfigContext).getPrefixCls,
                        v = d("popover", r),
                        y = d();
                    return l.createElement(u.default, (0, a.default)({}, p, {
                        prefixCls: v,
                        ref: t,
                        overlay: function(e) {
                            if (n || o) return l.createElement(l.Fragment, null, n && l.createElement("div", {
                                className: "".concat(e, "-title")
                            }, (0, f.getRenderPropValue)(n)), l.createElement("div", {
                                className: "".concat(e, "-inner-content")
                            }, (0, f.getRenderPropValue)(o)))
                        }(v),
                        transitionName: (0, c.getTransitionName)(y, "zoom-big", p.transitionName)
                    }))
                }));
            d.displayName = "Popover", d.defaultProps = {
                placement: "top",
                trigger: "hover",
                mouseEnterDelay: .1,
                mouseLeaveDelay: .1,
                overlayStyle: {}
            };
            var v = d;
            t.default = v
        },
        50999: (e, t, r) => {
            r(628035), r(934600)
        },
        934600: (e, t, r) => {
            r.r(t), r.d(t, {
                default: () => n
            });
            const n = {}
        }
    }
]);
//# sourceMappingURL=22491.2cced4c6.chunk.js.map