"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [82685], {
        147638: (s, o, k) => {
            o.A = void 0;
            var e = k(211216).Col;
            o.A = e
        },
        849416: (s, o, k) => {
            k(628035), k(217466)
        }
    }
]);
//# sourceMappingURL=82685.e769e93e.chunk.js.map