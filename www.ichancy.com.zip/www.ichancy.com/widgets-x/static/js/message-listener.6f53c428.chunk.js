"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [56857], {
        976376: (e, o, n) => {
            n.d(o, {
                R: () => p
            });
            var t = n(908198),
                i = n.n(t),
                s = n(446987),
                a = n(365043),
                u = n(870905),
                r = n(282695),
                c = n(735905),
                l = n(626038),
                d = n(238605),
                _ = n(123213),
                m = n(570579);
            const p = () => {
                const [e, o] = (0, a.useState)(!1), n = (0, l.N)(), {
                    t: t
                } = (0, u.B)(), {
                    loginCallback: p
                } = (0, r.S)({
                    rememberMe: !1,
                    password: null,
                    username: null
                });
                (0, a.useEffect)((() => {
                    var e;
                    null !== (e = window.median) && void 0 !== e && e.auth && window.median.auth.status({
                        callbackFunction: e => {
                            e && e.hasTouchId && e.hasSecret && o(!0)
                        }
                    })
                }), []);
                const v = () => {
                        var e;
                        null !== (e = window.median) && void 0 !== e && e.auth && (window.median.auth.delete(), o(!1))
                    },
                    h = (e, o) => {
                        var n;
                        null !== (n = window.median) && void 0 !== n && n.auth && (v(), window.median.auth.status({
                            callbackFunction: n => {
                                if (n && n.hasTouchId) {
                                    const n = JSON.stringify({
                                        username: e,
                                        password: o
                                    });
                                    window.median.auth.save({
                                        secret: n
                                    }), _.A.removeItem("isWrapperFirstLaunch")
                                }
                            },
                            prompt: "PROMPT"
                        }))
                    };
                return {
                    removeSecret: v,
                    loginWithFaceId: () => {
                        var e;
                        null !== (e = window.median) && void 0 !== e && e.auth && window.median.auth.status({
                            callbackFunction: e => {
                                e && e.hasTouchId && e.hasSecret && window.median.auth.get({
                                    callbackFunction: e => {
                                        if (e && e.success && e.secret) {
                                            const o = JSON.parse(e.secret),
                                                n = o.username,
                                                t = o.password;
                                            n && t && (0, s.iD)({
                                                username: n,
                                                password: t
                                            }, p)
                                        } else e && e.error, n()
                                    },
                                    callbackOnCancel: "true"
                                })
                            }
                        })
                    },
                    setCredentials: h,
                    credentialsExist: e,
                    showConfirmationPopup: (e, o) => {
                        var n;
                        null !== (n = window.median) && void 0 !== n && n.auth && window.median.auth.status({
                            callbackFunction: n => {
                                n && n.hasTouchId && i().alert((0, m.jsx)(c.GlobalIcon, {
                                    lib: "account",
                                    name: (0, d.Ri)("isIOSWrapperApp") ? "FaceId" : "Biometrics",
                                    theme: "default",
                                    size: 24
                                }), (0, d.Ri)("isIOSWrapperApp") ? t("account.faceIdConfirmationInfoIos") : t("account.faceIdConfirmationInfoAndroid"), [{
                                    text: t("account.cancel"),
                                    onPress: () => {}
                                }, {
                                    text: t("account.ok"),
                                    onPress: () => {
                                        h(e, o)
                                    }
                                }])
                            },
                            prompt: "PROMPT"
                        })
                    }
                }
            }
        },
        282695: (e, o, n) => {
            n.d(o, {
                S: () => b
            });
            var t = n(365043),
                i = n(507712),
                s = n(446987),
                a = n(117893),
                u = n(995392),
                r = n(701616),
                c = n(841591),
                l = n(124634),
                d = n(123213),
                _ = n(49770),
                m = n(171224),
                p = n(596771),
                v = n(816343),
                h = n(179177),
                I = n(115837),
                g = n(556785),
                w = n(954947),
                A = n(485138),
                f = n(849944),
                T = n(302258);
            const b = e => {
                let {
                    rememberMe: o,
                    userGroups: n
                } = e;
                const b = (0, t.useRef)(),
                    [S, O] = (0, t.useState)(!1),
                    [k, C] = (0, t.useState)(),
                    N = (0, i.wA)(),
                    y = (0, u.W6)(),
                    E = (0, i.d4)(c.h0),
                    U = null === E || void 0 === E ? void 0 : E.find((e => e && "personalId" === e.formType)),
                    R = () => {
                        d.A.setItem((0, g.U)("account", "AUTH_DATA"), JSON.stringify(b.current)), (0, s.wz)(M, F, "login", !1, !(null === U || void 0 === U || !U.editForm.showOnEditProfile || "2" !== U.editForm.personalIdType || "1" !== (null === U || void 0 === U ? void 0 : U.editForm.sendCPFAsDocNumber))), h.Ay.PUSH_NOTIFICATIONS_ENABLED && (0, l.f)()
                    },
                    {
                        updateUser: F
                    } = (0, I.Q)(),
                    M = e => {
                        var t;
                        (0, m.c)("loginCredentials", {
                            rememberMe: o,
                            userGroups: n || "",
                            jwe_token: (null === b || void 0 === b || null === (t = b.current) || void 0 === t ? void 0 : t.jwe_token) || ""
                        }), N((0, a.sX7)({ ...e,
                            last_login_date: e.last_login_date || Math.floor((new Date).getTime() / 1e3)
                        })), N((0, a.hB6)(60 * (e.session_duration || 0))), e.active_time_in_casino && _.A.setItem((0, g.U)("account", "ACTIVE_TIME_IN_CASINO"), `${e.active_time_in_casino}`);
                        const i = p.y.getAfterSignIn();
                        "function" === typeof i ? (p.y.setAfterSignIn(null), (0, v.XZ)(), i()) : (N((0, a.Xz$)(!e.is_verified)), y.push((0, v.XZ)())), N((0, a.VoE)(!0)), d.A.setItem((0, g.U)("account", "PARENT_ACCOUNT_CURRENCY"), e.currency), (0, m.c)("sbuser", {
                            rememberMe: o,
                            userGroups: n && n || ""
                        }, 15), window.refreshWhenLoggedIn && (y.push((0, v.oR)({
                            accounts: void 0,
                            login: void 0
                        })), window.mustRefreshForSessionVisibility = !0, window.location.reload())
                    };
                return {
                    loginCallback: e => {
                        const {
                            auth_token: o,
                            user_id: n,
                            qr_code_origin: t,
                            authentication_status: i,
                            jwe_token: s
                        } = e;
                        if (b.current = {
                                auth_token: o,
                                user_id: n,
                                qr_code_origin: t,
                                jwe_token: s
                            }, 4 === i) return O(!0), void C(t);
                        h.Ay.ADD_INFO_AFTER_LOGIN && N((0, r.rY)(!0)), (0, w.A)(), R(), (0, A.y)({
                            type: "userId",
                            value: e.user_id
                        }), window.popupIframe && window.parent.postMessage({
                            action: "login",
                            credentials: {
                                auth_token: e.auth_token,
                                user_id: e.user_id
                            }
                        }, "*"), h.Ay.IFRAME_SPORTSBOOK && (0, f.$i)("loggedIn"), h.Ay.LOGIN_LIMIT_POPUP && (0, T.as)()
                    },
                    updateAuthData: R,
                    isTwoFactorPopupVisible: S,
                    qrCodeOrigin: k
                }
            }
        },
        686130: (e, o, n) => {
            n.r(o), n.d(o, {
                MessageListener: () => h
            });
            var t = n(365043),
                i = n(507712),
                s = n(307022),
                a = n(995392),
                u = n(679559),
                r = n(179177),
                c = n(702044),
                l = n(626038),
                d = n(796410),
                _ = n(605060),
                m = n(115408),
                p = n(816343);
            const v = {
                    profile: {
                        accounts: "*",
                        settings: "*",
                        profile: "*"
                    },
                    documents: {
                        accounts: "*",
                        settings: "*",
                        documents: "*"
                    },
                    selfExclusion: {
                        accounts: "*",
                        settings: "*",
                        "self-exclusion": "*"
                    },
                    timeout: {
                        accounts: "*",
                        settings: "*",
                        timeout: "*"
                    },
                    password: {
                        accounts: "*",
                        settings: "*",
                        password: "*"
                    },
                    betHistory: {
                        accounts: "*",
                        "bet-history": "*"
                    },
                    deposit: {
                        accounts: "*",
                        wallet: "*",
                        deposit: "*"
                    },
                    balanceHistory: {
                        accounts: "*",
                        wallet: "*",
                        "balance-history": "*"
                    },
                    bonusSportsbook: {
                        accounts: "*",
                        bonuses: "*",
                        bonus: "*",
                        bonusType: "1"
                    },
                    bonusCasino: {
                        accounts: "*",
                        bonuses: "*",
                        bonus: "*",
                        bonusType: "2"
                    }
                },
                h = function() {
                    const e = (0, i.wA)(),
                        o = (0, c.d)(!0),
                        n = (0, l.N)(),
                        h = (0, m.A)(),
                        I = (0, a.W6)(),
                        g = (0, i.d4)(u.eP),
                        w = t => {
                            const {
                                data: i
                            } = t;
                            if ("login" === (null === i || void 0 === i ? void 0 : i.action) && null !== i && void 0 !== i && i.credentials && o({
                                    auth_token: i.credentials.auth_token,
                                    user_id: i.credentials.playerId
                                }), r.Ay.IFRAME_SPORTSBOOK) {
                                if ("logout" === (null === i || void 0 === i ? void 0 : i.action) && n(!0), "changeOddType" === (null === i || void 0 === i ? void 0 : i.action)) {
                                    const e = { ...(0, d.A)(_.z, "value", i.type, !1)
                                        },
                                        {
                                            id: o,
                                            value: n
                                        } = e;
                                    h(o, n)
                                }
                                "openProfile" === (null === i || void 0 === i ? void 0 : i.action) && null !== i && void 0 !== i && i.page && v[i.page] && ((0, p.qx)(), I.push((0, p.oR)(v[i.page])))
                            }
                            "https://vbet.com" === t.origin && "login" === (null === i || void 0 === i ? void 0 : i.action) && e((0, s.Vo)(!(null === i || void 0 === i || !i.params)))
                        };
                    return (0, t.useEffect)((() => (window.onmessage = w, () => {
                        window.onmessage = null
                    })), [g]), null
                }
        },
        702044: (e, o, n) => {
            n.d(o, {
                d: () => F
            });
            var t = n(365043),
                i = n(507712),
                s = n(995392),
                a = n(446987),
                u = n(307022),
                r = n(314100),
                c = n(322908),
                l = n.n(c),
                d = n(679559),
                _ = n(124634),
                m = n(841591),
                p = n(701616),
                v = n(550736),
                h = n(737536);
            const I = {},
                g = () => {
                    Object.keys(I).forEach((e => {
                        clearTimeout(I[e]), delete I[e]
                    }))
                },
                w = (e, o) => {
                    (0, v.S4)(h.y.GET_REMAINING_SESSION_DURATION.toUpperCase(), (n => {
                        let {
                            details: t
                        } = n;
                        const i = Object.values(t || {});
                        if (null !== i && void 0 !== i && i.length) {
                            const n = Math.min(...i);
                            Object.entries(t || {}).forEach((t => {
                                let [i, s] = t;
                                s === n && e[i] && !I[i] && ((e, n) => {
                                    I[e] = setTimeout((() => {
                                        o(e), g()
                                    }), 1e3 * n * 60)
                                })(i, s)
                            }))
                        }
                    }))
                };
            var A = n(462956),
                f = n(171224),
                T = n(49770),
                b = n(123213),
                S = n(816343),
                O = n(115837),
                k = n(556785),
                C = n(954947),
                N = n(179177),
                y = n(485138),
                E = n(626038),
                U = n(976376),
                R = n(759851);
            const F = function() {
                let e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                const o = (0, s.W6)(),
                    n = (0, i.wA)(),
                    c = (0, E.N)(),
                    v = (0, i.d4)(d.eP),
                    h = (0, i.d4)(m.h0),
                    I = (0, i.d4)((e => {
                        let {
                            socket: o
                        } = e;
                        return o.isConnected
                    })),
                    F = (0, i.d4)(A.gU),
                    M = (0, i.d4)(m.gh),
                    P = (0, i.d4)(d.c8),
                    {
                        loginWithFaceId: D
                    } = (0, U.R)(),
                    L = (0, t.useMemo)((() => !(0 === +(null === M || void 0 === M ? void 0 : M.rememberMeTick) || null !== F && void 0 !== F && F.single_login) && P), [null === M || void 0 === M ? void 0 : M.rememberMeTick, P, null === F || void 0 === F ? void 0 : F.single_login]),
                    {
                        jwe_token: W
                    } = (0, f.O)(),
                    x = (0, t.useCallback)((e => {
                        ["CUSTOM_CODE_REG_AFTER_REFRESH", "CUSTOM_CODE_LOGIN_AFTER_REFRESH"].forEach((o => {
                            const n = b.A.getItem((0, k.U)("account", o));
                            o && ((0, R.T)(n, e), b.A.removeItem((0, k.U)("account", o)))
                        })), e.active_time_in_casino && T.A.setItem((0, k.U)("account", "ACTIVE_TIME_IN_CASINO"), `${e.active_time_in_casino}`), n((0, r.O)((0, u.sX)(e), (0, u.Vo)(!0), (0, u.hB)(60 * (e.session_duration || 0)), (0, u.Xz)(!e.is_verified))), (0, C.A)(), N.Ay.PUSH_NOTIFICATIONS_ENABLED && (0, _.f)(), (0, y.y)({
                            type: "userId",
                            value: e.user_id
                        }), b.A.removeItem((0, k.U)("account", "SWITCH_MULTI_ACCOUNT"))
                    }), [n]);
                (0, t.useEffect)((() => {
                    if (!e && Number((null === M || void 0 === M ? void 0 : M.sessionLimits) || 0)) {
                        if (!v) return void g();
                        w({
                            RemainingDailyDuration: Number((null === M || void 0 === M ? void 0 : M.showDailySession) || 0),
                            RemainingWeeklyDuration: Number((null === M || void 0 === M ? void 0 : M.showWeeklySession) || 0),
                            RemainingMonthlyDuration: Number((null === M || void 0 === M ? void 0 : M.showMonthlySession) || 0)
                        }, (e => {
                            c(!0), n((0, p.mm)({
                                type: e,
                                isOpen: !0
                            }))
                        }))
                    }
                }), [M, v, e]);
                const G = () => {
                        (0, a.ZT)(), n((0, u.Sl)())
                    },
                    {
                        updateUser: H
                    } = (0, O.Q)(),
                    j = (0, t.useCallback)((function() {
                        let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null;
                        const n = JSON.parse(b.A.getItem((0, k.U)("account", "AUTH_DATA"))),
                            t = null === n || void 0 === n ? void 0 : n.auth_token,
                            i = L && W,
                            s = e || l().parse(o.location.search, {
                                ignoreQueryPrefix: !0
                            }),
                            u = null === h || void 0 === h ? void 0 : h.find((e => e && "personalId" === e.formType)),
                            r = !(!u || !u.editForm.showOnEditProfile || "2" !== u.editForm.personalIdType || "1" !== u.editForm.sendCPFAsDocNumber);
                        if (s.auth_token && s.user_id) {
                            const e = {
                                auth_token: s.auth_token,
                                user_id: Number(s.user_id)
                            };
                            o.replace((0, S.U7)({
                                auth_token: void 0,
                                user_id: void 0
                            })), (0, a.g6)(e, x, H, (() => G()), r)
                        } else i ? (0, a.g6)({
                            jwe_token: W,
                            auth_token: t
                        }, x, H, (() => G()), r) : t && (0, a.g6)(n, x, H, (() => G()), r);
                        v || t || i ? (s.login || s.register) && ((0, S.qx)(), o.replace((0, S.oR)({
                            accounts: "*",
                            profile: "*"
                        }))) : (s.settings || s.profile) && ((0, S.qx)(), o.replace((0, S.oR)({
                            accounts: "*",
                            login: "*"
                        })))
                    }), [v, x, L, h]);
                return (0, t.useEffect)((() => {
                    if (h && I && !e) {
                        var o;
                        const e = b.A.getItem("isWrapperFirstLaunch");
                        null !== (o = window.median) && void 0 !== o && o.auth && "null" !== e ? window.median.auth.status({
                            callbackFunction: e => {
                                e && e.hasTouchId && e.hasSecret ? (D(), b.A.removeItem("isWrapperFirstLaunch")) : j()
                            },
                            prompt: "PROMPT"
                        }) : j()
                    }
                }), [I, h]), j
            }
        },
        115837: (e, o, n) => {
            n.d(o, {
                Q: () => _
            });
            var t = n(507712),
                i = n(117893),
                s = n(464418),
                a = n(365043),
                u = n(841591),
                r = n(626038),
                c = n(123213),
                l = n(556785),
                d = n(179177);
            const _ = () => {
                const e = (0, t.wA)(),
                    o = (0, t.d4)(u.gh),
                    n = (0, r.N)(),
                    _ = (0, a.useCallback)((t => {
                        const a = c.A.getItem((0, l.U)("account", "SWITCH_MULTI_ACCOUNT"));
                        c.A.removeItem((0, l.U)("account", "SWITCH_MULTI_ACCOUNT")), t.logout && !JSON.parse(a) ? (+(null === o || void 0 === o ? void 0 : o.singleSignIn) || d.Ay.IS_MULTI_ACCOUNT_DISABLED) && n(!0) : (e((0, i.b6U)(t)), t.super_bet && (e((0, i.$5h)(t.super_bet)), e((0, s.wF)())))
                    }), [null === o || void 0 === o ? void 0 : o.singleSignIn]);
                return (0, a.useMemo)((() => ({
                    updateUser: _
                })), [_])
            }
        },
        954947: (e, o, n) => {
            n.d(o, {
                A: () => s
            });
            var t = n(446987),
                i = n(291372);
            const s = () => {
                const e = i.A.getState().appData.fireBaseToken;
                e && (0, t.NQ)(e)
            }
        },
        302258: (e, o, n) => {
            n.d(o, {
                Av: () => c,
                J3: () => u,
                as: () => l,
                ki: () => r
            });
            var t = n(860446),
                i = n.n(t),
                s = n(123213),
                a = n(556785);
            const u = e => (null !== e.first_name && null !== e.last_name ? `${e.first_name} ${e.last_name}` : e.username) || "",
                r = e => u(e).substr(0, 2).toUpperCase(),
                c = ["bonuses", "messages"],
                l = () => s.A.setItem((0, a.U)("account", "LOGIN_LIMIT_POPUP_START_TIME"), String(i()().unix()))
        }
    }
]);
//# sourceMappingURL=message-listener.6f53c428.chunk.js.map