"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [96771], {
        596771: (s, o, k) => {
            k.d(o, {
                y: () => t
            });
            const t = (0, k(446987).Ht)()
        }
    }
]);
//# sourceMappingURL=96771.1ae44959.chunk.js.map