"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [13695], {
        539425: (e, t, s) => {
            s.r(t), s.d(t, {
                AddToBetslipLink: () => A
            });
            var i = s(365043),
                o = s(995392),
                n = s(880279),
                a = s(123213),
                r = s(179177),
                _ = s(797760),
                c = s(435820),
                l = s(384716),
                p = s(200815),
                d = s(556785);
            const A = () => {
                const e = (0, l.o)(),
                    t = (0, o.zy)(),
                    [s, A] = (0, i.useState)(),
                    [$, m] = (0, i.useState)();
                (0, i.useEffect)((() => {
                    let e = a.A.getItem((0, d.U)("betslip", "ADD_TO_BETSLIP_DATA"));
                    t.pathname.includes(_.L.addToBetslip) ? (e = g(), e && S(e)) : JSON.parse(e) && O(e)
                }), []);
                const g = () => {
                        if (e.games && e.events) {
                            const t = JSON.stringify({
                                games: e.games,
                                events: e.events,
                                stake: e.stake,
                                is_racing: e.is_racing
                            });
                            return a.A.setItem((0, d.U)("betslip", "ADD_TO_BETSLIP_DATA"), t), t
                        }
                    },
                    S = e => {
                        const [t, s] = u(e);
                        t && s && (m(s), A(t))
                    };
                (0, i.useEffect)((() => {
                    s && $ && (0, n.J2)(null, T, void 0, void 0, s, $)
                }), [s]);
                const T = (0, i.useCallback)((e => {
                        const t = (0, p.DF)(e.data);
                        s && s.every((e => {
                            const s = t.find((t => t.gameId === e));
                            if (s) {
                                if (s.sport_id && c.T.includes(s.sport_id) && r.Ay.PAGE_URLS.racing) {
                                    const e = s.sport_id === c.d4.id ? c.d4.alias : c.cl.alias;
                                    return window.location.href = `${r.Ay.PAGE_URLS.racing}/${r.Ay.SPORTSBOOK_MOUNT_PATH}/${e}/${s.region_alias||s.region_name}/${s.competitionId}/${s.gameId}${window.location.search}`, !1
                                }
                                return 0 === s.sport_type && r.Ay.PAGE_URLS.esport ? (window.location.href = `${r.Ay.PAGE_URLS.esport}/${r.Ay.SPORTSBOOK_MOUNT_PATH}/${s.sport_alias}/${s.region_alias||s.region_name}/${s.competitionId}/${s.gameId}${window.location.search}`, !1) : 1 === s.type && r.Ay.PAGE_URLS.live ? (window.location.href = `${r.Ay.PAGE_URLS.live}/${r.Ay.SPORTSBOOK_MOUNT_PATH}/${s.sport_alias}/${s.region_alias||s.region_name}/${s.competitionId}/${s.gameId}${window.location.search}`, !1) : 2 !== s.type && 0 !== s.type || !r.Ay.PAGE_URLS.prematch || (window.location.href = `${r.Ay.PAGE_URLS.prematch}/${r.Ay.SPORTSBOOK_MOUNT_PATH}/${s.sport_alias}/${s.region_alias||s.region_name}/${s.competitionId}/${s.gameId}${window.location.search}`, !1)
                            }
                        }))
                    }), [s]),
                    u = e => {
                        const t = JSON.parse(e);
                        if (t.games) {
                            const e = t.games.split(",").map((e => parseInt(e)));
                            if (t.events) {
                                return [e, t.events.split(",").map((e => parseInt(e)))]
                            }
                        }
                        return [null, null]
                    },
                    O = e => {
                        const [t, s] = u(e);
                        t && s && (0, n.J2)(null, y, void 0, void 0, t, s)
                    },
                    y = e => {
                        const t = (0, p.DF)(e.data);
                        (0, p.aC)(t), a.A.removeItem((0, d.U)("betslip", "ADD_TO_BETSLIP_DATA"))
                    };
                return null
            }
        }
    }
]);
//# sourceMappingURL=add-to-betslip-link.d391ed31.chunk.js.map