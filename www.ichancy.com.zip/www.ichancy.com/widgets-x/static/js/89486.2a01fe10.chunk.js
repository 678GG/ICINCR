"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [89486], {
        479357: (e, a, l) => {
            var t = l(50130);
            Object.defineProperty(a, "__esModule", {
                value: !0
            }), a.default = void 0;
            var r = t(l(409004)).default;
            a.default = r
        },
        409004: (e, a, l) => {
            var t = l(50130);
            Object.defineProperty(a, "__esModule", {
                value: !0
            }), a.default = void 0;
            var r = t(l(319290)),
                o = t(l(568275)),
                n = t(l(802093)),
                d = {
                    lang: (0, r.default)({
                        placeholder: "\u0627\u062e\u062a\u064a\u0627\u0631 \u0627\u0644\u062a\u0627\u0631\u064a\u062e",
                        rangePlaceholder: ["\u0627\u0644\u0628\u062f\u0627\u064a\u0629", "\u0627\u0644\u0646\u0647\u0627\u064a\u0629"]
                    }, o.default),
                    timePickerLocale: (0, r.default)({}, n.default),
                    dateFormat: "DD-MM-YYYY",
                    monthFormat: "MM-YYYY",
                    dateTimeFormat: "DD-MM-YYYY HH:mm:ss",
                    weekFormat: "wo-YYYY"
                };
            a.default = d
        },
        989486: (e, a, l) => {
            var t = l(50130);
            Object.defineProperty(a, "__esModule", {
                value: !0
            }), a.default = void 0;
            var r = t(l(995409)),
                o = t(l(409004)),
                n = t(l(802093)),
                d = t(l(479357)),
                i = "\u0644\u064a\u0633 ${label} \u0645\u0646 \u0646\u0648\u0639 ${type} \u0635\u0627\u0644\u062d\u064b\u0627",
                m = {
                    locale: "ar",
                    Pagination: r.default,
                    DatePicker: o.default,
                    TimePicker: n.default,
                    Calendar: d.default,
                    global: {
                        placeholder: "\u064a\u0631\u062c\u0649 \u0627\u0644\u062a\u062d\u062f\u064a\u062f"
                    },
                    Table: {
                        filterTitle: "\u0627\u0644\u0641\u0644\u0627\u062a\u0631",
                        filterConfirm: "\u062a\u0623\u0643\u064a\u062f",
                        filterReset: "\u0625\u0639\u0627\u062f\u0629 \u0636\u0628\u0637",
                        selectAll: "\u0627\u062e\u062a\u064a\u0627\u0631 \u0627\u0644\u0643\u0644",
                        selectInvert: "\u0625\u0644\u063a\u0627\u0621 \u0627\u0644\u0627\u062e\u062a\u064a\u0627\u0631",
                        selectionAll: "\u062d\u062f\u062f \u062c\u0645\u064a\u0639 \u0627\u0644\u0628\u064a\u0627\u0646\u0627\u062a",
                        sortTitle: "\u0631\u062a\u0628",
                        expand: "\u062a\u0648\u0633\u064a\u0639 \u0627\u0644\u0635\u0641",
                        collapse: "\u0637\u064a \u0627\u0644\u0635\u0641",
                        triggerDesc: "\u062a\u0631\u062a\u064a\u0628 \u062a\u0646\u0627\u0632\u0644\u064a",
                        triggerAsc: "\u062a\u0631\u062a\u064a\u0628 \u062a\u0635\u0627\u0639\u062f\u064a",
                        cancelSort: "\u0625\u0644\u063a\u0627\u0621 \u0627\u0644\u062a\u0631\u062a\u064a\u0628"
                    },
                    Modal: {
                        okText: "\u062a\u0623\u0643\u064a\u062f",
                        cancelText: "\u0625\u0644\u063a\u0627\u0621",
                        justOkText: "\u062a\u0623\u0643\u064a\u062f"
                    },
                    Popconfirm: {
                        okText: "\u062a\u0623\u0643\u064a\u062f",
                        cancelText: "\u0625\u0644\u063a\u0627\u0621"
                    },
                    Transfer: {
                        searchPlaceholder: "\u0627\u0628\u062d\u062b \u0647\u0646\u0627",
                        itemUnit: "\u0639\u0646\u0635\u0631",
                        itemsUnit: "\u0639\u0646\u0627\u0635\u0631"
                    },
                    Upload: {
                        uploading: "\u062c\u0627\u0631\u064a \u0627\u0644\u0631\u0641\u0639...",
                        removeFile: "\u0627\u062d\u0630\u0641 \u0627\u0644\u0645\u0644\u0641",
                        uploadError: "\u0645\u0634\u0643\u0644\u0629 \u0641\u0649 \u0627\u0644\u0631\u0641\u0639",
                        previewFile: "\u0627\u0633\u062a\u0639\u0631\u0636 \u0627\u0644\u0645\u0644\u0641",
                        downloadFile: "\u062a\u062d\u0645\u064a\u0644 \u0627\u0644\u0645\u0644\u0641"
                    },
                    Empty: {
                        description: "\u0644\u0627 \u062a\u0648\u062c\u062f \u0628\u064a\u0627\u0646\u0627\u062a"
                    },
                    Icon: {
                        icon: "\u0623\u064a\u0642\u0648\u0646\u0629"
                    },
                    Text: {
                        edit: "\u062a\u0639\u062f\u064a\u0644",
                        copy: "\u0646\u0633\u062e",
                        copied: "\u0646\u0642\u0644",
                        expand: "\u0648\u0633\u0639"
                    },
                    PageHeader: {
                        back: "\u0639\u0648\u062f\u0629"
                    },
                    Form: {
                        defaultValidateMessages: {
                            default: "\u062e\u0637\u0623 \u0641\u064a \u062d\u0642\u0644 \u0627\u0644\u0625\u062f\u062e\u0627\u0644 ${label}",
                            required: "\u064a\u0631\u062c\u0649 \u0625\u062f\u062e\u0627\u0644 ${label}",
                            enum: "${label} \u064a\u062c\u0628 \u0623\u0646 \u064a\u0643\u0648\u0646 \u0648\u0627\u062d\u062f\u0627 \u0645\u0646 [${enum}]",
                            whitespace: "${label} \u0644\u0627 \u064a\u0645\u0643\u0646 \u0623\u0646 \u064a\u0643\u0648\u0646 \u062d\u0631\u0641\u064b\u0627 \u0641\u0627\u0631\u063a\u064b\u0627",
                            date: {
                                format: "${label} \u062a\u0646\u0633\u064a\u0642 \u0627\u0644\u062a\u0627\u0631\u064a\u062e \u063a\u064a\u0631 \u0635\u062d\u064a\u062d",
                                parse: "${label} \u0644\u0627 \u064a\u0645\u0643\u0646 \u062a\u062d\u0648\u064a\u0644\u0647\u0627 \u0625\u0644\u0649 \u062a\u0627\u0631\u064a\u062e",
                                invalid: "\u062a\u0627\u0631\u064a\u062e ${label} \u063a\u064a\u0631 \u0635\u062d\u064a\u062d"
                            },
                            types: {
                                string: i,
                                method: i,
                                array: i,
                                object: i,
                                number: i,
                                date: i,
                                boolean: i,
                                integer: i,
                                float: i,
                                regexp: i,
                                email: i,
                                url: i,
                                hex: i
                            },
                            string: {
                                len: "\u064a\u062c\u0628 ${label} \u0627\u0646 \u064a\u0643\u0648\u0646 ${len} \u0623\u062d\u0631\u0641",
                                min: "${label} \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644 ${min} \u0623\u062d\u0631\u0641",
                                max: "${label} \u064a\u0635\u0644 \u0625\u0644\u0649 ${max} \u0623\u062d\u0631\u0641",
                                range: "\u064a\u062c\u0628 ${label} \u0627\u0646 \u064a\u0643\u0648\u0646 \u0645\u0627\u0628\u064a\u0646 ${min}-${max} \u0623\u062d\u0631\u0641"
                            },
                            number: {
                                len: "${len} \u0627\u0646 \u064a\u0633\u0627\u0648\u064a ${label} \u064a\u062c\u0628",
                                min: "${min} \u0627\u0644\u0623\u062f\u0646\u0649 \u0647\u0648 ${label} \u062d\u062f",
                                max: "${max} \u0627\u0644\u0623\u0642\u0635\u0649 \u0647\u0648 ${label} \u062d\u062f",
                                range: "${max}-${min} \u0627\u0646 \u064a\u0643\u0648\u0646 \u0645\u0627\u0628\u064a\u0646 ${label} \u064a\u062c\u0628"
                            },
                            array: {
                                len: "\u064a\u062c\u0628 \u0623\u0646 \u064a\u0643\u0648\u0646 ${label} \u0637\u0648\u0644\u0647 ${len}",
                                min: "\u064a\u062c\u0628 \u0623\u0646 \u064a\u0643\u0648\u0646 ${label} \u0637\u0648\u0644\u0647 \u0627\u0644\u0623\u062f\u0646\u0649 ${min}",
                                max: "\u064a\u062c\u0628 \u0623\u0646 \u064a\u0643\u0648\u0646 ${label} \u0637\u0648\u0644\u0647 \u0627\u0644\u0623\u0642\u0635\u0649 ${max}",
                                range: "\u064a\u062c\u0628 \u0623\u0646 \u064a\u0643\u0648\u0646 ${label} \u0637\u0648\u0644\u0647 \u0645\u0627\u0628\u064a\u0646 ${min}-${max}"
                            },
                            pattern: {
                                mismatch: "\u0644\u0627 \u064a\u062a\u0637\u0627\u0628\u0642 ${label} \u0645\u0639 ${pattern}"
                            }
                        }
                    }
                };
            a.default = m
        },
        802093: (e, a) => {
            Object.defineProperty(a, "__esModule", {
                value: !0
            }), a.default = void 0;
            var l = {
                placeholder: "\u0627\u062e\u062a\u064a\u0627\u0631 \u0627\u0644\u0648\u0642\u062a"
            };
            a.default = l
        },
        995409: (e, a) => {
            Object.defineProperty(a, "__esModule", {
                value: !0
            }), a.default = void 0;
            a.default = {
                items_per_page: "/ \u0627\u0644\u0635\u0641\u062d\u0629",
                jump_to: "\u0627\u0644\u0630\u0647\u0627\u0628 \u0625\u0644\u0649",
                jump_to_confirm: "\u062a\u0623\u0643\u064a\u062f",
                page: "\u0627\u0644\u0635\u0641\u062d\u0629",
                prev_page: "\u0627\u0644\u0635\u0641\u062d\u0629 \u0627\u0644\u0633\u0627\u0628\u0642\u0629",
                next_page: "\u0627\u0644\u0635\u0641\u062d\u0629 \u0627\u0644\u062a\u0627\u0644\u064a\u0629",
                prev_5: "\u062e\u0645\u0633 \u0635\u0641\u062d\u0627\u062a \u0633\u0627\u0628\u0642\u0629",
                next_5: "\u062e\u0645\u0633 \u0635\u0641\u062d\u0627\u062a \u062a\u0627\u0644\u064a\u0629",
                prev_3: "\u062b\u0644\u0627\u062b \u0635\u0641\u062d\u0627\u062a \u0633\u0627\u0628\u0642\u0629",
                next_3: "\u062b\u0644\u0627\u062b \u0635\u0641\u062d\u0627\u062a \u062a\u0627\u0644\u064a\u0629",
                page_size: "\u0645\u0642\u0627\u0633 \u0627\u0644\u0635\u0641\u062d\u0647"
            }
        },
        568275: (e, a) => {
            Object.defineProperty(a, "__esModule", {
                value: !0
            }), a.default = void 0;
            var l = {
                locale: "ar_EG",
                today: "\u0627\u0644\u064a\u0648\u0645",
                now: "\u0627\u0644\u0623\u0646",
                backToToday: "\u0627\u0644\u0639\u0648\u062f\u0629 \u0625\u0644\u0649 \u0627\u0644\u064a\u0648\u0645",
                ok: "\u062a\u0623\u0643\u064a\u062f",
                clear: "\u0645\u0633\u062d",
                month: "\u0627\u0644\u0634\u0647\u0631",
                year: "\u0627\u0644\u0633\u0646\u0629",
                timeSelect: "\u0627\u062e\u062a\u064a\u0627\u0631 \u0627\u0644\u0648\u0642\u062a",
                dateSelect: "\u0627\u062e\u062a\u064a\u0627\u0631 \u0627\u0644\u062a\u0627\u0631\u064a\u062e",
                monthSelect: "\u0627\u062e\u062a\u064a\u0627\u0631 \u0627\u0644\u0634\u0647\u0631",
                yearSelect: "\u0627\u062e\u062a\u064a\u0627\u0631 \u0627\u0644\u0633\u0646\u0629",
                decadeSelect: "\u0627\u062e\u062a\u064a\u0627\u0631 \u0627\u0644\u0639\u0642\u062f",
                yearFormat: "YYYY",
                dateFormat: "M/D/YYYY",
                dayFormat: "D",
                dateTimeFormat: "M/D/YYYY HH:mm:ss",
                monthBeforeYear: !0,
                previousMonth: "\u0627\u0644\u0634\u0647\u0631 \u0627\u0644\u0633\u0627\u0628\u0642 (PageUp)",
                nextMonth: "\u0627\u0644\u0634\u0647\u0631 \u0627\u0644\u062a\u0627\u0644\u0649(PageDown)",
                previousYear: "\u0627\u0644\u0639\u0627\u0645 \u0627\u0644\u0633\u0627\u0628\u0642 (Control + left)",
                nextYear: "\u0627\u0644\u0639\u0627\u0645 \u0627\u0644\u062a\u0627\u0644\u0649 (Control + right)",
                previousDecade: "\u0627\u0644\u0639\u0642\u062f \u0627\u0644\u0633\u0627\u0628\u0642",
                nextDecade: "\u0627\u0644\u0639\u0642\u062f \u0627\u0644\u062a\u0627\u0644\u0649",
                previousCentury: "\u0627\u0644\u0642\u0631\u0646 \u0627\u0644\u0633\u0627\u0628\u0642",
                nextCentury: "\u0627\u0644\u0642\u0631\u0646 \u0627\u0644\u062a\u0627\u0644\u0649"
            };
            a.default = l
        }
    }
]);
//# sourceMappingURL=89486.2a01fe10.chunk.js.map