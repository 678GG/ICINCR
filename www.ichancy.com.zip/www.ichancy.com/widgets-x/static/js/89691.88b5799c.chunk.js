"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [89691], {
        909765: (e, t, r) => {
            var n = r(487066);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = t.SizeContextProvider = void 0;
            var a = function(e, t) {
                if (!t && e && e.__esModule) return e;
                if (null === e || "object" !== n(e) && "function" !== typeof e) return {
                    default: e
                };
                var r = o(t);
                if (r && r.has(e)) return r.get(e);
                var a = {},
                    l = Object.defineProperty && Object.getOwnPropertyDescriptor;
                for (var c in e)
                    if ("default" !== c && Object.prototype.hasOwnProperty.call(e, c)) {
                        var u = l ? Object.getOwnPropertyDescriptor(e, c) : null;
                        u && (u.get || u.set) ? Object.defineProperty(a, c, u) : a[c] = e[c]
                    }
                a.default = e, r && r.set(e, a);
                return a
            }(r(365043));

            function o(e) {
                if ("function" !== typeof WeakMap) return null;
                var t = new WeakMap,
                    r = new WeakMap;
                return (o = function(e) {
                    return e ? r : t
                })(e)
            }
            var l = a.createContext("default");
            t.SizeContextProvider = function(e) {
                var t = e.children,
                    r = e.size;
                return a.createElement(l.Consumer, null, (function(e) {
                    return a.createElement(l.Provider, {
                        value: r || e
                    }, t)
                }))
            };
            var c = l;
            t.default = c
        },
        691200: (e, t, r) => {
            var n = r(50130),
                a = r(487066);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = n(r(319290)),
                l = n(r(329085)),
                c = n(r(487066)),
                u = n(r(579459)),
                f = function(e, t) {
                    if (!t && e && e.__esModule) return e;
                    if (null === e || "object" !== a(e) && "function" !== typeof e) return {
                        default: e
                    };
                    var r = g(t);
                    if (r && r.has(e)) return r.get(e);
                    var n = {},
                        o = Object.defineProperty && Object.getOwnPropertyDescriptor;
                    for (var l in e)
                        if ("default" !== l && Object.prototype.hasOwnProperty.call(e, l)) {
                            var c = o ? Object.getOwnPropertyDescriptor(e, l) : null;
                            c && (c.get || c.set) ? Object.defineProperty(n, l, c) : n[l] = e[l]
                        }
                    n.default = e, r && r.set(e, n);
                    return n
                }(r(365043)),
                i = n(r(498139)),
                s = n(r(770289)),
                d = r(371147),
                p = r(445600),
                v = (n(r(697497)), r(390363)),
                y = n(r(885123)),
                m = n(r(909765));

            function g(e) {
                if ("function" !== typeof WeakMap) return null;
                var t = new WeakMap,
                    r = new WeakMap;
                return (g = function(e) {
                    return e ? r : t
                })(e)
            }
            var b = function(e, t) {
                    var r = {};
                    for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && t.indexOf(n) < 0 && (r[n] = e[n]);
                    if (null != e && "function" === typeof Object.getOwnPropertySymbols) {
                        var a = 0;
                        for (n = Object.getOwnPropertySymbols(e); a < n.length; a++) t.indexOf(n[a]) < 0 && Object.prototype.propertyIsEnumerable.call(e, n[a]) && (r[n[a]] = e[n[a]])
                    }
                    return r
                },
                O = function(e, t) {
                    var r, n, a = f.useContext(m.default),
                        g = f.useState(1),
                        O = (0, u.default)(g, 2),
                        h = O[0],
                        P = O[1],
                        j = f.useState(!1),
                        x = (0, u.default)(j, 2),
                        w = x[0],
                        C = x[1],
                        E = f.useState(!0),
                        k = (0, u.default)(E, 2),
                        M = k[0],
                        _ = k[1],
                        S = f.useRef(),
                        z = f.useRef(),
                        W = (0, d.composeRef)(t, S),
                        N = f.useContext(p.ConfigContext).getPrefixCls,
                        D = function() {
                            if (z.current && S.current) {
                                var t = z.current.offsetWidth,
                                    r = S.current.offsetWidth;
                                if (0 !== t && 0 !== r) {
                                    var n = e.gap,
                                        a = void 0 === n ? 4 : n;
                                    2 * a < r && P(r - 2 * a < t ? (r - 2 * a) / t : 1)
                                }
                            }
                        };
                    f.useEffect((function() {
                        C(!0)
                    }), []), f.useEffect((function() {
                        _(!0), P(1)
                    }), [e.src]), f.useEffect((function() {
                        D()
                    }), [e.gap]);
                    var R, A = e.prefixCls,
                        H = e.shape,
                        T = e.size,
                        G = e.src,
                        I = e.srcSet,
                        V = e.icon,
                        X = e.className,
                        q = e.alt,
                        B = e.draggable,
                        F = e.children,
                        J = e.crossOrigin,
                        K = b(e, ["prefixCls", "shape", "size", "src", "srcSet", "icon", "className", "alt", "draggable", "children", "crossOrigin"]),
                        L = "default" === T ? a : T,
                        Q = Object.keys("object" === (0, c.default)(L) && L || {}).some((function(e) {
                            return ["xs", "sm", "md", "lg", "xl", "xxl"].includes(e)
                        })),
                        U = (0, y.default)(Q),
                        Y = f.useMemo((function() {
                            if ("object" !== (0, c.default)(L)) return {};
                            var e = v.responsiveArray.find((function(e) {
                                    return U[e]
                                })),
                                t = L[e];
                            return t ? {
                                width: t,
                                height: t,
                                lineHeight: "".concat(t, "px"),
                                fontSize: V ? t / 2 : 18
                            } : {}
                        }), [U, L]),
                        Z = N("avatar", A),
                        $ = (0, i.default)((r = {}, (0, l.default)(r, "".concat(Z, "-lg"), "large" === L), (0, l.default)(r, "".concat(Z, "-sm"), "small" === L), r)),
                        ee = f.isValidElement(G),
                        te = (0, i.default)(Z, $, (n = {}, (0, l.default)(n, "".concat(Z, "-").concat(H), !!H), (0, l.default)(n, "".concat(Z, "-image"), ee || G && M), (0, l.default)(n, "".concat(Z, "-icon"), !!V), n), X),
                        re = "number" === typeof L ? {
                            width: L,
                            height: L,
                            lineHeight: "".concat(L, "px"),
                            fontSize: V ? L / 2 : 18
                        } : {};
                    if ("string" === typeof G && M) R = f.createElement("img", {
                        src: G,
                        draggable: B,
                        srcSet: I,
                        onError: function() {
                            var t = e.onError;
                            !1 !== (t ? t() : void 0) && _(!1)
                        },
                        alt: q,
                        crossOrigin: J
                    });
                    else if (ee) R = G;
                    else if (V) R = V;
                    else if (w || 1 !== h) {
                        var ne = "scale(".concat(h, ") translateX(-50%)"),
                            ae = {
                                msTransform: ne,
                                WebkitTransform: ne,
                                transform: ne
                            },
                            oe = "number" === typeof L ? {
                                lineHeight: "".concat(L, "px")
                            } : {};
                        R = f.createElement(s.default, {
                            onResize: D
                        }, f.createElement("span", {
                            className: "".concat(Z, "-string"),
                            ref: function(e) {
                                z.current = e
                            },
                            style: (0, o.default)((0, o.default)({}, oe), ae)
                        }, F))
                    } else R = f.createElement("span", {
                        className: "".concat(Z, "-string"),
                        style: {
                            opacity: 0
                        },
                        ref: function(e) {
                            z.current = e
                        }
                    }, F);
                    return delete K.onError, delete K.gap, f.createElement("span", (0, o.default)({}, K, {
                        style: (0, o.default)((0, o.default)((0, o.default)({}, re), Y), K.style),
                        className: te,
                        ref: W
                    }), R)
                },
                h = f.forwardRef(O);
            h.displayName = "Avatar", h.defaultProps = {
                shape: "circle",
                size: "default"
            };
            var P = h;
            t.default = P
        },
        756542: (e, t, r) => {
            var n = r(50130),
                a = r(487066);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = n(r(329085)),
                l = function(e, t) {
                    if (!t && e && e.__esModule) return e;
                    if (null === e || "object" !== a(e) && "function" !== typeof e) return {
                        default: e
                    };
                    var r = v(t);
                    if (r && r.has(e)) return r.get(e);
                    var n = {},
                        o = Object.defineProperty && Object.getOwnPropertyDescriptor;
                    for (var l in e)
                        if ("default" !== l && Object.prototype.hasOwnProperty.call(e, l)) {
                            var c = o ? Object.getOwnPropertyDescriptor(e, l) : null;
                            c && (c.get || c.set) ? Object.defineProperty(n, l, c) : n[l] = e[l]
                        }
                    n.default = e, r && r.set(e, n);
                    return n
                }(r(365043)),
                c = n(r(498139)),
                u = n(r(436046)),
                f = r(853590),
                i = r(445600),
                s = n(r(691200)),
                d = n(r(69661)),
                p = r(909765);

            function v(e) {
                if ("function" !== typeof WeakMap) return null;
                var t = new WeakMap,
                    r = new WeakMap;
                return (v = function(e) {
                    return e ? r : t
                })(e)
            }
            var y = function(e) {
                var t = l.useContext(i.ConfigContext),
                    r = t.getPrefixCls,
                    n = t.direction,
                    a = e.prefixCls,
                    v = e.className,
                    y = void 0 === v ? "" : v,
                    m = e.maxCount,
                    g = e.maxStyle,
                    b = e.size,
                    O = r("avatar-group", a),
                    h = (0, c.default)(O, (0, o.default)({}, "".concat(O, "-rtl"), "rtl" === n), y),
                    P = e.children,
                    j = e.maxPopoverPlacement,
                    x = void 0 === j ? "top" : j,
                    w = e.maxPopoverTrigger,
                    C = void 0 === w ? "hover" : w,
                    E = (0, u.default)(P).map((function(e, t) {
                        return (0, f.cloneElement)(e, {
                            key: "avatar-key-".concat(t)
                        })
                    })),
                    k = E.length;
                if (m && m < k) {
                    var M = E.slice(0, m),
                        _ = E.slice(m, k);
                    return M.push(l.createElement(d.default, {
                        key: "avatar-popover-key",
                        content: _,
                        trigger: C,
                        placement: x,
                        overlayClassName: "".concat(O, "-popover")
                    }, l.createElement(s.default, {
                        style: g
                    }, "+".concat(k - m)))), l.createElement(p.SizeContextProvider, {
                        size: b
                    }, l.createElement("div", {
                        className: h,
                        style: e.style
                    }, M))
                }
                return l.createElement(p.SizeContextProvider, {
                    size: b
                }, l.createElement("div", {
                    className: h,
                    style: e.style
                }, E))
            };
            t.default = y
        },
        804473: (e, t, r) => {
            var n = r(50130);
            t.Ay = void 0;
            var a = n(r(691200)),
                o = n(r(756542)),
                l = a.default;
            l.Group = o.default;
            var c = l;
            t.Ay = c
        },
        864099: (e, t, r) => {
            r(628035), r(12802), r(50999)
        },
        12802: (e, t, r) => {
            r.r(t), r.d(t, {
                default: () => n
            });
            const n = {}
        }
    }
]);
//# sourceMappingURL=89691.88b5799c.chunk.js.map