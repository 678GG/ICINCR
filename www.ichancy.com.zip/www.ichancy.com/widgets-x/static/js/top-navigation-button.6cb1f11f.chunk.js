"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [97972], {
        913829: (t, e, o) => {
            o.d(e, {
                VG: () => u,
                eG: () => d,
                hs: () => a
            });
            var n = o(253220);
            const r = {
                    left: "24px"
                },
                c = {
                    right: "24px"
                },
                s = {
                    left: "calc(50% - 24px)"
                },
                l = {
                    bottom: `${n.s6+24}px`
                },
                i = {
                    "bottom-left": { ...l,
                        ...r
                    },
                    "bottom-center": { ...l,
                        ...s
                    },
                    "bottom-right": { ...l,
                        ...c
                    },
                    left: { ...r
                    },
                    center: { ...s
                    },
                    right: { ...c
                    }
                },
                a = function(t, e) {
                    return "top" === t ? { ...i[e],
                        [t]: `${(arguments.length>2&&void 0!==arguments[2]?arguments[2]:150)+24}px`
                    } : i[`${t}-${e}`]
                },
                u = function(t) {
                    let e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
                        o = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "smooth";
                    t.preventDefault(), document.body.scrollTo({
                        top: e,
                        behavior: o
                    }), document.documentElement.scrollTo({
                        top: e,
                        behavior: o
                    })
                },
                d = function(t) {
                    u(t, 0, arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "smooth")
                }
        },
        66197: (t, e, o) => {
            o.r(e), o.d(e, {
                TopNavigationButton: () => m
            });
            var n = o(55418),
                r = o(179177),
                c = o(365043),
                s = o(889181),
                l = o(507712),
                i = o(273549),
                a = o(735905),
                u = o(913829),
                d = o(570579);
            const {
                TOP_NAVIGATION_BUTTON_POSITION: p,
                TOP_NAVIGATION_BUTTON_ALIGNMENT: T
            } = r.Ay, v = () => {
                const t = (0, l.d4)(i.co),
                    e = (0, l.d4)(i.Co),
                    o = (0, l.d4)(i.zN),
                    v = (0, c.useRef)(null),
                    [m, h] = (0, c.useState)(0),
                    [b, N] = (0, c.useState)(null),
                    A = (0, c.useMemo)((() => (0, n.F)() && (e || t)), [e, t]);
                return (0, c.useEffect)((() => {
                    A && b && (N(!1), clearTimeout(v.current))
                }), [A]), (0, c.useEffect)((() => {
                    const t = () => {
                        const t = document.body.scrollTop > 100 || document.documentElement.scrollTop > 100;
                        N((e => !!e !== t ? t : e)), v.current && clearTimeout(v.current), v.current = setTimeout((() => {
                            N(!1)
                        }), 4e3);
                        const e = document.querySelector("header.header-rows");
                        e && e.classList.contains("header-sticky") && h(e.clientHeight || e.offsetHeight)
                    };
                    return document.addEventListener("scroll", t), () => {
                        clearTimeout(v.current), document.removeEventListener("scroll", t)
                    }
                }), []), (0, d.jsx)("div", {
                    style: (0, u.hs)(T, p, m),
                    onClick: u.eG,
                    className: (0, s.A)(["v3-top-navigation-button-wrapper", {
                        "v3-top-navigation-button-wrapper--hidden": !1 === b,
                        "v3-top-navigation-button-wrapper--active": b,
                        "v3-top-navigation-button-wrapper--betsTotalOdds": o && r.Ay.BOTTOM_NAVIGATION,
                        "v3-top-navigation-button-wrapper--betsTotalOddsActive": o && !r.Ay.BOTTOM_NAVIGATION
                    }]),
                    children: (0, d.jsx)(a.GlobalIcon, {
                        lib: "generic",
                        name: "navigationArrowUp",
                        theme: "default",
                        size: 20
                    })
                })
            }, m = () => (0, n.F)() && r.Ay.IS_TOP_NAVIGATION_BUTTON_ENABLED ? (0, d.jsx)(v, {}) : null
        }
    }
]);
//# sourceMappingURL=top-navigation-button.6cb1f11f.chunk.js.map