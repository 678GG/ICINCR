"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [26921, 76790, 24757, 95459, 42146, 10795, 90286, 71139, 41591, 82463, 17893, 24541, 83573, 68392, 62956, 1891, 55606, 64833, 48070, 91338, 6683, 71237, 10771, 9491, 34364, 3266, 31746, 940, 51712], {
        486490: (e, t, a) => {
            a.r(t), a.d(t, {
                CasinoGameContext: () => I,
                CasinoGamePreview: () => P
            });
            var n = a(365043),
                i = a(995392),
                o = a(595459),
                l = a(870905),
                s = a(507712),
                r = a(542699),
                c = a(791338),
                d = a(890286),
                m = a(322908),
                p = a.n(m),
                _ = a(55418),
                u = a(884848),
                y = a(190797),
                S = (a(270757), a(694227)),
                T = (a(53124), a(570579));
            const g = () => (0, T.jsxs)(T.Fragment, {
                children: [(0, T.jsx)("div", {
                    className: "csItemPreview__image",
                    children: (0, T.jsx)(S.A.Image, {
                        style: {
                            width: "180px",
                            height: "120px"
                        }
                    })
                }), (0, T.jsx)("div", {
                    className: "csItemPreview__gameName",
                    children: (0, T.jsx)(S.A, {
                        title: {
                            style: {
                                width: "50%",
                                margin: "0 auto",
                                height: 25
                            }
                        },
                        paragraph: !1,
                        active: !0
                    })
                }), (0, T.jsx)("div", {
                    className: "csItemPreview__providerName",
                    children: (0, T.jsx)(S.A, {
                        title: {
                            style: {
                                width: "30%",
                                margin: "0 auto",
                                height: 12
                            }
                        },
                        paragraph: !1,
                        active: !0
                    })
                })]
            });
            var h = a(679559),
                E = a(179177);
            const A = () => {
                const e = (0, s.d4)(h.eP);
                return (0, T.jsxs)(T.Fragment, {
                    children: [(!E.Ay.CASINO_DISABLE_FUN_MODE || e) && E.Ay.CASINO_FUN_MODE && (0, T.jsx)(S.A, {
                        title: {
                            style: {
                                width: "100%",
                                margin: "0 auto",
                                height: 40
                            }
                        },
                        paragraph: !1,
                        active: !0
                    }), (0, T.jsx)(S.A, {
                        title: {
                            style: {
                                width: "100%",
                                margin: "8px auto 0",
                                height: 40
                            }
                        },
                        paragraph: !1,
                        active: !0
                    })]
                })
            };
            var v = a(424757),
                b = a(816343),
                f = a(490440),
                N = a(989618),
                O = a(384716);
            const I = (0, n.createContext)(null),
                {
                    GameDetailsBlock: C
                } = (0, N.R)((() => a.e(29388).then(a.bind(a, 92821)))),
                {
                    GameTournaments: M
                } = (0, N.R)((() => Promise.all([a.e(68843), a.e(46179), a.e(99384), a.e(55113), a.e(78788), a.e(26889), a.e(84810)]).then(a.bind(a, 187565)))),
                {
                    GameJackpot: R
                } = (0, N.R)((() => Promise.all([a.e(61190), a.e(42828), a.e(24541), a.e(25040), a.e(68392), a.e(62956), a.e(59620), a.e(89215), a.e(24756)]).then(a.bind(a, 848046)))),
                {
                    Buttons: D
                } = (0, N.R)((() => Promise.all([a.e(42146), a.e(10795), a.e(71139), a.e(17893), a.e(97760), a.e(62330), a.e(89910), a.e(96771), a.e(18056), a.e(6327), a.e(13900), a.e(44148), a.e(35573)]).then(a.bind(a, 760647)))),
                P = (0, n.memo)((() => {
                    var e, t;
                    const [a, m] = (0, n.useState)(!1), S = (0, s.d4)(r.v), h = (0, s.wA)(), N = (0, i.W6)(), {
                        t: P
                    } = (0, l.B)(), {
                        mounted: x
                    } = (0, f.q)(), {
                        params: w
                    } = (0, o.d)(), {
                        gameId: G
                    } = (0, O.o)(), L = G || w.game, k = p().parse(N.location.search, {
                        ignoreQueryPrefix: !0
                    }), B = E.Ay.CASINO_HIGH_QUALITY_PICTURES && null !== S && void 0 !== S && S.icon_3 ? null === S || void 0 === S ? void 0 : S.icon_3 : (0, _.F)() ? null === S || void 0 === S ? void 0 : S.icon_1 : null === S || void 0 === S ? void 0 : S.icon_2;
                    return (0, n.useEffect)((() => {
                        null !== k && void 0 !== k && k.tournamentId ? m(!1) : (L || m(!1), S && !a && L ? m(!0) : L && (0, _.F)() && !w.mode && (0, c.mb)({
                            by_key: "id",
                            id: L
                        }).then((e => {
                            if (e) {
                                var t;
                                const a = null === (t = e[0]) || void 0 === t ? void 0 : t[1];
                                h((0, d.$s)(a)), x.current && m(!0)
                            }
                        })))
                    }), [L, window.location.search]), (0, T.jsx)(u.t, {
                        selectedGame: S,
                        externalGameId: null === S || void 0 === S ? void 0 : S.extearnal_game_id,
                        thumbnail: B,
                        background: null === S || void 0 === S ? void 0 : S.background,
                        name: null === S || void 0 === S ? void 0 : S.name,
                        description: null === S || void 0 === S ? void 0 : S.description,
                        visible: a,
                        onClose: () => {
                            m(!1);
                            const e = (0, b.XZ)("casinoStartingRoute");
                            e && e !== window.location.pathname ? (N.push(e), (0, b.XZ)("casinoSingleGame")) : N.push({
                                pathname: `${(0,v.ic)(window.getPathname(),!1,!0)}/${w.gameCategory}`,
                                search: window.location.search
                            })
                        },
                        likeFunctionality: !0,
                        menu: [{
                            key: "info",
                            title: P("casino.info"),
                            content: (0, T.jsx)(y.VY, {
                                children: (null === S || void 0 === S ? void 0 : S.description) || P("casino.noInformation")
                            })
                        }, {
                            key: "tournament",
                            title: P("casino.tournament"),
                            content: S && (0, T.jsx)(I.Provider, {
                                value: m,
                                children: (0, T.jsx)(n.Suspense, {
                                    children: (0, T.jsx)(M, {
                                        externalGameId: S.extearnal_game_id
                                    })
                                })
                            })
                        }, {
                            key: "jackpot",
                            title: P("casino.jackpotTab"),
                            content: S && (0, T.jsx)(n.Suspense, {
                                children: (0, T.jsx)(R, {
                                    gameId: S.extearnal_game_id
                                })
                            })
                        }],
                        detailsBlock: (0, T.jsx)(n.Suspense, {
                            fallback: (0, T.jsx)(g, {}),
                            children: (0, T.jsx)(C, {
                                name: null !== (e = null === S || void 0 === S ? void 0 : S.name) && void 0 !== e ? e : "",
                                provider: null !== (t = null === S || void 0 === S ? void 0 : S.provider) && void 0 !== t ? t : "",
                                thumbnail: B
                            })
                        }),
                        buttons: (0, T.jsx)(n.Suspense, {
                            fallback: (0, T.jsx)(A, {}),
                            children: (0, T.jsx)(D, {
                                game: S
                            })
                        })
                    })
                }))
        },
        884848: (e, t, a) => {
            a.d(t, {
                t: () => _
            });
            var n = a(365043),
                i = a(507712),
                o = a(841591),
                l = a(384716),
                s = a(855606),
                r = a(179177),
                c = a(989618),
                d = a(787154),
                m = a(570579);
            r.Ay.IS_RTL && a.e(81690).then(a.bind(a, 781690));
            const {
                Content: p
            } = (0, c.R)((() => Promise.all([a.e(80192), a.e(65506), a.e(71139), a.e(78395), a.e(17893), a.e(83573), a.e(70990), a.e(77254), a.e(75949), a.e(19429)]).then(a.bind(a, 435103)))), _ = e => {
                const {
                    thumbnail: t,
                    background: a,
                    name: r,
                    visible: c,
                    onClose: _,
                    likeFunctionality: u,
                    menu: y,
                    detailsBlock: S,
                    buttons: T,
                    isTournaments: g,
                    externalGameId: h,
                    selectedGame: E
                } = e, [A, v] = (0, n.useState)("info"), {
                    game: b
                } = (0, l.o)(), f = (0, i.d4)(o.yX);
                return (0, n.useEffect)((() => {
                    b && g && v("games")
                }), [b]), (0, n.useEffect)((() => {
                    c || g || v("info")
                }), [c]), (0, m.jsx)(s.z, {
                    className: c ? "casino__game-popup" : "",
                    open: c,
                    animationType: "toTop",
                    style: {
                        zIndex: f ? d.uG : 13
                    },
                    children: c && (0, m.jsx)(n.Suspense, {
                        children: (0, m.jsx)(p, {
                            name: r,
                            onClose: _,
                            likeFunctionality: u,
                            background: a,
                            thumbnail: t,
                            detailsBlock: S,
                            activeTab: A,
                            setActiveTab: v,
                            menu: y,
                            buttons: T,
                            externalGameId: h,
                            selectedGame: E
                        })
                    })
                })
            }
        },
        190797: (e, t, a) => {
            a.d(t, {
                VY: () => d,
                Y9: () => i,
                YT: () => l,
                hE: () => o,
                mO: () => s,
                mc: () => c,
                yp: () => r
            });
            var n = a(294574);
            const i = n.Ay.div.withConfig({
                    displayName: "style__Header",
                    componentId: "sc-1yg5frv-0"
                })(["top:0;z-index:2;min-height:40px;display:flex;padding:0 12px;position:sticky;flex-direction:row;align-items:center;background-color:var(--v3-black-0);box-shadow:var(--v3-shadow-1-down);"]),
                o = n.Ay.div.withConfig({
                    displayName: "style__Title",
                    componentId: "sc-1yg5frv-1"
                })(["flex:1;padding-right:8px;font-size:14px;overflow:hidden;white-space:nowrap;letter-spacing:0.42px;text-overflow:ellipsis;color:var(--v3-text-color);"]),
                l = n.Ay.div.withConfig({
                    displayName: "style__Cover",
                    componentId: "sc-1yg5frv-2"
                })(["width:100%;height:200px;filter:blur(5px);background-size:cover;"]),
                s = n.Ay.div.withConfig({
                    displayName: "style__Wrapper",
                    componentId: "sc-1yg5frv-3"
                })(["text-align:center;"]),
                r = n.Ay.div.withConfig({
                    displayName: "style__Buttons",
                    componentId: "sc-1yg5frv-4"
                })(["display:flex;flex-direction:column;padding:12px 12px 24px 12px;"]),
                c = n.Ay.div.withConfig({
                    displayName: "style__Container",
                    componentId: "sc-1yg5frv-5"
                })(["", ";overflow:auto;background-color:var(--v3-black-2);"], (e => !e.isJackpot && "padding: 16px 12px")),
                d = n.Ay.div.withConfig({
                    displayName: "style__Description",
                    componentId: "sc-1yg5frv-6"
                })(["padding:12px;font-size:14px;line-height:21px;border-radius:8px;letter-spacing:0.42px;color:var(--v3-text-color);background-color:var(--v3-black-0);"])
        },
        855606: (e, t, a) => {
            a.d(t, {
                z: () => u
            });
            var n = a(365043),
                i = a(889181),
                o = a(294574);
            const l = {
                    toLeft: (0, o.i7)(["{0%{transform:translateX(100%);}100%{transform:translateX(0);}}"]),
                    toRight: (0, o.i7)(["{0%{transform:translateX(-100%);}100%{transform:translateX(0);}}"]),
                    toTop: (0, o.i7)(["{0%{transform:translateY(100%);}100%{transform:translateY(0);}}"]),
                    toBottom: (0, o.i7)(["{0%{transform:translateY(-100%);}100%{transform:translateY(0);}}"])
                },
                s = {
                    toLeft: (0, o.i7)(["{0%{transform:translateX(0);}100%{transform:translateX(100%);}}"]),
                    toRight: (0, o.i7)(["{0%{transform:translateX(0);}100%{transform:translateX(-100%);}}"]),
                    toTop: (0, o.i7)(["{0%{transform:translateY(0);}100%{transform:translateY(100%);}}"]),
                    toBottom: (0, o.i7)(["{0%{transform:translateY(0);}100%{transform:translateY(-100%);}}"])
                },
                r = o.Ay.div.withConfig({
                    displayName: "style__CustomMask",
                    componentId: "sc-g7ftgu-0"
                })(["position:fixed;top:0;left:0;right:0;height:100%;background:", ";z-index:1;"], (e => e.maskBackground ? e.maskBackground : "rgba(0,0,0,0.3)")),
                c = o.Ay.div.withConfig({
                    displayName: "style__Container",
                    componentId: "sc-g7ftgu-1"
                })(["position:fixed;height:-webkit-fill-available;height:-moz-available;height:fill-available;top:", ";left:0;right:0;opacity:", ";z-index:11;pointer-events:", ";overflow:hidden;transition:opacity ", ";", "{top:", ";}"], (e => e.$maskPosTop ? e.$maskPosTop : 0), (e => e.show ? 1 : 0), (e => e.show ? "all" : "none"), (e => e.animationTime ? e.animationTime : "0.3s"), r, (e => e.$maskPosTop ? e.$maskPosTop : 0)),
                d = o.Ay.div.withConfig({
                    displayName: "style__CustomData",
                    componentId: "sc-g7ftgu-2"
                })(["position:absolute;height:100%;bottom:", ";top:", ";left:", ";right:", ";display:flex;flex-direction:column;z-index:3;background:var(--v3-black-0);&.customPopup--open{animation:", " ", " ease forwards;}&.customPopup--close{animation:", " ", " ease forwards;}"], (e => e.posBottom ? e.posBottom : 0), (e => e.posTop ? e.posTop : 0), (e => e.posLeft ? e.posLeft : 0), (e => e.posRight ? e.posRight : 0), (e => l[e.animationType]), (e => e.animationTime ? e.animationTime : "0.3s"), (e => s[e.animationType]), (e => e.animationTime ? e.animationTime : "0.3s"));
            var m = a(120376),
                p = a(179177),
                _ = a(570579);
            const u = (0, n.memo)((e => {
                let {
                    open: t,
                    children: a,
                    onMaskClick: o,
                    mask: l,
                    animationType: s,
                    animationTime: u,
                    className: y,
                    posBottom: S,
                    posLeft: T,
                    posRight: g,
                    posTop: h,
                    maskPosTop: E,
                    maskBackground: A,
                    style: v = {},
                    onBeforeOpen: b,
                    onAfterOpen: f,
                    initiallyLoaded: N = !1
                } = e;
                const O = (0, n.useRef)(N),
                    I = (0, n.useMemo)((() => s || "toLeft"), [s]);
                return (0, n.useLayoutEffect)((() => {
                    null === b || void 0 === b || b()
                }), []), (0, n.useEffect)((() => {
                    t && (O.current = !0)
                }), [t]), p.Ay.MOCKED_DATA ? null : (0, _.jsx)(m.Z, {
                    children: (0, _.jsxs)(c, {
                        show: t,
                        animationTime: u,
                        className: y,
                        style: v,
                        $maskPosTop: null !== E && void 0 !== E && E.usePosTop ? h : null === E || void 0 === E ? void 0 : E.posTop,
                        children: [l && (0, _.jsx)(r, {
                            className: "customMask",
                            maskBackground: A,
                            onClick: () => null === o || void 0 === o ? void 0 : o(!0)
                        }), (0, _.jsx)(d, {
                            className: (0, i.A)(["custom-data", {
                                "customPopup--open": t,
                                "customPopup--close": !t
                            }]),
                            animationType: I,
                            animationTime: u,
                            posTop: h,
                            posRight: g,
                            posLeft: T,
                            posBottom: S,
                            onAnimationEnd: () => null === f || void 0 === f ? void 0 : f(t),
                            children: (t || O.current) && a
                        })]
                    })
                })
            }))
        },
        177075: (e, t, a) => {
            a.d(t, {
                z: () => m
            });
            a(270757);
            var n = a(694227),
                i = a(870905),
                o = a(889181),
                l = a(735905),
                s = a(68392),
                r = a(179177),
                c = a(706683),
                d = (a(980001), a(570579));
            r.Ay.IS_RTL && a.e(49063).then(a.bind(a, 849063));
            const m = e => {
                let {
                    prizeFund: t,
                    singleView: a,
                    currencyId: r,
                    isLoading: m,
                    enableThousandSeparator: p
                } = e;
                const {
                    t: _
                } = (0, i.B)();
                return (0, d.jsxs)("div", {
                    className: "tournament__prize__wrapper",
                    children: [(0, d.jsx)(l.GlobalIcon, {
                        lib: "generic",
                        name: "cup",
                        theme: "colored",
                        size: a ? 48 : 40,
                        className: "CasinoTournamentCard__cup-icon"
                    }), (0, d.jsxs)("div", {
                        className: (0, o.A)(["tournament__fundWrapper", {
                            "tournament__fundWrapper--singleView": a
                        }]),
                        children: [(0, d.jsx)("div", {
                            className: (0, o.A)(["tour__fund-label", {
                                "tour__fund-label--singleView": a
                            }]),
                            children: _("casino.prizeFund")
                        }), (0, d.jsx)("div", {
                            className: (0, o.A)(["tour__fundAmount", {
                                "tour__fundAmount--singleView": a
                            }]),
                            dir: "ltr",
                            children: m ? (0, d.jsx)(n.A, {
                                loading: !0,
                                title: {
                                    width: 100
                                },
                                paragraph: !1
                            }) : p ? (0, c.Q8)((0, s.HN)(r, t)) : (0, s.HN)(r, t)
                        })]
                    })]
                })
            }
        },
        383724: (e, t, a) => {
            a.d(t, {
                m: () => s
            });
            var n = a(197262),
                i = a(889181),
                o = a(179177),
                l = a(570579);
            o.Ay.IS_RTL && a.e(28792).then(a.bind(a, 828792));
            const s = e => {
                let {
                    status: t,
                    singleView: a
                } = e;
                return (0, l.jsx)("div", {
                    className: (0, i.A)(["v3TournamentStatus", {
                        "bg-cyan-base": [n.A.t("casino.liveCasinoTournaments"), n.A.t("casino.upcomingCasino")].includes(t),
                        "bg-red-5": ![n.A.t("casino.liveCasinoTournaments"), n.A.t("casino.upcomingCasino")].includes(t),
                        "single-view": a
                    }]),
                    children: t
                })
            }
        },
        439558: (e, t, a) => {
            a.d(t, {
                _: () => g
            });
            var n = a(365043),
                i = a(507712),
                o = a(890286),
                l = a(555113),
                s = a(542699),
                r = a(679559),
                c = a(870905),
                d = a(860446),
                m = a.n(d),
                p = a(80489),
                _ = a(810795),
                u = a(119131),
                y = a(343245),
                S = a(320308),
                T = a(570579);
            const g = e => {
                let {
                    fullwidth: t,
                    tournament: {
                        IsParticipated: a,
                        JoinDate: d,
                        Id: g,
                        RegistrationStartDate: h,
                        RegistrationEndDate: E
                    },
                    joinText: A
                } = e;
                const {
                    t: v
                } = (0, c.B)(), b = (0, i.wA)(), f = (0, i.d4)(s.px), N = (0, i.d4)(s.YG), O = (0, i.d4)(s.ol), [I, C] = (0, n.useState)(!1), M = (0, i.d4)(r.eP), R = (0, _.R)(), {
                    autoJoin: D
                } = O && (null === f || void 0 === f ? void 0 : f[O].find((e => e.Id === g))) || {}, P = (0, n.useMemo)((() => {
                    const e = m()();
                    return m().utc(h).isBefore(e) && m().utc(e).isBefore(E)
                }), [h, E]), x = () => {
                    C(!0), (0, l.CX)(g, (e => {
                        e.result.ErrorId === u.F.casino.switchToFTNWallet ? (0, S.$)(v(y.Rp[u.F.casino.switchToFTNWallet])) : b((0, o.gS)(g)), C(!1)
                    }), (() => C(!1)))
                };
                (0, n.useEffect)((() => {
                    !a && M && D && x()
                }), [M, a, D]);
                const w = (0, n.useCallback)((e => {
                        if (e.stopPropagation(), O && !M) return b((0, o.S5)({
                            data: f[O].map((e => ({ ...e,
                                autoJoin: String(e.Id) === String(g)
                            }))),
                            productTypeId: O
                        })), void R();
                        x()
                    }), [M, b, f, g, R]),
                    G = M && (Boolean(d || a || !P) || N.includes(g));
                return (0, T.jsx)(p.$, {
                    fullwidth: t,
                    type: "primary",
                    size: "large",
                    loading: I,
                    onClick: w,
                    disabled: G,
                    children: M && G ? v("casino.joined") : A
                })
            }
        },
        796189: (e, t, a) => {
            a.r(t), a.d(t, {
                DesktopTournamentSingleView: () => f
            });
            a(531806);
            var n = a(706628),
                i = (a(731059), a(509609)),
                o = a(365043),
                l = a(870905),
                s = a(889181),
                r = a(634364),
                c = a(84783),
                d = a(218545),
                m = a(600940),
                p = a(424541),
                _ = a(593903),
                u = a(177075),
                y = a(439558),
                S = a(208938),
                T = a(430984),
                g = a(383724),
                h = a(210771),
                E = a(692273),
                A = a(68392),
                v = a(963971),
                b = (a(947550), a(7035), a(570579));
            const f = e => {
                var t, a, f, N, O, I, C, M, R;
                let {
                    tournamentData: D,
                    loading: P,
                    isSportsTournament: x,
                    fromIndex: w,
                    topPlayerList: G
                } = e;
                const {
                    t: L
                } = (0, l.B)(), k = (0, _.h)(null === D || void 0 === D ? void 0 : D.Stage), B = (0, E.b)(null === D || void 0 === D ? void 0 : D.Stage), $ = (0, o.useRef)(null), {
                    placement: j
                } = (0, p.H)(), V = (null === G || void 0 === G || null === (t = G.TopPlayerList) || void 0 === t ? void 0 : t.CurrentPlayer) || (null === D || void 0 === D ? void 0 : D.CurrentPlayerStats) || (null === D || void 0 === D || null === (a = D.TopPlayerList) || void 0 === a ? void 0 : a.CurrentPlayer), U = e => {
                    var t;
                    e && (null === (t = e.closest("[class$='-tabs-content-holder']")) || void 0 === t || t.scrollTo(0, 0))
                };
                return w ? null : P && !D ? (0, b.jsx)(T.W, {}) : (0, b.jsxs)("div", {
                    className: "tournamentSingleView",
                    children: [(0, b.jsxs)("div", {
                        className: "tournamentSingleView__banner",
                        children: [(0, b.jsx)("img", {
                            className: "tournamentSingleView__banner__img",
                            src: null === D || void 0 === D || null === (f = D.DetailsBannerImages[0]) || void 0 === f ? void 0 : f.Images[0].ImageUrl,
                            loading: "lazy"
                        }), (0, b.jsx)("div", {
                            className: "gradient"
                        }), (0, b.jsxs)("div", {
                            className: "tournamentSingleView__banner__info",
                            children: [(0, b.jsxs)("div", {
                                className: "tournamentSingleView__banner__info__prize",
                                children: [(0, b.jsxs)("div", {
                                    className: "tournamentSingleView__banner__info__name",
                                    children: [null === D || void 0 === D ? void 0 : D.Name, k && (0, b.jsx)(g.m, {
                                        singleView: !0,
                                        status: k
                                    })]
                                }), (0, b.jsx)(u.z, {
                                    singleView: !0,
                                    prizeFund: (null === D || void 0 === D ? void 0 : D.PrizeFund) || 0,
                                    currencyId: (null === D || void 0 === D ? void 0 : D.CurrencyId) || " ",
                                    isLoading: P
                                })]
                            }), (0, b.jsx)("div", {
                                className: "tournamentSingleView__banner__info__timer",
                                children: D && (0, b.jsxs)(b.Fragment, {
                                    children: [(0, b.jsx)("div", {
                                        className: (0, s.A)(["tournamentSingleView__banner__info__timer__title", {
                                            tournamentSingleView__banner__info__timer__title__end: 3 !== D.Stage,
                                            tournamentSingleView__banner__info__timer__title__start: 3 == D.Stage
                                        }]),
                                        children: B
                                    }), (0, b.jsx)(r.M, {
                                        lightColors: !0,
                                        endDate: D.EndDate,
                                        startDate: D.StartDate,
                                        singleView: !0
                                    }), (0, v.a)(k) && (0, b.jsx)(y._, {
                                        tournament: D,
                                        fullwidth: !0,
                                        joinText: L("casino.joinNow")
                                    })]
                                })
                            })]
                        })]
                    }), (0, b.jsxs)("div", {
                        className: "tournamentSingleView__infoContainer",
                        children: [(0, b.jsxs)("div", {
                            className: "tournamentSingleView__infoContainer__mainSection",
                            children: [!!D && (0, b.jsxs)("div", {
                                className: "tour__info-section tournamentSingleView__infoContainer__mainSection__informationMainSection",
                                children: [(0, b.jsxs)("div", {
                                    className: "tournamentSingleView__infoContainer__mainSection__informationMainSection__labelValueWrapper",
                                    children: [(0, b.jsx)("div", {
                                        className: "tournamentSingleView__infoContainer__mainSection__informationMainSection__labelValueWrapper__infoLabel",
                                        children: L("casino.regStart")
                                    }), (0, b.jsx)("div", {
                                        className: "tournamentSingleView__infoContainer__mainSection__informationMainSection__labelValueWrapper__infoValue",
                                        dir: "ltr",
                                        children: (0, h.W)(D.RegistrationStartDate, "/")
                                    }), (0, b.jsx)("div", {
                                        className: "tournamentSingleView__infoContainer__mainSection__informationMainSection__labelValueWrapper__infoLabel",
                                        children: L("casino.regEnd")
                                    }), (0, b.jsx)("div", {
                                        className: "tournamentSingleView__infoContainer__mainSection__informationMainSection__labelValueWrapper__infoValue",
                                        dir: "ltr",
                                        children: (0, h.W)(D.RegistrationEndDate, "/")
                                    })]
                                }), (0, b.jsx)(i.A, {
                                    type: "vertical",
                                    className: "tournamentInfoDivider"
                                }), (0, b.jsxs)("div", {
                                    className: "tournamentSingleView__infoContainer__mainSection__informationMainSection__labelValueWrapper",
                                    children: [(0, b.jsx)("div", {
                                        className: "tournamentSingleView__infoContainer__mainSection__informationMainSection__labelValueWrapper__infoLabel",
                                        children: L("casino.tournamentStart")
                                    }), (0, b.jsx)("div", {
                                        className: "tournamentSingleView__infoContainer__mainSection__informationMainSection__labelValueWrapper__infoValue",
                                        dir: "ltr",
                                        children: (0, h.W)(D.StartDate, "/")
                                    }), (0, b.jsx)("div", {
                                        className: "tournamentSingleView__infoContainer__mainSection__informationMainSection__labelValueWrapper__infoLabel",
                                        children: L("casino.tournamentEnd")
                                    }), (0, b.jsx)("div", {
                                        className: "tournamentSingleView__infoContainer__mainSection__informationMainSection__labelValueWrapper__infoValue",
                                        dir: "ltr",
                                        children: (0, h.W)(D.EndDate, "/")
                                    })]
                                }), (0, b.jsx)(i.A, {
                                    type: "vertical",
                                    className: "tournamentInfoDivider"
                                }), (0, b.jsxs)("div", {
                                    className: "tournamentSingleView__infoContainer__mainSection__informationMainSection__labelValueWrapper",
                                    children: [!x && (0, b.jsxs)(b.Fragment, {
                                        children: [(0, b.jsx)("div", {
                                            className: "tournamentSingleView__infoContainer__mainSection__informationMainSection__labelValueWrapper__infoLabel",
                                            children: L("casino.min-max-spin")
                                        }), (0, b.jsxs)("div", {
                                            className: "tournamentSingleView__infoContainer__mainSection__informationMainSection__labelValueWrapper__infoValue",
                                            dir: "ltr",
                                            children: [D.MinRounds, " -", " ", D.MaxRounds || "\u221e"]
                                        })]
                                    }), (0, b.jsx)("div", {
                                        className: "tournamentSingleView__infoContainer__mainSection__informationMainSection__labelValueWrapper__infoLabel",
                                        children: L("casino.min-max-bet")
                                    }), (0, b.jsxs)("div", {
                                        className: "tournamentSingleView__infoContainer__mainSection__informationMainSection__labelValueWrapper__infoValue",
                                        dir: "ltr",
                                        children: ["left" === j && (0, A.N8)(null === D || void 0 === D ? void 0 : D.CurrencyId).currency, D.MinBet, " - ", D.MaxBet || "\u221e", " ", "right" === j && (0, A.N8)(null === D || void 0 === D ? void 0 : D.CurrencyId).currency]
                                    })]
                                }), (0, b.jsx)(i.A, {
                                    type: "vertical",
                                    className: "tournamentInfoDivider"
                                }), (0, b.jsxs)("div", {
                                    className: "tournamentSingleView__infoContainer__mainSection__informationMainSection__labelValueWrapper",
                                    children: [!x && (0, b.jsxs)(b.Fragment, {
                                        children: [(0, b.jsx)("div", {
                                            className: "tournamentSingleView__infoContainer__mainSection__informationMainSection__labelValueWrapper__infoLabel",
                                            children: L("casino.players")
                                        }), (0, b.jsxs)("div", {
                                            className: "tournamentSingleView__infoContainer__mainSection__informationMainSection__labelValueWrapper__infoValue",
                                            dir: "ltr",
                                            children: [D.JoinedPlayersCount, " /", " ", D.MinStartingNumberOfPlayers]
                                        })]
                                    }), (0, b.jsx)("div", {
                                        className: "tournamentSingleView__infoContainer__mainSection__informationMainSection__labelValueWrapper__infoLabel",
                                        children: L("casino.buyInFee")
                                    }), (0, b.jsx)("div", {
                                        className: "tournamentSingleView__infoContainer__mainSection__informationMainSection__labelValueWrapper__infoValue",
                                        dir: "ltr",
                                        children: (0, A.HN)(null === D || void 0 === D ? void 0 : D.CurrencyId, D.RegistrationAmount)
                                    })]
                                })]
                            }), D && !x && (0, b.jsxs)("div", {
                                className: "tournamentSingleView__infoContainer__mainSection__subSection",
                                children: [(0, b.jsx)("div", {
                                    className: "tournamentSingleView__infoContainer__mainSection__subSection__gamesName",
                                    children: L("casino.games")
                                }), (0, b.jsx)("div", {
                                    className: "tournamentSingleView__infoContainer__mainSection__subSection__gamesWrapper",
                                    children: (0, b.jsx)(S.k, {
                                        tournamentId: null === D || void 0 === D ? void 0 : D.Id,
                                        colSizes: {
                                            xs: 12,
                                            sm: 8,
                                            md: 8,
                                            lg: 6,
                                            xl: 6
                                        },
                                        gamesCount: 8,
                                        loadMoreButtonOptions: {
                                            type: "primary",
                                            style: {
                                                width: "240px",
                                                margin: "24px auto",
                                                display: "block"
                                            }
                                        }
                                    })
                                })]
                            }), (0, b.jsx)("div", {
                                className: "tournamentSingleView__infoContainer__mainSection__subSectionName",
                                children: L("casino.tournamentrules")
                            }), (0, b.jsx)("div", {
                                className: "tournamentSingleView__infoContainer__mainSection__subSection",
                                ref: $,
                                children: (0, b.jsx)("div", {
                                    className: "tour__info-section tournamentSingleView__infoContainer__mainSection__subSection__rulesMainSection",
                                    children: null === D || void 0 === D ? void 0 : D.Description.split(/(?=[\u25cf\u2022\n])/g).map(((e, t) => (0, b.jsx)("div", {
                                        children: e
                                    }, t)))
                                })
                            })]
                        }), P ? (0, b.jsx)(T.Y, {}) : (0, b.jsx)(c.u, {
                            children: (0, b.jsxs)(b.Fragment, {
                                children: [!(null === D || void 0 === D || null === (N = D.TopPlayerList) || void 0 === N || null === (O = N.TopPlayerList) || void 0 === O || !O.length) && (0, b.jsx)(n.A.TabPane, {
                                    tab: L("casino.leaderboard"),
                                    children: (0, b.jsxs)("div", {
                                        ref: U,
                                        children: [V && (0, b.jsx)(d.O, {
                                            player: V,
                                            isCurrentPlayer: !0
                                        }, `${V.PlayerId}${V.Place}`), ((null === G || void 0 === G || null === (I = G.TopPlayerList) || void 0 === I ? void 0 : I.TopPlayerList) || (null === D || void 0 === D || null === (C = D.TopPlayerList) || void 0 === C ? void 0 : C.TopPlayerList)).map((e => {
                                            var t, a;
                                            return (0, b.jsx)(d.O, {
                                                player: e,
                                                isCurrentPlayer: (null === D || void 0 === D || null === (t = D.TopPlayerList) || void 0 === t || null === (a = t.CurrentPlayer) || void 0 === a ? void 0 : a.PlayerId) === e.PlayerId
                                            }, e.PlayerId)
                                        }))]
                                    })
                                }, "1"), (null === D || void 0 === D || null === (M = D.PrizeStructure) || void 0 === M ? void 0 : M.length) && (0, b.jsx)(n.A.TabPane, {
                                    tab: L("casino.prizes"),
                                    children: (0, b.jsx)("div", {
                                        ref: U,
                                        children: null === D || void 0 === D || null === (R = D.PrizeStructure) || void 0 === R ? void 0 : R.map((e => (0, b.jsxs)("div", {
                                            className: "sidebarRowPrize",
                                            children: [(0, b.jsxs)("div", {
                                                className: "sidebarRowPrize__leaderBoardLeftPart",
                                                children: [" ", `${(0,m.Rt)(e.PlaceNumber)} ${L("casino.place")}`]
                                            }), (0, b.jsx)("span", {
                                                style: {
                                                    fontSize: 14
                                                },
                                                children: `${e.PrizePercent}%`
                                            })]
                                        }, e.PlaceNumber)))
                                    })
                                }, "2")]
                            })
                        })]
                    })]
                })
            }
        },
        208938: (e, t, a) => {
            a.d(t, {
                k: () => S
            });
            var n = a(870905),
                i = a(80489),
                o = a(951712),
                l = a(55418),
                s = a(570579);
            const r = {
                    width: "100%",
                    marginTop: 15
                },
                c = {
                    width: "20%",
                    display: "block",
                    margin: "0 auto"
                },
                d = e => {
                    const {
                        t: t
                    } = (0, n.B)();
                    return (0, s.jsxs)(s.Fragment, {
                        children: [(0, s.jsx)(o.n, {
                            games: e.games,
                            colSizes: e.colSizes
                        }), e.showLoadMoreBtn && (0, s.jsx)("div", {
                            className: "casino__load-more-button",
                            style: {
                                padding: "15px"
                            },
                            children: (0, s.jsx)(i.$, {
                                size: "large",
                                type: "ghost",
                                style: (0, l.F)() ? r : c,
                                onClick: () => {
                                    var t;
                                    return null === (t = e.loadMore) || void 0 === t ? void 0 : t.call(e)
                                },
                                loading: e.loadMoreBtnLoading,
                                ...e.loadMoreButtonOptions,
                                children: t("casino.seeMore")
                            })
                        })]
                    })
                };
            var m = a(365043),
                p = a(791338),
                _ = a(989618),
                u = a(486490);
            const {
                NoItem: y
            } = (0, _.R)((() => Promise.all([a.e(87161), a.e(34426), a.e(55608), a.e(84107), a.e(81927), a.e(35834), a.e(70136), a.e(28151), a.e(94574), a.e(90440), a.e(35905), a.e(89238), a.e(24615), a.e(94258)]).then(a.bind(a, 367452)))), S = function(e) {
                let {
                    tournamentId: t,
                    colSizes: a,
                    gamesCount: i = 10,
                    loadMoreButtonOptions: o
                } = e;
                const {
                    t: r
                } = (0, n.B)(), [c, _] = (0, m.useState)(null), [S, T] = (0, m.useState)(0), [g, h] = (0, m.useState)(), [E, A] = (0, m.useState)(!1), v = (0, m.useCallback)((() => {
                    A(!0), (0, p.db)({
                        tournament_id: t,
                        limit: i,
                        offset: S
                    }).then((e => {
                        e && (_((t => [...t || [], ...e.items || []])), h(e.total_count), T((e => e + i)), A(!1))
                    }))
                }), [S, t]);
                return (0, m.useEffect)((() => {
                    v()
                }), []), null == c ? null : null !== c && void 0 !== c && c.length ? (0, s.jsxs)(s.Fragment, {
                    children: [(0, l.F)() && (0, s.jsx)(u.CasinoGamePreview, {}), (0, s.jsx)(d, {
                        games: c,
                        showLoadMoreBtn: !!g && S < g,
                        loadMore: v,
                        colSizes: a,
                        loadMoreButtonOptions: o,
                        loadMoreBtnLoading: E
                    })]
                }) : (0, s.jsx)(m.Suspense, {
                    children: (0, s.jsx)(y, {
                        title: r("sportsbook.noGame"),
                        text: r("sportsbook.noGameText"),
                        size: "medium"
                    })
                })
            }
        },
        810795: (e, t, a) => {
            a.d(t, {
                R: () => c
            });
            var n = a(365043),
                i = a(995392),
                o = a(816343),
                l = a(384716),
                s = a(424757),
                r = a(242146);
            const c = () => {
                const e = (0, i.W6)(),
                    {
                        mode: t
                    } = (0, l.o)();
                return (0, n.useMemo)((() => () => {
                    let a;
                    "real" === t && (a = `${(0,s.ic)(window.location.pathname,!1,!0)}/${r.Hk.all.id}`), (0, o.qx)("login", a), e.push((0, o.U7)({
                        accounts: "*",
                        login: "*"
                    }))
                }), [])
            }
        },
        692273: (e, t, a) => {
            a.d(t, {
                b: () => o
            });
            var n = a(365043),
                i = a(871237);
            const o = e => (0, n.useMemo)((() => {
                var t;
                return null === (t = i.AE.find((t => t.value == e))) || void 0 === t ? void 0 : t.label
            }), [e])
        },
        593903: (e, t, a) => {
            a.d(t, {
                h: () => o
            });
            var n = a(365043),
                i = a(871237);
            const o = e => (0, n.useMemo)((() => {
                var t;
                return null === (t = i.FJ.find((t => t.value == e))) || void 0 === t ? void 0 : t.label
            }), [e])
        },
        424541: (e, t, a) => {
            a.d(t, {
                H: () => c
            });
            var n = a(507712),
                i = a(365043),
                o = a(462956),
                l = a(679559),
                s = a(68392),
                r = a(261190);
            const c = () => {
                const [e, t] = (0, i.useState)(""), {
                    currency: a
                } = (0, n.d4)(l.wz), c = (0, n.d4)(l.eP), d = (0, n.d4)(o.gU);
                (0, i.useLayoutEffect)((() => {
                    c && a ? t(a) : null !== d && void 0 !== d && d.currency && t(d.currency)
                }), [d, c, a]);
                return (0, i.useMemo)((() => {
                    const t = (0, s.N8)(e),
                        a = t.currency === r.Mi ? r.Wq : t.currency;
                    return {
                        currency: a,
                        currencyId: e,
                        placement: t.placement,
                        formatAmount: (0, s.Hv)(a, t.placement)
                    }
                }), [e])
            }
        },
        535789: (e, t, a) => {
            a.d(t, {
                L: () => l
            });
            var n = a(365043),
                i = a(860446),
                o = a.n(i);
            const l = e => {
                let {
                    endDate: t,
                    startDate: a
                } = e;
                const [i, l] = (0, n.useState)(""), [s, r] = (0, n.useState)(""), [c, d] = (0, n.useState)(""), [m, p] = (0, n.useState)(""), _ = e => e.toString().padStart(2, "0"), u = function() {
                    const e = "endDate" === (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "endDate") || t && o()().isBefore(o().utc(t)) && o()().isAfter(o().utc(a)) ? o().utc(t) : o().utc(a),
                        n = o()();
                    if (o()().isBefore(n)) return;
                    const i = o().duration(e.diff(n));
                    l(_(0 | i.asDays())), r(_(i.hours())), d(_(i.minutes())), p(_(i.seconds()))
                };
                return (0, n.useEffect)((() => {
                    let e;
                    return a && o()().isBefore(o().utc(a)) ? (u("startDate"), e = setInterval((() => {
                        u("startDate")
                    }), 1e3)) : t && o()().isBefore(o().utc(t)) && o()().isAfter(o().utc(a)) && (u("endDate"), e = setInterval((() => {
                        u("endDate")
                    }), 1e3)), () => {
                        e && clearInterval(e)
                    }
                }), [t, a]), {
                    countDownDays: i,
                    countDownHours: s,
                    countDownMinutes: c,
                    countDownSeconds: m
                }
            }
        },
        664833: (e, t, a) => {
            a.d(t, {
                d: () => n
            });
            let n = function(e) {
                return e.Id = "id", e.Category = "category", e
            }({})
        },
        971247: (e, t, a) => {
            a.d(t, {
                E: () => n
            });
            let n = function(e) {
                return e.topLeague = "topLeague", e.boostedOdds = "boostedOdds", e.todayEvents = "todayEvents", e.topMatches = "topMatches", e.multiples = "multiples", e.outright = "outright", e.AllESports = "AllESports", e.all = "all", e.favourites = "favourites", e.team = "team", e.myBets = "myBets", e.betBuilder = "betBuilder", e.coupon = "coupon", e
            }({})
        },
        218545: (e, t, a) => {
            a.d(t, {
                O: () => c
            });
            var n = a(870905),
                i = a(889181),
                o = a(735905),
                l = (a(7035), a(570579));
            const s = {
                    1: "goldmedal",
                    2: "silvermedal",
                    3: "bronzemedal"
                },
                r = [1, 2, 3],
                c = e => {
                    let {
                        player: t,
                        isCurrentPlayer: a
                    } = e;
                    const {
                        t: c
                    } = (0, n.B)();
                    return (0, l.jsxs)("div", {
                        className: (0, i.A)(["sidebarRow", {
                            "sidebarRow--gold": 1 === t.Place,
                            "sidebarRow--silver": 2 === t.Place,
                            "sidebarRow--bronze": 3 === t.Place,
                            "sidebarRow--currentPlayer": a
                        }]),
                        children: [(0, l.jsxs)("div", {
                            className: "sidebarRow__leaderBoardLeftPart",
                            children: [r.includes(t.Place) && !a ? (0, l.jsx)(o.GlobalIcon, {
                                lib: "generic",
                                theme: "colored",
                                name: s[t.Place],
                                size: 28
                            }) : (0, l.jsx)("div", {
                                className: "sidebarRow__leaderBoardLeftPart__playerPosition",
                                children: t.Place
                            }), (0, l.jsx)("span", {
                                className: "sidebarRow__leaderBoardLeftPart",
                                "data-testid": "leaderboard-user-id",
                                children: `${t.ExternalIdMasked}`
                            }), a && `(${c("casino.tournamentCurrentPlayer")})`]
                        }), (0, l.jsx)("span", {
                            className: "sidebarRow__leaderBoardLeftPart",
                            children: t.Amount
                        })]
                    }, t.PlayerId)
                }
        },
        84783: (e, t, a) => {
            a.d(t, {
                u: () => l
            });
            a(531806);
            var n = a(706628),
                i = a(889181),
                o = (a(738281), a(570579));
            const l = e => {
                let {
                    isCasino: t,
                    children: a,
                    activeKey: l,
                    isFullHeight: s,
                    setActiveKey: r,
                    isJackpot: c
                } = e;
                const d = document.querySelectorAll(".header-row-fix");
                let m = 0;
                return d.forEach((e => {
                    m += e.clientHeight
                })), (0, o.jsx)("div", {
                    className: (0, i.A)(["tabsWrapper", {
                        "tabsWrapper--isFullHeight": s,
                        "tabsWrapper--notIsCasino": !t,
                        "tabsWrapper--isJackpot": c
                    }]),
                    style: d ? {
                        top: `${m}px`
                    } : {},
                    children: (0, o.jsx)(n.A, { ...!!l && {
                            activeKey: l,
                            onTabClick: e => null === r || void 0 === r ? void 0 : r(`${e}`)
                        },
                        centered: !0,
                        defaultActiveKey: "1",
                        destroyInactiveTabPane: !0,
                        tabBarStyle: {
                            width: "100%"
                        },
                        children: a
                    })
                })
            }
        },
        48070: (e, t, a) => {
            a.d(t, {
                D: () => s
            });
            a(270757);
            var n = a(694227),
                i = a(889181),
                o = a(55418),
                l = (a(183215), a(687886), a(224532), a(570579));
            const s = e => {
                let {
                    extraStyle: t
                } = e;
                return (0, l.jsx)("div", {
                    className: (0, i.A)([{
                        "x-casinoGameCardMobile": (0, o.F)(),
                        "x-casinoGameCardDesktop": !(0, o.F)(),
                        cardSkeleton__position: t
                    }]),
                    children: (0, l.jsx)("div", {
                        className: "x-casinoGameCardImageWrapper x-casinoGameCardImageWrapper__skeleton",
                        children: (0, l.jsx)(n.A.Image, {
                            className: "x-casinoGameCardImageSkeleton",
                            style: {
                                position: "absolute",
                                left: 0,
                                top: 0,
                                right: 0,
                                bottom: 0,
                                width: "100%",
                                height: "100%"
                            }
                        })
                    })
                })
            }
        },
        109491: (e, t, a) => {
            a.d(t, {
                k: () => u
            });
            var n = a(365043),
                i = a(507712),
                o = a(48070),
                l = a(283573),
                s = a(117893),
                r = a(989618),
                c = a(185762),
                d = a(179177),
                m = a(570579);
            d.Ay.IS_RTL && a.e(45443).then(a.bind(a, 645443));
            const {
                CasinoGameCardMobile: p
            } = (0, r.R)((() => Promise.all([a.e(24757), a.e(84716), a.e(95459), a.e(42146), a.e(65506), a.e(10795), a.e(97760), a.e(62330), a.e(89910), a.e(96771), a.e(18056), a.e(6327), a.e(13900), a.e(44148), a.e(30797), a.e(23295)]).then(a.bind(a, 563331)))), {
                CasinoGameCardDesktop: _
            } = (0, r.R)((() => Promise.all([a.e(24757), a.e(84716), a.e(95459), a.e(42146), a.e(65506), a.e(10795), a.e(96771), a.e(18056), a.e(6327), a.e(13900), a.e(30797), a.e(88563)]).then(a.bind(a, 218586)))), u = e => {
                const t = (0, i.wA)(),
                    a = (0, i.d4)((0, l.YK)(e.game.id, "casino")),
                    r = (0, n.useCallback)((a => {
                        a.stopPropagation(), t((0, s.dwU)({
                            entity: e.game,
                            groupKey: "casino"
                        }))
                    }), [e.game]);
                return (0, m.jsx)(c.L, {
                    desktop: _,
                    mobile: p,
                    innerProps: { ...e,
                        isFavorite: a,
                        onFavoriteToggle: r,
                        casinoNameSize: e.casinoNameSize,
                        casinoPlayRealBtnSize: e.casinoPlayRealBtnSize,
                        setVisible: e.setVisible
                    },
                    fallback: (0, m.jsx)(o.D, {})
                })
            }
        },
        951712: (e, t, a) => {
            a.d(t, {
                n: () => _
            });
            a(780510);
            var n = a(326468),
                i = (a(849416), a(147638)),
                o = a(365043),
                l = a(507712),
                s = a(890286),
                r = a(542699),
                c = a(109491),
                d = a(330412),
                m = a(55418),
                p = a(570579);
            const _ = (0, o.memo)((e => {
                var t;
                const a = (0, l.wA)(),
                    d = (0, l.d4)(r.v),
                    _ = (0, l.d4)(r.w2);
                return (0, o.useEffect)((() => {
                    _ && a((0, s.uV)(null))
                }), [d]), (0, p.jsx)(n.A, {
                    gutter: [8, 8],
                    className: e.className,
                    children: null === e || void 0 === e || null === (t = e.games) || void 0 === t ? void 0 : t.map((t => (0, p.jsx)(i.A, { ...e.colSizes,
                        className: (0, m.F)() ? "gameCard-mobile" : "",
                        children: (0, p.jsx)(c.k, {
                            game: t,
                            scaleOut: !0,
                            fromAccount: e.fromAccount
                        })
                    }, t.id)))
                })
            }), ((e, t) => !!e.games && !!t.games && (0, d.F)(e.games, t.games)))
        },
        634364: (e, t, a) => {
            a.d(t, {
                M: () => s
            });
            var n = a(870905),
                i = a(889181),
                o = a(535789),
                l = a(570579);
            const s = e => {
                let {
                    endDate: t,
                    startDate: a,
                    lightColors: s,
                    hideDay: r,
                    customStyle: c,
                    className: d,
                    singleView: m
                } = e;
                const {
                    countDownDays: p,
                    countDownHours: _,
                    countDownMinutes: u,
                    countDownSeconds: y
                } = (0, o.L)({
                    endDate: t,
                    startDate: a
                }), {
                    t: S
                } = (0, n.B)();
                return (0, l.jsxs)("div", {
                    className: (0, i.A)([`${d||""} timer__timeSquare`, {
                        "timer__timeSquare--lightColors": s
                    }]),
                    dir: "ltr",
                    style: c,
                    children: [r ? null : (0, l.jsxs)("div", {
                        className: "timer__square__wrapper",
                        children: [(0, l.jsx)("div", {
                            className: (0, i.A)(["timer__timeSquare__item", {
                                "timer__timeSquare__item--lightColors": s,
                                "timer__timeSquare__item--singleView": m
                            }]),
                            children: p || 0
                        }), (0, l.jsx)("div", {
                            className: (0, i.A)(["timeSquareLabel", {
                                "timeSquareLabel--singleView": m
                            }]),
                            children: S("casino.day")
                        })]
                    }), (0, l.jsxs)("div", {
                        className: "timer__square__wrapper",
                        children: [(0, l.jsx)("div", {
                            className: (0, i.A)(["timer__timeSquare__item", {
                                "timer__timeSquare__item--lightColors": s,
                                "timer__timeSquare__item--singleView": m
                            }]),
                            children: _ || 0
                        }), (0, l.jsx)("div", {
                            className: (0, i.A)(["timeSquareLabel", {
                                "timeSquareLabel--singleView": m
                            }]),
                            children: S("casino.hour")
                        })]
                    }), (0, l.jsxs)("div", {
                        className: "timer__square__wrapper",
                        children: [(0, l.jsx)("div", {
                            className: (0, i.A)(["timer__timeSquare__item", {
                                "timer__timeSquare__item--lightColors": s,
                                "timer__timeSquare__item--singleView": m
                            }]),
                            children: u || 0
                        }), (0, l.jsx)("div", {
                            className: (0, i.A)(["timeSquareLabel", {
                                "timeSquareLabel--singleView": m
                            }]),
                            children: S("casino.minute")
                        })]
                    }), (0, l.jsxs)("div", {
                        className: "timer__square__wrapper",
                        children: [(0, l.jsx)("div", {
                            className: (0, i.A)(["timer__timeSquare__item", {
                                "timer__timeSquare__item--lightColors": s,
                                "timer__timeSquare__item--singleView": m
                            }]),
                            children: y || 0
                        }), (0, l.jsx)("div", {
                            className: (0, i.A)(["timeSquareLabel", {
                                "timeSquareLabel--singleView": m
                            }]),
                            children: S("casino.second")
                        })]
                    })]
                })
            }
        },
        595459: (e, t, a) => {
            a.d(t, {
                d: () => i
            });
            var n = a(995392);
            const i = e => (0, n.W5)(e) || {
                url: "",
                path: "",
                params: {},
                isExact: !1
            }
        },
        791338: (e, t, a) => {
            a.d(t, {
                db: () => y,
                mb: () => u,
                pP: () => S
            });
            var n = a(140854),
                i = a.n(n),
                o = a(664833),
                l = a(179177),
                s = a(224272),
                r = a(320308),
                c = a(55418),
                d = a(457250);
            const m = {
                    partner_id: l.Ay.PARTNER_ID,
                    is_mobile: Number((0, c.F)()),
                    lang: d.Ic
                },
                p = { ...m,
                    by_key: o.d.Category,
                    offset: 0,
                    limit: l.Ay.CASINO_GAMES_FETCH_COUNT
                },
                _ = { ...m,
                    with: "images,categories"
                },
                u = async function() {
                    let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                        t = p;
                    return arguments.length > 1 && void 0 !== arguments[1] && arguments[1] && (t = m), i().get(`${l.Ay.CASINO_URL}/${s.j.GET_GAMES}`, {
                        params: { ...t,
                            ...e
                        }
                    }).then((e => "string" === typeof e.data && e.data.includes('"status":-1') || -1 === e.data.status ? -1 : 200 === e.status && e.data && "ok" === e.data.status ? Object.entries(e.data.games) : ((0, r.$)(e.statusText || e.data.message), null))).catch((e => ((0, r.$)(e.toString()), null)))
                },
                y = async function() {
                    let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                    return i().get(`${l.Ay.CASINO_URL}/${s.j.GET_TOURNAMENT_GAMES}`, {
                        params: { ..._,
                            ...e
                        }
                    }).then((e => 200 === e.status && e.data && "ok" === e.data.status ? e.data : ((0, r.$)(e.statusText), null))).catch((e => ((0, r.$)(e.toString()), null)))
                },
                S = async e => i().get(`${l.Ay.CASINO_URL}/${s.j.GET_GAME_TOURNAMENTS}`, {
                    params: {
                        external_id: e,
                        partner_id: l.Ay.PARTNER_ID
                    }
                }).then((e => {
                    if (200 === e.status && e.data && "ok" === e.data.status) return e.data.data;
                    throw new Error(e.statusText)
                })).catch((() => null))
        },
        314100: (e, t, a) => {
            function n() {
                for (var e = arguments.length, t = new Array(e), a = 0; a < e; a++) t[a] = arguments[a];
                return {
                    type: "BATCH_ACTIONS",
                    actions: t
                }
            }
            a.d(t, {
                O: () => n
            })
        },
        890286: (e, t, a) => {
            a.d(t, {
                $s: () => g,
                C: () => A,
                MU: () => r,
                P: () => l,
                S5: () => S,
                XS: () => p,
                YH: () => E,
                Zr: () => o,
                e_: () => T,
                gS: () => h,
                h4: () => y,
                lk: () => u,
                m1: () => i,
                p0: () => d,
                qH: () => c,
                u0: () => _,
                u2: () => m,
                uV: () => s
            });
            var n = a(560529);
            const i = e => ({
                    type: n.v.SET_CASINO_OPTIONS,
                    payload: e
                }),
                o = () => ({
                    type: n.v.RESET_CASINO_OPTIONS
                }),
                l = e => ({
                    type: n.v.TOGGLE_ACTIVE_CATEGORY,
                    payload: e
                }),
                s = e => ({
                    type: n.v.SET_CASINO_GAME_TOURNAMENTS,
                    payload: e
                }),
                r = e => ({
                    type: n.v.SET_IS_LOADED,
                    payload: e
                }),
                c = e => ({
                    type: n.v.SET_CASINO_JACKPOT,
                    payload: e
                }),
                d = e => ({
                    type: n.v.SET_SPORTSBOOK_JACKPOT,
                    payload: e
                }),
                m = e => ({
                    type: n.v.SET_CASINO_GAME_JACKPOT,
                    payload: e
                }),
                p = () => ({
                    type: n.v.RESET_CASINO_JACKPOT
                }),
                _ = () => ({
                    type: n.v.RESET_SPORTSBOOK_JACKPOT
                }),
                u = () => ({
                    type: n.v.RESET_CASINO_GAME_JACKPOT
                }),
                y = function(e) {
                    let t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
                    return {
                        type: n.v.SET_ACTIVE_OPTIONS,
                        payload: { ...e,
                            shouldUpdateUID: t
                        }
                    }
                },
                S = e => ({
                    type: n.v.SET_CASHED_TOURNAMENTS_DATA,
                    payload: e
                }),
                T = e => ({
                    type: n.v.SET_CASHED_TOURNAMENTS_OPTIONS,
                    payload: e
                }),
                g = e => ({
                    type: n.v.SET_SELECTED_CASINO_GAME,
                    payload: e
                }),
                h = e => ({
                    type: n.v.SET_JOINED_TOURNAMENTS,
                    payload: e
                }),
                E = e => ({
                    type: n.v.SET_SELECTED_CASINO_CATEGORY_ID,
                    payload: e
                }),
                A = e => ({
                    type: n.v.SET_TOURNAMENT_ACTIVE_PRODUCT_TYPE_ID,
                    payload: e
                })
        },
        333033: (e, t, a) => {
            a.d(t, {
                Vt: () => o,
                Xo: () => s,
                gT: () => i,
                z_: () => l
            });
            var n = a(159686);
            const i = e => ({
                    type: n.ly.SET_E_SPORT_LIST_DATA,
                    payload: e
                }),
                o = e => ({
                    type: n.ly.SET_CASHED_E_SPORT_PREMATCH_GAMES,
                    payload: e
                }),
                l = e => ({
                    type: n.ly.SET_ESPORT_GAMES,
                    payload: e
                }),
                s = e => ({
                    type: n.ly.SET_ESPORT_GAME_DATA,
                    payload: e
                })
        },
        685527: (e, t, a) => {
            a.d(t, {
                Mz: () => p,
                ZA: () => c,
                cl: () => d,
                eM: () => r,
                oU: () => s,
                zg: () => m
            });
            var n = a(849594),
                i = a(123213),
                o = a(556785);
            const l = JSON.parse(i.A.getItem((0, o.U)("events", "ACTIVE_TIME_FILTER"))) || {},
                s = e => ({
                    type: n.f.SET_EVENTS,
                    payload: e
                }),
                r = e => ({
                    type: n.f.SET_SPORTS,
                    payload: e
                }),
                c = e => ({
                    type: n.f.REMOVE_SPORT,
                    payload: e
                }),
                d = e => ({
                    type: n.f.SET_SELECTED_SPORT,
                    payload: e
                }),
                m = e => ({
                    type: n.f.SET_SELECTED_EVENTS_TYPE,
                    payload: e
                }),
                p = e => (i.A.setItem((0, o.U)("events", "ACTIVE_TIME_FILTER"), JSON.stringify({ ...l,
                    ...e
                })), {
                    type: n.f.SET_TIME_FILTER,
                    payload: e
                })
        },
        398610: (e, t, a) => {
            a.d(t, {
                $S: () => m,
                DX: () => d,
                K2: () => l,
                WW: () => i,
                dw: () => o,
                eQ: () => s,
                rp: () => r,
                vN: () => c
            });
            var n = a(159686);
            const i = e => ({
                    type: n.ig.SET_FAVORITES_MARKETS_COUNT,
                    payload: e
                }),
                o = e => ({
                    type: n.ig.TOGGLE_FAVORITE,
                    payload: e
                }),
                l = e => ({
                    type: n.ig.SET_FAVORITE_SPORTS_DATA,
                    payload: e
                }),
                s = e => ({
                    type: n.ig.SET_MARKETS_COUNTS,
                    payload: e
                }),
                r = e => ({
                    type: n.ig.CLEAR_FAVORITE,
                    payload: e
                }),
                c = e => ({
                    type: n.ig.SET_FAVORITE_DATA_LOADING,
                    payload: e
                }),
                d = e => ({
                    type: n.ig.SET_FAVORITE_IDS_LOADING,
                    payload: e
                }),
                m = () => ({
                    type: n.ig.CLEAR_FAVORITE_MATCHES
                })
        },
        563077: (e, t, a) => {
            a.d(t, {
                $: () => o,
                p: () => i
            });
            var n = a(159686);
            const i = e => ({
                    type: n.AU.SET_STATE,
                    payload: {
                        swarmData: e
                    }
                }),
                o = e => ({
                    type: n.AU.UPDATE_STATE,
                    payload: {
                        updatedSwarmData: e
                    }
                })
        },
        117893: (e, t, a) => {
            a.d(t, {
                OJQ: () => i.O,
                rpN: () => r.rp,
                $SV: () => r.$S,
                PaU: () => u.P,
                kWR: () => u.kW,
                x7m: () => o.x7,
                XM_: () => h,
                PSk: () => o.PS,
                Pel: () => o.Pe,
                JJI: () => n.JJ,
                Wvp: () => o.Wv,
                fZJ: () => o.fZ,
                lGH: () => y.lG,
                KKp: () => y.KK,
                qQ2: () => o.qQ,
                d_c: () => y.d_,
                QMc: () => y.QM,
                Vtw: () => s.Vt,
                VVX: () => y.VV,
                Tvr: () => y.Tv,
                TGP: () => u.TG,
                wZO: () => _.wZ,
                Si7: () => _.Si,
                Av6: () => u.Av,
                eZZ: () => _.eZ,
                pbi: () => p.pb,
                Ik1: () => o.Ik,
                CrN: () => y.Cr,
                pG8: () => _.pG,
                gTd: () => s.gT,
                kBf: () => _.kB,
                ipv: () => _.ip,
                $Vu: () => o.$V,
                bPu: () => u.bP,
                vN2: () => r.vN,
                DX2: () => r.DX,
                h3P: () => n.h3,
                K2R: () => r.K2,
                WWz: () => r.WW,
                LOZ: () => n.LO,
                L15: () => _.L1,
                ps9: () => c.p,
                AnC: () => _.An,
                AJg: () => p.AJ,
                Xoz: () => s.Xo,
                qpX: () => n.qp,
                xJb: () => o.xJ,
                xSz: () => o.xS,
                _1E: () => o._1,
                zN: () => _.zN,
                _EO: () => n._E,
                yB5: () => _.yB,
                nUT: () => m.nU,
                upf: () => m.up,
                n_q: () => _.n_,
                pU9: () => m.pU,
                hB6: () => u.hB,
                LYK: () => y.LY,
                t$7: () => y.t$,
                ywT: () => y.yw,
                eQ5: () => r.eQ,
                _yk: () => m._y,
                xiv: () => m.xi,
                j9B: () => o.j9,
                zkF: () => d.z,
                W8U: () => y.W8,
                Aiz: () => u.Ai,
                Ujw: () => T,
                gBu: () => g,
                $5h: () => u.$5,
                Mi9: () => u.Mi,
                lDW: () => y.lD,
                QH4: () => y.QH,
                $sl: () => l.$s,
                pNR: () => o.pN,
                kYL: () => o.kY,
                WOw: () => u.WO,
                OXN: () => _.OX,
                Rij: () => o.Ri,
                PSM: () => y.PS,
                k8p: () => p.k8,
                JqY: () => u.Jq,
                _Io: () => o._I,
                ykG: () => _.yk,
                ziV: () => y.zi,
                drc: () => y.dr,
                RM6: () => y.RM,
                BGx: () => u.BG,
                Se9: () => y.Se,
                Qrh: () => o.Qr,
                kQt: () => o.kQ,
                Kay: () => y.K,
                DMb: () => u.DM,
                Xd9: () => _.Xd,
                qe: () => _.qe,
                Bti: () => u.Bt,
                sX7: () => u.sX,
                Ov8: () => u.Ov,
                VoE: () => u.Vo,
                oa9: () => u.XO,
                Xz$: () => u.Xz,
                EW7: () => u.EW,
                dwU: () => r.dw,
                pho: () => o.ph,
                _Ty: () => o._T,
                P0W: () => _.P0,
                $jT: () => c.$,
                sip: () => _.si,
                b6U: () => u.b6
            });
            var n = a(701616),
                i = a(314100),
                o = a(464418),
                l = a(890286),
                s = a(333033),
                r = (a(685527), a(398610)),
                c = a(563077),
                d = a(355939),
                m = a(122900),
                p = a(799112),
                _ = a(791661),
                u = (a(971139), a(493587), a(552176), a(307022)),
                y = a(93907),
                S = a(159686);
            const T = e => ({
                    type: S.YV.SET_PAYMENTS,
                    payload: e
                }),
                g = () => ({
                    type: S.YV.SET_PAYMENTS_LOADING
                }),
                h = () => ({
                    type: S.YV.RESET_PAYMENTS
                })
        },
        355939: (e, t, a) => {
            a.d(t, {
                f: () => i,
                z: () => o
            });
            var n = a(944882);
            const i = e => ({
                    type: n.g.SET_REGION_DATA_LOADING,
                    payload: e
                }),
                o = e => ({
                    type: n.g.SET_MOBILE_DATA_LOADING,
                    payload: e
                })
        },
        122900: (e, t, a) => {
            a.d(t, {
                $p: () => m,
                CN: () => u,
                D$: () => c,
                H_: () => T,
                Mc: () => p,
                Qe: () => y,
                _y: () => _,
                _z: () => v,
                fq: () => E,
                gZ: () => s,
                l3: () => l,
                lL: () => A,
                m$: () => o,
                mr: () => i,
                nU: () => S,
                pU: () => r,
                uY: () => h,
                up: () => g,
                xi: () => d
            });
            var n = a(350355);
            const i = e => ({
                    payload: e,
                    type: n.f.SET_MATCH_STREAMING_GAME_DATA
                }),
                o = e => ({
                    payload: e,
                    type: n.f.SET_MATCH_STREAMING_MODE
                }),
                l = e => ({
                    payload: e,
                    type: n.f.SET_IS_CAN_FIX_MS_ON_TOP
                }),
                s = (e, t) => ({
                    payload: {
                        ignoreMinimizedState: e,
                        gameId: t
                    },
                    type: n.f.RESET_MATCH_STREAMING_STATE
                }),
                r = e => ({
                    payload: e,
                    type: n.f.SET_LIVE_STREAM_INFO
                }),
                c = e => ({
                    payload: e,
                    type: n.f.SET_MATCH_STREAMING_CHANNELS_INFO
                }),
                d = e => ({
                    payload: e,
                    type: n.f.SET_MATCH_STREAMING_STREAM_URL
                }),
                m = e => ({
                    payload: e,
                    type: n.f.SET_IS_MATCH_STREAMER_IFRAME_LOADED
                }),
                p = e => ({
                    payload: e,
                    type: n.f.SET_IS_STREAMER_LANDSCAPE
                }),
                _ = e => ({
                    payload: e,
                    type: n.f.SET_MATCH_STREAMING_STREAM_TYPE
                }),
                u = e => ({
                    payload: e,
                    type: n.f.SET_DISABLE_MATCH_STREAMING_STREAM_TYPE
                }),
                y = e => ({
                    payload: e,
                    type: n.f.TOGGLE_MATCH_STREAMING_SETTINGS
                }),
                S = e => ({
                    payload: e,
                    type: n.f.SET_IS_MATCH_STREAMING_CHANNELS_AVAILABLE
                }),
                T = e => ({
                    payload: e,
                    type: n.f.SET_IS_MATCH_STREAMING_THEATRE_MODE_AVAILABLE
                }),
                g = e => ({
                    payload: e,
                    type: n.f.SET_IS_MATCH_STREAMING_HIDDEN
                }),
                h = e => ({
                    payload: e,
                    type: n.f.SET_MATCH_STREAMING_THEATRE_MODE
                }),
                E = e => ({
                    payload: e,
                    type: n.f.SET_MATCH_STREAMING_CONTAINER_INFO
                }),
                A = e => ({
                    payload: e,
                    type: n.f.SET_MATCH_STREAMING_MOUNTING_INFO
                }),
                v = e => ({
                    payload: e,
                    type: n.f.SET_IS_MATCH_STREAMING_PREVIEW_UNAVAILABLE
                })
        },
        799112: (e, t, a) => {
            a.d(t, {
                AJ: () => l,
                k8: () => i,
                pb: () => o,
                tj: () => s
            });
            var n = a(879003);
            const i = e => ({
                    type: n.d.SET_SPORT_DATA,
                    payload: e
                }),
                o = e => ({
                    type: n.d.SET_COMPETITION_DATA,
                    payload: e
                }),
                l = e => ({
                    type: n.d.SET_GAME_DATA,
                    payload: e
                }),
                s = e => ({
                    type: n.d.SET_ALL_DATA,
                    payload: e
                })
        },
        791661: (e, t, a) => {
            a.d(t, {
                An: () => p,
                L1: () => m,
                OX: () => g,
                P0: () => d,
                Si: () => h,
                Xd: () => l,
                eZ: () => c,
                ip: () => A,
                kB: () => _,
                n_: () => T,
                pG: () => u,
                qe: () => r,
                si: () => s,
                wZ: () => E,
                yB: () => S,
                yk: () => v,
                zN: () => y
            });
            var n = a(159686),
                i = a(123213),
                o = a(556785);
            const l = e => ({
                    type: n.u1.SET_UPCOMING_DATA,
                    payload: {
                        swarmData: e
                    }
                }),
                s = e => ({
                    type: n.u1.UPDATE_UPCOMING_DATA,
                    payload: {
                        updatedSwarmData: e
                    }
                }),
                r = e => ({
                    type: n.u1.SET_UPCOMING_JSON_EXIST_IDS,
                    payload: e
                }),
                c = e => ({
                    type: n.u1.SET_RACING_COMPETITION_DATA,
                    payload: {
                        swarmData: e
                    }
                }),
                d = e => ({
                    type: n.u1.UPDATE_RACING_COMPETITION_DATA,
                    payload: {
                        updatedSwarmData: e
                    }
                }),
                m = e => ({
                    type: n.u1.SET_GAME,
                    payload: {
                        swarmData: e
                    }
                }),
                p = e => ({
                    type: n.u1.SET_GAME_JSON_EXIST_IDS,
                    payload: e
                }),
                _ = (e, t) => ({
                    type: n.u1.SET_EACH_WAY_PARTNER_TERMS,
                    payload: {
                        manualEachWayData: e,
                        marketId: t
                    }
                }),
                u = e => (i.A.setItem((0, o.U)("sportsbook", "RACING_DATE_AND_SPORT_FILTER_ACTIVE_TAB"), e), {
                    type: n.u1.SET_DATE_AND_SPORT_FILTER_ACTIVE_TAB,
                    payload: e
                }),
                y = e => ({
                    type: n.u1.SET_IS_COMPETITIONS_LOADING,
                    payload: e
                }),
                S = e => ({
                    type: n.u1.SET_IS_GAMES_LOADING,
                    payload: e
                }),
                T = e => ({
                    type: n.u1.SET_IS_UPCOMING_RACES_LOADING,
                    payload: e
                }),
                g = e => ({
                    type: n.u1.SET_SINGLE_GAME_FROM_ACTIVE_TAB,
                    payload: e
                }),
                h = e => ({
                    type: n.u1.CHECK_SINGLE_GAME_START_TS,
                    payload: e
                }),
                E = e => ({
                    type: n.u1.CHECK_COMPETITION,
                    payload: e
                }),
                A = e => ({
                    type: n.u1.ENDED_GAME_ID,
                    payload: e
                }),
                v = e => ({
                    type: n.u1.SET_STORED_GAME_IDS,
                    payload: e
                })
        },
        971139: (e, t, a) => {
            a.d(t, {
                DF: () => p,
                Mc: () => m,
                NW: () => d,
                QI: () => o,
                RL: () => s,
                UG: () => l,
                XO: () => c,
                XU: () => i,
                dr: () => _,
                tL: () => r
            });
            var n = a(203754);
            const i = e => ({
                    type: n.k.SET_DATE,
                    payload: e
                }),
                o = e => ({
                    type: n.k.SET_COMPETITION,
                    payload: e
                }),
                l = e => ({
                    type: n.k.SET_TEAM,
                    payload: e
                }),
                s = e => ({
                    type: n.k.SET_STATUS,
                    payload: e
                }),
                r = e => ({
                    type: n.k.SET_SPORT,
                    payload: e
                }),
                c = e => ({
                    type: n.k.SET_DATA,
                    payload: e
                }),
                d = () => ({
                    type: n.k.SET_TRIGGER
                }),
                m = () => ({
                    type: n.k.SET_CURRENT_STATUS
                }),
                p = e => ({
                    type: n.k.SET_DATA_LOADING,
                    payload: e
                }),
                _ = () => ({
                    type: n.k.RESET_FILTERS
                })
        },
        552176: (e, t, a) => {
            a.d(t, {
                WK: () => o,
                w1: () => i
            });
            var n = a(451957);
            const i = e => ({
                    type: n.R.SET_ELEMENT_PRESENT,
                    payload: e
                }),
                o = e => ({
                    type: n.R.SET_ELEMENT_ABSENT,
                    payload: e
                })
        },
        93907: (e, t, a) => {
            a.d(t, {
                Cr: () => C,
                Jl: () => s,
                K: () => I,
                KK: () => u,
                LY: () => v,
                M5: () => S,
                PS: () => i,
                QH: () => T,
                QM: () => A,
                RM: () => y,
                Se: () => h,
                TB: () => O,
                Tv: () => l,
                UF: () => E,
                VV: () => o,
                W8: () => d,
                d_: () => b,
                dr: () => r,
                lD: () => g,
                lG: () => _,
                sV: () => N,
                t$: () => p,
                yE: () => f,
                yw: () => m,
                zi: () => c
            });
            var n = a(159686);
            const i = e => ({
                    type: n.e8.SET_SPORT_LIST_DATA,
                    payload: e
                }),
                o = e => ({
                    type: n.e8.SET_CAHSED_GAME_DATA,
                    payload: e
                }),
                l = e => ({
                    type: n.e8.SET_CASHED_SPORT_DATA,
                    payload: e
                }),
                s = e => ({
                    type: n.e8.SET_GAMES_BY_COMPETITIONS,
                    payload: e
                }),
                r = e => ({
                    type: n.e8.SET_STREAM_DATA,
                    payload: e
                }),
                c = e => ({
                    type: n.e8.SET_STREAM_CHANNELS,
                    payload: e
                }),
                d = e => ({
                    type: n.e8.SET_MULTIPLE_SELECTIONS,
                    payload: e
                }),
                m = e => ({
                    type: n.e8.SET_MARKET_TYPES,
                    payload: e
                }),
                p = e => ({
                    type: n.e8.SET_MARKET_TYPE,
                    payload: e
                }),
                _ = e => ({
                    type: n.e8.SET_BOOSTED_ODDS,
                    payload: e
                }),
                u = () => ({
                    type: n.e8.SET_BOOSTED_ODDS_CALLED
                }),
                y = () => ({
                    type: n.e8.SET_STREAM_DATA_LOADING
                }),
                S = e => ({
                    type: n.e8.SET_HAS_TOP_LEAGUE_GAMES,
                    payload: e
                }),
                T = e => ({
                    type: n.e8.SCROLL_TO_GAME_ID,
                    payload: e
                }),
                g = e => ({
                    type: n.e8.SCROLL_TO_COMPETITION_ID,
                    payload: e
                }),
                h = e => ({
                    type: n.e8.SET_TIME_FILTER_DATA,
                    payload: e
                }),
                E = (e, t) => ({
                    type: n.e8.SET_SPORTS_LIST_SPORT_DATA,
                    payload: e,
                    sportAlias: t
                }),
                A = e => ({
                    type: n.e8.SET_CALENDAR_MARKET_TYPES,
                    payload: e
                }),
                v = e => ({
                    type: n.e8.SET_MARKET_INFO_TYPE,
                    payload: e
                }),
                b = e => ({
                    type: n.e8.SET_CALENDAR_MARKET_TYPE,
                    payload: e
                }),
                f = e => ({
                    type: n.e8.SET_REGION_MARKETS,
                    payload: e
                }),
                N = e => ({
                    type: n.e8.SET_USER_NOTIFICATIONS,
                    payload: e
                }),
                O = e => ({
                    type: n.e8.SET_GAMES_COUNT,
                    payload: e
                }),
                I = e => ({
                    type: n.e8.SET_TOURNAMENT_SPORT_IDS,
                    payload: e
                }),
                C = e => ({
                    type: n.e8.SET_COUPONS,
                    payload: e
                })
        },
        307022: (e, t, a) => {
            a.d(t, {
                $5: () => u,
                $M: () => E,
                $S: () => O,
                Ai: () => P,
                Av: () => R,
                BG: () => D,
                Bt: () => _,
                D3: () => A,
                DM: () => m,
                EW: () => g,
                Jq: () => x,
                Mi: () => M,
                Ov: () => C,
                P: () => p,
                Sl: () => r,
                TG: () => h,
                Vo: () => c,
                WO: () => b,
                XO: () => v,
                Xz: () => S,
                b6: () => s,
                bP: () => T,
                fk: () => I,
                hB: () => d,
                kW: () => y,
                rO: () => N,
                sX: () => l,
                tw: () => f
            });
            var n = a(550736),
                i = a(215493),
                o = a(647905);
            const l = e => ({
                    type: i.Z.SET_USER_DATA,
                    payload: e
                }),
                s = e => ({
                    type: i.Z.UPDATE_USER_DATA,
                    payload: e
                }),
                r = () => ({
                    type: i.Z.REMOVE_USER_DATA
                }),
                c = e => ({
                    type: i.Z.SET_USER_LOGGED_IN,
                    payload: e
                }),
                d = e => ({
                    type: i.Z.SET_USER_LOGIN_LIMIT,
                    payload: e
                }),
                m = e => ({
                    type: i.Z.SET_INBOX_MESSAGES_COUNT,
                    payload: e
                }),
                p = e => ({
                    type: i.Z.DELETE_MESSAGE,
                    payload: e
                }),
                _ = (e, t, a, l) => s => {
                    a ? (0, n.KO)({
                        max_rows: 30,
                        acceptance_type: l || 0
                    }, (e => {
                        s({
                            type: i.Z.SET_USER_BONUSES,
                            payload: {
                                freeSpinBonuses: Array.isArray(e.details) ? e.details : []
                            }
                        }), null === t || void 0 === t || t()
                    })) : (0, n.Ey)(e, (a => {
                        const n = e ? o.H5.FREE_BONUSES : o.H5.CASINO_BONUSES;
                        s({
                            type: i.Z.SET_USER_BONUSES,
                            payload: {
                                [n]: Array.isArray(a.bonuses) ? a.bonuses : []
                            }
                        }), null === t || void 0 === t || t()
                    }))
                },
                u = e => ({
                    type: i.Z.SET_PENDING_SUPER_BETS,
                    payload: e
                }),
                y = e => ({
                    type: i.Z.REMOVE_PENDING_SUPER_BET,
                    payload: e
                }),
                S = e => ({
                    type: i.Z.SET_VERIFICATION_MODAL,
                    payload: e
                }),
                T = e => ({
                    type: i.Z.SET_FAST_REG_DATA,
                    payload: e
                }),
                g = e => ({
                    type: i.Z.SET_WITHDRAWAL_CAPABILITY,
                    payload: e
                }),
                h = e => ({
                    type: i.Z.SET_CASINO_BONUS_DETAILS,
                    payload: e
                }),
                E = e => ({
                    type: i.Z.SET_SHOW_AUTOIDENT_VERIFICATION_MODAL,
                    payload: e
                }),
                A = e => ({
                    type: i.Z.SET_SHOW_CANCEL_REGISTER_POPUP,
                    payload: e
                }),
                v = e => ({
                    type: i.Z.SET_USER_OPT_INS,
                    payload: e
                }),
                b = e => ({
                    type: i.Z.SHOULD_GET_USER_OPTINS,
                    payload: e
                }),
                f = e => ({
                    type: i.Z.SEND_AS_PROMO_CODE,
                    payload: e
                }),
                N = e => ({
                    type: i.Z.HAS_FORM_ERROR,
                    payload: e
                }),
                O = e => ({
                    type: i.Z.UPDATE_GPS_TRACKING,
                    payload: e
                }),
                I = () => ({
                    type: i.Z.RESET_GPS_TRACKING
                }),
                C = e => ({
                    type: i.Z.USER_DEPOSIT_LIMITS,
                    payload: e
                }),
                M = e => ({
                    type: i.Z.SET_REMEMBER_ME,
                    payload: e
                }),
                R = e => ({
                    type: i.Z.SET_CLIENT_INFO,
                    payload: e
                }),
                D = e => ({
                    type: i.Z.SUM_SUB_MODAL_OPEN,
                    payload: e
                }),
                P = e => ({
                    type: i.Z.SET_PAYMENT_DEPOSIT_PROMO,
                    payload: e
                }),
                x = e => ({
                    type: i.Z.STAKE_BALANCE,
                    payload: e
                })
        },
        841591: (e, t, a) => {
            a.d(t, {
                BM: () => E,
                E: () => c,
                Ed: () => l,
                FI: () => O,
                GT: () => S,
                Hk: () => g,
                I1: () => u,
                JL: () => T,
                Jo: () => m,
                KD: () => i,
                Ks: () => C,
                RX: () => r,
                T_: () => R,
                Uf: () => A,
                V7: () => b,
                XD: () => w,
                Xb: () => o,
                Xv: () => v,
                Z6: () => G,
                d1: () => d,
                d5: () => I,
                f6: () => s,
                fI: () => _,
                gh: () => h,
                h0: () => p,
                jp: () => L,
                oL: () => k,
                p_: () => D,
                t9: () => N,
                tB: () => x,
                tH: () => f,
                wV: () => y,
                yX: () => B,
                z$: () => M,
                zQ: () => P
            });
            const n = (0, a(534977).g)("appData"),
                i = n("colCount"),
                o = n("recaptchaEnabled"),
                l = n("recaptchaVersion"),
                s = n("siteKey"),
                r = n("recaptchaKey"),
                c = n("dataConfigs"),
                d = n("rounding"),
                m = n("roundingLoading"),
                p = n("regFieldData"),
                _ = n("showAdditionalInfo"),
                u = n("openedModals"),
                y = n("atozMenuData"),
                S = n("menuJsonData"),
                T = n("sectionsData"),
                g = n("postGridHiddenParams"),
                h = n("accountParams"),
                E = n("cashoutModalOpen"),
                A = n("depositModalOpen"),
                v = n("confirmedDeposit"),
                b = n("fireBaseToken"),
                f = n("headerState"),
                N = n("geolocationShakeData"),
                O = n("homeworkData"),
                I = n("sportsConfigsData"),
                C = n("isPaymentsLoading"),
                M = n("setCryptoCurrencies"),
                R = n("betShops"),
                D = n("sid"),
                P = n("remainingSessionDuration"),
                x = n("favoriteOnHeaderOpen"),
                w = n("favoriteSelectedTab"),
                G = n("idinData"),
                L = n("locateData"),
                k = n("isDarkMode"),
                B = n("higherZIndex")
        },
        283573: (e, t, a) => {
            a.d(t, {
                Gx: () => c,
                Kh: () => S,
                QJ: () => y,
                YK: () => g,
                fn: () => r,
                gI: () => _,
                tx: () => u,
                v6: () => T,
                zc: () => m
            });
            var n = a(280192),
                i = a(534977),
                o = a(827198);
            const l = (0, i.g)("favData"),
                s = l("marketsCount"),
                r = l("dataLoading"),
                c = l("idsLoading"),
                d = l("esport"),
                m = l("casino"),
                p = l("sportsbook"),
                _ = l("markets"),
                u = l("competitions"),
                y = (0, n.Mz)([p, d, s], ((e, t, a) => {
                    const n = {
                            live: { ...e.live,
                                data: (0, o.gn)(e.live.data, a)
                            },
                            prematch: { ...e.prematch,
                                data: (0, o.gn)(e.prematch.data, a)
                            }
                        },
                        i = {
                            live: { ...t.live,
                                data: (0, o.gn)(t.live.data, a)
                            },
                            prematch: { ...t.prematch,
                                data: (0, o.gn)(t.prematch.data, a)
                            }
                        },
                        l = { ...n.live.data,
                            ...i.live.data
                        },
                        s = { ...n.prematch.data,
                            ...i.prematch.data
                        };
                    return {
                        all: { ...l,
                            ...s
                        },
                        esport: i,
                        sportsbook: n,
                        liveSports: l,
                        prematchSports: s
                    }
                })),
                S = (0, n.Mz)([d, p], ((e, t) => {
                    const a = [...e.live.ids, ...e.prematch.ids],
                        n = [...t.live.ids, ...t.prematch.ids];
                    return {
                        esport: {
                            live: e.live.ids,
                            prematch: e.prematch.ids,
                            all: a
                        },
                        sportsbook: {
                            live: t.live.ids,
                            prematch: t.prematch.ids,
                            all: n
                        },
                        liveSports: [...e.live.ids, ...t.live.ids],
                        prematchSports: [...e.prematch.ids, ...t.prematch.ids],
                        all: [...n, ...a]
                    }
                })),
                T = (0, n.Mz)([d, p, m, u], ((e, t, a, n) => {
                    const i = a.length,
                        o = n.length,
                        l = e.live.ids.length + e.prematch.ids.length,
                        s = t.live.ids.length + t.prematch.ids.length;
                    return {
                        esport: l,
                        casino: i,
                        sportsbook: s,
                        competitions: o,
                        sports: s + l,
                        total: l + s + i + o,
                        sportsWithCompetitions: s + l + o,
                        liveSports: e.live.ids.length + t.live.ids.length,
                        prematchSports: e.prematch.ids.length + t.prematch.ids.length,
                        onlyLiveSports: {
                            ids: [...e.live.ids, ...t.live.ids],
                            count: e.live.ids.length + t.live.ids.length
                        }
                    }
                })),
                g = function() {
                    for (var e = arguments.length, t = new Array(e), a = 0; a < e; a++) t[a] = arguments[a];
                    const [i, o] = t;
                    switch (o) {
                        case "casino":
                            return (0, n.Mz)([m], (e => e.some((e => {
                                let {
                                    id: t
                                } = e;
                                return i === t
                            }))));
                        case "competitions":
                            return (0, n.Mz)([u], (e => e.some((e => e.id === i))));
                        case "esport":
                        case "sportsbook":
                            return (0, n.Mz)([S], (e => {
                                let {
                                    all: t
                                } = e;
                                return t.includes(i)
                            }));
                        case "markets":
                            return (0, n.Mz)([_], (e => e.includes(i)))
                    }
                }
        },
        462956: (e, t, a) => {
            a.d(t, {
                Ot: () => l,
                es: () => o,
                gU: () => i
            });
            const n = (0, a(534977).g)("socket"),
                i = n("partnerConfigs"),
                o = n("jackpots"),
                l = n("isConnected")
        },
        963971: (e, t, a) => {
            a.d(t, {
                a: () => i
            });
            const n = ["Canceled", "Finished"],
                i = e => !e || !n.includes(e)
        },
        482463: (e, t, a) => {
            a.d(t, {
                I: () => n
            });
            const n = (e, t, a) => {
                const n = t || "order",
                    i = a || "asc";
                return e.sort(((e, t) => {
                    var a, o, l, s, r, c;
                    return (null !== (a = null === e || void 0 === e ? void 0 : e[n]) && void 0 !== a ? a : 0) === (null !== (o = null === t || void 0 === t ? void 0 : t[n]) && void 0 !== o ? o : 0) ? 0 : "desc" === i ? (null !== (l = null === e || void 0 === e ? void 0 : e[n]) && void 0 !== l ? l : 0) < (null !== (s = null === t || void 0 === t ? void 0 : t[n]) && void 0 !== s ? s : 1) ? 1 : -1 : (null !== (r = null === e || void 0 === e ? void 0 : e[n]) && void 0 !== r ? r : 0) > (null !== (c = null === t || void 0 === t ? void 0 : t[n]) && void 0 !== c ? c : 1) ? 1 : -1
                }))
            }
        },
        647905: (e, t, a) => {
            a.d(t, {
                By: () => o,
                H5: () => n,
                v0: () => i
            });
            let n = function(e) {
                return e.FREE_BONUSES = "freeBonuses", e.CASINO_BONUSES = "casinoBonuses", e
            }({});
            const i = {
                    CANCEL_BONUS: "cancel_bonus",
                    CLAIM_BONUS: "claim_bonus"
                },
                o = {
                    BONUS_CANCELED_SUCCESS: "bonusCanceledSuccess",
                    BONUS_CLAIMED_SUCCESS: "bonusClaimedSuccess"
                }
        },
        224272: (e, t, a) => {
            a.d(t, {
                j: () => n
            });
            const n = {
                GET_OPTIONS: "getOptions",
                GET_GAMES: "getGames",
                GET_PROMOTED_GAMES: "getPromotedGames",
                GET_TOURNAMENT_GAMES: "getTournamentGames",
                GET_GAME_TOURNAMENTS: "getTournaments",
                GET_GROUPED_PROVIDER_OPTIONS: "getGroupedProviderOptions",
                GET_DECENTRALIZED_GAMES: "games",
                GET_DECENTRALIZED_GAME: "game",
                GET_DECENTRALIZED_CATEGORIES: "categories"
            }
        },
        242146: (e, t, a) => {
            a.d(t, {
                DE: () => d,
                EE: () => c,
                Hk: () => o,
                _l: () => s,
                bX: () => l,
                qU: () => r
            });
            var n = a(197262),
                i = a(737536);
            const o = {
                    favorite: {
                        id: "favorite",
                        name: "favorite",
                        title: n.A.t("casino.favorite"),
                        games_count: ""
                    },
                    all: {
                        id: "all",
                        name: "all",
                        title: n.A.t("casino.all-games"),
                        games_count: ""
                    },
                    lastPlayed: {
                        id: "last-played",
                        name: "last-played",
                        title: n.A.t("casino.last-played"),
                        games_count: ""
                    },
                    suggested: {
                        id: "suggested",
                        name: "suggested",
                        title: n.A.t("casino.suggested"),
                        games_count: ""
                    },
                    special: {
                        id: "special",
                        name: "special",
                        title: n.A.t("casino.special"),
                        games_count: ""
                    },
                    specialLive: {
                        id: "specialLive",
                        name: "specialLive",
                        title: n.A.t("casino.specialLive"),
                        games_count: ""
                    }
                },
                l = Object.values(o),
                s = Object.values(o).map((e => e.id)),
                r = [o.favorite.id, o.lastPlayed.id, o.suggested.id, o.special.id, o.specialLive.id],
                c = {
                    [o.lastPlayed.id]: i.y.GET_RECENT_PLAYED_CASINO_GAMES,
                    [o.suggested.id]: i.y.GET_CASINO_SUGGESTED_GAMES
                },
                d = ["casino", "live-casino"]
        },
        207610: (e, t, a) => {
            a.d(t, {
                Hl: () => s,
                Kk: () => c,
                Pg: () => i,
                Zg: () => o,
                _0: () => m,
                fe: () => d,
                iR: () => n,
                k4: () => l,
                n6: () => r,
                tU: () => p
            });
            const n = 2,
                i = 6,
                o = {
                    0: 6,
                    1: 5,
                    2: 5
                },
                l = 3,
                s = 6,
                r = 10,
                c = 6,
                d = 3,
                m = 10,
                p = 3
        },
        871237: (e, t, a) => {
            a.d(t, {
                AE: () => r,
                FJ: () => o,
                e9: () => l,
                qG: () => c,
                un: () => s
            });
            var n = a(197262),
                i = a(998285);
            const o = [{
                    label: n.A.t("casino.all"),
                    value: 0
                }, {
                    label: n.A.t("casino.canceledCasino"),
                    value: -1
                }, {
                    label: n.A.t("casino.finishedCasino"),
                    value: 1
                }, {
                    label: n.A.t("casino.liveCasinoTournaments"),
                    value: 2
                }, {
                    label: n.A.t("casino.upcomingCasino"),
                    value: 3
                }],
                l = [{
                    label: n.A.t("casino.registrationStarted"),
                    value: !0
                }, {
                    label: n.A.t("casino.registrationFinished"),
                    value: !1
                }],
                s = [{
                    label: n.A.t("casino.buyInCasino"),
                    value: 0
                }, {
                    label: n.A.t("casino.freeEntryCasino"),
                    value: 1
                }],
                r = [{
                    label: n.A.t("casino.canceled"),
                    value: -1
                }, {
                    label: n.A.t("casino.finished"),
                    value: 1
                }, {
                    label: n.A.t("casino.endsIn"),
                    value: 2
                }, {
                    label: n.A.t("casino.startsIn"),
                    value: 3
                }],
                c = [{
                    value: n.A.t("casino.casino"),
                    key: i.k.CASINO
                }, {
                    value: n.A.t("casino.sport"),
                    key: i.k.SPORT
                }]
        },
        210771: (e, t, a) => {
            a.d(t, {
                W: () => s
            });
            var n = a(860446),
                i = a.n(n),
                o = a(179177),
                l = a(558073);
            const s = function(e) {
                let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : ".";
                return i().utc(e).local().format((0, l.i)({
                    date: o.Ay.DT.longDate,
                    separator: t,
                    time: o.Ay.DT.time,
                    dateTimeSeparator: " "
                }).replace("MMM", "MM"))
            }
        },
        68392: (e, t, a) => {
            a.d(t, {
                N8: () => l,
                HN: () => r,
                Hv: () => s
            });
            const n = {
                AFA: {
                    symbol: "\u060b",
                    placement: "right"
                },
                ALL: {
                    symbol: "Lek",
                    placement: "right"
                },
                DZD: {
                    symbol: "\u062f\u062c",
                    placement: "right"
                },
                AOA: {
                    symbol: "Kz",
                    placement: "right"
                },
                ARS: {
                    symbol: "$",
                    placement: "left"
                },
                AMD: {
                    symbol: "\u058f",
                    placement: "right"
                },
                AWG: {
                    symbol: "\u0192",
                    placement: "right"
                },
                AUD: {
                    symbol: "$",
                    placement: "left"
                },
                AZN: {
                    symbol: "\u20bc",
                    placement: "right"
                },
                BSD: {
                    symbol: "B$",
                    placement: "right"
                },
                BHD: {
                    symbol: ".\u062f.\u0628",
                    placement: "right"
                },
                BDT: {
                    symbol: "\u09f3",
                    placement: "right"
                },
                BBD: {
                    symbol: "Bds$",
                    placement: "right"
                },
                BYR: {
                    symbol: "Br",
                    placement: "right"
                },
                BYN: {
                    symbol: "Br",
                    placement: "right"
                },
                BEF: {
                    symbol: "fr",
                    placement: "right"
                },
                BZD: {
                    symbol: "BZ$",
                    placement: "right"
                },
                BMD: {
                    symbol: "$",
                    placement: "left"
                },
                BTN: {
                    symbol: "Nu.",
                    placement: "right"
                },
                BOB: {
                    symbol: "Bs.",
                    placement: "right"
                },
                BAM: {
                    symbol: "KM",
                    placement: "right"
                },
                BWP: {
                    symbol: "P",
                    placement: "right"
                },
                BRL: {
                    symbol: "R$",
                    placement: "right"
                },
                GBP: {
                    symbol: "\xa3",
                    placement: "right"
                },
                BND: {
                    symbol: "B$",
                    placement: "right"
                },
                BGN: {
                    symbol: "\u041b\u0432.",
                    placement: "right"
                },
                BIF: {
                    symbol: "FBu",
                    placement: "right"
                },
                KHR: {
                    symbol: "\u17db",
                    placement: "right"
                },
                CAD: {
                    symbol: "C$",
                    placement: "left"
                },
                CVE: {
                    symbol: "$",
                    placement: "left"
                },
                CYP: {
                    symbol: "\xa3",
                    placement: "right"
                },
                KYD: {
                    symbol: "$",
                    placement: "left"
                },
                XOF: {
                    symbol: "CFA",
                    placement: "right"
                },
                XAF: {
                    symbol: "FCFA",
                    placement: "right"
                },
                XPF: {
                    symbol: "\u20a3",
                    placement: "right"
                },
                CLP: {
                    symbol: "$",
                    placement: "left"
                },
                CNY: {
                    symbol: "\xa5",
                    placement: "right"
                },
                COP: {
                    symbol: "$",
                    placement: "left"
                },
                KMF: {
                    symbol: "CF",
                    placement: "right"
                },
                CDF: {
                    symbol: "FC",
                    placement: "right"
                },
                CRC: {
                    symbol: "\u20a1",
                    placement: "right"
                },
                HRK: {
                    symbol: "kn",
                    placement: "right"
                },
                CUC: {
                    symbol: "CUC$",
                    placement: "right"
                },
                CUP: {
                    symbol: "\u20b1",
                    placement: "right"
                },
                CZK: {
                    symbol: "K\u010d",
                    placement: "right"
                },
                DKK: {
                    symbol: "Kr.",
                    placement: "right"
                },
                DJF: {
                    symbol: "Fdj",
                    placement: "right"
                },
                DOP: {
                    symbol: "RD$",
                    placement: "right"
                },
                XCD: {
                    symbol: "$",
                    placement: "left"
                },
                EGP: {
                    symbol: "E\xa3",
                    placement: "right"
                },
                ERN: {
                    symbol: "\u1293\u1255\u134b",
                    placement: "right"
                },
                EEK: {
                    symbol: "kr",
                    placement: "right"
                },
                ETB: {
                    symbol: "\u1265\u122d",
                    placement: "right"
                },
                EUR: {
                    symbol: "\u20ac",
                    placement: "left"
                },
                FKP: {
                    symbol: "\xa3",
                    placement: "right"
                },
                FJD: {
                    symbol: "FJ$",
                    placement: "right"
                },
                GMD: {
                    symbol: "D",
                    placement: "right"
                },
                GEL: {
                    symbol: "\u10da",
                    placement: "right"
                },
                DEM: {
                    symbol: "DM",
                    placement: "right"
                },
                GHC: {
                    symbol: "GH\u20b5",
                    placement: "right"
                },
                GHS: {
                    symbol: "GH\u20b5",
                    placement: "right"
                },
                GIP: {
                    symbol: "\xa3",
                    placement: "right"
                },
                GRD: {
                    symbol: "\u20af",
                    placement: "right"
                },
                GTQ: {
                    symbol: "Q",
                    placement: "right"
                },
                GGP: {
                    symbol: "\xa3",
                    placement: "right"
                },
                GNF: {
                    symbol: "FG",
                    placement: "right"
                },
                GYD: {
                    symbol: "$",
                    placement: "left"
                },
                HTG: {
                    symbol: "G",
                    placement: "right"
                },
                HNL: {
                    symbol: "L",
                    placement: "right"
                },
                HKD: {
                    symbol: "HK$",
                    placement: "left"
                },
                HUF: {
                    symbol: "Ft",
                    placement: "right"
                },
                ISK: {
                    symbol: "kr",
                    placement: "right"
                },
                INR: {
                    symbol: "\u20b9",
                    placement: "right"
                },
                IDR: {
                    symbol: "Rp",
                    placement: "right"
                },
                IRR: {
                    symbol: "\ufdfc",
                    placement: "right"
                },
                IQD: {
                    symbol: "\u062f.\u0639",
                    placement: "right"
                },
                IMP: {
                    symbol: "\xa3",
                    placement: "right"
                },
                ILS: {
                    symbol: "\u20aa",
                    placement: "right"
                },
                ITL: {
                    symbol: "L,\xa3",
                    placement: "right"
                },
                JMD: {
                    symbol: "J$",
                    placement: "right"
                },
                JPY: {
                    symbol: "\xa5",
                    placement: "right"
                },
                JEP: {
                    symbol: "\xa3",
                    placement: "right"
                },
                JOD: {
                    symbol: "\u0627.\u062f",
                    placement: "right"
                },
                KZT: {
                    symbol: "\u043b\u0432",
                    placement: "right"
                },
                KES: {
                    symbol: "KSh",
                    placement: "right"
                },
                KWD: {
                    symbol: "\u0643.\u062f",
                    placement: "right"
                },
                KGS: {
                    symbol: "\u043b\u0432",
                    placement: "right"
                },
                LAK: {
                    symbol: "\u20ad",
                    placement: "right"
                },
                LVL: {
                    symbol: "Ls",
                    placement: "right"
                },
                LBP: {
                    symbol: "\xa3",
                    placement: "right"
                },
                LSL: {
                    symbol: "L",
                    placement: "right"
                },
                LRD: {
                    symbol: "$",
                    placement: "left"
                },
                LYD: {
                    symbol: "\u062f.\u0644",
                    placement: "right"
                },
                LTL: {
                    symbol: "Lt",
                    placement: "right"
                },
                MTL: {
                    symbol: "\u20a4M",
                    placement: "right"
                },
                MOP: {
                    symbol: "$",
                    placement: "left"
                },
                MKD: {
                    symbol: "\u0434\u0435\u043d",
                    placement: "right"
                },
                MGA: {
                    symbol: "Ar",
                    placement: "right"
                },
                MWK: {
                    symbol: "MK",
                    placement: "right"
                },
                MYR: {
                    symbol: "RM",
                    placement: "right"
                },
                MVR: {
                    symbol: "Rf",
                    placement: "right"
                },
                MRO: {
                    symbol: "MRU",
                    placement: "right"
                },
                MUR: {
                    symbol: "\u20a8",
                    placement: "right"
                },
                MXN: {
                    symbol: "$",
                    placement: "left"
                },
                MDL: {
                    symbol: "L",
                    placement: "right"
                },
                MNT: {
                    symbol: "\u20ae",
                    placement: "right"
                },
                MZN: {
                    symbol: "MT",
                    placement: "right"
                },
                MAD: {
                    symbol: "MAD",
                    placement: "right"
                },
                MZM: {
                    symbol: "MT",
                    placement: "right"
                },
                MMK: {
                    symbol: "K",
                    placement: "right"
                },
                NAD: {
                    symbol: "$",
                    placement: "left"
                },
                NPR: {
                    symbol: "\u20a8",
                    placement: "right"
                },
                ANG: {
                    symbol: "\u0192",
                    placement: "right"
                },
                TWD: {
                    symbol: "NT$",
                    placement: "right"
                },
                NZD: {
                    symbol: "$",
                    placement: "left"
                },
                NIO: {
                    symbol: "C$",
                    placement: "right"
                },
                NGN: {
                    symbol: "\u20a6",
                    placement: "right"
                },
                KPW: {
                    symbol: "\u20a9",
                    placement: "right"
                },
                NOK: {
                    symbol: "kr",
                    placement: "right"
                },
                OMR: {
                    symbol: "\u0631.\u0639.",
                    placement: "right"
                },
                PKR: {
                    symbol: "\u20a8",
                    placement: "right"
                },
                PAB: {
                    symbol: "B/.",
                    placement: "right"
                },
                PGK: {
                    symbol: "K",
                    placement: "right"
                },
                PYG: {
                    symbol: "\u20b2",
                    placement: "right"
                },
                PEN: {
                    symbol: "S/.",
                    placement: "right"
                },
                PHP: {
                    symbol: "\u20b1",
                    placement: "right"
                },
                PLN: {
                    symbol: "z\u0142",
                    placement: "right"
                },
                QAR: {
                    symbol: "\u0631.\u0642",
                    placement: "right"
                },
                RON: {
                    symbol: "lei",
                    placement: "right"
                },
                RUB: {
                    symbol: "\u20bd",
                    placement: "right"
                },
                RWF: {
                    symbol: "FRw",
                    placement: "right"
                },
                SVC: {
                    symbol: "\u20a1",
                    placement: "right"
                },
                WST: {
                    symbol: "SAT",
                    placement: "right"
                },
                SAR: {
                    symbol: "\ufdfc",
                    placement: "right"
                },
                RSD: {
                    symbol: "\u0414\u0438\u043d.",
                    placement: "right"
                },
                SCR: {
                    symbol: "SRe",
                    placement: "right"
                },
                SLL: {
                    symbol: "Le",
                    placement: "right"
                },
                SGD: {
                    symbol: "$",
                    placement: "left"
                },
                SKK: {
                    symbol: "Sk",
                    placement: "right"
                },
                SBD: {
                    symbol: "Si$",
                    placement: "right"
                },
                SOS: {
                    symbol: "Sh.so.",
                    placement: "right"
                },
                ZAR: {
                    symbol: "R",
                    placement: "right"
                },
                KRW: {
                    symbol: "\u20a9",
                    placement: "right"
                },
                XDR: {
                    symbol: "SDR",
                    placement: "right"
                },
                LKR: {
                    symbol: "Rs",
                    placement: "right"
                },
                SHP: {
                    symbol: "\xa3",
                    placement: "right"
                },
                SDG: {
                    symbol: ".\u0633.\u062c",
                    placement: "right"
                },
                SSP: {
                    symbol: "\xa3",
                    placement: "right"
                },
                SRD: {
                    symbol: "$",
                    placement: "left"
                },
                SZL: {
                    symbol: "E",
                    placement: "right"
                },
                SEK: {
                    symbol: "kr",
                    placement: "right"
                },
                CHF: {
                    symbol: "CHf",
                    placement: "right"
                },
                SYP: {
                    symbol: "\xa3S",
                    placement: "right"
                },
                STD: {
                    symbol: "Db",
                    placement: "right"
                },
                TJS: {
                    symbol: "SM",
                    placement: "right"
                },
                TZS: {
                    symbol: "TSh",
                    placement: "right"
                },
                THB: {
                    symbol: "\u0e3f",
                    placement: "right"
                },
                TOP: {
                    symbol: "$",
                    placement: "left"
                },
                TTD: {
                    symbol: "TT$",
                    placement: "right"
                },
                TND: {
                    symbol: "\u062a.\u062f",
                    placement: "right"
                },
                TRY: {
                    symbol: "\u20ba",
                    placement: "right"
                },
                TMM: {
                    symbol: "T",
                    placement: "right"
                },
                TMT: {
                    symbol: "T",
                    placement: "right"
                },
                TVD: {
                    symbol: "$",
                    placement: "left"
                },
                UGX: {
                    symbol: "USh",
                    placement: "right"
                },
                UAH: {
                    symbol: "\u20b4",
                    placement: "right"
                },
                AED: {
                    symbol: "\u062f.\u0625",
                    placement: "right"
                },
                UYU: {
                    symbol: "$U",
                    placement: "right"
                },
                USD: {
                    symbol: "$",
                    placement: "left"
                },
                UZS: {
                    symbol: "\u043b\u0432",
                    placement: "right"
                },
                VUV: {
                    symbol: "VT",
                    placement: "right"
                },
                VEF: {
                    symbol: "Bs",
                    placement: "right"
                },
                VND: {
                    symbol: "\u20ab",
                    placement: "right"
                },
                YER: {
                    symbol: "\ufdfc",
                    placement: "right"
                },
                ZMK: {
                    symbol: "ZK",
                    placement: "right"
                },
                ZWD: {
                    symbol: "Z$",
                    placement: "right"
                },
                BTC: {
                    symbol: "\u0e3f\u20bf",
                    placement: "right"
                },
                ETH: {
                    symbol: "\u039e",
                    placement: "right"
                },
                USDT: {
                    symbol: "\u20ae",
                    placement: "right"
                },
                TUS: {
                    symbol: "\u20ae",
                    placement: "right"
                },
                FTN: {
                    symbol: "FTN",
                    placement: "right"
                },
                NSP: {
                    symbol: "NSP",
                    placement: "right"
                }
            };
            var i = a(179177);
            const o = e => ({
                    default: e,
                    left: "left",
                    right: "right"
                }[i.Ay.CURRENCY_PLACEMENT]),
                l = function() {
                    let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
                    if (e) {
                        const t = n[e];
                        return t ? i.Ay.CURRENCIES_WITH_SYMBOLS ? {
                            currency: t.symbol,
                            placement: o(t.placement)
                        } : {
                            currency: e,
                            placement: o(t.placement)
                        } : {
                            currency: e,
                            placement: "right"
                        }
                    }
                    return {
                        currency: e,
                        placement: "right"
                    }
                },
                s = (e, t) => function(a, n) {
                    return !1 === n ? `${a}` : "left" === t ? `${e} ${a}` : `${a} ${e}`
                },
                r = (e, t) => s(l(e).currency, l(e).placement)(t)
        },
        424757: (e, t, a) => {
            a.d(t, {
                Gf: () => u,
                M3: () => _,
                Mw: () => S,
                NI: () => y,
                Vv: () => A,
                Ye: () => E,
                de: () => c,
                e2: () => h,
                fi: () => T,
                i9: () => g,
                ic: () => p,
                nm: () => m
            });
            var n = a(971247),
                i = a(179177),
                o = a(263847),
                l = a(10922),
                s = a(718402),
                r = a(55418);
            const c = e => {
                    const t = (e = decodeURI(e)).indexOf("?");
                    t > -1 && (e = e.slice(0, t));
                    const a = e.indexOf(`/${i.Ay.SPORTSBOOK_MOUNT_PATH}/`);
                    a > -1 && (e = e.slice(0, a));
                    const n = e.indexOf(`/${i.Ay.CASINO_MOUNT_PATH}/`);
                    return n > -1 && (e = e.slice(0, n)), e.replace(/\/$/, "")
                },
                d = e => {
                    if (e = (e = decodeURI(e)).replace(/([^:]\/)\/+/g, "$1"), !i.Ay.SHOW_GAMBLING_AREAS || !i.Ay.GAMBLING_AREAS) return !1;
                    if (i.Ay.SHOW_GAMBLING_AREAS && i.Ay.GAMBLING_AREAS && !i.Ay.MOCKED_DATA) {
                        const t = i.Ay.GAMBLING_AREAS,
                            a = E();
                        let n = null;
                        return Object.keys(t).forEach((a => {
                            t[a].forEach((t => {
                                c(e) === c(t) && (n = a)
                            }))
                        })), !(!a || !n || n === c(a)) && (window.postMessage({
                            action: "gambling_area_changed",
                            destinationUrl: e
                        }, "*"), !0)
                    }
                    return !0
                },
                m = function(e) {
                    let t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                    return `${e.replace(/\/:.*/i,"").replace(/\/$/,"")}${t?`/${i.Ay.SPORTSBOOK_MOUNT_PATH}`:""}`
                };

            function p(e) {
                let t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
                    a = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
                const n = a ? arguments.length > 3 && void 0 !== arguments[3] && arguments[3] ? "" : i.Ay.CASINO_MOUNT_PATH : `${i.Ay.SPORTSBOOK_MOUNT_PATH}`,
                    o = new RegExp(`/${n}(?![-a-zA-Z0-9]).*$`),
                    l = e.match(o);
                if (null !== l && void 0 !== l && l.length) {
                    const a = e.lastIndexOf(l.pop()),
                        i = `${e.slice(0,a)}/${n}`.replace(/(\/)\/+/g, "$1");
                    return t ? [!1, i] : i
                }
                let s = `${e}/${n}`.replace(/(\/)\/+/g, "$1");
                return a && (s = s.replace(/\/$/, "")), t ? [!l, `${s}${a?window.location.search:""}`] : s
            }
            const _ = e => `${e.sport?`/${e.sport}`:""}${e.region?`/${e.region}`:""}${e.competition?`/${e.competition}`:""}${e.game?`/${e.game}`:""}`,
                u = e => {
                    const t = s.dB.join("|"),
                        a = new RegExp(`/${i.Ay.SPORTSBOOK_MOUNT_PATH}/(${t})`, "gi");
                    let o;
                    return window.getPathname().search(a) > -1 ? (window.getPathname().includes(n.E.team) && e.includes(":competition") && (0, r.F)() && (e = e.replace(":competition", ":competition?")), o = `${p(window.getPathname())}/:category${e}`) : o = `${p(window.getPathname())}${e}`, o
                },
                y = e => {
                    const t = new RegExp(`/${i.Ay.SPORTSBOOK_MOUNT_PATH}.*$`),
                        a = e.match(t);
                    if (null !== a && void 0 !== a && a.length) {
                        const t = e.lastIndexOf(a.pop());
                        return e.slice(t)
                    }
                    return e
                },
                S = e => {
                    const t = e.replace(/\?.*$/, "").replace(/\/$/, ""),
                        a = decodeURIComponent(window.location.href.replace(/\?.*$/, "").replace(/\/$/, "")),
                        n = new RegExp(`/(${i.Ay.CASINO_MOUNT_PATH}|${i.Ay.SPORTSBOOK_MOUNT_PATH})/`),
                        [o] = t.split(n),
                        [l] = a.split(n);
                    return o !== (l || "")
                },
                T = e => e.slice(window.origin.length),
                g = () => {
                    var e;
                    const t = window.location.pathname.slice(window.location.pathname.lastIndexOf(i.Ay.CASINO_MOUNT_PATH) + (null === (e = i.Ay.CASINO_MOUNT_PATH) || void 0 === e ? void 0 : e.length) + 1),
                        a = {},
                        [n, s, r] = t.split("/");
                    if (r) {
                        const [e, t] = (0, o.P)(r, "-"), [n, i] = (0, o.P)(t, "-");
                        a.gameId = e, a.gameExternalId = n, a.gameName = (0, l.J)(i)
                    }
                    return s && (a.providerName = (0, l.J)(s)), n && (a.categoryId = n), a
                },
                h = function(e) {
                    let t = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
                        a = arguments.length > 3 ? arguments[3] : void 0,
                        n = arguments.length > 4 ? arguments[4] : void 0;
                    if (arguments.length > 1 && void 0 !== arguments[1] && arguments[1]) {
                        const t = `${window.location.origin}${a?`/${a}`:""}/${e}`,
                            i = new URL(t);
                        i.search = "", d(t) || ("_blank" === n ? window.open(i.toString(), n) : window.location.href = i.toString())
                    }
                    t && (d(e) || ("_blank" === n ? window.open(e, n) : window.location.href = e))
                },
                E = () => {
                    let e = null;
                    if (i.Ay.SHOW_GAMBLING_AREAS && i.Ay.GAMBLING_AREAS && !i.Ay.MOCKED_DATA) {
                        const t = i.Ay.GAMBLING_AREAS;
                        Object.keys(t).forEach((a => {
                            t[a].forEach((t => {
                                c(window.location.href) === c(t) && (e = a)
                            }))
                        }))
                    }
                    return e
                },
                A = function(e, t) {
                    let a = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
                    let n = `${e.replace(/\/:.*/i,"").replace(/\/$/,"")}${a?`/${i.Ay.SPORTSBOOK_MOUNT_PATH}`:""}`;
                    return t && (n = `${n.slice(0,n.lastIndexOf("/"))}/${t}${n.slice(n.lastIndexOf("/"))}`), n
                }
        },
        706683: (e, t, a) => {
            a.d(t, {
                AM: () => r,
                EZ: () => s,
                Es: () => o,
                Q8: () => l,
                zH: () => i
            });
            var n = a(179177);
            const i = (e, t) => {
                    var a;
                    if (!e) return;
                    e.includes(",") && !t && (e = e.replace(",", ".")), e = e.replace(/[^\d.]/g, "");
                    let n = String(null === (a = e) || void 0 === a ? void 0 : a.replace(",", "."));
                    if (n.includes(".")) {
                        const e = n.indexOf("."),
                            t = n.indexOf(".", e + 1); - 1 !== t && (n = n.substring(0, t))
                    }
                    let i = null;
                    return 2 === n.length && 0 === +n[0] && "." !== n[1] && (i = `0.${n[1]}`), (e => /^[+]?((?!00\d*$)[0-9]+(?:[.][0-9]*)?|\.[0-9]+)$/.test(e))(n) || !e || i ? i || n : void 0
                },
                o = e => {
                    const t = e.target,
                        a = /[^0-9.]/g;
                    "." === `${t.value||""}`.charAt(0) ? t.value = `0${t.value}` : t.value.split(".").length > 2 ? t.value = t.value.slice(0, t.value.lastIndexOf(".")) : t.value = t.value.replace(a, "")
                },
                l = e => {
                    const t = (null === e || void 0 === e ? void 0 : e.toString()) || "";
                    return "," === n.Ay.PRICE_SEPARATOR && e ? t.indexOf(".") <= t.indexOf(",") ? t.replace(/\B(?=(\d{3})+(?!\d))/g, ",") : t.split(".")[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",").concat(".", t.split(".")[1].replace(",", "")) : e
                },
                s = e => e ? e.replace(",", "") : e,
                r = (e, t) => {
                    let a = !1;
                    return Object.entries(e).forEach((e => {
                        let [n, i] = e;
                        const o = t[n];
                        Number(o) !== Number(i) && (a = !0)
                    })), a
                }
        },
        600940: (e, t, a) => {
            a.d(t, {
                wM: () => T,
                B4: () => g,
                NT: () => p,
                HU: () => y,
                I0: () => S,
                Bo: () => _,
                IE: () => u,
                Rt: () => h
            });
            var n = a(860446),
                i = a.n(n),
                o = a(197262);
            const l = {
                AmericanFootball: "Quarter",
                AustralianFootball: "Quarter",
                Badminton: "Game",
                BallHockey: "Half",
                Baseball: "Inning",
                Basketball: "Quarter",
                BeachFootball: "Half",
                BeachHandball: "Half",
                BeachVolleyball: "Set",
                Bowls: "End",
                Boxing: "Round",
                CounterStrike: "Map",
                Cricket: "Inning",
                Curling: "End",
                CyberFootball: "Half",
                Dota2: "Game",
                EBasketball: "Quarter",
                Floorball: "Period",
                Futsal: "Half",
                GaelicFootball: "Half",
                GearsOfWar: "Game",
                Handball: "Half",
                Hearthstone: "Game",
                HeroesOfTheStorm: "Game",
                Hockey: "Period",
                IceHockey: "Period",
                LeagueOfLegends: "Game",
                Mma: "Round",
                MortalKombatXL: "Game",
                Netball: "Quarter",
                Overwatch: "Game",
                RugbyLeague: "Half",
                RugbySevens: "Half",
                RugbyUnion: "Half",
                Smite: "Game",
                Snooker: "Frame",
                Soccer: "Half",
                StarCraft: "Game",
                StarCraft2: "Game",
                TableTennis: "Set",
                Tekken7: "Game",
                Tennis: "Set",
                Volleyball: "Set",
                WarcraftIII: "Game",
                WaterPolo: "Quarter",
                WorldOfTanks: "Game",
                WorldOfWarcraft: "Game",
                PistolShooting: "Set",
                PistolHead2Head: "Set",
                ArcheryH2H: "Set",
                CompoundArchery: "Set",
                Archery: "Set",
                BasketballShots: "Shot"
            };
            var s = a(207610),
                r = a(482463),
                c = a(558073),
                d = a(179177);
            const m = {
                    "Half End": "halfEnd",
                    "Quarter End": "quarterEnd"
                },
                p = function(e) {
                    let {
                        current_game_state: t,
                        current_game_time: a
                    } = e, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "", i = arguments.length > 2 && void 0 !== arguments[2] && arguments[2], l = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0;
                    switch (!0) {
                        case "Half Time" === t:
                            return i ? o.A.t("sportsbook.halfTimeShort") : o.A.t("sportsbook.halfTime");
                        case ["Half End", "Quarter End"].includes(t) && "Basketball" === n:
                            return o.A.t(`sportsbook.${m[t]}`);
                        case "timeout" === t:
                            return i ? o.A.t("sportsbook.timeoutShort") : o.A.t("sportsbook.timeout");
                        case "notstarted" === t:
                            return i ? "0'" : o.A.t("sportsbook.notStarted");
                        case "finished" === t:
                            return i ? o.A.t("sportsbook.finishedShort") : o.A.t("sportsbook.finished");
                        case a && !!t && "Soccer" === n && i:
                            return `${a}'`;
                        case a && !!t && i:
                            return `${_(n,t,i,l)}`;
                        case a && !!t:
                            return `${_(n,t,i,l)} ${a}'`;
                        case !!a:
                            return `${a}'`;
                        case !!t:
                            return _(n, t, i, l);
                        case !t && !a:
                            return i ? "-" : ""
                    }
                    return ""
                };

            function _(e, t, a, n) {
                const i = l[e] ? l[e] : "Set",
                    r = +t.replace("set", "");
                return isNaN(r) ? t.replace("set", "") : "PistolHead2Head" === e && r === s.iR || "ArcheryH2H" === e && r === s.Pg || "CompoundArchery" === e && r === n ? o.A.t("sportsbook.shootOff") : a ? `${o.A.t(`sportsbook.${i}`)[0]}${r}` : `${u(r,i)} ${o.A.t(`sportsbook.${i}`)}`
            }

            function u(e) {
                let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
                const a = ["First", "Second", "Third", "Fourth", "Fifth", "Sixth", "Seventh", "Eighth", "Ninth", "Tenth", "Eleventh", "Twelfth"];
                return e <= a.length ? o.A.t(`sportsbook.${(t?t.toLowerCase():"")+a[e-1]}`) : `${e}${o.A.t(`sportsbook.${t?t.toLowerCase():""}DefaultSuffix`)}`
            }

            function y(e, t, a, n, o) {
                return a ? p({
                    current_game_state: e,
                    current_game_time: t
                }, o, !1, arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : 0) : n ? i()(1e3 * n).format((0, c.i)({
                    date: d.Ay.DT.shortDate,
                    time: d.Ay.DT.time
                })) : "--"
            }

            function S(e, t) {
                let a = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
                try {
                    const n = Object.values(e[0].competition || {});
                    let i;
                    if (i = a ? (0, r.I)(Object.values(n))[0] : Object.values(n)[0], i) switch (t) {
                        case "competition":
                            return i.id;
                        case "game":
                            return Number(Object.values(i.game || {}).sort(((e, t) => e.start_ts - t.start_ts))[0].id)
                    }
                } catch (n) {
                    console.info(n)
                }
            }

            function T(e) {
                switch (e) {
                    case "Half Time":
                    case "timeout":
                    case "notstarted":
                    case "finished":
                        return !0;
                    default:
                        return !1
                }
            }
            const g = e => {
                const t = Object.values(e.maps || {}).find((t => t.mapNumber === e.currentMap));
                return null !== t && void 0 !== t && t.mapNumber ? (null === t || void 0 === t ? void 0 : t.mapName) || `${u(t.mapNumber)} ${o.A.t("sportsbook.Map")}` : ""
            };

            function h(e) {
                return 1 === e ? `${e}${o.A.t("sportsbook.st")}` : 2 === e ? `${e}${o.A.t("sportsbook.nd")}` : `${e}${o.A.t("sportsbook.th")}`
            }
        },
        10922: (e, t, a) => {
            a.d(t, {
                J: () => n,
                a: () => i
            });
            const n = e => e.replace(/[-]/g, " ").replace(/(^|\s)\S/g, (e => e.toUpperCase())).trim(),
                i = e => e.trim().toLowerCase().replace(/\s/g, "-").replace(/#/g, "")
        },
        263847: (e, t, a) => {
            a.d(t, {
                P: () => n
            });
            const n = function(e) {
                let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
                return [null === e || void 0 === e ? void 0 : e.slice(0, e.indexOf(t)), null === e || void 0 === e ? void 0 : e.slice(e.indexOf(t) + 1)]
            }
        },
        53124: () => {},
        980001: () => {},
        687886: () => {},
        224532: () => {},
        183215: () => {}
    }
]);
//# sourceMappingURL=desktop-casino-tournaments-single.1c7be19a.chunk.js.map