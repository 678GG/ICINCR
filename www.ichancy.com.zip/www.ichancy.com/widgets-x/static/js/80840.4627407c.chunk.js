"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [80840], {
        780840: (e, t, o) => {
            o.r(t), o.d(t, {
                default: () => v
            });
            var n = o(984414),
                s = o(296731),
                u = o(902239),
                i = o(731912),
                a = o(796835),
                c = o(365043),
                r = o(498139),
                h = o.n(r),
                l = function(e) {
                    function t() {
                        (0, s.default)(this, t);
                        var e = (0, i.default)(this, (t.__proto__ || Object.getPrototypeOf(t)).apply(this, arguments));
                        return e.state = {
                            active: !1
                        }, e.onTouchStart = function(t) {
                            e.triggerEvent("TouchStart", !0, t)
                        }, e.onTouchMove = function(t) {
                            e.triggerEvent("TouchMove", !1, t)
                        }, e.onTouchEnd = function(t) {
                            e.triggerEvent("TouchEnd", !1, t)
                        }, e.onTouchCancel = function(t) {
                            e.triggerEvent("TouchCancel", !1, t)
                        }, e.onMouseDown = function(t) {
                            e.triggerEvent("MouseDown", !0, t)
                        }, e.onMouseUp = function(t) {
                            e.triggerEvent("MouseUp", !1, t)
                        }, e.onMouseLeave = function(t) {
                            e.triggerEvent("MouseLeave", !1, t)
                        }, e
                    }
                    return (0, a.default)(t, e), (0, u.default)(t, [{
                        key: "componentDidUpdate",
                        value: function() {
                            this.props.disabled && this.state.active && this.setState({
                                active: !1
                            })
                        }
                    }, {
                        key: "triggerEvent",
                        value: function(e, t, o) {
                            var n = "on" + e,
                                s = this.props.children;
                            s.props[n] && s.props[n](o), t !== this.state.active && this.setState({
                                active: t
                            })
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this.props,
                                t = e.children,
                                o = e.disabled,
                                s = e.activeClassName,
                                u = e.activeStyle,
                                i = o ? void 0 : {
                                    onTouchStart: this.onTouchStart,
                                    onTouchMove: this.onTouchMove,
                                    onTouchEnd: this.onTouchEnd,
                                    onTouchCancel: this.onTouchCancel,
                                    onMouseDown: this.onMouseDown,
                                    onMouseUp: this.onMouseUp,
                                    onMouseLeave: this.onMouseLeave
                                },
                                a = c.Children.only(t);
                            if (!o && this.state.active) {
                                var r = a.props,
                                    l = r.style,
                                    v = r.className;
                                return !1 !== u && (u && (l = (0, n.default)({}, l, u)), v = h()(v, s)), c.cloneElement(a, (0, n.default)({
                                    className: v,
                                    style: l
                                }, i))
                            }
                            return c.cloneElement(a, i)
                        }
                    }]), t
                }(c.Component);
            const v = l;
            l.defaultProps = {
                disabled: !1
            }
        }
    }
]);
//# sourceMappingURL=80840.4627407c.chunk.js.map