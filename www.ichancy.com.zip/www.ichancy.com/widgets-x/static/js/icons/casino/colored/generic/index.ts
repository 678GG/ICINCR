import { ReactComponent as Generic } from './Generic.svg';

export default Generic;
