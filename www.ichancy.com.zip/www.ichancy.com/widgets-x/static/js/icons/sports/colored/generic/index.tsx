import { ReactComponent as Generic } from './generic.svg';

export default Generic;
