"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [15408], {
        115408: (s, o, t) => {
            t.d(o, {
                A: () => n
            });
            var a = t(365043),
                c = t(507712),
                e = t(464418),
                k = t(273549),
                r = t(132392),
                u = t(855221);
            const n = () => {
                const s = (0, c.d4)(k.RT),
                    o = (0, c.d4)(k.uf),
                    t = (0, c.wA)();
                return (0, a.useCallback)(((a, c) => {
                    c && s !== a && ("fractional" !== c || o ? t((0, e.Gp)(a)) : (0, u.X)(a), (0, r.s)(c))
                }), [s, o])
            }
        }
    }
]);
//# sourceMappingURL=15408.65334d44.chunk.js.map