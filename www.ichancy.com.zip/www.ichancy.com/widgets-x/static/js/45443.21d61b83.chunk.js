"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [45443], {
        645443: (s, o, e) => {
            e.r(o), e.d(o, {
                default: () => k
            });
            const k = {}
        }
    }
]);
//# sourceMappingURL=45443.21d61b83.chunk.js.map