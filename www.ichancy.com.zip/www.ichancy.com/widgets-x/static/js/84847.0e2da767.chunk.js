"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [84847], {
        684847: (e, t, l) => {
            l.r(t), l.d(t, {
                default: () => f
            });
            var r, n, a, i, o, s, C = l(365043);

            function c() {
                return c = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var l = arguments[t];
                        for (var r in l) Object.prototype.hasOwnProperty.call(l, r) && (e[r] = l[r])
                    }
                    return e
                }, c.apply(this, arguments)
            }

            function p(e, t) {
                let {
                    title: l,
                    titleId: p,
                    ...h
                } = e;
                return C.createElement("svg", c({
                    width: 32,
                    height: 32,
                    viewBox: "0 0 32 33",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    ref: t,
                    "aria-labelledby": p
                }, h), l ? C.createElement("title", {
                    id: p
                }, l) : null, r || (r = C.createElement("path", {
                    d: "M16 30.5205C24.8366 30.5205 32 27.4694 32 23.7057C32 19.942 24.8366 16.8909 16 16.8909C7.16344 16.8909 0 19.942 0 23.7057C0 27.4694 7.16344 30.5205 16 30.5205Z",
                    fill: "#88C057"
                })), n || (n = C.createElement("path", {
                    d: "M11.2592 28.7427C17.1502 28.7427 21.9259 26.7086 21.9259 24.1993C21.9259 21.69 17.1502 19.6559 11.2592 19.6559C5.36816 19.6559 0.592529 21.69 0.592529 24.1993C0.592529 26.7086 5.36816 28.7427 11.2592 28.7427Z",
                    fill: "#659C35"
                })), a || (a = C.createElement("path", {
                    d: "M12.4865 26.0429C14.4734 26.0429 16.0842 24.7901 16.0842 23.2446C16.0842 21.6992 14.4734 20.4464 12.4865 20.4464C10.4996 20.4464 8.88892 21.6992 8.88892 23.2446C8.88892 24.7901 10.4996 26.0429 12.4865 26.0429Z",
                    fill: "#38454F"
                })), i || (i = C.createElement("path", {
                    d: "M11.2593 2.07605L21.9259 5.03901L11.2593 8.59457V2.07605Z",
                    fill: "#E64C3C"
                })), o || (o = C.createElement("path", {
                    d: "M23.7038 26.9649C24.6857 26.9649 25.4816 26.169 25.4816 25.1871C25.4816 24.2053 24.6857 23.4094 23.7038 23.4094C22.7219 23.4094 21.926 24.2053 21.926 25.1871C21.926 26.169 22.7219 26.9649 23.7038 26.9649Z",
                    fill: "white"
                })), s || (s = C.createElement("path", {
                    d: "M11.2593 22.8168V2.07605",
                    stroke: "#ECF0F1",
                    strokeWidth: 2,
                    strokeMiterlimit: 10,
                    strokeLinecap: "round"
                })))
            }
            const h = C.forwardRef(p),
                f = (l.p, h)
        }
    }
]);
//# sourceMappingURL=84847.0e2da767.chunk.js.map