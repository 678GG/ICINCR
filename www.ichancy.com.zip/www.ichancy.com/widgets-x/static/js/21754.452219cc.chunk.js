"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [21754], {
        721754: (e, t, a) => {
            a.r(t), a.d(t, {
                default: () => p
            });
            var l, r, n, s, i = a(365043);

            function c() {
                return c = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var a = arguments[t];
                        for (var l in a) Object.prototype.hasOwnProperty.call(a, l) && (e[l] = a[l])
                    }
                    return e
                }, c.apply(this, arguments)
            }

            function o(e, t) {
                let {
                    title: a,
                    titleId: o,
                    ...f
                } = e;
                return i.createElement("svg", c({
                    id: "Layer_1",
                    "data-name": "Layer 1",
                    xmlns: "http://www.w3.org/2000/svg",
                    xmlnsXlink: "http://www.w3.org/1999/xlink",
                    viewBox: "0 0 56 56",
                    ref: t,
                    "aria-labelledby": o
                }, f), a ? i.createElement("title", {
                    id: o
                }, a) : null, l || (l = i.createElement("defs", null, i.createElement("style", null, ".cls-1{fill:url(#linear-gradient);}.cls-2{fill:#fff;}"), i.createElement("linearGradient", {
                    id: "linear-gradient",
                    x1: -.06,
                    y1: 27.85,
                    x2: 55.95,
                    y2: 28.15,
                    gradientTransform: "matrix(1, 0, 0, -1, 0, 56)",
                    gradientUnits: "userSpaceOnUse"
                }, i.createElement("stop", {
                    offset: 0,
                    stopColor: "#fe8453"
                }), i.createElement("stop", {
                    offset: 1,
                    stopColor: "#ed5f91"
                })))), r || (r = i.createElement("path", {
                    className: "cls-1",
                    d: "M0,16.8A16.8,16.8,0,0,1,16.8,0H39.2A16.8,16.8,0,0,1,56,16.8V39.2A16.8,16.8,0,0,1,39.2,56H16.8A16.8,16.8,0,0,1,0,39.2Z"
                })), n || (n = i.createElement("path", {
                    className: "cls-2",
                    d: "M8.38,38.5l3.55-21.38H20.5a8.87,8.87,0,0,1,3.82.7,4.06,4.06,0,0,1,2.05,1.94,4.68,4.68,0,0,1,.32,2.84,5.42,5.42,0,0,1-.89,2.19,5.6,5.6,0,0,1-1.63,1.55,6.59,6.59,0,0,1-2.11.85l0,.21a4.32,4.32,0,0,1,2.18.69,3.77,3.77,0,0,1,1.45,1.78,4.83,4.83,0,0,1,.22,2.72,6.49,6.49,0,0,1-1.34,3,7.41,7.41,0,0,1-2.84,2.1,10.45,10.45,0,0,1-4.17.77Zm5.15-3.7h3.69a4.77,4.77,0,0,0,2.87-.73,2.88,2.88,0,0,0,1.19-1.93,2.67,2.67,0,0,0-.18-1.56,2.22,2.22,0,0,0-1-1.07,3.82,3.82,0,0,0-1.83-.39H14.46ZM15,26.07h3.35A4.38,4.38,0,0,0,20,25.74a3.28,3.28,0,0,0,1.3-.94A2.89,2.89,0,0,0,22,23.35a2,2,0,0,0-.52-1.87,3,3,0,0,0-2.2-.71H15.86Z"
                })), s || (s = i.createElement("path", {
                    className: "cls-2",
                    d: "M27.82,38.5l3.55-21.38h8.56a8.81,8.81,0,0,1,3.82.7,4,4,0,0,1,2.06,1.94,4.68,4.68,0,0,1,.31,2.84,5.27,5.27,0,0,1-.88,2.19,5.6,5.6,0,0,1-1.63,1.55,6.59,6.59,0,0,1-2.11.85l0,.21a4.35,4.35,0,0,1,2.18.69,3.77,3.77,0,0,1,1.45,1.78,4.92,4.92,0,0,1,.22,2.72,6.5,6.5,0,0,1-1.35,3,7.33,7.33,0,0,1-2.84,2.1A10.37,10.37,0,0,1,37,38.5ZM33,34.8h3.68a4.8,4.8,0,0,0,2.88-.73,2.92,2.92,0,0,0,1.19-1.93,2.67,2.67,0,0,0-.18-1.56,2.2,2.2,0,0,0-1-1.07,3.78,3.78,0,0,0-1.82-.39H33.9Zm1.45-8.73h3.35a4.33,4.33,0,0,0,1.7-.33,3.32,3.32,0,0,0,1.31-.94,2.89,2.89,0,0,0,.66-1.45,2,2,0,0,0-.53-1.87,3,3,0,0,0-2.19-.71H35.3Z"
                })))
            }
            const f = i.forwardRef(o),
                p = (a.p, f)
        }
    }
]);
//# sourceMappingURL=21754.452219cc.chunk.js.map