"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [68392], {
        68392: (e, l, t) => {
            t.d(l, {
                N8: () => s,
                HN: () => p,
                Hv: () => o
            });
            const m = {
                AFA: {
                    symbol: "\u060b",
                    placement: "right"
                },
                ALL: {
                    symbol: "Lek",
                    placement: "right"
                },
                DZD: {
                    symbol: "\u062f\u062c",
                    placement: "right"
                },
                AOA: {
                    symbol: "Kz",
                    placement: "right"
                },
                ARS: {
                    symbol: "$",
                    placement: "left"
                },
                AMD: {
                    symbol: "\u058f",
                    placement: "right"
                },
                AWG: {
                    symbol: "\u0192",
                    placement: "right"
                },
                AUD: {
                    symbol: "$",
                    placement: "left"
                },
                AZN: {
                    symbol: "\u20bc",
                    placement: "right"
                },
                BSD: {
                    symbol: "B$",
                    placement: "right"
                },
                BHD: {
                    symbol: ".\u062f.\u0628",
                    placement: "right"
                },
                BDT: {
                    symbol: "\u09f3",
                    placement: "right"
                },
                BBD: {
                    symbol: "Bds$",
                    placement: "right"
                },
                BYR: {
                    symbol: "Br",
                    placement: "right"
                },
                BYN: {
                    symbol: "Br",
                    placement: "right"
                },
                BEF: {
                    symbol: "fr",
                    placement: "right"
                },
                BZD: {
                    symbol: "BZ$",
                    placement: "right"
                },
                BMD: {
                    symbol: "$",
                    placement: "left"
                },
                BTN: {
                    symbol: "Nu.",
                    placement: "right"
                },
                BOB: {
                    symbol: "Bs.",
                    placement: "right"
                },
                BAM: {
                    symbol: "KM",
                    placement: "right"
                },
                BWP: {
                    symbol: "P",
                    placement: "right"
                },
                BRL: {
                    symbol: "R$",
                    placement: "right"
                },
                GBP: {
                    symbol: "\xa3",
                    placement: "right"
                },
                BND: {
                    symbol: "B$",
                    placement: "right"
                },
                BGN: {
                    symbol: "\u041b\u0432.",
                    placement: "right"
                },
                BIF: {
                    symbol: "FBu",
                    placement: "right"
                },
                KHR: {
                    symbol: "\u17db",
                    placement: "right"
                },
                CAD: {
                    symbol: "C$",
                    placement: "left"
                },
                CVE: {
                    symbol: "$",
                    placement: "left"
                },
                CYP: {
                    symbol: "\xa3",
                    placement: "right"
                },
                KYD: {
                    symbol: "$",
                    placement: "left"
                },
                XOF: {
                    symbol: "CFA",
                    placement: "right"
                },
                XAF: {
                    symbol: "FCFA",
                    placement: "right"
                },
                XPF: {
                    symbol: "\u20a3",
                    placement: "right"
                },
                CLP: {
                    symbol: "$",
                    placement: "left"
                },
                CNY: {
                    symbol: "\xa5",
                    placement: "right"
                },
                COP: {
                    symbol: "$",
                    placement: "left"
                },
                KMF: {
                    symbol: "CF",
                    placement: "right"
                },
                CDF: {
                    symbol: "FC",
                    placement: "right"
                },
                CRC: {
                    symbol: "\u20a1",
                    placement: "right"
                },
                HRK: {
                    symbol: "kn",
                    placement: "right"
                },
                CUC: {
                    symbol: "CUC$",
                    placement: "right"
                },
                CUP: {
                    symbol: "\u20b1",
                    placement: "right"
                },
                CZK: {
                    symbol: "K\u010d",
                    placement: "right"
                },
                DKK: {
                    symbol: "Kr.",
                    placement: "right"
                },
                DJF: {
                    symbol: "Fdj",
                    placement: "right"
                },
                DOP: {
                    symbol: "RD$",
                    placement: "right"
                },
                XCD: {
                    symbol: "$",
                    placement: "left"
                },
                EGP: {
                    symbol: "E\xa3",
                    placement: "right"
                },
                ERN: {
                    symbol: "\u1293\u1255\u134b",
                    placement: "right"
                },
                EEK: {
                    symbol: "kr",
                    placement: "right"
                },
                ETB: {
                    symbol: "\u1265\u122d",
                    placement: "right"
                },
                EUR: {
                    symbol: "\u20ac",
                    placement: "left"
                },
                FKP: {
                    symbol: "\xa3",
                    placement: "right"
                },
                FJD: {
                    symbol: "FJ$",
                    placement: "right"
                },
                GMD: {
                    symbol: "D",
                    placement: "right"
                },
                GEL: {
                    symbol: "\u10da",
                    placement: "right"
                },
                DEM: {
                    symbol: "DM",
                    placement: "right"
                },
                GHC: {
                    symbol: "GH\u20b5",
                    placement: "right"
                },
                GHS: {
                    symbol: "GH\u20b5",
                    placement: "right"
                },
                GIP: {
                    symbol: "\xa3",
                    placement: "right"
                },
                GRD: {
                    symbol: "\u20af",
                    placement: "right"
                },
                GTQ: {
                    symbol: "Q",
                    placement: "right"
                },
                GGP: {
                    symbol: "\xa3",
                    placement: "right"
                },
                GNF: {
                    symbol: "FG",
                    placement: "right"
                },
                GYD: {
                    symbol: "$",
                    placement: "left"
                },
                HTG: {
                    symbol: "G",
                    placement: "right"
                },
                HNL: {
                    symbol: "L",
                    placement: "right"
                },
                HKD: {
                    symbol: "HK$",
                    placement: "left"
                },
                HUF: {
                    symbol: "Ft",
                    placement: "right"
                },
                ISK: {
                    symbol: "kr",
                    placement: "right"
                },
                INR: {
                    symbol: "\u20b9",
                    placement: "right"
                },
                IDR: {
                    symbol: "Rp",
                    placement: "right"
                },
                IRR: {
                    symbol: "\ufdfc",
                    placement: "right"
                },
                IQD: {
                    symbol: "\u062f.\u0639",
                    placement: "right"
                },
                IMP: {
                    symbol: "\xa3",
                    placement: "right"
                },
                ILS: {
                    symbol: "\u20aa",
                    placement: "right"
                },
                ITL: {
                    symbol: "L,\xa3",
                    placement: "right"
                },
                JMD: {
                    symbol: "J$",
                    placement: "right"
                },
                JPY: {
                    symbol: "\xa5",
                    placement: "right"
                },
                JEP: {
                    symbol: "\xa3",
                    placement: "right"
                },
                JOD: {
                    symbol: "\u0627.\u062f",
                    placement: "right"
                },
                KZT: {
                    symbol: "\u043b\u0432",
                    placement: "right"
                },
                KES: {
                    symbol: "KSh",
                    placement: "right"
                },
                KWD: {
                    symbol: "\u0643.\u062f",
                    placement: "right"
                },
                KGS: {
                    symbol: "\u043b\u0432",
                    placement: "right"
                },
                LAK: {
                    symbol: "\u20ad",
                    placement: "right"
                },
                LVL: {
                    symbol: "Ls",
                    placement: "right"
                },
                LBP: {
                    symbol: "\xa3",
                    placement: "right"
                },
                LSL: {
                    symbol: "L",
                    placement: "right"
                },
                LRD: {
                    symbol: "$",
                    placement: "left"
                },
                LYD: {
                    symbol: "\u062f.\u0644",
                    placement: "right"
                },
                LTL: {
                    symbol: "Lt",
                    placement: "right"
                },
                MTL: {
                    symbol: "\u20a4M",
                    placement: "right"
                },
                MOP: {
                    symbol: "$",
                    placement: "left"
                },
                MKD: {
                    symbol: "\u0434\u0435\u043d",
                    placement: "right"
                },
                MGA: {
                    symbol: "Ar",
                    placement: "right"
                },
                MWK: {
                    symbol: "MK",
                    placement: "right"
                },
                MYR: {
                    symbol: "RM",
                    placement: "right"
                },
                MVR: {
                    symbol: "Rf",
                    placement: "right"
                },
                MRO: {
                    symbol: "MRU",
                    placement: "right"
                },
                MUR: {
                    symbol: "\u20a8",
                    placement: "right"
                },
                MXN: {
                    symbol: "$",
                    placement: "left"
                },
                MDL: {
                    symbol: "L",
                    placement: "right"
                },
                MNT: {
                    symbol: "\u20ae",
                    placement: "right"
                },
                MZN: {
                    symbol: "MT",
                    placement: "right"
                },
                MAD: {
                    symbol: "MAD",
                    placement: "right"
                },
                MZM: {
                    symbol: "MT",
                    placement: "right"
                },
                MMK: {
                    symbol: "K",
                    placement: "right"
                },
                NAD: {
                    symbol: "$",
                    placement: "left"
                },
                NPR: {
                    symbol: "\u20a8",
                    placement: "right"
                },
                ANG: {
                    symbol: "\u0192",
                    placement: "right"
                },
                TWD: {
                    symbol: "NT$",
                    placement: "right"
                },
                NZD: {
                    symbol: "$",
                    placement: "left"
                },
                NIO: {
                    symbol: "C$",
                    placement: "right"
                },
                NGN: {
                    symbol: "\u20a6",
                    placement: "right"
                },
                KPW: {
                    symbol: "\u20a9",
                    placement: "right"
                },
                NOK: {
                    symbol: "kr",
                    placement: "right"
                },
                OMR: {
                    symbol: "\u0631.\u0639.",
                    placement: "right"
                },
                PKR: {
                    symbol: "\u20a8",
                    placement: "right"
                },
                PAB: {
                    symbol: "B/.",
                    placement: "right"
                },
                PGK: {
                    symbol: "K",
                    placement: "right"
                },
                PYG: {
                    symbol: "\u20b2",
                    placement: "right"
                },
                PEN: {
                    symbol: "S/.",
                    placement: "right"
                },
                PHP: {
                    symbol: "\u20b1",
                    placement: "right"
                },
                PLN: {
                    symbol: "z\u0142",
                    placement: "right"
                },
                QAR: {
                    symbol: "\u0631.\u0642",
                    placement: "right"
                },
                RON: {
                    symbol: "lei",
                    placement: "right"
                },
                RUB: {
                    symbol: "\u20bd",
                    placement: "right"
                },
                RWF: {
                    symbol: "FRw",
                    placement: "right"
                },
                SVC: {
                    symbol: "\u20a1",
                    placement: "right"
                },
                WST: {
                    symbol: "SAT",
                    placement: "right"
                },
                SAR: {
                    symbol: "\ufdfc",
                    placement: "right"
                },
                RSD: {
                    symbol: "\u0414\u0438\u043d.",
                    placement: "right"
                },
                SCR: {
                    symbol: "SRe",
                    placement: "right"
                },
                SLL: {
                    symbol: "Le",
                    placement: "right"
                },
                SGD: {
                    symbol: "$",
                    placement: "left"
                },
                SKK: {
                    symbol: "Sk",
                    placement: "right"
                },
                SBD: {
                    symbol: "Si$",
                    placement: "right"
                },
                SOS: {
                    symbol: "Sh.so.",
                    placement: "right"
                },
                ZAR: {
                    symbol: "R",
                    placement: "right"
                },
                KRW: {
                    symbol: "\u20a9",
                    placement: "right"
                },
                XDR: {
                    symbol: "SDR",
                    placement: "right"
                },
                LKR: {
                    symbol: "Rs",
                    placement: "right"
                },
                SHP: {
                    symbol: "\xa3",
                    placement: "right"
                },
                SDG: {
                    symbol: ".\u0633.\u062c",
                    placement: "right"
                },
                SSP: {
                    symbol: "\xa3",
                    placement: "right"
                },
                SRD: {
                    symbol: "$",
                    placement: "left"
                },
                SZL: {
                    symbol: "E",
                    placement: "right"
                },
                SEK: {
                    symbol: "kr",
                    placement: "right"
                },
                CHF: {
                    symbol: "CHf",
                    placement: "right"
                },
                SYP: {
                    symbol: "\xa3S",
                    placement: "right"
                },
                STD: {
                    symbol: "Db",
                    placement: "right"
                },
                TJS: {
                    symbol: "SM",
                    placement: "right"
                },
                TZS: {
                    symbol: "TSh",
                    placement: "right"
                },
                THB: {
                    symbol: "\u0e3f",
                    placement: "right"
                },
                TOP: {
                    symbol: "$",
                    placement: "left"
                },
                TTD: {
                    symbol: "TT$",
                    placement: "right"
                },
                TND: {
                    symbol: "\u062a.\u062f",
                    placement: "right"
                },
                TRY: {
                    symbol: "\u20ba",
                    placement: "right"
                },
                TMM: {
                    symbol: "T",
                    placement: "right"
                },
                TMT: {
                    symbol: "T",
                    placement: "right"
                },
                TVD: {
                    symbol: "$",
                    placement: "left"
                },
                UGX: {
                    symbol: "USh",
                    placement: "right"
                },
                UAH: {
                    symbol: "\u20b4",
                    placement: "right"
                },
                AED: {
                    symbol: "\u062f.\u0625",
                    placement: "right"
                },
                UYU: {
                    symbol: "$U",
                    placement: "right"
                },
                USD: {
                    symbol: "$",
                    placement: "left"
                },
                UZS: {
                    symbol: "\u043b\u0432",
                    placement: "right"
                },
                VUV: {
                    symbol: "VT",
                    placement: "right"
                },
                VEF: {
                    symbol: "Bs",
                    placement: "right"
                },
                VND: {
                    symbol: "\u20ab",
                    placement: "right"
                },
                YER: {
                    symbol: "\ufdfc",
                    placement: "right"
                },
                ZMK: {
                    symbol: "ZK",
                    placement: "right"
                },
                ZWD: {
                    symbol: "Z$",
                    placement: "right"
                },
                BTC: {
                    symbol: "\u0e3f\u20bf",
                    placement: "right"
                },
                ETH: {
                    symbol: "\u039e",
                    placement: "right"
                },
                USDT: {
                    symbol: "\u20ae",
                    placement: "right"
                },
                TUS: {
                    symbol: "\u20ae",
                    placement: "right"
                },
                FTN: {
                    symbol: "FTN",
                    placement: "right"
                },
                NSP: {
                    symbol: "NSP",
                    placement: "right"
                }
            };
            var n = t(179177);
            const c = e => ({
                    default: e,
                    left: "left",
                    right: "right"
                }[n.Ay.CURRENCY_PLACEMENT]),
                s = function() {
                    let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
                    if (e) {
                        const l = m[e];
                        return l ? n.Ay.CURRENCIES_WITH_SYMBOLS ? {
                            currency: l.symbol,
                            placement: c(l.placement)
                        } : {
                            currency: e,
                            placement: c(l.placement)
                        } : {
                            currency: e,
                            placement: "right"
                        }
                    }
                    return {
                        currency: e,
                        placement: "right"
                    }
                },
                o = (e, l) => function(t, m) {
                    return !1 === m ? `${t}` : "left" === l ? `${e} ${t}` : `${t} ${e}`
                },
                p = (e, l) => o(s(e).currency, s(e).placement)(l)
        }
    }
]);
//# sourceMappingURL=68392.6484f82e.chunk.js.map