"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [35260], {
        935260: (t, e, r) => {
            r.r(e), r.d(e, {
                default: () => i
            });
            var n, l = r(365043);

            function a() {
                return a = Object.assign ? Object.assign.bind() : function(t) {
                    for (var e = 1; e < arguments.length; e++) {
                        var r = arguments[e];
                        for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (t[n] = r[n])
                    }
                    return t
                }, a.apply(this, arguments)
            }

            function o(t, e) {
                let {
                    title: r,
                    titleId: o,
                    ...s
                } = t;
                return l.createElement("svg", a({
                    width: 32,
                    height: 32,
                    viewBox: "0 0 32 32",
                    fill: "currentColor",
                    xmlns: "http://www.w3.org/2000/svg",
                    ref: e,
                    "aria-labelledby": o
                }, s), r ? l.createElement("title", {
                    id: o
                }, r) : null, n || (n = l.createElement("path", {
                    d: "M25.1412 15.9997C25.1407 16.2752 25.0855 16.5479 24.9789 16.802C24.8722 17.056 24.7162 17.2864 24.5199 17.4797L10.4159 31.429C10.0133 31.7974 9.48478 31.9974 8.93916 31.988C8.39354 31.9785 7.87227 31.7604 7.48258 31.3784C7.0956 30.9968 6.87356 30.4788 6.86409 29.9354C6.85461 29.392 7.05846 28.8665 7.43192 28.4717L20.0426 15.9917L7.43192 3.5117C7.05846 3.11687 6.85461 2.59141 6.86409 2.04802C6.87356 1.50464 7.0956 0.986604 7.48258 0.605029C7.87227 0.223016 8.39354 0.00486007 8.93916 -0.0045643C9.48478 -0.0139887 10.0133 0.186035 10.4159 0.554362L24.5226 14.5117C24.7194 14.7062 24.8754 14.9379 24.9817 15.1934C25.0879 15.4489 25.1421 15.723 25.1412 15.9997Z"
                })))
            }
            const s = l.forwardRef(o),
                i = (r.p, s)
        }
    }
]);
//# sourceMappingURL=35260.dd05fc99.chunk.js.map