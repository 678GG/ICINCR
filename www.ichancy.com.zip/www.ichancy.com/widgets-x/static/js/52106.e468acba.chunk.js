(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [52106], {
        606578: (e, t, n) => {
            try {
                var i = n(133359)
            } catch (s) {
                i = n(133359)
            }
            var o = /\s+/,
                r = Object.prototype.toString;

            function a(e) {
                if (!e || !e.nodeType) throw new Error("A DOM element reference is required");
                this.el = e, this.list = e.classList
            }
            e.exports = function(e) {
                return new a(e)
            }, a.prototype.add = function(e) {
                if (this.list) return this.list.add(e), this;
                var t = this.array();
                return ~i(t, e) || t.push(e), this.el.className = t.join(" "), this
            }, a.prototype.remove = function(e) {
                if ("[object RegExp]" == r.call(e)) return this.removeMatching(e);
                if (this.list) return this.list.remove(e), this;
                var t = this.array(),
                    n = i(t, e);
                return ~n && t.splice(n, 1), this.el.className = t.join(" "), this
            }, a.prototype.removeMatching = function(e) {
                for (var t = this.array(), n = 0; n < t.length; n++) e.test(t[n]) && this.remove(t[n]);
                return this
            }, a.prototype.toggle = function(e, t) {
                return this.list ? ("undefined" !== typeof t ? t !== this.list.toggle(e, t) && this.list.toggle(e) : this.list.toggle(e), this) : ("undefined" !== typeof t ? t ? this.add(e) : this.remove(e) : this.has(e) ? this.remove(e) : this.add(e), this)
            }, a.prototype.array = function() {
                var e = (this.el.getAttribute("class") || "").replace(/^\s+|\s+$/g, "").split(o);
                return "" === e[0] && e.shift(), e
            }, a.prototype.has = a.prototype.contains = function(e) {
                return this.list ? this.list.contains(e) : !!~i(this.array(), e)
            }
        },
        133359: e => {
            e.exports = function(e, t) {
                if (e.indexOf) return e.indexOf(t);
                for (var n = 0; n < e.length; ++n)
                    if (e[n] === t) return n;
                return -1
            }
        },
        952106: (e, t, n) => {
            "use strict";
            n.r(t), n.d(t, {
                default: () => X
            });
            var i = n(984414),
                o = n(296731),
                r = n(902239),
                a = n(731912),
                s = n(796835),
                l = n(365043),
                c = n(297950),
                u = n(281777),
                p = n(965173),
                f = n.n(p);
            const d = function(e) {
                var t = e.prototype;
                if (!t || !t.isReactComponent) throw new Error("Can only polyfill class components");
                return "function" !== typeof t.componentWillReceiveProps ? e : l.Profiler ? (t.UNSAFE_componentWillReceiveProps = t.componentWillReceiveProps, delete t.componentWillReceiveProps, e) : e
            };

            function m(e) {
                var t = [];
                return l.Children.forEach(e, (function(e) {
                    t.push(e)
                })), t
            }

            function v(e, t) {
                var n = null;
                return e && e.forEach((function(e) {
                    n || e && e.key === t && (n = e)
                })), n
            }

            function h(e, t, n) {
                var i = null;
                return e && e.forEach((function(e) {
                    if (e && e.key === t && e.props[n]) {
                        if (i) throw new Error("two child with same key for <rc-animate> children");
                        i = e
                    }
                })), i
            }
            var y = n(936926),
                E = {
                    transitionstart: {
                        transition: "transitionstart",
                        WebkitTransition: "webkitTransitionStart",
                        MozTransition: "mozTransitionStart",
                        OTransition: "oTransitionStart",
                        msTransition: "MSTransitionStart"
                    },
                    animationstart: {
                        animation: "animationstart",
                        WebkitAnimation: "webkitAnimationStart",
                        MozAnimation: "mozAnimationStart",
                        OAnimation: "oAnimationStart",
                        msAnimation: "MSAnimationStart"
                    }
                },
                k = {
                    transitionend: {
                        transition: "transitionend",
                        WebkitTransition: "webkitTransitionEnd",
                        MozTransition: "mozTransitionEnd",
                        OTransition: "oTransitionEnd",
                        msTransition: "MSTransitionEnd"
                    },
                    animationend: {
                        animation: "animationend",
                        WebkitAnimation: "webkitAnimationEnd",
                        MozAnimation: "mozAnimationEnd",
                        OAnimation: "oAnimationEnd",
                        msAnimation: "MSAnimationEnd"
                    }
                },
                g = [],
                b = [];

            function A(e, t, n) {
                e.addEventListener(t, n, !1)
            }

            function w(e, t, n) {
                e.removeEventListener(t, n, !1)
            }
            "undefined" !== typeof window && "undefined" !== typeof document && function() {
                var e = document.createElement("div").style;

                function t(t, n) {
                    for (var i in t)
                        if (t.hasOwnProperty(i)) {
                            var o = t[i];
                            for (var r in o)
                                if (r in e) {
                                    n.push(o[r]);
                                    break
                                }
                        }
                }
                "AnimationEvent" in window || (delete E.animationstart.animation, delete k.animationend.animation), "TransitionEvent" in window || (delete E.transitionstart.transition, delete k.transitionend.transition), t(E, g), t(k, b)
            }();
            const C = {
                startEvents: g,
                addStartEventListener: function(e, t) {
                    0 !== g.length ? g.forEach((function(n) {
                        A(e, n, t)
                    })) : window.setTimeout(t, 0)
                },
                removeStartEventListener: function(e, t) {
                    0 !== g.length && g.forEach((function(n) {
                        w(e, n, t)
                    }))
                },
                endEvents: b,
                addEndEventListener: function(e, t) {
                    0 !== b.length ? b.forEach((function(n) {
                        A(e, n, t)
                    })) : window.setTimeout(t, 0)
                },
                removeEndEventListener: function(e, t) {
                    0 !== b.length && b.forEach((function(n) {
                        w(e, n, t)
                    }))
                }
            };
            var T = n(606578),
                L = n.n(T),
                N = 0 !== C.endEvents.length,
                S = ["Webkit", "Moz", "O", "ms"],
                P = ["-webkit-", "-moz-", "-o-", "ms-", ""];

            function x(e, t) {
                for (var n = window.getComputedStyle(e, null), i = "", o = 0; o < P.length && !(i = n.getPropertyValue(P[o] + t)); o++);
                return i
            }

            function _(e) {
                if (N) {
                    var t = parseFloat(x(e, "transition-delay")) || 0,
                        n = parseFloat(x(e, "transition-duration")) || 0,
                        i = parseFloat(x(e, "animation-delay")) || 0,
                        o = parseFloat(x(e, "animation-duration")) || 0,
                        r = Math.max(n + t, o + i);
                    e.rcEndAnimTimeout = setTimeout((function() {
                        e.rcEndAnimTimeout = null, e.rcEndListener && e.rcEndListener()
                    }), 1e3 * r + 200)
                }
            }

            function O(e) {
                e.rcEndAnimTimeout && (clearTimeout(e.rcEndAnimTimeout), e.rcEndAnimTimeout = null)
            }
            var R = function(e, t, n) {
                var i = "object" === ("undefined" === typeof t ? "undefined" : (0, y.default)(t)),
                    o = i ? t.name : t,
                    r = i ? t.active : t + "-active",
                    a = n,
                    s = void 0,
                    l = void 0,
                    c = L()(e);
                return n && "[object Object]" === Object.prototype.toString.call(n) && (a = n.end, s = n.start, l = n.active), e.rcEndListener && e.rcEndListener(), e.rcEndListener = function(t) {
                    t && t.target !== e || (e.rcAnimTimeout && (clearTimeout(e.rcAnimTimeout), e.rcAnimTimeout = null), O(e), c.remove(o), c.remove(r), C.removeEndEventListener(e, e.rcEndListener), e.rcEndListener = null, a && a())
                }, C.addEndEventListener(e, e.rcEndListener), s && s(), c.add(o), e.rcAnimTimeout = setTimeout((function() {
                    e.rcAnimTimeout = null, c.add(r), l && setTimeout(l, 0), _(e)
                }), 30), {
                    stop: function() {
                        e.rcEndListener && e.rcEndListener()
                    }
                }
            };
            R.style = function(e, t, n) {
                e.rcEndListener && e.rcEndListener(), e.rcEndListener = function(t) {
                    t && t.target !== e || (e.rcAnimTimeout && (clearTimeout(e.rcAnimTimeout), e.rcAnimTimeout = null), O(e), C.removeEndEventListener(e, e.rcEndListener), e.rcEndListener = null, n && n())
                }, C.addEndEventListener(e, e.rcEndListener), e.rcAnimTimeout = setTimeout((function() {
                    for (var n in t) t.hasOwnProperty(n) && (e.style[n] = t[n]);
                    e.rcAnimTimeout = null, _(e)
                }), 0)
            }, R.setTransition = function(e, t, n) {
                var i = t,
                    o = n;
                void 0 === n && (o = i, i = ""), i = i || "", S.forEach((function(t) {
                    e.style[t + "Transition" + i] = o
                }))
            }, R.isCssAnimationSupported = N;
            const M = R;
            const W = {
                isAppearSupported: function(e) {
                    return e.transitionName && e.transitionAppear || e.animation.appear
                },
                isEnterSupported: function(e) {
                    return e.transitionName && e.transitionEnter || e.animation.enter
                },
                isLeaveSupported: function(e) {
                    return e.transitionName && e.transitionLeave || e.animation.leave
                },
                allowAppearCallback: function(e) {
                    return e.transitionAppear || e.animation.appear
                },
                allowEnterCallback: function(e) {
                    return e.transitionEnter || e.animation.enter
                },
                allowLeaveCallback: function(e) {
                    return e.transitionLeave || e.animation.leave
                }
            };
            var j = {
                    enter: "transitionEnter",
                    appear: "transitionAppear",
                    leave: "transitionLeave"
                },
                D = function(e) {
                    function t() {
                        return (0, o.default)(this, t), (0, a.default)(this, (t.__proto__ || Object.getPrototypeOf(t)).apply(this, arguments))
                    }
                    return (0, s.default)(t, e), (0, r.default)(t, [{
                        key: "componentWillUnmount",
                        value: function() {
                            this.stop()
                        }
                    }, {
                        key: "componentWillEnter",
                        value: function(e) {
                            W.isEnterSupported(this.props) ? this.transition("enter", e) : e()
                        }
                    }, {
                        key: "componentWillAppear",
                        value: function(e) {
                            W.isAppearSupported(this.props) ? this.transition("appear", e) : e()
                        }
                    }, {
                        key: "componentWillLeave",
                        value: function(e) {
                            W.isLeaveSupported(this.props) ? this.transition("leave", e) : e()
                        }
                    }, {
                        key: "transition",
                        value: function(e, t) {
                            var n = this,
                                i = c.findDOMNode(this),
                                o = this.props,
                                r = o.transitionName,
                                a = "object" === typeof r;
                            this.stop();
                            var s = function() {
                                n.stopper = null, t()
                            };
                            if ((N || !o.animation[e]) && r && o[j[e]]) {
                                var l = a ? r[e] : r + "-" + e,
                                    u = l + "-active";
                                a && r[e + "Active"] && (u = r[e + "Active"]), this.stopper = M(i, {
                                    name: l,
                                    active: u
                                }, s)
                            } else this.stopper = o.animation[e](i, s)
                        }
                    }, {
                        key: "stop",
                        value: function() {
                            var e = this.stopper;
                            e && (this.stopper = null, e.stop())
                        }
                    }, {
                        key: "render",
                        value: function() {
                            return this.props.children
                        }
                    }]), t
                }(l.Component);
            D.propTypes = {
                children: f().any,
                animation: f().any,
                transitionName: f().any
            };
            const z = D;
            var K = "rc_animate_" + Date.now();

            function U(e) {
                var t = e.children;
                return l.isValidElement(t) && !t.key ? l.cloneElement(t, {
                    key: K
                }) : t
            }

            function I() {}
            var F = function(e) {
                function t(e) {
                    (0, o.default)(this, t);
                    var n = (0, a.default)(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this, e));
                    return V.call(n), n.currentlyAnimatingKeys = {}, n.keysToEnter = [], n.keysToLeave = [], n.state = {
                        children: m(U(e))
                    }, n.childrenRefs = {}, n
                }
                return (0, s.default)(t, e), (0, r.default)(t, [{
                    key: "componentDidMount",
                    value: function() {
                        var e = this,
                            t = this.props.showProp,
                            n = this.state.children;
                        t && (n = n.filter((function(e) {
                            return !!e.props[t]
                        }))), n.forEach((function(t) {
                            t && e.performAppear(t.key)
                        }))
                    }
                }, {
                    key: "componentWillReceiveProps",
                    value: function(e) {
                        var t = this;
                        this.nextProps = e;
                        var n = m(U(e)),
                            i = this.props;
                        i.exclusive && Object.keys(this.currentlyAnimatingKeys).forEach((function(e) {
                            t.stop(e)
                        }));
                        var o = i.showProp,
                            r = this.currentlyAnimatingKeys,
                            a = i.exclusive ? m(U(i)) : this.state.children,
                            s = [];
                        o ? (a.forEach((function(e) {
                            var t = e && v(n, e.key),
                                i = void 0;
                            (i = t && t.props[o] || !e.props[o] ? t : l.cloneElement(t || e, (0, u.default)({}, o, !0))) && s.push(i)
                        })), n.forEach((function(e) {
                            e && v(a, e.key) || s.push(e)
                        }))) : s = function(e, t) {
                            var n = [],
                                i = {},
                                o = [];
                            return e.forEach((function(e) {
                                e && v(t, e.key) ? o.length && (i[e.key] = o, o = []) : o.push(e)
                            })), t.forEach((function(e) {
                                e && Object.prototype.hasOwnProperty.call(i, e.key) && (n = n.concat(i[e.key])), n.push(e)
                            })), n = n.concat(o)
                        }(a, n), this.setState({
                            children: s
                        }), n.forEach((function(e) {
                            var n = e && e.key;
                            if (!e || !r[n]) {
                                var i = e && v(a, n);
                                if (o) {
                                    var s = e.props[o];
                                    if (i) !h(a, n, o) && s && t.keysToEnter.push(n);
                                    else s && t.keysToEnter.push(n)
                                } else i || t.keysToEnter.push(n)
                            }
                        })), a.forEach((function(e) {
                            var i = e && e.key;
                            if (!e || !r[i]) {
                                var a = e && v(n, i);
                                if (o) {
                                    var s = e.props[o];
                                    if (a) !h(n, i, o) && s && t.keysToLeave.push(i);
                                    else s && t.keysToLeave.push(i)
                                } else a || t.keysToLeave.push(i)
                            }
                        }))
                    }
                }, {
                    key: "componentDidUpdate",
                    value: function() {
                        var e = this.keysToEnter;
                        this.keysToEnter = [], e.forEach(this.performEnter);
                        var t = this.keysToLeave;
                        this.keysToLeave = [], t.forEach(this.performLeave)
                    }
                }, {
                    key: "isValidChildByKey",
                    value: function(e, t) {
                        var n = this.props.showProp;
                        return n ? h(e, t, n) : v(e, t)
                    }
                }, {
                    key: "stop",
                    value: function(e) {
                        delete this.currentlyAnimatingKeys[e];
                        var t = this.childrenRefs[e];
                        t && t.stop()
                    }
                }, {
                    key: "render",
                    value: function() {
                        var e = this,
                            t = this.props;
                        this.nextProps = t;
                        var n = this.state.children,
                            o = null;
                        n && (o = n.map((function(n) {
                            if (null === n || void 0 === n) return n;
                            if (!n.key) throw new Error("must set key for <rc-animate> children");
                            return l.createElement(z, {
                                key: n.key,
                                ref: function(t) {
                                    e.childrenRefs[n.key] = t
                                },
                                animation: t.animation,
                                transitionName: t.transitionName,
                                transitionEnter: t.transitionEnter,
                                transitionAppear: t.transitionAppear,
                                transitionLeave: t.transitionLeave
                            }, n)
                        })));
                        var r = t.component;
                        if (r) {
                            var a = t;
                            return "string" === typeof r && (a = (0, i.default)({
                                className: t.className,
                                style: t.style
                            }, t.componentProps)), l.createElement(r, a, o)
                        }
                        return o[0] || null
                    }
                }]), t
            }(l.Component);
            F.isAnimate = !0, F.propTypes = {
                className: f().string,
                style: f().object,
                component: f().any,
                componentProps: f().object,
                animation: f().object,
                transitionName: f().oneOfType([f().string, f().object]),
                transitionEnter: f().bool,
                transitionAppear: f().bool,
                exclusive: f().bool,
                transitionLeave: f().bool,
                onEnd: f().func,
                onEnter: f().func,
                onLeave: f().func,
                onAppear: f().func,
                showProp: f().string,
                children: f().node
            }, F.defaultProps = {
                animation: {},
                component: "span",
                componentProps: {},
                transitionEnter: !0,
                transitionLeave: !0,
                transitionAppear: !1,
                onEnd: I,
                onEnter: I,
                onLeave: I,
                onAppear: I
            };
            var V = function() {
                var e = this;
                this.performEnter = function(t) {
                    e.childrenRefs[t] && (e.currentlyAnimatingKeys[t] = !0, e.childrenRefs[t].componentWillEnter(e.handleDoneAdding.bind(e, t, "enter")))
                }, this.performAppear = function(t) {
                    e.childrenRefs[t] && (e.currentlyAnimatingKeys[t] = !0, e.childrenRefs[t].componentWillAppear(e.handleDoneAdding.bind(e, t, "appear")))
                }, this.handleDoneAdding = function(t, n) {
                    var i = e.props;
                    if (delete e.currentlyAnimatingKeys[t], !i.exclusive || i === e.nextProps) {
                        var o = m(U(i));
                        e.isValidChildByKey(o, t) ? "appear" === n ? W.allowAppearCallback(i) && (i.onAppear(t), i.onEnd(t, !0)) : W.allowEnterCallback(i) && (i.onEnter(t), i.onEnd(t, !0)) : e.performLeave(t)
                    }
                }, this.performLeave = function(t) {
                    e.childrenRefs[t] && (e.currentlyAnimatingKeys[t] = !0, e.childrenRefs[t].componentWillLeave(e.handleDoneLeaving.bind(e, t)))
                }, this.handleDoneLeaving = function(t) {
                    var n = e.props;
                    if (delete e.currentlyAnimatingKeys[t], !n.exclusive || n === e.nextProps) {
                        var i = m(U(n));
                        if (e.isValidChildByKey(i, t)) e.performEnter(t);
                        else {
                            var o = function() {
                                W.allowLeaveCallback(n) && (n.onLeave(t), n.onEnd(t, !1))
                            };
                            ! function(e, t, n) {
                                var i = e.length === t.length;
                                return i && e.forEach((function(e, o) {
                                    var r = t[o];
                                    e && r && (e && !r || !e && r || e.key !== r.key || n && e.props[n] !== r.props[n]) && (i = !1)
                                })), i
                            }(e.state.children, i, n.showProp) ? e.setState({
                                children: i
                            }, o): o()
                        }
                    }
                }
            };
            const B = d(F);
            const Z = function(e) {
                function t() {
                    return (0, o.default)(this, t), (0, a.default)(this, (t.__proto__ || Object.getPrototypeOf(t)).apply(this, arguments))
                }
                return (0, s.default)(t, e), (0, r.default)(t, [{
                    key: "shouldComponentUpdate",
                    value: function(e) {
                        return !!e.hiddenClassName || !!e.visible
                    }
                }, {
                    key: "render",
                    value: function() {
                        var e = this.props.className;
                        this.props.hiddenClassName && !this.props.visible && (e += " " + this.props.hiddenClassName);
                        var t = (0, i.default)({}, this.props);
                        return delete t.hiddenClassName, delete t.visible, t.className = e, l.createElement("div", (0, i.default)({}, t))
                    }
                }]), t
            }(l.Component);

            function q() {}
            var $ = function(e) {
                function t() {
                    (0, o.default)(this, t);
                    var e = (0, a.default)(this, (t.__proto__ || Object.getPrototypeOf(t)).apply(this, arguments));
                    return e.getDialogElement = function() {
                        var t = e.props,
                            n = t.closable,
                            i = t.prefixCls,
                            o = void 0;
                        t.footer && (o = l.createElement("div", {
                            className: i + "-footer",
                            ref: function(t) {
                                return e.footerRef = t
                            }
                        }, t.footer));
                        var r = void 0;
                        t.title && (r = l.createElement("div", {
                            className: i + "-header",
                            ref: function(t) {
                                return e.headerRef = t
                            }
                        }, l.createElement("div", {
                            className: i + "-title"
                        }, t.title)));
                        var a = void 0;
                        n && (a = l.createElement("button", {
                            onClick: e.close,
                            "aria-label": "Close",
                            className: i + "-close"
                        }, l.createElement("span", {
                            className: i + "-close-x"
                        })));
                        var s = e.getTransitionName(),
                            c = l.createElement(Z, {
                                key: "dialog-element",
                                role: "document",
                                ref: function(t) {
                                    return e.dialogRef = t
                                },
                                style: t.style || {},
                                className: i + " " + (t.className || ""),
                                visible: t.visible
                            }, l.createElement("div", {
                                className: i + "-content"
                            }, a, r, l.createElement("div", {
                                className: i + "-body",
                                style: t.bodyStyle,
                                ref: function(t) {
                                    return e.bodyRef = t
                                }
                            }, t.children), o));
                        return l.createElement(B, {
                            key: "dialog",
                            showProp: "visible",
                            onAppear: e.onAnimateAppear,
                            onLeave: e.onAnimateLeave,
                            transitionName: s,
                            component: "",
                            transitionAppear: !0
                        }, c)
                    }, e.onAnimateAppear = function() {
                        document.body.style.overflow = "hidden"
                    }, e.onAnimateLeave = function() {
                        document.body.style.overflow = "", e.wrapRef && (e.wrapRef.style.display = "none"), e.props.onAnimateLeave && e.props.onAnimateLeave(), e.props.afterClose && e.props.afterClose()
                    }, e.close = function(t) {
                        e.props.onClose && e.props.onClose(t)
                    }, e.onMaskClick = function(t) {
                        t.target === t.currentTarget && e.close(t)
                    }, e
                }
                return (0, s.default)(t, e), (0, r.default)(t, [{
                    key: "componentWillUnmount",
                    value: function() {
                        document.body.style.overflow = "", this.wrapRef && (this.wrapRef.style.display = "none")
                    }
                }, {
                    key: "getZIndexStyle",
                    value: function() {
                        var e = {},
                            t = this.props;
                        return void 0 !== t.zIndex && (e.zIndex = t.zIndex), e
                    }
                }, {
                    key: "getWrapStyle",
                    value: function() {
                        var e = this.props.wrapStyle || {};
                        return (0, i.default)({}, this.getZIndexStyle(), e)
                    }
                }, {
                    key: "getMaskStyle",
                    value: function() {
                        var e = this.props.maskStyle || {};
                        return (0, i.default)({}, this.getZIndexStyle(), e)
                    }
                }, {
                    key: "getMaskTransitionName",
                    value: function() {
                        var e = this.props,
                            t = e.maskTransitionName,
                            n = e.maskAnimation;
                        return !t && n && (t = e.prefixCls + "-" + n), t
                    }
                }, {
                    key: "getTransitionName",
                    value: function() {
                        var e = this.props,
                            t = e.transitionName,
                            n = e.animation;
                        return !t && n && (t = e.prefixCls + "-" + n), t
                    }
                }, {
                    key: "getMaskElement",
                    value: function() {
                        var e = this.props,
                            t = void 0;
                        if (e.mask) {
                            var n = this.getMaskTransitionName();
                            t = l.createElement(Z, (0, i.default)({
                                style: this.getMaskStyle(),
                                key: "mask-element",
                                className: e.prefixCls + "-mask",
                                hiddenClassName: e.prefixCls + "-mask-hidden",
                                visible: e.visible
                            }, e.maskProps)), n && (t = l.createElement(B, {
                                key: "mask",
                                showProp: "visible",
                                transitionAppear: !0,
                                component: "",
                                transitionName: n
                            }, t))
                        }
                        return t
                    }
                }, {
                    key: "render",
                    value: function() {
                        var e = this,
                            t = this.props,
                            n = t.prefixCls,
                            o = t.maskClosable,
                            r = this.getWrapStyle();
                        return t.visible && (r.display = null), l.createElement("div", null, this.getMaskElement(), l.createElement("div", (0, i.default)({
                            className: n + "-wrap " + (t.wrapClassName || ""),
                            ref: function(t) {
                                return e.wrapRef = t
                            },
                            onClick: o ? this.onMaskClick : void 0,
                            role: "dialog",
                            "aria-labelledby": t.title,
                            style: r
                        }, t.wrapProps), this.getDialogElement()))
                    }
                }]), t
            }(l.Component);
            const G = $;
            $.defaultProps = {
                afterClose: q,
                className: "",
                mask: !0,
                visible: !1,
                closable: !0,
                maskClosable: !0,
                prefixCls: "rmc-dialog",
                onClose: q
            };
            var H = !!c.createPortal,
                J = !("undefined" === typeof window || !window.document || !window.document.createElement),
                Q = function(e) {
                    function t() {
                        (0, o.default)(this, t);
                        var e = (0, a.default)(this, (t.__proto__ || Object.getPrototypeOf(t)).apply(this, arguments));
                        return e.saveRef = function(t) {
                            H && (e._component = t)
                        }, e.getComponent = function(t) {
                            var n = (0, i.default)({}, e.props);
                            return ["visible", "onAnimateLeave"].forEach((function(e) {
                                n.hasOwnProperty(e) && delete n[e]
                            })), l.createElement(G, (0, i.default)({}, n, {
                                visible: t,
                                onAnimateLeave: e.removeContainer,
                                ref: e.saveRef
                            }))
                        }, e.removeContainer = function() {
                            e.container && (H || c.unmountComponentAtNode(e.container), e.container.parentNode.removeChild(e.container), e.container = null)
                        }, e.getContainer = function() {
                            if (!e.container) {
                                var t = document.createElement("div"),
                                    n = e.props.prefixCls + "-container-" + (new Date).getTime();
                                t.setAttribute("id", n), document.body.appendChild(t), e.container = t
                            }
                            return e.container
                        }, e
                    }
                    return (0, s.default)(t, e), (0, r.default)(t, [{
                        key: "componentDidMount",
                        value: function() {
                            this.props.visible && this.componentDidUpdate()
                        }
                    }, {
                        key: "shouldComponentUpdate",
                        value: function(e) {
                            var t = e.visible;
                            return !(!this.props.visible && !t)
                        }
                    }, {
                        key: "componentWillUnmount",
                        value: function() {
                            this.props.visible ? H ? this.removeContainer() : this.renderDialog(!1) : this.removeContainer()
                        }
                    }, {
                        key: "componentDidUpdate",
                        value: function() {
                            H || this.renderDialog(this.props.visible)
                        }
                    }, {
                        key: "renderDialog",
                        value: function(e) {
                            c.unstable_renderSubtreeIntoContainer(this, this.getComponent(e), this.getContainer())
                        }
                    }, {
                        key: "render",
                        value: function() {
                            if (!J) return null;
                            var e = this.props.visible;
                            return H && (e || this._component) ? c.createPortal(this.getComponent(e), this.getContainer()) : null
                        }
                    }]), t
                }(l.Component);
            const X = Q;
            Q.defaultProps = {
                visible: !1,
                prefixCls: "rmc-dialog",
                onClose: function() {}
            }
        }
    }
]);
//# sourceMappingURL=52106.e468acba.chunk.js.map