"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [55221], {
        855221: (t, i, e) => {
            e.d(i, {
                C: () => v,
                X: () => g
            });
            var o = e(464418),
                n = e(737536),
                r = e(423400),
                a = e(704270);
            const c = (t, i) => {
                (async (t, i, e, o, n) => {
                    a.l.then((r => {
                        r.sendCommand(t, i, e, o, n)
                    }))
                })({
                    command: n.y.GET_PERMISSIBLE_ODDS,
                    params: {},
                    rid: r.A.gForCommand()
                }, "", t, (() => {}), i)
            };
            var l = e(291372),
                d = e(605060);
            const u = {
                    decimalFormatRemove3Digit: !1,
                    roundDecimalCoeficients: e(179177).Ay.ODD_ROUNDING,
                    useLadderForFractionalFormat: !0
                },
                s = {},
                {
                    oddFormat: f,
                    ladderLoaded: m
                } = l.A.getState().betSlip;
            let h, p = !1;
            async function g() {
                let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
                l.A.dispatch((0, o.wT)()), c((i => {
                    null !== i && void 0 !== i && i.details ? (p = i.details, l.A.dispatch((0, o.Gp)(t))) : p = []
                }), (() => {
                    p = []
                }))
            }

            function v(t, i) {
                var e;
                let o = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "";
                if (isNaN(+t) || +t === 1 / 0) return "-";
                if ((1 === i || "fractional" === i) && !p) return "-";
                const n = (null === (e = d.z.find((t => t.value === i || t.id === i))) || void 0 === e ? void 0 : e.value) || "decimal",
                    r = parseFloat(`${t}`),
                    a = `${n}${r}`;
                if (isNaN(r)) return "";
                if (void 0 === s[a])
                    if ("fractional" === n && u.useLadderForFractionalFormat && "fictional" === o && void 0 !== r) s[a] = Math.round(100 * (r - 1) || 0) / 100 + "/1";
                    else {
                        const t = function(t, i, e) {
                            const o = t,
                                n = Math.floor(t),
                                r = void 0 !== t ? Math.round(100 * o || 0) / 100 : t;
                            switch (i) {
                                case "decimal":
                                    return function(t, i, e) {
                                        return void 0 !== t ? i !== e && t.toString().split(".")[1] && t.toString().split(".")[1].length > 2 && !u.decimalFormatRemove3Digit ? Math.round(t * Math.pow(10, u.roundDecimalCoeficients)) / Math.pow(10, u.roundDecimalCoeficients) : e.toFixed(2) : t
                                    }(t, n, o);
                                case "fractional":
                                    return function(t, i, e, o) {
                                        if (t && u.useLadderForFractionalFormat) {
                                            const n = function(t, i) {
                                                let e = "";
                                                if (i.length) {
                                                    let o = 0,
                                                        n = i.find((i => {
                                                            let {
                                                                Price: e
                                                            } = i;
                                                            return e === t
                                                        }));
                                                    if (n) e = `${n.Numerator}/${n.Denominator}`;
                                                    else {
                                                        for (let e = 0; e < i.length; e++) i[e].Price > o && i[e].Price < t && (o = i[e].Price);
                                                        n = i.find((t => {
                                                            let {
                                                                Price: i
                                                            } = t;
                                                            return i === o
                                                        })), n && (e = `${n.Numerator}/${n.Denominator}`)
                                                    }
                                                }
                                                return e
                                            }(i, o);
                                            if (n) return n; {
                                                const t = function(t) {
                                                    let i, e, o;

                                                    function n(r, a, c) {
                                                        return a = void 0 !== a ? a : 1, c = void 0 !== c ? c : 0, i = 1 / (r - Math.floor(r)), e = a * Math.floor(i) + c, o = Math.round(t * e), o / e === t ? `${o.toString()}/${e.toString()}` : n(i, e, a)
                                                    }
                                                    t !== Math.floor(t) ? t = parseFloat(`${(Math.floor(t)-1).toString()}.${String(t).split(".")[1]}`) : t -= 1;
                                                    return t % 1 === 0 ? `${String(t)}/1` : String(n(t))
                                                }(e);
                                                if (t) return t
                                            }
                                            return t
                                        }
                                        return "-"
                                    }(t, o, r, e);
                                case "american":
                                    return function(t, i) {
                                        return t ? i > 2 ? `+${(100*(i-1)).toString().split(".")[0]}` : 1 !== i ? (-100 / (i - 1)).toString().split(".")[0] : "-" : i
                                    }(t, r);
                                case "hongkong":
                                    return function(t, i, e) {
                                        return void 0 !== t ? i !== e && t.toString().split(".")[1].length > 2 ? Math.round((t - 1) * Math.pow(10, u.roundDecimalCoeficients)) / Math.pow(10, u.roundDecimalCoeficients) : (e - 1).toFixed(2) : t
                                    }(t, n, o);
                                case "malay":
                                    return function(t) {
                                        return 2 === t ? "0.000" : t > 2 ? (Math.round(+(1 / (1 - t)).toFixed(u.roundDecimalCoeficients + 1) * Math.pow(10, u.roundDecimalCoeficients)) / Math.pow(10, u.roundDecimalCoeficients)).toFixed(u.roundDecimalCoeficients) : (t - 1).toFixed(u.roundDecimalCoeficients)
                                    }(o);
                                case "indo":
                                    return function(t) {
                                        return 2 === t ? "0.000" : t > 2 ? (t - 1).toFixed(u.roundDecimalCoeficients) : (Math.round(+(1 / (1 - t)).toFixed(u.roundDecimalCoeficients + 1) * Math.pow(10, u.roundDecimalCoeficients)) / Math.pow(10, u.roundDecimalCoeficients)).toFixed(u.roundDecimalCoeficients)
                                    }(o);
                                default:
                                    return r
                            }
                        }(r, n, p);
                        let i = String(t) || "";
                        if (t && "decimal" === n) {
                            var c, f, m;
                            if (!h) {
                                const t = l.A.getState().socket.partnerConfigs;
                                h = null === t || void 0 === t ? void 0 : t.price_decimals
                            }
                            h && t && (null === (c = String(t)) || void 0 === c || null === (f = c.split(".")) || void 0 === f || null === (m = f[1]) || void 0 === m ? void 0 : m.length) > h && (i = Number(t).toFixed(h))
                        }
                        s[a] = i
                    }
                return s[a]
            }
            m || g(f)
        }
    }
]);
//# sourceMappingURL=55221.bdc30ed2.chunk.js.map