"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [42146], {
        242146: (e, a, s) => {
            s.d(a, {
                DE: () => g,
                EE: () => n,
                Hk: () => l,
                _l: () => d,
                bX: () => c,
                qU: () => o
            });
            var i = s(197262),
                t = s(737536);
            const l = {
                    favorite: {
                        id: "favorite",
                        name: "favorite",
                        title: i.A.t("casino.favorite"),
                        games_count: ""
                    },
                    all: {
                        id: "all",
                        name: "all",
                        title: i.A.t("casino.all-games"),
                        games_count: ""
                    },
                    lastPlayed: {
                        id: "last-played",
                        name: "last-played",
                        title: i.A.t("casino.last-played"),
                        games_count: ""
                    },
                    suggested: {
                        id: "suggested",
                        name: "suggested",
                        title: i.A.t("casino.suggested"),
                        games_count: ""
                    },
                    special: {
                        id: "special",
                        name: "special",
                        title: i.A.t("casino.special"),
                        games_count: ""
                    },
                    specialLive: {
                        id: "specialLive",
                        name: "specialLive",
                        title: i.A.t("casino.specialLive"),
                        games_count: ""
                    }
                },
                c = Object.values(l),
                d = Object.values(l).map((e => e.id)),
                o = [l.favorite.id, l.lastPlayed.id, l.suggested.id, l.special.id, l.specialLive.id],
                n = {
                    [l.lastPlayed.id]: t.y.GET_RECENT_PLAYED_CASINO_GAMES,
                    [l.suggested.id]: t.y.GET_CASINO_SUGGESTED_GAMES
                },
                g = ["casino", "live-casino"]
        }
    }
]);
//# sourceMappingURL=42146.1c160104.chunk.js.map