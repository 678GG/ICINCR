"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [8246], {
        708246: (n, i, e) => {
            e.d(i, {
                n: () => v
            });
            var a = e(889181),
                o = e(930797),
                s = e(906327),
                l = e(944148),
                _ = e(735905),
                d = e(68392),
                r = e(706683),
                c = e(179177),
                t = (e(826090), e(570579));
            const v = n => {
                var i;
                let {
                    isMobile: e,
                    cardData: {
                        game: v,
                        game_name: m,
                        currency_id: p,
                        win_amount: u,
                        player_user_name: h
                    }
                } = n;
                const b = (0, s.b)(),
                    g = (0, l.Q)(v);
                return (0, t.jsxs)("div", {
                    className: (0, a.A)(["topWinners__card", {
                        topWinners__card__mobile: e,
                        "topWinners__card--disable": !v || !(null !== v && void 0 !== v && null !== (i = v.cats) && void 0 !== i && i.length)
                    }]),
                    onClick: n => {
                        var i;
                        !c.Ay.MOCKED_DATA && v && null !== v && void 0 !== v && null !== (i = v.cats) && void 0 !== i && i.length && (c.Ay.CASINO_MOBILE_IFRAME || !e ? (n.stopPropagation(), b("real", v)) : g("real"))
                    },
                    children: [(0, t.jsx)("div", {
                        className: "topWinners__card__game",
                        children: v ? (0, t.jsx)(o.V, {
                            icon_1: null === v || void 0 === v ? void 0 : v.icon_1,
                            icon_2: null === v || void 0 === v ? void 0 : v.icon_2,
                            icon_3: null === v || void 0 === v ? void 0 : v.icon_3,
                            id: null === v || void 0 === v ? void 0 : v.id,
                            name: null === v || void 0 === v ? void 0 : v.name
                        }) : (0, t.jsx)("div", {
                            className: "topWinners__card__game--empty",
                            children: (0, t.jsx)(_.GlobalIcon, {
                                skeleton: !0,
                                lib: "generic",
                                name: "emptyCasinoGame",
                                theme: "colored",
                                size: 46
                            })
                        })
                    }), (0, t.jsxs)("div", {
                        className: "topWinners__card__info",
                        children: [(0, t.jsx)("div", {
                            className: "topWinners__card__info--name globalEllipsis",
                            children: m
                        }), (0, t.jsx)("div", {
                            className: "topWinners__card__info--player",
                            children: h
                        }), (0, t.jsx)("div", {
                            className: "topWinners__card__info--win-amount",
                            children: (0, d.HN)(p, (0, r.Q8)(u))
                        })]
                    })]
                })
            }
        }
    }
]);
//# sourceMappingURL=8246.3546617c.chunk.js.map