import { FC, useEffect, useMemo, useRef, useState } from 'react';
import cc from 'classcat';
import { useSelector } from 'react-redux';
import {
  getBetslipOpen,
  getBetsTotalOdds,
  getQuickBetEnabled
} from 'store/selectors/bet-slip';

import { GlobalIcon } from 'components/GlobalIcon';
import { isMobile } from 'utils/is-mobile';
import { getButtonStyles, scrollToTop } from './helpers';
import SpringConfigs from 'utils/constants/swarm/spring-configs';

import './index.less';

const SCROLL_TOP_TO_SHOW_BUTTON = 100;
const TIME_TO_HIDE_NAVIGATION_BUTTON = 4000;

const {
  TOP_NAVIGATION_BUTTON_POSITION: position,
  TOP_NAVIGATION_BUTTON_ALIGNMENT: alignment
} = SpringConfigs;

export const NavigationButtonElement: FC = () => {
  const isQuickBetEnabled = useSelector(getQuickBetEnabled);
  const isBetslipOpened = useSelector(getBetslipOpen);
  const betsTotalOdds = useSelector(getBetsTotalOdds);
  const timeoutRef = useRef<null | any>(null);
  const [headerHeight, setHeaderHeight] = useState(0);
  const [isVisible, setIsVisible] = useState<null | boolean>(null);

  const isBetslipModalOpened = useMemo(
    () => isMobile() && (isBetslipOpened || isQuickBetEnabled),
    [isBetslipOpened, isQuickBetEnabled]
  );

  useEffect(() => {
    if (isBetslipModalOpened) {
      if (isVisible) {
        setIsVisible(false);
        clearTimeout(timeoutRef.current);
      }
    }
  }, [isBetslipModalOpened]);

  useEffect(() => {
    const handleScroll = () => {
      const isVisible =
        document.body.scrollTop > SCROLL_TOP_TO_SHOW_BUTTON ||
        document.documentElement.scrollTop > SCROLL_TOP_TO_SHOW_BUTTON;

      setIsVisible(current => (!!current !== isVisible ? isVisible : current));

      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }

      timeoutRef.current = setTimeout(() => {
        setIsVisible(false);
      }, TIME_TO_HIDE_NAVIGATION_BUTTON);

      const header = document.querySelector(
        'header.header-rows'
      ) as HTMLDivElement;

      if (header && header.classList.contains('header-sticky')) {
        setHeaderHeight(header.clientHeight || header.offsetHeight);
      }
    };

    document.addEventListener('scroll', handleScroll);

    return () => {
      clearTimeout(timeoutRef.current);
      document.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <div
      style={getButtonStyles(alignment, position, headerHeight)}
      onClick={scrollToTop}
      className={cc([
        'v3-top-navigation-button-wrapper',
        {
          'v3-top-navigation-button-wrapper--hidden': isVisible === false,
          'v3-top-navigation-button-wrapper--active': isVisible,
          'v3-top-navigation-button-wrapper--betsTotalOdds':
            betsTotalOdds && SpringConfigs.BOTTOM_NAVIGATION,
          'v3-top-navigation-button-wrapper--betsTotalOddsActive':
            betsTotalOdds && !SpringConfigs.BOTTOM_NAVIGATION
        }
      ])}
    >
      <GlobalIcon
        lib="generic"
        name="navigationArrowUp"
        theme="default"
        size={20}
      />
    </div>
  );
};
