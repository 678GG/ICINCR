import { FC } from 'react';

import { isMobile } from 'utils/is-mobile';
import SpringConfigs from 'utils/constants/swarm/spring-configs';
import { NavigationButtonElement } from './NavigationButtonElement';

export const TopNavigationButton: FC = () => {
  return isMobile() && SpringConfigs.IS_TOP_NAVIGATION_BUTTON_ENABLED ? (
    <NavigationButtonElement />
  ) : null;
};
