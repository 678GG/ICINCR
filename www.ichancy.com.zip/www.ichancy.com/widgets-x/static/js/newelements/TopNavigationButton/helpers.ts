import { tAlignment, tPosition } from 'interfaces/generic';
import { MouseEvent } from 'react';

import { BOTTOM_NAVIGATION_ELEMENT_DEFAULT_HEIGHT } from 'utils/constants/app/BottomNavigationDefaultData';

type tStyleObject = { [k in tPosition | tAlignment]?: string };

const INDENT_SIZE = 24;
const BUTTON_WIDTH = 48;

const leftStyles: tStyleObject = { left: `${INDENT_SIZE}px` };
const rightStyles: tStyleObject = { right: `${INDENT_SIZE}px` };
const centerStyles: tStyleObject = {
  left: `calc(50% - ${BUTTON_WIDTH / 2}px)`
};

const bottomStyles: tStyleObject = {
  bottom: `${BOTTOM_NAVIGATION_ELEMENT_DEFAULT_HEIGHT + INDENT_SIZE}px`
};

const buttonStyling: { [k in tPosition | string]: tStyleObject } = {
  'bottom-left': { ...bottomStyles, ...leftStyles },
  'bottom-center': { ...bottomStyles, ...centerStyles },
  'bottom-right': { ...bottomStyles, ...rightStyles },
  left: { ...leftStyles },
  center: { ...centerStyles },
  right: { ...rightStyles }
};

export const getButtonStyles = (
  alignment: tAlignment,
  position: tPosition,
  headerHeight = 150
): tStyleObject => {
  if (alignment === 'top') {
    return {
      ...buttonStyling[position],
      [alignment]: `${headerHeight + INDENT_SIZE}px`
    };
  }

  return buttonStyling[`${alignment}-${position}`];
};

export const scrollTo = (
  e: MouseEvent<HTMLDivElement>,
  position = 0,
  behavior: ScrollBehavior = 'smooth'
): void => {
  e.preventDefault();
  document.body.scrollTo({ top: position, behavior });
  document.documentElement.scrollTo({ top: position, behavior });
};

export const scrollToTop = (
  e: MouseEvent<HTMLDivElement>,
  behavior: ScrollBehavior = 'smooth'
): void => {
  scrollTo(e, 0, behavior);
};
