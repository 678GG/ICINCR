"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [61579], {
        161579: (e, t, o) => {
            function r() {
                return r = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var o = arguments[t];
                        for (var r in o) Object.prototype.hasOwnProperty.call(o, r) && (e[r] = o[r])
                    }
                    return e
                }, r.apply(this, arguments)
            }

            function n(e) {
                return n = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                    return typeof e
                } : function(e) {
                    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                }, n(e)
            }

            function i(e, t, o) {
                return t in e ? Object.defineProperty(e, t, {
                    value: o,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = o, e
            }

            function l(e, t) {
                var o = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), o.push.apply(o, r)
                }
                return o
            }

            function f(e, t) {
                if (null == e) return {};
                var o, r, n = function(e, t) {
                    if (null == e) return {};
                    var o, r, n = {},
                        i = Object.keys(e);
                    for (r = 0; r < i.length; r++) o = i[r], t.indexOf(o) >= 0 || (n[o] = e[o]);
                    return n
                }(e, t);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    for (r = 0; r < i.length; r++) o = i[r], t.indexOf(o) >= 0 || Object.prototype.propertyIsEnumerable.call(e, o) && (n[o] = e[o])
                }
                return n
            }
            o.r(t), o.d(t, {
                default: () => v
            });
            var a = o(365043),
                s = o(731528),
                p = {
                    adjustX: 1,
                    adjustY: 1
                },
                u = [0, 0],
                c = {
                    left: {
                        points: ["cr", "cl"],
                        overflow: p,
                        offset: [-4, 0],
                        targetOffset: u
                    },
                    right: {
                        points: ["cl", "cr"],
                        overflow: p,
                        offset: [4, 0],
                        targetOffset: u
                    },
                    top: {
                        points: ["bc", "tc"],
                        overflow: p,
                        offset: [0, -4],
                        targetOffset: u
                    },
                    bottom: {
                        points: ["tc", "bc"],
                        overflow: p,
                        offset: [0, 4],
                        targetOffset: u
                    },
                    topLeft: {
                        points: ["bl", "tl"],
                        overflow: p,
                        offset: [0, -4],
                        targetOffset: u
                    },
                    leftTop: {
                        points: ["tr", "tl"],
                        overflow: p,
                        offset: [-4, 0],
                        targetOffset: u
                    },
                    topRight: {
                        points: ["br", "tr"],
                        overflow: p,
                        offset: [0, -4],
                        targetOffset: u
                    },
                    rightTop: {
                        points: ["tl", "tr"],
                        overflow: p,
                        offset: [4, 0],
                        targetOffset: u
                    },
                    bottomRight: {
                        points: ["tr", "br"],
                        overflow: p,
                        offset: [0, 4],
                        targetOffset: u
                    },
                    rightBottom: {
                        points: ["bl", "br"],
                        overflow: p,
                        offset: [4, 0],
                        targetOffset: u
                    },
                    bottomLeft: {
                        points: ["tl", "bl"],
                        overflow: p,
                        offset: [0, 4],
                        targetOffset: u
                    },
                    leftBottom: {
                        points: ["br", "bl"],
                        overflow: p,
                        offset: [-4, 0],
                        targetOffset: u
                    }
                };
            const y = function(e) {
                var t = e.overlay,
                    o = e.prefixCls,
                    r = e.id,
                    n = e.overlayInnerStyle;
                return a.createElement("div", {
                    className: "".concat(o, "-inner"),
                    id: r,
                    role: "tooltip",
                    style: n
                }, "function" === typeof t ? t() : t)
            };
            var b = function(e, t) {
                var o = e.overlayClassName,
                    p = e.trigger,
                    u = void 0 === p ? ["hover"] : p,
                    b = e.mouseEnterDelay,
                    v = void 0 === b ? 0 : b,
                    g = e.mouseLeaveDelay,
                    m = void 0 === g ? .1 : g,
                    O = e.overlayStyle,
                    d = e.prefixCls,
                    w = void 0 === d ? "rc-tooltip" : d,
                    h = e.children,
                    j = e.onVisibleChange,
                    C = e.afterVisibleChange,
                    P = e.transitionName,
                    S = e.animation,
                    k = e.motion,
                    D = e.placement,
                    E = void 0 === D ? "right" : D,
                    V = e.align,
                    N = void 0 === V ? {} : V,
                    x = e.destroyTooltipOnHide,
                    T = void 0 !== x && x,
                    I = e.defaultVisible,
                    L = e.getTooltipContainer,
                    H = e.overlayInnerStyle,
                    R = f(e, ["overlayClassName", "trigger", "mouseEnterDelay", "mouseLeaveDelay", "overlayStyle", "prefixCls", "children", "onVisibleChange", "afterVisibleChange", "transitionName", "animation", "motion", "placement", "align", "destroyTooltipOnHide", "defaultVisible", "getTooltipContainer", "overlayInnerStyle"]),
                    _ = (0, a.useRef)(null);
                (0, a.useImperativeHandle)(t, (function() {
                    return _.current
                }));
                var A = function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var o = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? l(Object(o), !0).forEach((function(t) {
                            i(e, t, o[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(o)) : l(Object(o)).forEach((function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(o, t))
                        }))
                    }
                    return e
                }({}, R);
                "visible" in e && (A.popupVisible = e.visible);
                var B = !1,
                    M = !1;
                if ("boolean" === typeof T) B = T;
                else if (T && "object" === n(T)) {
                    var X = T.keepParent;
                    B = !0 === X, M = !1 === X
                }
                return a.createElement(s.A, r({
                    popupClassName: o,
                    prefixCls: w,
                    popup: function() {
                        var t = e.arrowContent,
                            o = void 0 === t ? null : t,
                            r = e.overlay,
                            n = e.id;
                        return [a.createElement("div", {
                            className: "".concat(w, "-arrow"),
                            key: "arrow"
                        }, o), a.createElement(y, {
                            key: "content",
                            prefixCls: w,
                            id: n,
                            overlay: r,
                            overlayInnerStyle: H
                        })]
                    },
                    action: u,
                    builtinPlacements: c,
                    popupPlacement: E,
                    ref: _,
                    popupAlign: N,
                    getPopupContainer: L,
                    onPopupVisibleChange: j,
                    afterPopupVisibleChange: C,
                    popupTransitionName: P,
                    popupAnimation: S,
                    popupMotion: k,
                    defaultPopupVisible: I,
                    destroyPopupOnHide: B,
                    autoDestroy: M,
                    mouseLeaveDelay: m,
                    popupStyle: O,
                    mouseEnterDelay: v
                }, A), h)
            };
            const v = (0, a.forwardRef)(b)
        }
    }
]);
//# sourceMappingURL=61579.03cd7033.chunk.js.map