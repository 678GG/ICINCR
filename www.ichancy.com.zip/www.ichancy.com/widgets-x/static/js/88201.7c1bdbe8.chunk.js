"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [88201], {
        788201: (e, t, r) => {
            r.r(t), r.d(t, {
                default: () => f
            });
            var l, a, n, i = r(365043);

            function o() {
                return o = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = arguments[t];
                        for (var l in r) Object.prototype.hasOwnProperty.call(r, l) && (e[l] = r[l])
                    }
                    return e
                }, o.apply(this, arguments)
            }

            function C(e, t) {
                let {
                    title: r,
                    titleId: C,
                    ...c
                } = e;
                return i.createElement("svg", o({
                    width: 32,
                    height: 32,
                    viewBox: "0 0 32 32",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    ref: t,
                    "aria-labelledby": C
                }, c), r ? i.createElement("title", {
                    id: C
                }, r) : null, l || (l = i.createElement("circle", {
                    cx: 16,
                    cy: 15.999,
                    r: 16,
                    fill: "#B8A75D"
                })), a || (a = i.createElement("g", {
                    filter: "url(#filter0_d_226_2510)"
                }, i.createElement("path", {
                    d: "M6.002 25.5489L11.065 20.4359C8.681 17.1869 9.787 13.7259 11.548 12.0029C12.698 10.8549 14.285 10.1449 16.038 10.1449C17.522 10.1449 18.887 10.6529 19.968 11.5049L19.954 11.4949L22.18 9.27995C19.381 6.45595 13.598 6.19995 10.492 8.81595C10.548 8.91395 10.632 9.00695 10.698 9.11395C10.597 9.17695 8.763 11.0069 8.553 11.2059C8.513 11.1669 8.32 11.0209 8.28 10.9819C6.63 13.4539 6.102 16.1239 6.894 19.0239C7.088 19.6719 7.2 20.4159 7.2 21.1859C7.2 21.9469 7.091 22.6829 6.888 23.3779L6.902 23.3229C6.676 24.0969 6.298 24.8259 6 25.5479L6.002 25.5489Z",
                    fill: "white"
                }), i.createElement("path", {
                    d: "M16.5667 17.7969C16.4487 17.8569 16.2847 17.9849 16.2817 18.0849C16.2587 18.8989 16.2697 19.7139 16.2697 20.5699C17.5987 20.4299 18.6157 19.8749 19.3607 18.8529C19.9167 18.0989 20.2507 17.1519 20.2507 16.1269C20.2507 15.7829 20.2127 15.4469 20.1417 15.1249L20.1477 15.1559C19.8917 13.8749 18.9507 12.9869 17.7297 12.4829C17.1537 12.2449 16.6067 12.0089 16.2697 11.4109C16.2697 12.5479 16.2627 13.6859 16.2817 14.8229C16.2837 14.9259 16.4357 15.0669 16.5517 15.1209C17.1207 15.3899 17.4207 15.8269 17.4247 16.4519C17.4287 17.0769 17.1257 17.5169 16.5687 17.7979L16.5667 17.7969Z",
                    fill: "white"
                }), i.createElement("path", {
                    d: "M15.7402 15.0129V12.3789C14.5142 12.4449 13.4432 13.0569 12.7602 13.9749L12.7522 13.9859C12.1622 14.7449 11.8062 15.7119 11.8062 16.7609C11.8062 17.1369 11.8522 17.5019 11.9382 17.8519L11.9312 17.8209C12.2152 19.0979 13.1602 19.9699 14.3752 20.4709C14.9442 20.7049 15.4512 20.9679 15.7242 21.5759C15.7632 20.4099 15.7712 19.2589 15.7512 18.1079C15.7492 18.0079 15.5862 17.8769 15.4682 17.8189C14.9492 17.5629 14.6452 17.1679 14.5982 16.5869C14.5412 15.8819 14.8672 15.4319 15.7402 15.0129Z",
                    fill: "white"
                }), i.createElement("path", {
                    d: "M25.1398 9.64199C25.3648 8.86899 25.7438 8.13999 26.0418 7.41699L20.9788 12.529C23.3628 15.778 22.2568 19.239 20.4958 20.962C19.3458 22.11 17.7588 22.82 16.0048 22.82C14.5208 22.82 13.1558 22.312 12.0748 21.46L12.0888 21.47L9.86279 23.685C12.6618 26.509 18.4448 26.765 21.5508 24.149C21.4948 24.051 21.4108 23.958 21.3448 23.851C21.4458 23.788 23.2798 21.958 23.4898 21.759C23.5298 21.798 23.7228 21.944 23.7628 21.983C25.4128 19.511 25.9408 16.841 25.1488 13.941C24.9548 13.293 24.8428 12.549 24.8428 11.779C24.8428 11.018 24.9518 10.282 25.1548 9.58699L25.1398 9.64199Z",
                    fill: "white"
                }))), n || (n = i.createElement("defs", null, i.createElement("filter", {
                    id: "filter0_d_226_2510",
                    x: 2,
                    y: 6.99902,
                    width: 28.0417,
                    height: 26.9669,
                    filterUnits: "userSpaceOnUse",
                    colorInterpolationFilters: "sRGB"
                }, i.createElement("feFlood", {
                    floodOpacity: 0,
                    result: "BackgroundImageFix"
                }), i.createElement("feColorMatrix", { in: "SourceAlpha",
                    type: "matrix",
                    values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",
                    result: "hardAlpha"
                }), i.createElement("feOffset", {
                    dy: 4
                }), i.createElement("feGaussianBlur", {
                    stdDeviation: 2
                }), i.createElement("feComposite", {
                    in2: "hardAlpha",
                    operator: "out"
                }), i.createElement("feColorMatrix", {
                    type: "matrix",
                    values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.04 0"
                }), i.createElement("feBlend", {
                    mode: "normal",
                    in2: "BackgroundImageFix",
                    result: "effect1_dropShadow_226_2510"
                }), i.createElement("feBlend", {
                    mode: "normal",
                    in: "SourceGraphic",
                    in2: "effect1_dropShadow_226_2510",
                    result: "shape"
                })))))
            }
            const c = i.forwardRef(C),
                f = (r.p, c)
        }
    }
]);
//# sourceMappingURL=88201.7c1bdbe8.chunk.js.map