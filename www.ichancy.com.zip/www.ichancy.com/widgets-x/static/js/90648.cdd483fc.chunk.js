"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [90648], {
        390648: (e, t, s) => {
            s.d(t, {
                $P: () => _,
                Fh: () => F,
                G2: () => y,
                HU: () => n,
                JG: () => z,
                RS: () => O,
                Ss: () => S,
                UQ: () => v,
                XA: () => d,
                Zd: () => C,
                Zs: () => l,
                _X: () => j,
                aE: () => i,
                gd: () => G,
                iF: () => f,
                iO: () => c,
                im: () => b,
                jE: () => p,
                kH: () => h,
                kT: () => g,
                lV: () => L,
                mx: () => I,
                n4: () => m,
                pt: () => u,
                tK: () => T,
                td: () => w,
                vX: () => M,
                zF: () => E,
                zH: () => k
            });
            var a = s(280192),
                o = s(589415);
            const r = (0, s(534977).g)("sportData"),
                n = r("sport"),
                i = r("multipleSelections"),
                l = r("cashedSport"),
                p = r("cashedGame"),
                d = r("streamData"),
                m = r("streamChannels"),
                c = r("marketTypes"),
                u = r("marketType"),
                k = r("boostedOdds"),
                b = r("boostedOddsCalled"),
                h = r("hasTopLeagueGames"),
                O = r("streamDataLoading"),
                T = r("timeFilterOption"),
                v = r("timeFilterOptionObj"),
                y = r("scrollToGameId"),
                C = r("scrollToCompetitionId"),
                f = r("sportsList"),
                j = r("calendarMarketTypes"),
                M = r("calendarMarketType"),
                g = r("regionViewAllMarkets"),
                S = r("userNotifications"),
                z = r("calendarMarketInfoType"),
                E = r("gamesCount"),
                F = r("gamesByCompetitions"),
                G = r("tournamentSportIds"),
                I = r("coupons"),
                L = (0, a.Mz)([i], (e => {
                    let t = null;
                    if (e) {
                        const s = Object.values(e).map((e => e.Selections));
                        t = new Set, s.forEach((e => e.forEach((e => {
                            var s;
                            return null === (s = t) || void 0 === s ? void 0 : s.add(e.CompetitionId)
                        }))))
                    }
                    return t
                })),
                _ = (0, a.Mz)([k], (e => e && Object.keys(e).map((e => Number(e))))),
                w = (0, a.Mz)([k], (e => e && Object.keys(e).map((e => Number(e))).filter((t => Object.values(e[t]).some((e => {
                    let {
                        type: t
                    } = e;
                    return [o.j.ALL, o.j.PREMATCH].includes(t)
                }))))))
        }
    }
]);
//# sourceMappingURL=90648.cdd483fc.chunk.js.map