"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [83543, 26038, 39736], {
        976376: (e, n, t) => {
            t.d(n, {
                R: () => h
            });
            var o = t(908198),
                s = t.n(o),
                i = t(446987),
                a = t(365043),
                l = t(870905),
                r = t(282695),
                c = t(735905),
                u = t(626038),
                d = t(238605),
                m = t(123213),
                p = t(570579);
            const h = () => {
                const [e, n] = (0, a.useState)(!1), t = (0, u.N)(), {
                    t: o
                } = (0, l.B)(), {
                    loginCallback: h
                } = (0, r.S)({
                    rememberMe: !1,
                    password: null,
                    username: null
                });
                (0, a.useEffect)((() => {
                    var e;
                    null !== (e = window.median) && void 0 !== e && e.auth && window.median.auth.status({
                        callbackFunction: e => {
                            e && e.hasTouchId && e.hasSecret && n(!0)
                        }
                    })
                }), []);
                const g = () => {
                        var e;
                        null !== (e = window.median) && void 0 !== e && e.auth && (window.median.auth.delete(), n(!1))
                    },
                    A = (e, n) => {
                        var t;
                        null !== (t = window.median) && void 0 !== t && t.auth && (g(), window.median.auth.status({
                            callbackFunction: t => {
                                if (t && t.hasTouchId) {
                                    const t = JSON.stringify({
                                        username: e,
                                        password: n
                                    });
                                    window.median.auth.save({
                                        secret: t
                                    }), m.A.removeItem("isWrapperFirstLaunch")
                                }
                            },
                            prompt: "PROMPT"
                        }))
                    };
                return {
                    removeSecret: g,
                    loginWithFaceId: () => {
                        var e;
                        null !== (e = window.median) && void 0 !== e && e.auth && window.median.auth.status({
                            callbackFunction: e => {
                                e && e.hasTouchId && e.hasSecret && window.median.auth.get({
                                    callbackFunction: e => {
                                        if (e && e.success && e.secret) {
                                            const n = JSON.parse(e.secret),
                                                t = n.username,
                                                o = n.password;
                                            t && o && (0, i.iD)({
                                                username: t,
                                                password: o
                                            }, h)
                                        } else e && e.error, t()
                                    },
                                    callbackOnCancel: "true"
                                })
                            }
                        })
                    },
                    setCredentials: A,
                    credentialsExist: e,
                    showConfirmationPopup: (e, n) => {
                        var t;
                        null !== (t = window.median) && void 0 !== t && t.auth && window.median.auth.status({
                            callbackFunction: t => {
                                t && t.hasTouchId && s().alert((0, p.jsx)(c.GlobalIcon, {
                                    lib: "account",
                                    name: (0, d.Ri)("isIOSWrapperApp") ? "FaceId" : "Biometrics",
                                    theme: "default",
                                    size: 24
                                }), (0, d.Ri)("isIOSWrapperApp") ? o("account.faceIdConfirmationInfoIos") : o("account.faceIdConfirmationInfoAndroid"), [{
                                    text: o("account.cancel"),
                                    onPress: () => {}
                                }, {
                                    text: o("account.ok"),
                                    onPress: () => {
                                        A(e, n)
                                    }
                                }])
                            },
                            prompt: "PROMPT"
                        })
                    }
                }
            }
        },
        282695: (e, n, t) => {
            t.d(n, {
                S: () => P
            });
            var o = t(365043),
                s = t(507712),
                i = t(446987),
                a = t(117893),
                l = t(995392),
                r = t(701616),
                c = t(841591),
                u = t(124634),
                d = t(123213),
                m = t(49770),
                p = t(171224),
                h = t(596771),
                g = t(816343),
                A = t(179177),
                v = t(115837),
                _ = t(556785),
                S = t(954947),
                I = t(485138),
                y = t(849944),
                f = t(302258);
            const P = e => {
                let {
                    rememberMe: n,
                    userGroups: t
                } = e;
                const P = (0, o.useRef)(),
                    [b, T] = (0, o.useState)(!1),
                    [O, R] = (0, o.useState)(),
                    x = (0, s.wA)(),
                    N = (0, l.W6)(),
                    C = (0, s.d4)(c.h0),
                    E = null === C || void 0 === C ? void 0 : C.find((e => e && "personalId" === e.formType)),
                    w = () => {
                        d.A.setItem((0, _.U)("account", "AUTH_DATA"), JSON.stringify(P.current)), (0, i.wz)(k, j, "login", !1, !(null === E || void 0 === E || !E.editForm.showOnEditProfile || "2" !== E.editForm.personalIdType || "1" !== (null === E || void 0 === E ? void 0 : E.editForm.sendCPFAsDocNumber))), A.Ay.PUSH_NOTIFICATIONS_ENABLED && (0, u.f)()
                    },
                    {
                        updateUser: j
                    } = (0, v.Q)(),
                    k = e => {
                        var o;
                        (0, p.c)("loginCredentials", {
                            rememberMe: n,
                            userGroups: t || "",
                            jwe_token: (null === P || void 0 === P || null === (o = P.current) || void 0 === o ? void 0 : o.jwe_token) || ""
                        }), x((0, a.sX7)({ ...e,
                            last_login_date: e.last_login_date || Math.floor((new Date).getTime() / 1e3)
                        })), x((0, a.hB6)(60 * (e.session_duration || 0))), e.active_time_in_casino && m.A.setItem((0, _.U)("account", "ACTIVE_TIME_IN_CASINO"), `${e.active_time_in_casino}`);
                        const s = h.y.getAfterSignIn();
                        "function" === typeof s ? (h.y.setAfterSignIn(null), (0, g.XZ)(), s()) : (x((0, a.Xz$)(!e.is_verified)), N.push((0, g.XZ)())), x((0, a.VoE)(!0)), d.A.setItem((0, _.U)("account", "PARENT_ACCOUNT_CURRENCY"), e.currency), (0, p.c)("sbuser", {
                            rememberMe: n,
                            userGroups: t && t || ""
                        }, 15), window.refreshWhenLoggedIn && (N.push((0, g.oR)({
                            accounts: void 0,
                            login: void 0
                        })), window.mustRefreshForSessionVisibility = !0, window.location.reload())
                    };
                return {
                    loginCallback: e => {
                        const {
                            auth_token: n,
                            user_id: t,
                            qr_code_origin: o,
                            authentication_status: s,
                            jwe_token: i
                        } = e;
                        if (P.current = {
                                auth_token: n,
                                user_id: t,
                                qr_code_origin: o,
                                jwe_token: i
                            }, 4 === s) return T(!0), void R(o);
                        A.Ay.ADD_INFO_AFTER_LOGIN && x((0, r.rY)(!0)), (0, S.A)(), w(), (0, I.y)({
                            type: "userId",
                            value: e.user_id
                        }), window.popupIframe && window.parent.postMessage({
                            action: "login",
                            credentials: {
                                auth_token: e.auth_token,
                                user_id: e.user_id
                            }
                        }, "*"), A.Ay.IFRAME_SPORTSBOOK && (0, y.$i)("loggedIn"), A.Ay.LOGIN_LIMIT_POPUP && (0, f.as)()
                    },
                    updateAuthData: w,
                    isTwoFactorPopupVisible: b,
                    qrCodeOrigin: O
                }
            }
        },
        441090: (e, n, t) => {
            t.d(n, {
                P: () => _
            });
            var o = t(365043),
                s = t(507712),
                i = t(307022),
                a = t(679559),
                l = t(841591),
                r = t(462956),
                c = t(500223),
                u = t(701616),
                d = t(737536),
                m = t(55418),
                p = t(179177),
                h = t(626038),
                g = t(123213),
                A = t(556785),
                v = t(925699);
            const _ = () => {
                const e = (0, s.wA)(),
                    n = (0, h.N)(),
                    t = (0, s.d4)(a._r),
                    _ = (0, s.d4)(l.t9),
                    S = (0, s.d4)(r.Ot),
                    [I, y] = (0, o.useState)(!0),
                    f = (0, o.useMemo)((() => t.sendGeoToken), [t.sendGeoToken]),
                    P = (0, o.useMemo)((() => t.action), [t.action]);
                (0, o.useEffect)((() => {
                    S && O()
                }), [S]), (0, o.useEffect)((() => {
                    P ? (O(), b()) : t.popupType ? b() : I && T()
                }), [P, t.popupType]);
                const b = (0, o.useCallback)((() => {
                        t.checkInterval && (clearInterval(t.checkInterval), (0, i.$S)({
                            checkInterval: 0
                        }))
                    }), [t.checkInterval]),
                    T = (0, o.useCallback)((() => {
                        if (!t.checkInterval) {
                            const n = setInterval((() => {
                                O()
                            }), 60 * p.Ay.GPS_TRACKING_CHECKING_INTERVAL * 1e3);
                            e((0, i.$S)({
                                checkInterval: n
                            }))
                        }
                    }), [t.checkInterval]);
                (0, o.useEffect)((() => {
                    var n;
                    _ && (v.A.geolocationWindow && (v.A.geolocationWindow.close(), v.A.geolocationWindow = null), "confirm_geo_token" !== _ ? e((0, i.$S)({
                        popupType: "shakeError"
                    })) : (null === (n = t.validateGeoRestrictionSuccessCallback) || void 0 === n || n.call(t), e((0, u.p1)(null)), e((0, i.fk)())))
                }), [_]);
                const O = (0, o.useCallback)((() => {
                        navigator.geolocation.getCurrentPosition(x, R, {
                            enableHighAccuracy: !0,
                            timeout: 5e3,
                            maximumAge: 0
                        })
                    }), [t]),
                    R = (0, o.useCallback)((() => {
                        e((0, i.$S)({
                            popupType: "error"
                        }))
                    }), []),
                    x = (0, o.useCallback)((e => {
                        const n = e.coords;
                        N(n.latitude, n.longitude)
                    }), [t]),
                    N = (0, o.useCallback)(((n, o) => {
                        const s = {
                            lat: n,
                            lng: o
                        };
                        t.popupType || t.loadingValidateGeoRestriction || (e((0, i.$S)({
                            loadingValidateGeoRestriction: !0
                        })), (0, c.qE)(d.y.VALIDATE_GEO_RESTRICTION, s, E, null, (n => {
                            k(n), e((0, i.$S)({
                                loadingValidateGeoRestriction: !1
                            }))
                        })))
                    }), [t]),
                    C = (0, o.useCallback)((() => {
                        !!JSON.parse(g.A.getItem((0, A.U)("account", "AUTH_DATA"))) && n()
                    }), []),
                    E = (0, o.useCallback)((n => {
                        e((0, i.$S)({
                            loadingValidateGeoRestriction: !1
                        })), n.result ? f && P && w() : e((0, i.$S)({
                            popupType: "error"
                        }))
                    }), [t]),
                    w = (0, o.useCallback)((() => {
                        t.loadingGetGeoToken || (e((0, i.$S)({
                            loadingGetGeoToken: !0
                        })), (0, c.qE)(d.y.GET_GEO_TOKEN, {
                            action: P
                        }, j, null, (n => {
                            k(n), e((0, i.$S)({
                                loadingGetGeoToken: !1
                            }))
                        })))
                    }), [t]),
                    j = (0, o.useCallback)((n => {
                        if (e((0, i.$S)({
                                loadingGetGeoToken: !1
                            })), 0 === n.result) {
                            const t = `${p.Ay.GPS_TRACKING_URL}/?token=${n.details.token}&language=eng&geoDataWriteInterval=50&geoDataListenDuration=20000&siteId=${p.Ay.PARTNER_ID}&websocketUrl=${p.Ay.SWARM_URL}`;
                            (0, m.F)() ? e((0, i.$S)({
                                popupType: "confirm",
                                trackingLink: t
                            })): e((0, i.$S)({
                                popupType: "qr-popup",
                                trackingLink: t,
                                trackingDuration: n.details.duration
                            }))
                        } else k(n)
                    }), [t]),
                    k = (0, o.useCallback)((function() {
                        var n;
                        let o = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null;
                        C(), null === (n = t.validateGeoRestrictionCancelCallback) || void 0 === n || n.call(t), o ? (y(!1), e((0, i.$S)({
                            popupType: "error",
                            errorPopupTitle: o.msg,
                            errorPopupMsg: o.data
                        }))) : (T(), e((0, i.fk)()))
                    }), [t]);
                return {
                    popupType: t.popupType,
                    checkLocation: O,
                    gpsLogout: C
                }
            }
        },
        796487: (e, n, t) => {
            t.r(n), t.d(n, {
                Accounts: () => ln
            });
            var o = t(365043),
                s = t(507712),
                i = t(889181),
                a = t(679559),
                l = t(841591),
                r = t(307022),
                c = t(701616),
                u = t(550736),
                d = t(462956),
                m = t(322908),
                p = t.n(m),
                h = t(870905),
                g = t(995392),
                A = t(117893),
                v = t(285275),
                _ = t(989618),
                S = t(816343),
                I = t(446987),
                y = t(320308),
                f = t(123213),
                P = t(556785),
                b = t(238605);
            const T = () => {
                const [e, n] = (0, o.useState)(null), {
                    t: t
                } = (0, h.B)(), i = (0, s.wA)(), c = (0, g.W6)(), u = (0, s.d4)(a.eP), d = (0, s.d4)(a.DG), {
                    last_login_date: m
                } = (0, s.d4)(a.wz), A = (0, s.d4)(l.JL);
                (0, o.useEffect)((() => {
                    var o, s;
                    if (A && !(null !== A && void 0 !== A && null !== (o = A.myProfile) && void 0 !== o && null !== (s = o.find((e => "loginLimit" === (null === e || void 0 === e ? void 0 : e.formType)))) && void 0 !== s && s.hidden) && u && d && m) {
                        const e = f.A.getItem((0, P.U)("account", "LOGIN_LIMIT_START_TIME"));
                        n(setTimeout((() => {
                            (0, I.ri)((() => {
                                (() => {
                                    i((0, r.Sl)()), i((0, r.XO)(null)), (0, b.Yj)("loginCredentials");
                                    const {
                                        accounts: e
                                    } = p().parse(window.location.search, {
                                        ignoreQueryPrefix: !0
                                    });
                                    e && c.push((0, S.XZ)())
                                })(), (0, y.$)(t("account.sessionExpired"))
                            }))
                        }), "null" !== e ? +e : 1e3 * m + 1e3 * d - (new Date).getTime()))
                    }
                    return () => {
                        e && (clearTimeout(e), n(null))
                    }
                }), [u, d, m, A])
            };
            var O = t(702044),
                R = t(393738),
                x = t(179177),
                N = t(55418),
                C = t(839736),
                E = t(384716),
                w = t(123343),
                j = t(596771),
                k = t(570579);
            const {
                MobileLayout: F
            } = (0, _.R)((() => Promise.all([t.e(70990), t.e(75558), t.e(46749)]).then(t.bind(t, 312388)))), {
                DesktopLayout: M
            } = (0, _.R)((() => Promise.all([t.e(99701), t.e(22093), t.e(45375), t.e(76481), t.e(90363), t.e(15243), t.e(85123), t.e(22491), t.e(82363), t.e(89691), t.e(31528), t.e(9297), t.e(36273), t.e(61579), t.e(70289), t.e(80192), t.e(36046), t.e(61190), t.e(87154), t.e(40999), t.e(24541), t.e(83753), t.e(38686), t.e(52056), t.e(88397), t.e(40763), t.e(71103)]).then(t.bind(t, 126246)))), U = e => {
                const n = (0, g.W6)(),
                    t = (0, s.wA)(),
                    i = (0, s.d4)(l.gh),
                    a = (0, s.d4)(l.yX),
                    {
                        register: u
                    } = (0, E.o)(),
                    d = (0, o.useCallback)((() => {
                        if (a && t((0, c.qp)(!1)), u && Number(null === i || void 0 === i ? void 0 : i.exitConfirmPopup)) t((0, r.D3)(!0));
                        else {
                            const e = (0, S.XZ)();
                            if (e.includes("accounts=") && !e.includes("login=")) return void n.push((0, S.oR)({
                                accounts: void 0,
                                login: void 0
                            }));
                            e === `${n.location.pathname}${n.location.search}` ? n.push(n.location.pathname) : n.push(e), x.Ay.POSTGRID_API_KEY && t((0, c.W0)()), t((0, r.bP)(null))
                        }
                        j.y.setAfterSignIn(null)
                    }), [i, u, a]);
                return (0, k.jsxs)(C.xZ, {
                    children: [(0, N.F)() && (0, k.jsx)(o.Suspense, {
                        fallback: (0, k.jsx)(w.R, {}),
                        children: (0, k.jsx)(F, {
                            closeModal: d,
                            children: e.children
                        })
                    }), !(0, N.F)() && (0, k.jsx)(o.Suspense, {
                        fallback: null,
                        children: (0, k.jsx)(M, {
                            closeModal: d,
                            children: e.children
                        })
                    })]
                })
            }, {
                Login: D
            } = (0, _.R)((() => Promise.all([t.e(80192), t.e(51238), t.e(73549), t.e(40999), t.e(14971), t.e(56982), t.e(62519), t.e(96966)]).then(t.bind(t, 112716)))), {
                Wallet: L
            } = (0, _.R)((() => Promise.all([t.e(80192), t.e(61190), t.e(85762), t.e(82463), t.e(96660)]).then(t.bind(t, 245618)))), {
                ProfilePreview: B
            } = (0, _.R)((() => Promise.all([t.e(85762), t.e(58138)]).then(t.bind(t, 495664)))), {
                Register: W
            } = (0, _.R)((() => Promise.all([t.e(99701), t.e(22093), t.e(45375), t.e(99989), t.e(76481), t.e(75634), t.e(90363), t.e(15243), t.e(20509), t.e(77484), t.e(34519), t.e(73157), t.e(12967), t.e(74027), t.e(66399), t.e(46203), t.e(10985), t.e(58171), t.e(539), t.e(49115), t.e(31528), t.e(9297), t.e(36273), t.e(61579), t.e(70289), t.e(18574), t.e(80192), t.e(51238), t.e(31437), t.e(34885), t.e(96884), t.e(53167), t.e(13398), t.e(86773), t.e(17457), t.e(61190), t.e(98224)]).then(t.bind(t, 677261)))), {
                Messages: $
            } = (0, _.R)((() => Promise.all([t.e(99701), t.e(22093), t.e(45375), t.e(99989), t.e(76481), t.e(75634), t.e(90363), t.e(20509), t.e(77484), t.e(74027), t.e(31528), t.e(9297), t.e(36273), t.e(61579), t.e(70289), t.e(18574), t.e(80192), t.e(51238), t.e(31437), t.e(57008), t.e(82675), t.e(69478), t.e(73549), t.e(40999), t.e(14971), t.e(85762), t.e(17366), t.e(45905)]).then(t.bind(t, 284014)))), {
                NewPassword: G
            } = (0, _.R)((() => Promise.all([t.e(85762), t.e(56982), t.e(19935)]).then(t.bind(t, 383490)))), {
                BonusIframe: V
            } = (0, _.R)((() => Promise.all([t.e(85762), t.e(78395), t.e(37053), t.e(63354), t.e(38629)]).then(t.bind(t, 454530)))), {
                BonusesMenu: H
            } = (0, _.R)((() => Promise.all([t.e(99701), t.e(82363), t.e(38686), t.e(88397), t.e(40763), t.e(66408)]).then(t.bind(t, 305644)))), {
                Settings: q
            } = (0, _.R)((() => Promise.all([t.e(99701), t.e(82363), t.e(38686), t.e(88397), t.e(26472)]).then(t.bind(t, 103764)))), {
                MyCards: J
            } = (0, _.R)((() => Promise.all([t.e(68843), t.e(80192), t.e(51238), t.e(46179), t.e(73549), t.e(87154), t.e(40999), t.e(14971), t.e(10251)]).then(t.bind(t, 838930)))), {
                Bonuses: K
            } = (0, _.R)((() => Promise.all([t.e(99701), t.e(22093), t.e(45375), t.e(99989), t.e(76481), t.e(90363), t.e(77484), t.e(74027), t.e(31528), t.e(9297), t.e(36273), t.e(61579), t.e(69478), t.e(85762), t.e(44400)]).then(t.bind(t, 950642)))), {
                LoyaltyPoints: Y
            } = (0, _.R)((() => Promise.all([t.e(99989), t.e(75634), t.e(34519), t.e(31528), t.e(70289), t.e(18574), t.e(31437), t.e(34885), t.e(81643), t.e(58073), t.e(85762), t.e(27989), t.e(78395), t.e(37053), t.e(63354), t.e(46035), t.e(71533), t.e(89947), t.e(5649)]).then(t.bind(t, 521627)))), {
                Rewards: z
            } = (0, _.R)((() => Promise.all([t.e(99989), t.e(75634), t.e(20509), t.e(9297), t.e(70289), t.e(18574), t.e(80192), t.e(51238), t.e(31437), t.e(57008), t.e(82675), t.e(73549), t.e(87154), t.e(40999), t.e(14971), t.e(85762), t.e(16199), t.e(16801)]).then(t.bind(t, 526459)))), {
                ForgotPassword: X
            } = (0, _.R)((() => Promise.all([t.e(99701), t.e(22093), t.e(45375), t.e(99989), t.e(76481), t.e(75634), t.e(90363), t.e(20509), t.e(77484), t.e(34519), t.e(74027), t.e(31528), t.e(9297), t.e(36273), t.e(61579), t.e(70289), t.e(18574), t.e(80192), t.e(51238), t.e(31437), t.e(34885), t.e(81643), t.e(57008), t.e(82675), t.e(69478), t.e(86773), t.e(73549), t.e(40999), t.e(14971), t.e(31100)]).then(t.bind(t, 397980)))), {
                BalanceHistoryPage: Q
            } = (0, _.R)((() => Promise.all([t.e(85762), t.e(87939)]).then(t.bind(t, 3742)))), {
                AccountStakeAndEarn: Z
            } = (0, _.R)((() => Promise.all([t.e(85762), t.e(80856)]).then(t.bind(t, 26853)))), {
                Limits: ee
            } = (0, _.R)((() => Promise.all([t.e(78395), t.e(37053), t.e(63354), t.e(58673)]).then(t.bind(t, 35608)))), {
                Statement: ne
            } = (0, _.R)((() => Promise.all([t.e(58073), t.e(85762), t.e(74225)]).then(t.bind(t, 794552)))), {
                CustomerJourneyLayout: te
            } = (0, _.R)((() => Promise.all([t.e(99701), t.e(22093), t.e(45375), t.e(76481), t.e(66399), t.e(31528), t.e(9297), t.e(36273), t.e(61579), t.e(17522), t.e(78395), t.e(37053), t.e(63354), t.e(40864)]).then(t.bind(t, 755134)))), {
                TimeOut: oe
            } = (0, _.R)((() => Promise.all([t.e(99701), t.e(22093), t.e(45375), t.e(99989), t.e(76481), t.e(75634), t.e(90363), t.e(15243), t.e(20509), t.e(85123), t.e(77484), t.e(82685), t.e(34519), t.e(74027), t.e(11216), t.e(23973), t.e(31528), t.e(9297), t.e(36273), t.e(61579), t.e(70289), t.e(18574), t.e(80192), t.e(51238), t.e(31437), t.e(34885), t.e(81643), t.e(57008), t.e(82675), t.e(16998)]).then(t.bind(t, 888158)))), {
                GamStop: se
            } = (0, _.R)((() => Promise.all([t.e(85762), t.e(33326)]).then(t.bind(t, 964974)))), {
                ReferFriend: ie
            } = (0, _.R)((() => Promise.all([t.e(99701), t.e(22093), t.e(45375), t.e(90363), t.e(15243), t.e(85123), t.e(22491), t.e(89691), t.e(31528), t.e(9297), t.e(36273), t.e(61579), t.e(70289), t.e(51238), t.e(36046), t.e(75270), t.e(37053), t.e(91485), t.e(82474)]).then(t.bind(t, 976884)))), {
                LoginLimit: ae
            } = (0, _.R)((() => Promise.all([t.e(99701), t.e(22093), t.e(45375), t.e(99989), t.e(76481), t.e(75634), t.e(90363), t.e(15243), t.e(85123), t.e(77484), t.e(82685), t.e(34519), t.e(74027), t.e(11216), t.e(23973), t.e(31528), t.e(9297), t.e(36273), t.e(61579), t.e(70289), t.e(18574), t.e(31437), t.e(34885), t.e(81643), t.e(69478), t.e(87154), t.e(27989), t.e(37053), t.e(17366), t.e(72258)]).then(t.bind(t, 341397)))), {
                BetingHistoryLayout: le
            } = (0, _.R)((() => Promise.all([t.e(99701), t.e(22093), t.e(45375), t.e(99989), t.e(76481), t.e(75634), t.e(90363), t.e(20509), t.e(77484), t.e(74027), t.e(31528), t.e(9297), t.e(36273), t.e(61579), t.e(70289), t.e(18574), t.e(80192), t.e(51238), t.e(31437), t.e(57008), t.e(82675), t.e(69478), t.e(73549), t.e(40999), t.e(24757), t.e(14971), t.e(85762), t.e(78395), t.e(63354), t.e(42411)]).then(t.bind(t, 37147)))), {
                RealityCheck: re
            } = (0, _.R)((() => Promise.all([t.e(99701), t.e(22093), t.e(45375), t.e(99989), t.e(76481), t.e(75634), t.e(90363), t.e(15243), t.e(20509), t.e(85123), t.e(77484), t.e(82685), t.e(34519), t.e(74027), t.e(11216), t.e(23973), t.e(31528), t.e(9297), t.e(36273), t.e(61579), t.e(70289), t.e(18574), t.e(80192), t.e(51238), t.e(31437), t.e(34885), t.e(81643), t.e(57008), t.e(82675), t.e(41112)]).then(t.bind(t, 808272)))), {
                ProfileEdit: ce
            } = (0, _.R)((() => Promise.all([t.e(99701), t.e(22093), t.e(45375), t.e(99989), t.e(76481), t.e(75634), t.e(90363), t.e(15243), t.e(20509), t.e(77484), t.e(34519), t.e(73157), t.e(12967), t.e(74027), t.e(66399), t.e(46203), t.e(10985), t.e(58171), t.e(539), t.e(49115), t.e(31528), t.e(9297), t.e(36273), t.e(61579), t.e(70289), t.e(18574), t.e(80192), t.e(51238), t.e(31437), t.e(34885), t.e(96884), t.e(13398), t.e(86773), t.e(17457), t.e(61190), t.e(29600)]).then(t.bind(t, 643454)))), {
                SelfExclusion: ue
            } = (0, _.R)((() => Promise.all([t.e(99701), t.e(22093), t.e(45375), t.e(99989), t.e(76481), t.e(75634), t.e(90363), t.e(15243), t.e(20509), t.e(85123), t.e(77484), t.e(82685), t.e(34519), t.e(74027), t.e(11216), t.e(23973), t.e(31528), t.e(9297), t.e(36273), t.e(61579), t.e(70289), t.e(18574), t.e(80192), t.e(51238), t.e(31437), t.e(34885), t.e(81643), t.e(57008), t.e(82675), t.e(91816)]).then(t.bind(t, 755836)))), {
                NotificationSettings: de
            } = (0, _.R)((() => Promise.all([t.e(99701), t.e(22093), t.e(45375), t.e(99989), t.e(76481), t.e(75634), t.e(90363), t.e(20509), t.e(77484), t.e(74027), t.e(31528), t.e(9297), t.e(36273), t.e(61579), t.e(70289), t.e(18574), t.e(80192), t.e(51238), t.e(31437), t.e(57008), t.e(82675), t.e(69478), t.e(73549), t.e(87154), t.e(40999), t.e(14971), t.e(85762), t.e(37053), t.e(77957), t.e(52891)]).then(t.bind(t, 343095)))), {
                AccountStatus: me
            } = (0, _.R)((() => Promise.all([t.e(99989), t.e(75634), t.e(20509), t.e(34519), t.e(31528), t.e(9297), t.e(70289), t.e(18574), t.e(31437), t.e(34885), t.e(81643), t.e(57008), t.e(82675), t.e(27989), t.e(37053), t.e(72837), t.e(81343)]).then(t.bind(t, 557553)))), {
                ChangePassword: pe
            } = (0, _.R)((() => Promise.all([t.e(99701), t.e(22093), t.e(45375), t.e(99989), t.e(76481), t.e(75634), t.e(90363), t.e(15243), t.e(20509), t.e(85123), t.e(77484), t.e(82685), t.e(74027), t.e(11216), t.e(23973), t.e(31528), t.e(9297), t.e(36273), t.e(61579), t.e(70289), t.e(18574), t.e(80192), t.e(51238), t.e(31437), t.e(57008), t.e(82675), t.e(69478), t.e(73549), t.e(40999), t.e(82777)]).then(t.bind(t, 947809)))), {
                MySessions: he
            } = (0, _.R)((() => Promise.all([t.e(85762), t.e(26724)]).then(t.bind(t, 924450)))), {
                BonusManagement: ge
            } = (0, _.R)((() => Promise.all([t.e(85762), t.e(35216)]).then(t.bind(t, 505082)))), {
                Documents: Ae
            } = (0, _.R)((() => Promise.all([t.e(99701), t.e(22093), t.e(45375), t.e(99989), t.e(76481), t.e(90363), t.e(77484), t.e(74027), t.e(66266), t.e(18675), t.e(31528), t.e(9297), t.e(36273), t.e(61579), t.e(57008), t.e(69478), t.e(60503), t.e(48484), t.e(98419), t.e(87751), t.e(85762), t.e(47953)]).then(t.bind(t, 47473)))), {
                AccumulatedProfit: ve
            } = (0, _.R)((() => Promise.all([t.e(85762), t.e(55671)]).then(t.bind(t, 150687)))), {
                VerifyAccount: _e
            } = (0, _.R)((() => Promise.all([t.e(99701), t.e(22093), t.e(45375), t.e(99989), t.e(76481), t.e(90363), t.e(77484), t.e(74027), t.e(31528), t.e(9297), t.e(36273), t.e(61579), t.e(69478), t.e(85762), t.e(35420)]).then(t.bind(t, 711739)))), {
                TwoFactorAuth: Se
            } = (0, _.R)((() => Promise.all([t.e(99701), t.e(22093), t.e(45375), t.e(99989), t.e(76481), t.e(75634), t.e(90363), t.e(15243), t.e(20509), t.e(85123), t.e(77484), t.e(82685), t.e(74027), t.e(11216), t.e(23973), t.e(31528), t.e(9297), t.e(36273), t.e(61579), t.e(70289), t.e(18574), t.e(80192), t.e(51238), t.e(31437), t.e(57008), t.e(82675), t.e(69478), t.e(75270), t.e(46807), t.e(9259)]).then(t.bind(t, 801414)))), {
                SaferGambling: Ie
            } = (0, _.R)((() => Promise.all([t.e(37053), t.e(40908)]).then(t.bind(t, 716460)))), {
                CurrentSession: ye
            } = (0, _.R)((() => Promise.all([t.e(99701), t.e(22093), t.e(45375), t.e(99989), t.e(76481), t.e(75634), t.e(90363), t.e(15243), t.e(20509), t.e(85123), t.e(34519), t.e(73157), t.e(12967), t.e(77499), t.e(31139), t.e(6995), t.e(46203), t.e(25029), t.e(66266), t.e(66649), t.e(31528), t.e(9297), t.e(36273), t.e(61579), t.e(70289), t.e(18574), t.e(31437), t.e(34885), t.e(81643), t.e(11115), t.e(94938), t.e(57811), t.e(61190), t.e(37427)]).then(t.bind(t, 285430)))), {
                AvailabilityPeriod: fe
            } = (0, _.R)((() => Promise.all([t.e(99989), t.e(75634), t.e(20509), t.e(34519), t.e(31528), t.e(9297), t.e(70289), t.e(18574), t.e(80192), t.e(51238), t.e(31437), t.e(34885), t.e(81643), t.e(57008), t.e(82675), t.e(73549), t.e(87154), t.e(40999), t.e(14971), t.e(85762), t.e(42828), t.e(27989), t.e(37053), t.e(77957), t.e(89947), t.e(54210)]).then(t.bind(t, 216322)))), {
                ForgotUsername: Pe
            } = (0, _.R)((() => Promise.all([t.e(99701), t.e(22093), t.e(45375), t.e(99989), t.e(76481), t.e(75634), t.e(90363), t.e(20509), t.e(77484), t.e(34519), t.e(74027), t.e(31528), t.e(9297), t.e(36273), t.e(61579), t.e(70289), t.e(18574), t.e(80192), t.e(51238), t.e(31437), t.e(34885), t.e(81643), t.e(57008), t.e(82675), t.e(69478), t.e(86773), t.e(73549), t.e(40999), t.e(14971), t.e(88271)]).then(t.bind(t, 787139)))), be = e => {
                const n = (0, g.W6)(),
                    t = (0, s.d4)(a.wz),
                    i = (0, s.d4)(a.eP),
                    r = (0, s.d4)(l.JL),
                    c = e => {
                        var n;
                        return !(null === r || void 0 === r || !r.myProfile) && !(null !== (n = r.myProfile.find((n => n.sectionType === e))) && void 0 !== n && n.hidden)
                    },
                    u = (0, o.useCallback)((() => {
                        n.push((0, S.oR)({
                            accounts: "*",
                            settings: "*",
                            profile: "*"
                        }))
                    }), []);
                return t.pending || i && (null === r || void 0 === r || !r.myProfile) ? null : (0, k.jsx)(U, {
                    children: (0, k.jsxs)(o.Suspense, {
                        fallback: (0, k.jsx)(w.R, {}),
                        children: [(0, k.jsx)(S.Wy, {
                            includes: ["accounts", "login"],
                            shouldMount: () => !i && e.signInBtn,
                            onCatch: () => n.push((0, S.oR)({
                                accounts: void 0,
                                login: void 0
                            })),
                            excludes: [],
                            render: () => (0, k.jsx)(D, {
                                accountNextButtonStyle: e.accountNextButtonStyle,
                                signInBtn: e.signInBtn,
                                signUpBtn: e.signUpBtn
                            })
                        }), (0, k.jsx)(S.Wy, {
                            includes: ["accounts", "forgot-password"],
                            excludes: [],
                            component: X
                        }), (0, k.jsx)(S.Wy, {
                            includes: ["accounts", "forgot-username"],
                            excludes: [],
                            component: Pe
                        }), (0, k.jsx)(S.Wy, {
                            includes: ["accounts", "reset-password"],
                            excludes: [],
                            component: G
                        }), (0, k.jsx)(S.Wy, {
                            includes: ["accounts", "register"],
                            excludes: [],
                            shouldMount: () => !i && e.signUpBtn,
                            onCatch: () => n.push((0, S.oR)({
                                accounts: void 0,
                                register: void 0
                            })),
                            render: () => (0, k.jsx)(W, {
                                setVisible: e.setVisible,
                                accountSignUpButtonStyle: e.accountSignUpButtonStyle,
                                accountNextButtonStyle: e.accountNextButtonStyle,
                                accountPrevButtonStyle: e.accountPrevButtonStyle,
                                signInBtn: e.signInBtn,
                                signUpBtn: e.signUpBtn
                            })
                        }), (0, k.jsx)(S.Wy, {
                            includes: ["accounts", "profile"],
                            excludes: ["settings"],
                            component: B,
                            auth: !0
                        }), (0, k.jsx)(S.Wy, {
                            includes: ["accounts", "settings", "profile"],
                            excludes: [],
                            component: ce,
                            auth: !0
                        }), (0, k.jsx)(S.Wy, {
                            includes: ["accounts", "settings", "menu"],
                            excludes: [],
                            component: q,
                            auth: !0
                        }), (0, k.jsx)(S.Wy, {
                            includes: ["accounts", "settings", "password"],
                            excludes: [],
                            component: pe,
                            auth: !0
                        }), (0, k.jsx)(S.Wy, {
                            includes: ["accounts", "settings", "limits"],
                            excludes: [],
                            component: ee,
                            auth: !0,
                            shouldMount: () => c("tabBetLimit"),
                            onCatch: u
                        }), (0, k.jsx)(S.Wy, {
                            includes: ["accounts", "bonuses", "menu"],
                            excludes: [],
                            component: H,
                            auth: !0
                        }), (0, k.jsx)(S.Wy, {
                            includes: ["accounts", "bonuses", "bonus"],
                            excludes: [],
                            component: K,
                            auth: !0
                        }), (0, k.jsx)(S.Wy, {
                            includes: ["accounts", "bonuses", "refer-friend"],
                            excludes: [],
                            component: ie,
                            auth: !0
                        }), (0, k.jsx)(S.Wy, {
                            includes: ["accounts", "bonuses", "management"],
                            excludes: [],
                            component: ge,
                            auth: !0
                        }), (0, k.jsx)(S.Wy, {
                            includes: ["accounts", "bonus-iframe"],
                            excludes: [],
                            component: V,
                            auth: !0
                        }), (0, k.jsx)(S.Wy, {
                            includes: ["accounts", "loyalty-points"],
                            excludes: [],
                            component: Y,
                            auth: !0
                        }), (0, k.jsx)(S.Wy, {
                            includes: ["accounts", "rewards"],
                            excludes: [],
                            component: z,
                            auth: !0
                        }), (0, k.jsx)(S.Wy, {
                            includes: ["accounts", "settings", "gamstop"],
                            excludes: [],
                            component: se,
                            auth: !0,
                            shouldMount: () => c("tabGamstop"),
                            onCatch: u
                        }), (0, k.jsx)(S.Wy, {
                            includes: ["accounts", "settings", "accumulated-profit"],
                            excludes: [],
                            component: ve,
                            auth: !0
                        }), (0, k.jsx)(S.Wy, {
                            includes: ["accounts", "settings", "reality-check"],
                            excludes: [],
                            component: re,
                            auth: !0
                        }), (0, k.jsx)(S.Wy, {
                            includes: ["accounts", "settings", "login-limit"],
                            excludes: [],
                            component: ae,
                            auth: !0,
                            shouldMount: () => c("loginLimit"),
                            onCatch: u
                        }), x.Ay.SHOW_ACCOUNT_SESSION && (0, k.jsx)(S.Wy, {
                            includes: ["accounts", "settings", "session-information"],
                            excludes: [],
                            component: ye,
                            auth: !0
                        }), (0, k.jsx)(S.Wy, {
                            includes: ["accounts", "settings", "safer-gambling"],
                            excludes: [],
                            component: Ie,
                            auth: !0,
                            shouldMount: () => c("saferGambling"),
                            onCatch: u
                        }), (0, k.jsx)(S.Wy, {
                            includes: ["accounts", "settings", "availability-period"],
                            excludes: [],
                            component: fe,
                            auth: !0,
                            shouldMount: () => c("availability-period"),
                            onCatch: u
                        }), (0, k.jsx)(S.Wy, {
                            includes: ["accounts", "settings", "sessions"],
                            excludes: [],
                            component: he,
                            auth: !0,
                            shouldMount: () => c("current-session-info"),
                            onCatch: u
                        }), (0, k.jsx)(S.Wy, {
                            includes: ["accounts", "settings", "notification-settings"],
                            excludes: [],
                            component: de,
                            auth: !0,
                            shouldMount: () => c("tabNotifications"),
                            onCatch: u
                        }), (0, k.jsx)(S.Wy, {
                            includes: ["accounts", "settings", "timeout"],
                            excludes: [],
                            component: oe,
                            auth: !0,
                            shouldMount: () => c("tabTimeOut"),
                            onCatch: u
                        }), (0, k.jsx)(S.Wy, {
                            includes: ["accounts", "settings", "account-status"],
                            excludes: [],
                            component: me,
                            auth: !0
                        }), (0, k.jsx)(S.Wy, {
                            includes: ["accounts", "settings", "self-exclusion"],
                            excludes: [],
                            component: ue,
                            auth: !0,
                            shouldMount: () => c("tabSelfExclusion"),
                            onCatch: u
                        }), (0, k.jsx)(S.Wy, {
                            includes: ["accounts", "settings", "documents"],
                            excludes: [],
                            component: Ae,
                            auth: !0,
                            shouldMount: () => c("tabDocuments"),
                            onCatch: u
                        }), (0, k.jsx)(S.Wy, {
                            includes: ["accounts", "settings", "verify-account"],
                            excludes: [],
                            component: _e,
                            auth: !0,
                            shouldMount: () => c("tabVerifyAccount"),
                            onCatch: u
                        }), (0, k.jsx)(S.Wy, {
                            includes: ["accounts", "bet-history"],
                            excludes: [],
                            component: le,
                            auth: !0
                        }), (0, k.jsx)(S.Wy, {
                            includes: ["accounts", "stake-and-earn"],
                            excludes: [],
                            component: !(0, N.F)() && Z,
                            auth: !0
                        }), (0, k.jsx)(S.Wy, {
                            includes: ["accounts", "balance-history"],
                            excludes: [],
                            component: Q,
                            auth: !0
                        }), (0, k.jsx)(S.Wy, {
                            includes: ["accounts", "my-cards"],
                            excludes: [],
                            component: J,
                            auth: !0
                        }), (0, k.jsx)(S.Wy, {
                            includes: ["accounts", "statement"],
                            excludes: [],
                            component: ne,
                            auth: !0
                        }), (0, k.jsx)(S.Wy, {
                            includes: ["accounts", "two-factor-auth"],
                            excludes: [],
                            component: Se,
                            auth: !0,
                            shouldMount: () => c("twoFactorAuthentication"),
                            onCatch: u
                        }), (0, k.jsx)(S.Wy, {
                            includes: ["accounts", "wallet"],
                            excludes: [],
                            auth: !0,
                            render: e => (0, k.jsx)(L, {}, e.location.search)
                        }), (0, k.jsx)(S.Wy, {
                            includes: ["accounts", "messages"],
                            excludes: [],
                            component: $,
                            auth: !0
                        }), (0, k.jsx)(S.Wy, {
                            includes: ["accounts", "journey"],
                            excludes: [],
                            component: te,
                            auth: !0
                        })]
                    })
                })
            };
            var Te = t(177859),
                Oe = t(855606);
            var Re = t(626038),
                xe = t(441090);
            const {
                GpsTrackingPopup: Ne
            } = (0, _.R)((() => Promise.all([t.e(80192), t.e(51238), t.e(73549), t.e(87154), t.e(40999), t.e(14971), t.e(8856)]).then(t.bind(t, 367467)))), Ce = (0, o.memo)((() => (0, xe.P)().popupType ? (0, k.jsx)(o.Suspense, {
                fallback: null,
                children: (0, k.jsx)(Ne, {})
            }) : null));
            var Ee = t(260894);
            var we = t(743544),
                je = t(759851),
                ke = t(429634),
                Fe = t(315702),
                Me = t(828088);
            const Ue = {
                bankIdIntergration: e => 35 === e.active_step && 5 === e.active_step_state
            };
            t(751631);
            x.Ay.IS_RTL && t.e(91741).then(t.bind(t, 91741));
            const {
                FavoriteOnHeaderPopup: De
            } = (0, _.R)((() => Promise.all([t.e(99701), t.e(22093), t.e(45375), t.e(99989), t.e(76481), t.e(75634), t.e(90363), t.e(15243), t.e(20509), t.e(85123), t.e(77484), t.e(82685), t.e(34519), t.e(73157), t.e(12967), t.e(77499), t.e(74027), t.e(11216), t.e(23973), t.e(22491), t.e(31139), t.e(6995), t.e(82363), t.e(6635), t.e(29925), t.e(31528), t.e(9297), t.e(36273), t.e(61579), t.e(34885), t.e(11115), t.e(94875), t.e(61190), t.e(77058)]).then(t.bind(t, 275955)))), {
                BankIDIntegration: Le
            } = (0, _.R)((() => Promise.all([t.e(6635), t.e(80192), t.e(51238), t.e(73549), t.e(40999), t.e(14971), t.e(3320), t.e(23860)]).then(t.bind(t, 401160)))), {
                ChangeTheme: Be
            } = (0, _.R)((() => Promise.all([t.e(90286), t.e(71139), t.e(17893), t.e(38761)]).then(t.bind(t, 70573)))), {
                ProfileInfo: We
            } = (0, _.R)((() => Promise.all([t.e(99701), t.e(22093), t.e(45375), t.e(76481), t.e(22491), t.e(31139), t.e(6995), t.e(82363), t.e(29925), t.e(31528), t.e(9297), t.e(36273), t.e(61579), t.e(70289), t.e(18574), t.e(80192), t.e(81643), t.e(11115), t.e(36046), t.e(60503), t.e(48484), t.e(88191), t.e(61190), t.e(24541), t.e(83573), t.e(89265), t.e(83753), t.e(31436), t.e(53575), t.e(19256)]).then(t.bind(t, 334170)))), {
                CryptoWallets: $e
            } = (0, _.R)((() => Promise.all([t.e(99989), t.e(75634), t.e(20509), t.e(34519), t.e(31528), t.e(9297), t.e(70289), t.e(18574), t.e(80192), t.e(51238), t.e(31437), t.e(34885), t.e(81643), t.e(57008), t.e(82675), t.e(61190), t.e(73549), t.e(87154), t.e(40999), t.e(14971), t.e(85762), t.e(27989), t.e(16199), t.e(76665)]).then(t.bind(t, 722902)))), {
                Login: Ge
            } = (0, _.R)((() => Promise.all([t.e(80192), t.e(51238), t.e(73549), t.e(40999), t.e(14971), t.e(56982), t.e(62519)]).then(t.bind(t, 154487)))), {
                RegisterOnPage: Ve
            } = (0, _.R)((() => Promise.all([t.e(99701), t.e(22093), t.e(45375), t.e(99989), t.e(76481), t.e(75634), t.e(90363), t.e(15243), t.e(20509), t.e(77484), t.e(34519), t.e(73157), t.e(12967), t.e(74027), t.e(66399), t.e(46203), t.e(10985), t.e(58171), t.e(539), t.e(49115), t.e(31528), t.e(9297), t.e(36273), t.e(61579), t.e(70289), t.e(18574), t.e(80192), t.e(51238), t.e(31437), t.e(34885), t.e(96884), t.e(53167), t.e(13398), t.e(86773), t.e(17457), t.e(61190), t.e(91721)]).then(t.bind(t, 259988)))), {
                VerifyEmailModal: He
            } = (0, _.R)((() => Promise.all([t.e(80192), t.e(51238), t.e(73549), t.e(40999), t.e(14971), t.e(97752)]).then(t.bind(t, 288062)))), {
                CheckEmailModal: qe
            } = (0, _.R)((() => Promise.all([t.e(80192), t.e(51238), t.e(73549), t.e(40999), t.e(14971), t.e(97043), t.e(23995)]).then(t.bind(t, 386995)))), {
                DocumentUploadModal: Je
            } = (0, _.R)((() => Promise.all([t.e(99701), t.e(22093), t.e(45375), t.e(99989), t.e(76481), t.e(75634), t.e(90363), t.e(15243), t.e(77484), t.e(34519), t.e(74027), t.e(66399), t.e(539), t.e(31528), t.e(9297), t.e(36273), t.e(61579), t.e(70289), t.e(18574), t.e(80192), t.e(51238), t.e(31437), t.e(34885), t.e(81643), t.e(57008), t.e(69478), t.e(17522), t.e(13398), t.e(73549), t.e(30078)]).then(t.bind(t, 819651)))), {
                CounterOfferModal: Ke
            } = (0, _.R)((() => Promise.all([t.e(80192), t.e(51238), t.e(61190), t.e(73549), t.e(87154), t.e(40999), t.e(14971), t.e(24541), t.e(5060), t.e(55221), t.e(80279), t.e(74853)]).then(t.bind(t, 179206)))), {
                LoginFreeze: Ye
            } = (0, _.R)((() => Promise.all([t.e(80192), t.e(51238), t.e(73549), t.e(87154), t.e(40999), t.e(14971), t.e(94081)]).then(t.bind(t, 338414)))), {
                LoginLimitPopup: ze
            } = (0, _.R)((() => Promise.all([t.e(80192), t.e(51238), t.e(73549), t.e(87154), t.e(40999), t.e(14971), t.e(83604)]).then(t.bind(t, 803714)))), {
                RealityCheckModal: Xe
            } = (0, _.R)((() => Promise.all([t.e(80192), t.e(51238), t.e(73549), t.e(87154), t.e(40999), t.e(14971), t.e(159)]).then(t.bind(t, 207123)))), {
                RemainingSessionDurationModal: Qe
            } = (0, _.R)((() => Promise.all([t.e(80192), t.e(51238), t.e(73549), t.e(87154), t.e(40999), t.e(14971), t.e(14928)]).then(t.bind(t, 196262)))), {
                PlayerInfo: Ze
            } = (0, _.R)((() => Promise.all([t.e(80192), t.e(51238), t.e(61190), t.e(73549), t.e(87154), t.e(40999), t.e(14971), t.e(24541), t.e(87092)]).then(t.bind(t, 640927)))), {
                AdditionalInfoPopup: en
            } = (0, _.R)((() => Promise.all([t.e(80192), t.e(51238), t.e(53167), t.e(61190), t.e(73549), t.e(58073), t.e(87154), t.e(40999), t.e(14971), t.e(24541), t.e(88097)]).then(t.bind(t, 828482)))), {
                AuthSection: nn
            } = (0, _.R)((() => Promise.all([t.e(24757), t.e(42146), t.e(10795), t.e(43688)]).then(t.bind(t, 535030)))), {
                AutoidentVerificationModal: tn
            } = (0, _.R)((() => Promise.all([t.e(80192), t.e(51238), t.e(73549), t.e(87154), t.e(40999), t.e(14971), t.e(5326)]).then(t.bind(t, 463154)))), {
                TermsAndConditions: on
            } = (0, _.R)((() => Promise.all([t.e(80192), t.e(51238), t.e(73549), t.e(87154), t.e(40999), t.e(14971), t.e(73143)]).then(t.bind(t, 942083)))), {
                NotVerifiedMessage: sn
            } = (0, _.R)((() => Promise.all([t.e(91004), t.e(5517)]).then(t.bind(t, 793999)))), {
                VerifyAccountModalRedirect: an
            } = (0, _.R)((() => Promise.all([t.e(80192), t.e(51238), t.e(73549), t.e(87154), t.e(40999), t.e(14971), t.e(69822)]).then(t.bind(t, 43331)))), ln = e => {
                var n;
                let {
                    configs: {
                        accountLayout: m,
                        slideView: _,
                        horizontalView: I,
                        accountSignInButtonType: b,
                        accountSignInButtonStyle: C,
                        accountSignInButtonIcon: j,
                        accountSignUpButtonType: F,
                        accountSignUpButtonStyle: M,
                        accountSignUpButtonIcon: U,
                        accountButtonsDistance: D,
                        mounted: L,
                        accountPrevButtonStyle: B,
                        accountNextButtonStyle: W,
                        signInBtn: $,
                        signUpBtn: G,
                        favorite: V,
                        favoriteTabs: H
                    }
                } = e;
                T(), (0, O.d)(), (0, R.p)(), (() => {
                    const e = (0, s.wA)(),
                        n = (0, s.d4)(l.JL),
                        t = (0, s.d4)(a.eP);
                    (0, o.useEffect)((() => {
                        t && (null !== n && void 0 !== n && n.sections || !x.Ay.SECTIONS_JSON || (0, u.is)(x.Ay.SECTIONS_JSON).then((n => {
                            e((0, c.rg)(n))
                        })).catch((() => {
                            e((0, c.rg)([]))
                        })), x.Ay.SECTIONS_JSON || e((0, c.rg)([])))
                    }), [t])
                })(), (() => {
                    const e = (0, s.wA)();
                    (0, o.useEffect)((() => {
                        x.Ay.SEON_INTEGRATION && !window.seon && (0, Ee.k)("https://cdn.deviceinf.com/js/v5/agent.js", "seonScript", (() => {
                            window.seon && window.seon.getBase64Session((n => {
                                n ? e((0, c.ax)(n)) : console.error("Failed to retrieve session data")
                            }))
                        }))
                    }), [])
                })(), (() => {
                    const e = (0, g.W6)(),
                        {
                            t: n
                        } = (0, h.B)(),
                        t = (0, s.d4)(a.eP),
                        i = (0, s.d4)(a.wz);
                    (0, o.useEffect)((() => {
                        if (t) {
                            const t = p().parse(e.location.search, {
                                    ignoreQueryPrefix: !0
                                }),
                                o = JSON.parse(f.A.getItem((0, P.U)("account", "PAYMENT_DATA")));
                            if (t && t.message) {
                                switch (t.message) {
                                    case we.mk.CANCEL:
                                        (0, y.$)(n(`account.${we.pr.CANCEL}`)), x.Ay.APPEND_CUSTOM_CODE_DEPOSIT_FAIL && (0, je.T)(x.Ay.CUSTOM_CODE_DEPOSIT_FAIL, { ...i,
                                            ...o
                                        });
                                        break;
                                    case we.mk.FAIL:
                                        (0, y.$)(n(`account.${we.pr.FAIL}`)), x.Ay.APPEND_CUSTOM_CODE_DEPOSIT_FAIL && (0, je.T)(x.Ay.CUSTOM_CODE_DEPOSIT_FAIL, { ...i,
                                            ...o
                                        });
                                        break;
                                    case we.mk.PENDING:
                                        (0, ke.h)(n(`account.${we.pr.PENDING}`));
                                        break;
                                    case we.mk.SUCCESS:
                                        (0, Fe.RO)(i), (0, Me.y)(n(`account.${we.pr.SUCCESS}`));
                                        break;
                                    default:
                                        (0, ke.h)(t.message)
                                }
                                e.push((0, S.U7)({
                                    message: void 0
                                }))
                            }
                        }
                    }), [t])
                })();
                const q = m || "popup",
                    J = null === H || void 0 === H ? void 0 : H.map((e => String(e))),
                    [K, Y] = (0, o.useState)(!1),
                    [z, X] = (0, o.useState)(!1),
                    [Q, Z] = (0, o.useState)([]),
                    [ee, ne] = (0, o.useState)("onPage" === q ? _ : void 0),
                    {
                        t: te
                    } = (0, h.B)(),
                    oe = (0, g.W6)(),
                    se = (0, s.wA)(),
                    ie = (0, E.o)(),
                    ae = (0, Re.N)(),
                    le = (0, O.d)(!0),
                    re = (0, s.d4)(a.eP),
                    ce = (0, s.d4)(a.wz),
                    ue = (0, s.d4)(l.fI),
                    de = (0, s.d4)(a.TR),
                    me = (0, s.d4)(a.pI),
                    pe = (0, s.d4)(l.gh),
                    he = (0, s.d4)(l.h0),
                    ge = (0, s.d4)(a.dt),
                    Ae = (0, s.d4)(a.ob),
                    ve = (0, s.d4)(l.zQ),
                    _e = (0, s.d4)(d.gU),
                    Se = (0, s.d4)(l.JL),
                    Ie = JSON.parse(f.A.getItem((0, P.U)("account", "ADDITIONAL_INFO_POPUP"))),
                    ye = JSON.parse(f.A.getItem((0, P.U)("account", "AUTH_DATA"))) && !x.Ay.MOCKED_DATA;
                (0, o.useEffect)((() => {
                    "function" !== typeof window.selfExclude && (window.selfExclude = function() {
                        let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {
                                value: 1,
                                label: "1 days",
                                type: "days",
                                amount: 1,
                                show: !0,
                                name: "days-1",
                                user: ce
                            },
                            n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1;
                        (0, u.XB)(e, n, ae)
                    })
                }), []), (0, o.useEffect)((() => {
                    if (re) {
                        const e = p().parse(window.location.search, {
                            ignoreQueryPrefix: !0
                        });
                        e && null !== e && void 0 !== e && e.kycaid && (oe.replace("/", {}), (0, Me.y)(te("account.success")))
                    }
                    re || (se((0, A.XM_)()), se((0, r.Ai)(null)))
                }), [re]), (0, o.useEffect)((() => {
                    re && Ue.bankIdIntergration(ce) && (x.Ay.IS_BANK_ID_INTEGRATION_ENABLED || 1 === +(null === pe || void 0 === pe ? void 0 : pe.diiaVerification)) ? Y(!0) : Y(!1)
                }), [re, ce.active_step, ce.active_step_state]), (0, o.useEffect)((() => {
                    (0, N.F)() && (ie.accounts ? (document.documentElement.classList.add("accountModal--html--overflow--hidden"), document.body.classList.add("accountModal--html--overflow--hidden")) : (document.documentElement.classList.remove("accountModal--html--overflow--hidden"), document.body.classList.remove("accountModal--html--overflow--hidden")))
                }), [ie.accounts]);
                const fe = (0, o.useMemo)((() => !(null === de || 0 === Object.keys(de).length)), [de]),
                    Pe = (0, o.useCallback)((e => {
                        X(e)
                    }), []),
                    xe = JSON.parse(f.A.getItem((0, P.U)("account", "SESSION_VISIBILITY_REFRESH")));
                window.refreshWhenLoggedIn && x.Ay.ADD_INFO_AFTER_LOGIN && ue && f.A.setItem((0, P.U)("account", "SESSION_VISIBILITY_REFRESH"), JSON.stringify(1)), (0, o.useEffect)((() => {
                    (0, N.F)() ? Promise.all([t.e(70990), t.e(75558), t.e(46749)]).then(t.bind(t, 312388)): Promise.all([t.e(99701), t.e(22093), t.e(45375), t.e(76481), t.e(90363), t.e(15243), t.e(85123), t.e(22491), t.e(82363), t.e(89691), t.e(31528), t.e(9297), t.e(36273), t.e(61579), t.e(70289), t.e(80192), t.e(36046), t.e(61190), t.e(87154), t.e(40999), t.e(24541), t.e(83753), t.e(38686), t.e(52056), t.e(88397), t.e(40763), t.e(71103)]).then(t.bind(t, 126246))
                }), []), (0, o.useEffect)((() => {
                    const e = JSON.parse(f.A.getItem((0, P.U)("account", "AUTH_DATA")));
                    null !== e && void 0 !== e && e.auth_token || (se((0, r.Sl)()), f.A.removeItem((0, P.U)("account", "LOGIN_LIMIT_START_TIME")))
                }), []), (0, o.useEffect)((() => {
                    !pe && x.Ay.ACCOUNT_PARAMS && (0, u.is)(x.Ay.ACCOUNT_PARAMS).then((e => {
                        x.Ay.CYPRUS_ACCOUNT_TYPE && (e["months-7"] = "1", e["months-8"] = "1", e["months-9"] = "1", e["months-10"] = "1", e["months-11"] = "1", e["timeout-hours-72"] = "1"), se((0, c.Y7)(e))
                    })).catch((() => {
                        se((0, c.Y7)({}))
                    }))
                }), []), (0, o.useEffect)((() => {
                    x.Ay.IFRAME_SPORTSBOOK && ie.user_id && ie.auth_token && le({
                        auth_token: ie.auth_token,
                        user_id: ie.user_id
                    })
                }), [ie.user_id, ie.auth_token]);
                const Ne = (0, o.useMemo)((() => !(!Object.keys(ce).length || !(27 === ce.active_step && 5 === ce.active_step_state || x.Ay.SELFIE_WITH_DOCUMENTS && !ce.is_verified && me))), [ce, me]),
                    ln = (0, o.useMemo)((() => {
                        const e = !(!x.Ay.MGA_ACCOUNT_TYPE && !x.Ay.CANADIAN_ACCOUNT_TYPE) && 33 === ce.active_step && 5 === ce.active_step_state;
                        return se((0, r.$M)(e)), e
                    }), [ce]),
                    rn = x.Ay.SHOW_VERIFY_ACCOUNT_MODAL && 50 === ce.active_step && 5 === ce.active_step_state;
                (0, o.useEffect)((() => {
                    re && !ge && Ae && (0, u.L3)((e => {
                        e && e.details.length && se((0, r.XO)(e.details))
                    }))
                }), [re, ge, Ae]), (0, o.useEffect)((() => {
                    ie.accounts && (ie.login && !Q.includes("login") && Z((e => [...e, "login"])), ie.register && !Q.includes("register") && Z((e => [...e, "register"])))
                }), [ie.accounts]), (0, o.useEffect)((() => {
                    (0, N.F)() && ie.login && (Promise.all([t.e(99701), t.e(22093), t.e(45375), t.e(99989), t.e(76481), t.e(75634), t.e(90363), t.e(20509), t.e(77484), t.e(73157), t.e(12967), t.e(77499), t.e(74027), t.e(31528), t.e(9297), t.e(36273), t.e(61579), t.e(70289), t.e(18574), t.e(31437), t.e(57008), t.e(82675), t.e(69478), t.e(53167), t.e(37053), t.e(51172), t.e(17366), t.e(89265), t.e(89910), t.e(69493)]).then(t.bind(t, 105095)), Promise.all([t.e(80192), t.e(51238), t.e(73549), t.e(40999), t.e(14971), t.e(56982), t.e(62519), t.e(96966)]).then(t.bind(t, 112716)))
                }), [Q, ie.accounts]), (0, o.useEffect)((() => {
                    x.Ay.ACCOUNT_REGISTRATION_JSON_PATH || he ? !he && (0, u.is)(x.Ay.ACCOUNT_REGISTRATION_JSON_PATH).then((e => {
                        se((0, c.HR)(e))
                    })).catch((() => {
                        se((0, c.HR)(Te.G))
                    })) : se((0, c.HR)(Te.G))
                }), [ie.register, ee]);
                const cn = (0, o.useMemo)((() => {
                    var e;
                    const n = Number(null === ce || void 0 === ce ? void 0 : ce.terms_and_conditions_version),
                        t = Number(null === pe || void 0 === pe ? void 0 : pe.tcVersion);
                    return 1 === +(null === pe || void 0 === pe ? void 0 : pe.termsConditionsCustom) && n < t && (null === (e = x.Ay.TERMS_POPUP_LINK) || void 0 === e ? void 0 : e.length)
                }), [null === ce || void 0 === ce ? void 0 : ce.terms_and_conditions_version, null === pe || void 0 === pe ? void 0 : pe.tcVersion, null === pe || void 0 === pe ? void 0 : pe.termsConditionsCustom]);
                return x.Ay.MOCKED_DATA ? (0, k.jsx)(o.Suspense, {
                    children: (0, k.jsx)(nn, {
                        accountSignUpButtonStyle: M,
                        accountSignInButtonStyle: C,
                        accountButtonsDistance: D,
                        favoriteEnabled: !!Number(V),
                        signInBtn: $,
                        signUpBtn: G
                    })
                }) : (x.Ay.SHOW_ACCOUNT_ADDITIONAL_INFO_MODAL && re && null == Ie && f.A.setItem((0, P.U)("account", "ADDITIONAL_INFO_POPUP"), JSON.stringify({
                    count: 1
                })), (0, k.jsxs)(k.Fragment, {
                    children: [!!Number(V) && (0, k.jsx)(o.Suspense, {
                        fallback: null,
                        children: (0, k.jsx)(De, {
                            favoriteTypes: J
                        })
                    }), x.Ay.GPS_TRACKING_ENABLED && (0, k.jsx)(o.Suspense, {
                        fallback: null,
                        children: (0, k.jsx)(Ce, {})
                    }), re && !ce.pending && (null === Se || void 0 === Se ? void 0 : Se.myProfile) && (0, k.jsxs)(k.Fragment, {
                        children: [x.Ay.IOVATION_ENABLED && Ne && (0, k.jsx)(o.Suspense, {
                            children: (0, k.jsx)(Je, {})
                        }), rn && (0, k.jsx)(o.Suspense, {
                            children: (0, k.jsx)(an, {})
                        }), x.Ay.DOC_UPLOAD_TRU_NARRATIVE && Ne && (0, k.jsx)(o.Suspense, {
                            children: (0, k.jsx)(Je, {})
                        }), x.Ay.LOGIN_FREEZE && (0, k.jsx)(o.Suspense, {
                            children: (0, k.jsx)(Ye, {})
                        }), x.Ay.LOGIN_LIMIT_POPUP && (0, k.jsx)(ze, {}), (x.Ay.REALITY_CHECK || x.Ay.REALITY_CHECK_SWITCHER) && (0, k.jsx)(o.Suspense, {
                            children: (0, k.jsx)(Xe, {})
                        }), (x.Ay.ADD_INFO_AFTER_LOGIN && ue || xe) && (0, k.jsx)(o.Suspense, {
                            children: (0, k.jsx)(Ze, {})
                        }), x.Ay.SHOW_ACCOUNT_ADDITIONAL_INFO_MODAL && 1 === (null === Ie || void 0 === Ie ? void 0 : Ie.count) && (0, k.jsx)(en, {}), ln && (0, k.jsx)(o.Suspense, {
                            children: (0, k.jsx)(tn, {})
                        }), fe && (0, k.jsx)(o.Suspense, {
                            children: (0, k.jsx)(Ke, {})
                        }), cn && (0, k.jsx)(o.Suspense, {
                            children: (0, k.jsx)(on, {})
                        }), x.Ay.SHOW_USER_UNVERIFIED_MESSAGE && !ce.is_verified && (0, k.jsx)(o.Suspense, {
                            children: (0, k.jsx)(sn, {})
                        })]
                    }), ye ? (0, k.jsxs)("div", {
                        className: (0, i.A)(["profileInfo__container", {
                            "profileInfo__container--mobile": (0, N.F)()
                        }]),
                        children: [!(null === _e || void 0 === _e || null === (n = _e.secondary_wallet_currencies) || void 0 === n || !n.length) && (0, k.jsx)(o.Suspense, {
                            children: (0, k.jsx)($e, {})
                        }), (0, k.jsx)(o.Suspense, {
                            children: (0, k.jsx)(We, {
                                user: ce,
                                data: ye,
                                favoriteEnabled: !!Number(V),
                                favoriteTabs: J
                            })
                        })]
                    }) : "signin" === ee ? (0, k.jsxs)("div", {
                        className: "x-account__onPageWrapper",
                        children: [(0, k.jsx)(o.Suspense, {
                            fallback: (0, k.jsx)(w.R, {}),
                            children: (0, k.jsx)(Ge, {
                                onPage: !0,
                                inline: !0,
                                horizontal: I,
                                setOnPageCurrentSlide: ne,
                                accountSignUpButtonStyle: M,
                                accountSignInButtonStyle: C,
                                accountButtonsDistance: D,
                                signInBtn: $,
                                signUpBtn: G
                            })
                        }), x.Ay.THEME_SWITCHER && !(0, N.F)() && (0, k.jsx)(o.Suspense, {
                            fallback: (0, k.jsx)(v.X, {}),
                            children: (0, k.jsx)(Be, {})
                        })]
                    }) : "signup" === ee ? (0, k.jsx)("div", {
                        className: "x-account__onPageWrapper",
                        children: (0, k.jsx)(o.Suspense, {
                            fallback: (0, k.jsx)(w.R, {}),
                            children: (0, k.jsx)(Ve, {
                                accountSignUpButtonStyle: M,
                                setOnPageCurrentSlide: ne,
                                onPageCurrentSlide: ee,
                                accountPrevButtonStyle: B,
                                accountNextButtonStyle: W,
                                signInBtn: $,
                                signUpBtn: G
                            })
                        })
                    }) : (0, k.jsx)(o.Suspense, {
                        children: (0, k.jsx)(nn, {
                            accountSignInButtonType: b,
                            accountSignInButtonStyle: C,
                            accountSignInButtonIcon: j,
                            accountSignUpButtonType: F,
                            accountSignUpButtonStyle: M,
                            accountSignUpButtonIcon: U,
                            accountButtonsDistance: D,
                            signInBtn: $,
                            signUpBtn: G,
                            favoriteEnabled: !!Number(V),
                            favoriteTabs: J
                        })
                    }), L && (0, k.jsx)(Oe.z, {
                        open: (0, N.F)() && !!ie.accounts,
                        animationType: "toLeft",
                        className: (0, i.A)(["account-popup", {
                            "register-popup": ie.register,
                            "account-popup-open": (0, N.F)() && !!ie.accounts
                        }]),
                        children: (0, N.F)() && (0, k.jsx)(be, {
                            setVisible: Pe,
                            accountSignUpButtonStyle: M,
                            accountPrevButtonStyle: B,
                            accountNextButtonStyle: W,
                            signInBtn: $,
                            signUpBtn: G
                        })
                    }), !(0, N.F)() && Object.keys(ie).length > 1 && ie.accounts && (0, k.jsx)(be, {
                        setVisible: X,
                        accountSignUpButtonStyle: M,
                        accountPrevButtonStyle: B,
                        accountNextButtonStyle: W,
                        signInBtn: $,
                        signUpBtn: G
                    }), (0, k.jsx)(o.Suspense, {
                        children: (0, k.jsx)(S.Wy, {
                            includes: ["verify", "code"],
                            excludes: [],
                            component: He
                        })
                    }), K && (0, k.jsx)(o.Suspense, {
                        children: (0, k.jsx)(Le, {
                            visible: K,
                            close: () => Y(!1)
                        })
                    }), z && (0, k.jsx)(o.Suspense, {
                        children: (0, k.jsx)(qe, {
                            visible: z,
                            setVisible: Pe
                        })
                    }), !(null === ve || void 0 === ve || !ve.isOpen) && (0, k.jsx)(o.Suspense, {
                        children: (0, k.jsx)(Qe, {})
                    })]
                }))
            }
        },
        626038: (e, n, t) => {
            t.d(n, {
                N: () => g
            });
            var o = t(507712),
                s = t(995392),
                i = t(307022),
                a = t(841591),
                l = t(446987),
                r = t(93907),
                c = t(816343),
                u = t(123213),
                d = t(556785),
                m = t(238605),
                p = t(179177),
                h = t(849944);
            const g = e => {
                const n = (0, o.wA)(),
                    t = (0, s.W6)(),
                    g = (0, o.d4)(a.V7);
                return o => {
                    (0, l.ri)((() => (e => {
                        var o;
                        e && t.push((0, c.XZ)()), n((0, i.Sl)()), n((0, i.XO)(null)), n((0, r.sV)({})), u.A.removeItem((0, d.U)("account", "LOGIN_LIMIT_START_TIME")), u.A.removeItem((0, d.U)("account", "LOGIN_LIMIT_POPUP_START_TIME")), u.A.removeItem((0, d.U)("account", "IS_LOGOUT")), (0, m.Yj)("sbuser"), (0, m.Yj)("loginCredentials"), u.A.removeItem((0, d.U)("account", "ADDITIONAL_INFO_POPUP")), u.A.removeItem((0, d.U)("account", "PARENT_ACCOUNT_CURRENCY")), window.refreshWhenLoggedIn && (window.mustRefreshForSessionVisibility = !0, window.location.reload()), p.Ay.IFRAME_SPORTSBOOK && (0, h.$i)("loggedOut"), p.Ay.WRAPPER_APP && null !== (o = window.median) && void 0 !== o && o.auth && window.median.auth.delete()
                    })(o)), {
                        fcm_token: g || void 0,
                        ...e
                    })
                }
            }
        },
        702044: (e, n, t) => {
            t.d(n, {
                d: () => j
            });
            var o = t(365043),
                s = t(507712),
                i = t(995392),
                a = t(446987),
                l = t(307022),
                r = t(314100),
                c = t(322908),
                u = t.n(c),
                d = t(679559),
                m = t(124634),
                p = t(841591),
                h = t(701616),
                g = t(550736),
                A = t(737536);
            const v = {},
                _ = () => {
                    Object.keys(v).forEach((e => {
                        clearTimeout(v[e]), delete v[e]
                    }))
                },
                S = (e, n) => {
                    (0, g.S4)(A.y.GET_REMAINING_SESSION_DURATION.toUpperCase(), (t => {
                        let {
                            details: o
                        } = t;
                        const s = Object.values(o || {});
                        if (null !== s && void 0 !== s && s.length) {
                            const t = Math.min(...s);
                            Object.entries(o || {}).forEach((o => {
                                let [s, i] = o;
                                i === t && e[s] && !v[s] && ((e, t) => {
                                    v[e] = setTimeout((() => {
                                        n(e), _()
                                    }), 1e3 * t * 60)
                                })(s, i)
                            }))
                        }
                    }))
                };
            var I = t(462956),
                y = t(171224),
                f = t(49770),
                P = t(123213),
                b = t(816343),
                T = t(115837),
                O = t(556785),
                R = t(954947),
                x = t(179177),
                N = t(485138),
                C = t(626038),
                E = t(976376),
                w = t(759851);
            const j = function() {
                let e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                const n = (0, i.W6)(),
                    t = (0, s.wA)(),
                    c = (0, C.N)(),
                    g = (0, s.d4)(d.eP),
                    A = (0, s.d4)(p.h0),
                    v = (0, s.d4)((e => {
                        let {
                            socket: n
                        } = e;
                        return n.isConnected
                    })),
                    j = (0, s.d4)(I.gU),
                    k = (0, s.d4)(p.gh),
                    F = (0, s.d4)(d.c8),
                    {
                        loginWithFaceId: M
                    } = (0, E.R)(),
                    U = (0, o.useMemo)((() => !(0 === +(null === k || void 0 === k ? void 0 : k.rememberMeTick) || null !== j && void 0 !== j && j.single_login) && F), [null === k || void 0 === k ? void 0 : k.rememberMeTick, F, null === j || void 0 === j ? void 0 : j.single_login]),
                    {
                        jwe_token: D
                    } = (0, y.O)(),
                    L = (0, o.useCallback)((e => {
                        ["CUSTOM_CODE_REG_AFTER_REFRESH", "CUSTOM_CODE_LOGIN_AFTER_REFRESH"].forEach((n => {
                            const t = P.A.getItem((0, O.U)("account", n));
                            n && ((0, w.T)(t, e), P.A.removeItem((0, O.U)("account", n)))
                        })), e.active_time_in_casino && f.A.setItem((0, O.U)("account", "ACTIVE_TIME_IN_CASINO"), `${e.active_time_in_casino}`), t((0, r.O)((0, l.sX)(e), (0, l.Vo)(!0), (0, l.hB)(60 * (e.session_duration || 0)), (0, l.Xz)(!e.is_verified))), (0, R.A)(), x.Ay.PUSH_NOTIFICATIONS_ENABLED && (0, m.f)(), (0, N.y)({
                            type: "userId",
                            value: e.user_id
                        }), P.A.removeItem((0, O.U)("account", "SWITCH_MULTI_ACCOUNT"))
                    }), [t]);
                (0, o.useEffect)((() => {
                    if (!e && Number((null === k || void 0 === k ? void 0 : k.sessionLimits) || 0)) {
                        if (!g) return void _();
                        S({
                            RemainingDailyDuration: Number((null === k || void 0 === k ? void 0 : k.showDailySession) || 0),
                            RemainingWeeklyDuration: Number((null === k || void 0 === k ? void 0 : k.showWeeklySession) || 0),
                            RemainingMonthlyDuration: Number((null === k || void 0 === k ? void 0 : k.showMonthlySession) || 0)
                        }, (e => {
                            c(!0), t((0, h.mm)({
                                type: e,
                                isOpen: !0
                            }))
                        }))
                    }
                }), [k, g, e]);
                const B = () => {
                        (0, a.ZT)(), t((0, l.Sl)())
                    },
                    {
                        updateUser: W
                    } = (0, T.Q)(),
                    $ = (0, o.useCallback)((function() {
                        let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null;
                        const t = JSON.parse(P.A.getItem((0, O.U)("account", "AUTH_DATA"))),
                            o = null === t || void 0 === t ? void 0 : t.auth_token,
                            s = U && D,
                            i = e || u().parse(n.location.search, {
                                ignoreQueryPrefix: !0
                            }),
                            l = null === A || void 0 === A ? void 0 : A.find((e => e && "personalId" === e.formType)),
                            r = !(!l || !l.editForm.showOnEditProfile || "2" !== l.editForm.personalIdType || "1" !== l.editForm.sendCPFAsDocNumber);
                        if (i.auth_token && i.user_id) {
                            const e = {
                                auth_token: i.auth_token,
                                user_id: Number(i.user_id)
                            };
                            n.replace((0, b.U7)({
                                auth_token: void 0,
                                user_id: void 0
                            })), (0, a.g6)(e, L, W, (() => B()), r)
                        } else s ? (0, a.g6)({
                            jwe_token: D,
                            auth_token: o
                        }, L, W, (() => B()), r) : o && (0, a.g6)(t, L, W, (() => B()), r);
                        g || o || s ? (i.login || i.register) && ((0, b.qx)(), n.replace((0, b.oR)({
                            accounts: "*",
                            profile: "*"
                        }))) : (i.settings || i.profile) && ((0, b.qx)(), n.replace((0, b.oR)({
                            accounts: "*",
                            login: "*"
                        })))
                    }), [g, L, U, A]);
                return (0, o.useEffect)((() => {
                    if (A && v && !e) {
                        var n;
                        const e = P.A.getItem("isWrapperFirstLaunch");
                        null !== (n = window.median) && void 0 !== n && n.auth && "null" !== e ? window.median.auth.status({
                            callbackFunction: e => {
                                e && e.hasTouchId && e.hasSecret ? (M(), P.A.removeItem("isWrapperFirstLaunch")) : $()
                            },
                            prompt: "PROMPT"
                        }) : $()
                    }
                }), [v, A]), $
            }
        },
        115837: (e, n, t) => {
            t.d(n, {
                Q: () => m
            });
            var o = t(507712),
                s = t(117893),
                i = t(464418),
                a = t(365043),
                l = t(841591),
                r = t(626038),
                c = t(123213),
                u = t(556785),
                d = t(179177);
            const m = () => {
                const e = (0, o.wA)(),
                    n = (0, o.d4)(l.gh),
                    t = (0, r.N)(),
                    m = (0, a.useCallback)((o => {
                        const a = c.A.getItem((0, u.U)("account", "SWITCH_MULTI_ACCOUNT"));
                        c.A.removeItem((0, u.U)("account", "SWITCH_MULTI_ACCOUNT")), o.logout && !JSON.parse(a) ? (+(null === n || void 0 === n ? void 0 : n.singleSignIn) || d.Ay.IS_MULTI_ACCOUNT_DISABLED) && t(!0) : (e((0, s.b6U)(o)), o.super_bet && (e((0, s.$5h)(o.super_bet)), e((0, i.wF)())))
                    }), [null === n || void 0 === n ? void 0 : n.singleSignIn]);
                return (0, a.useMemo)((() => ({
                    updateUser: m
                })), [m])
            }
        },
        393738: (e, n, t) => {
            t.d(n, {
                h: () => d,
                p: () => m
            });
            var o = t(365043),
                s = t(507712),
                i = t(446987),
                a = t(464418),
                l = t(679559),
                r = t(423400),
                c = t(123213),
                u = t(737536);
            const d = e => {
                    (0, i.sd)({
                        command: u.y.MARK_AS_READ_NOTIFICATION,
                        params: {
                            notification_id: e
                        },
                        rid: r.A.gForCommand()
                    }, null)
                },
                m = () => {
                    const e = (0, s.d4)(l.eP),
                        n = (0, s.d4)(l.wz),
                        t = (0, s.wA)(),
                        u = r.A.gForSubscribe(),
                        [m, p] = (0, o.useState)(!1);
                    (0, o.useEffect)((() => {
                        e && !m && (0, i.Jv)((e => {
                            p(!0), (e => {
                                if (window.refreshWhenLoggedIn && window.mustRefreshForSessionVisibility) return !1;
                                const t = [];
                                let o = !1;
                                const s = {
                                    1: "is",
                                    2: "isNot",
                                    3: "startsWith",
                                    4: "endsWith",
                                    5: "contains",
                                    6: "doesNotContains"
                                };
                                for (const p in e) {
                                    var i;
                                    const u = {};
                                    if (e[p].ClientId === n.id && e[p].Id && (null === (i = e[p].Page) || void 0 === i || !i.Value)) {
                                        var a;
                                        let n = c.A.getItem("openedPopupsListByLanguage");
                                        const t = null === (a = window.currentLanguageObject) || void 0 === a ? void 0 : a.id;
                                        if (n = n ? JSON.parse(n) : {}, !(n && t && n[t] && n[t].length && n[t].indexOf(e[p].Id) + 1)) {
                                            var l, r;
                                            null === (l = (r = window).openPopup) || void 0 === l || l.call(r, e[p].Alias), d(+p), o = !0;
                                            break
                                        }
                                        o = !1
                                    }
                                    e[p].ClientId === n.id && e[p].Id && e[p].Page.Comparison && e[p].Page.Value && (u.triggeringUrlValue = e[p].Page.Value, u.triggeringUrlRule = s[e[p].Page.Comparison], u.alias = e[p].Alias, u.id = e[p].Id, u.enableTriggeringRule = 1, u.triggeringTime = 0, u.key = +p, t.push(u))
                                }
                                var u, m;
                                o || !t.length || window.triggeringRuleIsWorked || (window.popupTriggeringRules = t, null === (u = (m = window).popupTriggering) || void 0 === u || u.call(m, !0))
                            })(e)
                        }), (e => {
                            if (e && e.cashout) {
                                const n = Object.keys(e.cashout).map((n => ({
                                    id: +n,
                                    amount: e.cashout[n].amount
                                })));
                                t((0, a.wZ)(n))
                            }
                        }), u)
                    }), [e])
                }
        },
        285275: (e, n, t) => {
            t.d(n, {
                X: () => i
            });
            t(270757);
            var o = t(694227),
                s = (t(485319), t(570579));
            const i = () => (0, s.jsx)(o.A.Button, {
                shape: "round",
                className: "ChangeThemeSkeleton"
            })
        },
        839736: (e, n, t) => {
            t.d(n, {
                DS: () => u,
                oe: () => c,
                xZ: () => r
            });
            var o = t(365043),
                s = t(570579);
            const i = {
                    title: "",
                    extra: null,
                    prevTitle: "",
                    hideBack: !0,
                    class: ""
                },
                a = o.createContext(void 0),
                l = o.createContext(void 0),
                r = e => {
                    const [n, t] = (0, o.useState)(i), [r, c] = (0, o.useState)(null), [u, d] = (0, o.useState)(null), [m, p] = (0, o.useState)(null), [h, g] = (0, o.useState)({}), A = (0, o.useCallback)((e => {
                        t({
                            extra: null,
                            hideBack: !1,
                            ...e
                        })
                    }), []);
                    return (0, s.jsx)(a.Provider, {
                        value: n,
                        children: (0, s.jsx)(l.Provider, {
                            value: {
                                updateAccountModal: A,
                                peselNumberValue: r,
                                isCpfPersonalId: u,
                                setPeselNumberValue: c,
                                setIsCpfPersonalId: d,
                                relatedDisabledFields: h,
                                setRelatedDisabledFields: g,
                                birthDateValue: m,
                                setBirthDateValue: p
                            },
                            children: e.children
                        })
                    })
                };

            function c() {
                const e = o.useContext(a);
                if (void 0 === e) throw new Error("useAccountsState must be used within a AccountsModalProvider");
                return e
            }

            function u() {
                const e = o.useContext(l);
                return void 0 === e ? {
                    updateAccountModal: () => {},
                    peselNumberValue: null,
                    isCpfPersonalId: null,
                    setPeselNumberValue: () => {},
                    setIsCpfPersonalId: () => {},
                    relatedDisabledFields: {},
                    setRelatedDisabledFields: () => {},
                    birthDateValue: null,
                    setBirthDateValue: () => {}
                } : e
            }
        },
        315702: (e, n, t) => {
            t.d(n, {
                DB: () => A,
                HF: () => g,
                RO: () => v,
                ef: () => p,
                my: () => h
            });
            var o = t(197262),
                s = t(860446),
                i = t.n(s),
                a = t(556785),
                l = t(759851),
                r = t(123213),
                c = t(179177),
                u = t(68392),
                d = t(706683),
                m = t(260945);
            const p = e => {
                    const n = [{
                        required: !0,
                        message: `${null===e||void 0===e?void 0:e.lang} ${o.A.t("validationMessages.isRequired")}`
                    }];
                    return n.push({
                        validator: (n, t) => {
                            const s = null === t || void 0 === t ? void 0 : t.replaceAll(" ", "");
                            return Number.isNaN(Number(s)) ? Promise.reject(`${e.lang} ${o.A.t("validationMessages.mustBeNumber")}`) : e.minLenght && s.length < e.minLenght ? Promise.reject(`${e.lang} ${o.A.t("validationMessages.minimumIs")} ${e.minLenght}`) : e.maxLenght && s.length > e.maxLenght ? Promise.reject(`${e.lang} ${o.A.t("validationMessages.maximumIs")} ${e.maxLenght}`) : Promise.resolve()
                        }
                    }), n
                },
                h = e => {
                    const n = [{
                        required: !0,
                        message: `${null===e||void 0===e?void 0:e.lang} ${o.A.t("validationMessages.isRequired")}`
                    }];
                    return n.push({
                        validator: (e, n) => {
                            const t = null === n || void 0 === n ? void 0 : n.replaceAll(" ", "");
                            return /^[a-zA-Z]+$/.test(t) ? Promise.resolve() : Promise.reject(`${o.A.t("validationMessages.onlyLetters")}`)
                        }
                    }), n
                },
                g = (e, n, t) => {
                    const s = [{
                        required: !0,
                        message: o.A.t("account.required")
                    }];
                    return s.push({
                        validator: (s, a) => {
                            const l = a.split(/[/.]/);
                            return Number(l[0]) > 12 || !Number(l[1]) || l[1].toString().length < e || l[1] < i()().year() && 4 === e ? (n.setFields([{
                                name: [t],
                                errors: [`${o.A.t("validationMessages.invalidDate")}`]
                            }]), Promise.reject(`${o.A.t("validationMessages.invalidDate")}`)) : Promise.resolve()
                        }
                    }), s
                },
                A = (e, n, t, s, i, a) => {
                    var l, r, c, p;
                    const h = n.lang || "",
                        g = [{
                            required: !0,
                            message: `${h} ${o.A.t("validationMessages.isRequired")}`
                        }],
                        A = ["eamount", "amount", "displayamount"].includes(e),
                        v = "accountNumber" === e || "cpf" === e,
                        _ = Number(null === s || void 0 === s || null === (l = s.info_notes) || void 0 === l || null === (r = l[t]) || void 0 === r ? void 0 : r.min),
                        S = Number(null === s || void 0 === s || null === (c = s.info_notes) || void 0 === c || null === (p = c[t]) || void 0 === p ? void 0 : p.max),
                        I = (0, u.N8)(t),
                        y = Number(null === n || void 0 === n ? void 0 : n.minLenght),
                        f = Number(null === n || void 0 === n ? void 0 : n.maxLenght);
                    return y && g.push({
                        validator: (e, n) => n.replace(/[^0-9]/g, "").length < y ? Promise.reject(`${h} ${o.A.t("validationMessages.minCharacter",{count:y})}`) : Promise.resolve()
                    }), f && g.push({
                        validator: (e, n) => n.replace(/[^0-9]/g, "").length > f ? Promise.reject(`${h} ${o.A.t("validationMessages.maxCharacter",{count:f})}`) : Promise.resolve()
                    }), v && g.push({
                        validator: (e, n) => {
                            n = n.trim();
                            return /^[0-9.-]+$/.test(n) ? Promise.resolve() : Promise.reject(`${h} ${o.A.t("validationMessages.mustBeNumber")}`)
                        }
                    }), (A || (null === n || void 0 === n ? void 0 : n.mask) && !isNaN(null === n || void 0 === n ? void 0 : n.mask)) && g.push({
                        validator: (e, n) => (A && (n = n.replace(m.u, "")), Number.isNaN(Number(n)) ? Promise.reject(`${h} ${o.A.t("validationMessages.mustBeNumber")}`) : Promise.resolve())
                    }), _ && A && g.push({
                        validator: (e, n) => {
                            var t;
                            return Number(null === n || void 0 === n || null === (t = n.toString()) || void 0 === t ? void 0 : t.replaceAll(m.u, "")) < _ ? Promise.reject(`${h} ${o.A.t("validationMessages.minimumIs")} ${"left"===I.placement?I.currency:""} ${(0,d.Q8)(_)} ${"right"===I.placement?I.currency:""}`) : Promise.resolve()
                        }
                    }), S && A && g.push({
                        validator: (e, n) => {
                            var t;
                            return Number(null === n || void 0 === n || null === (t = n.toString()) || void 0 === t ? void 0 : t.replaceAll(m.u, "")) > S ? Promise.reject(`${h} ${o.A.t("validationMessages.maximumIs")} ${"left"===I.placement?I.currency:""} ${(0,d.Q8)(S)} ${"right"===I.placement?I.currency:""}`) : Promise.resolve()
                        }
                    }), "number" === typeof i && a && A && g.push({
                        validator: (e, n) => {
                            var t;
                            return Number(null === n || void 0 === n || null === (t = n.toString()) || void 0 === t ? void 0 : t.replaceAll(m.u, "")) > i ? Promise.reject(`${o.A.t("validationMessages.excessBalance")}`) : Promise.resolve()
                        }
                    }), g
                },
                v = e => {
                    const n = JSON.parse(r.A.getItem((0, a.U)("account", "PAYMENT_DATA")));
                    c.Ay.APPEND_CUSTOM_CODE_DEPOSIT && (0, l.T)(c.Ay.CUSTOM_CODE_DEPOSIT, { ...e,
                        ...n
                    }), c.Ay.APPEND_CUSTOM_CODE_FIRST_DEPOSIT && "1" === r.A.getItem((0, a.U)("account", "FIRST_DEPOSIT")) && ((0, l.T)(c.Ay.CUSTOM_CODE_FIRST_DEPOSIT, { ...e,
                        ...n
                    }), r.A.setItem((0, a.U)("account", "FIRST_DEPOSIT"), "null"))
                }
        },
        954947: (e, n, t) => {
            t.d(n, {
                A: () => i
            });
            var o = t(446987),
                s = t(291372);
            const i = () => {
                const e = s.A.getState().appData.fireBaseToken;
                e && (0, o.NQ)(e)
            }
        },
        302258: (e, n, t) => {
            t.d(n, {
                Av: () => c,
                J3: () => l,
                as: () => u,
                ki: () => r
            });
            var o = t(860446),
                s = t.n(o),
                i = t(123213),
                a = t(556785);
            const l = e => (null !== e.first_name && null !== e.last_name ? `${e.first_name} ${e.last_name}` : e.username) || "",
                r = e => l(e).substr(0, 2).toUpperCase(),
                c = ["bonuses", "messages"],
                u = () => i.A.setItem((0, a.U)("account", "LOGIN_LIMIT_POPUP_START_TIME"), String(s()().unix()))
        },
        260894: (e, n, t) => {
            t.d(n, {
                k: () => o
            });
            const o = (e, n, t) => {
                var o;
                const s = document.createElement("script"),
                    i = document.getElementsByTagName("script")[0];
                s.src = e, s.type = "text/javascript", s.async = !0, s.id = n, s.onload = () => {
                    t()
                }, null === i || void 0 === i || null === (o = i.parentNode) || void 0 === o || o.insertBefore(s, i)
            }
        },
        743544: (e, n, t) => {
            t.d(n, {
                $6: () => u,
                HH: () => s,
                Uc: () => m,
                mk: () => i,
                oA: () => d,
                pr: () => a,
                vV: () => c,
                z7: () => r,
                zx: () => l
            });
            var o = t(179177);
            const s = {
                    POST: "post",
                    GET: "get",
                    IFRAME: "iframe",
                    FORM_DRAW: "formdraw",
                    MESSAGE: "message"
                },
                i = {
                    CANCEL: "cancel",
                    FAIL: "fail",
                    PENDING: "pending",
                    SUCCESS: "success"
                },
                a = {
                    CANCEL: "depositStatusMessageCancel",
                    FAIL: "depositStatusMessageFail",
                    PENDING: "depositStatusMessagePending",
                    SUCCESS: "depositStatusMessageDone"
                },
                l = {
                    SUCCESS: "withdrawSuccess"
                },
                r = {
                    "-2": "Rejected",
                    "-1": "Canceled",
                    0: "New",
                    1: "Allowed",
                    2: "Pending",
                    3: "Paid",
                    4: "RollBacked"
                };
            let c = function(e) {
                return e.sport = "sport", e.casino = "casino", e
            }({});
            const u = !o.Ay.CASINO_SPORTSBOOK_SWITCHER && !!o.Ay.IS_TWO_WALLET_ACTIVE,
                d = [0, 1].includes(o.Ay.CASINO_SPORTSBOOK_SWITCHER) ? c.sport : c.casino;
            let m = function(e) {
                return e[e.BANK_ID = 1] = "BANK_ID", e[e.DIIA = 2] = "DIIA", e
            }({})
        },
        177859: (e, n, t) => {
            t.d(n, {
                G: () => o
            });
            const o = [{
                type: "text",
                formType: "username",
                editForm: {
                    showOnRegFields: "1",
                    required: "1",
                    showOnEditProfile: "1",
                    usernameInMyProfile: "1"
                }
            }, {
                type: "text",
                formType: "address",
                editForm: {
                    showOnRegFields: "1",
                    required: "1",
                    showOnEditProfile: "1"
                }
            }, {
                type: "text",
                formType: "province",
                editForm: {
                    showOnRegFields: "1",
                    required: "1",
                    showOnEditProfile: "1"
                }
            }, {
                type: "text",
                formType: "city",
                editForm: {
                    showOnRegFields: "1",
                    required: "1",
                    showOnEditProfile: "1"
                }
            }, {
                label: "Account Number",
                type: "accountNumber",
                formType: "accountNumber",
                name: "iban",
                hasSettings: !0,
                hidden: !0,
                editForm: {
                    label: "Account Number",
                    showOnRegFields: "1",
                    showOnEditProfile: "1",
                    required: "0",
                    disabled: "0",
                    customValidation: "0",
                    customValidationCode: "",
                    uploadDoc: "0",
                    showAccountNumberPrefix: "1",
                    accountNumberPrefix: "FR"
                },
                params: {
                    validations: {
                        required: !0
                    }
                }
            }, {
                type: "radio",
                formType: "gender",
                editForm: {
                    showOnRegFields: "0",
                    showOnEditProfile: "1",
                    required: "1",
                    disabled: "1"
                },
                params: {
                    btnInfo: {
                        male: "M",
                        female: "F"
                    },
                    validations: {
                        required: !0
                    }
                }
            }, {
                type: "text",
                formType: "first_name",
                formLabel: "firstName",
                editForm: {
                    showOnRegFields: "1",
                    required: "1",
                    showOnEditProfile: "1",
                    disabled: "1",
                    onlyLetters: "1"
                }
            }, {
                type: "text",
                formType: "last_name",
                formLabel: "lastName",
                editForm: {
                    showOnRegFields: "1",
                    required: "1",
                    showOnEditProfile: "1",
                    disabled: "1",
                    onlyLetters: "1"
                }
            }, {
                type: "date",
                formType: "birthDate",
                name: "birth_date",
                editForm: {
                    disabled: "1",
                    dateType: "1",
                    label: "Birth Date",
                    ageLimit: "18",
                    showOnRegFields: "0",
                    showOnEditProfile: "1",
                    required: "1"
                }
            }, {
                type: "email",
                formType: "email",
                editForm: {
                    showOnRegFields: "1",
                    showOnEditProfile: "1",
                    required: "1",
                    disabled: "1"
                }
            }, {
                type: "password",
                formType: "password",
                editForm: {
                    showOnRegFields: "1"
                },
                params: {
                    validations: {
                        required: !0
                    }
                }
            }, {
                type: "password",
                confirm: !0,
                formType: "passwordConfirmation",
                name: "password_confirmation",
                editForm: {
                    showOnRegFields: "0"
                },
                params: {
                    validations: {
                        required: !0
                    }
                }
            }, {
                type: "select",
                formType: "country",
                fromData: "countries",
                name: "country_code",
                editForm: {
                    showOnRegFields: "1",
                    required: "1",
                    showOnEditProfile: "1",
                    disabled: "1"
                }
            }, {
                type: "mobile-number",
                formType: "mobileNumber",
                name: "phone",
                editForm: {
                    showOnRegFields: "0",
                    showOnEditProfile: "1",
                    required: "1",
                    disabled: "1"
                }
            }, {
                type: "select",
                formType: "currency",
                fromData: "currencyList",
                inParams: !0,
                name: "currency_name",
                editForm: {
                    showOnRegFields: "0",
                    required: "1"
                }
            }, {
                type: "select",
                formType: "occupation",
                fromData: "occupations",
                name: "occupation",
                editForm: {
                    showOnRegFields: "0",
                    showOnEditProfile: "1",
                    required: "0"
                }
            }, {
                type: "text",
                formType: "promoCode",
                name: "promo_code",
                editForm: {
                    showOnRegFields: "0",
                    required: "0"
                }
            }, {
                type: "checkbox",
                formType: "T&C_Checkbox",
                name: "tccheckbox",
                editForm: {
                    showOnRegFields: "1",
                    required: "1"
                }
            }, {
                type: "zipCode",
                formType: "zipCode",
                editForm: {
                    showOnRegFields: "1",
                    required: "1",
                    showOnEditProfile: "1",
                    disabled: "1"
                }
            }]
        },
        260945: (e, n, t) => {
            t.d(n, {
                P: () => i,
                u: () => s
            });
            var o = t(179177);
            const s = o.Ay.PRICE_SEPARATOR ? new RegExp(o.Ay.PRICE_SEPARATOR, "g") : "",
                i = /[^0-9.]/g
        },
        751631: () => {},
        485319: () => {}
    }
]);
//# sourceMappingURL=accounts.cc2d561c.chunk.js.map