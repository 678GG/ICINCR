"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [85123], {
        885123: (e, u, r) => {
            var t = r(50130);
            Object.defineProperty(u, "__esModule", {
                value: !0
            }), u.default = void 0;
            var n = r(365043),
                s = t(r(15243)),
                f = t(r(390363));
            var o = function() {
                var e = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0],
                    u = (0, n.useRef)({}),
                    r = (0, s.default)();
                return (0, n.useEffect)((function() {
                    var t = f.default.subscribe((function(t) {
                        u.current = t, e && r()
                    }));
                    return function() {
                        return f.default.unsubscribe(t)
                    }
                }), []), u.current
            };
            u.default = o
        }
    }
]);
//# sourceMappingURL=85123.3e171c05.chunk.js.map