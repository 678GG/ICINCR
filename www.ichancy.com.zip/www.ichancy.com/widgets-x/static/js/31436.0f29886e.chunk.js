"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [31436], {
        231436: (e, t, a) => {
            a.d(t, {
                c: () => i,
                v: () => _
            });
            var s = a(419090);
            const i = (e, t) => ({
                    game: {
                        id: {
                            "@in": e
                        }
                    },
                    ..."basic" === t ? s.q9 : "european" === t ? s.hs : {}
                }),
                _ = {
                    subscribedHookIds: {
                        fetchIds: null,
                        fetchData: null,
                        fetchMarkets: null
                    },
                    mountedHookIds: {
                        fetchIds: [],
                        fetchData: []
                    },
                    withAdditionalMarkets: !1
                }
        },
        419090: (e, t, a) => {
            a.d(t, {
                AZ: () => s,
                Ei: () => o,
                H_: () => _,
                Q0: () => i,
                b7: () => n,
                hs: () => c,
                q1: () => d,
                q9: () => p,
                tN: () => r
            });
            const s = {
                    event: ["name", "id", "price", "base", "order", "type_1", "extra_info", "display_column"]
                },
                i = {
                    market: ["name", "order", "type", "id", "base", "express_id", "col_count", "express_id", "group_id", "group_name", "cashout", "display_key"]
                },
                _ = {
                    market: ["id", "name", "type", "order", "main_order", "cashout", "col_count", "display_key", "display_sub_key", "market_type", "name_template", "point_sequence", "sequence", "extra_info", "express_id"]
                },
                d = {
                    sport: ["name", "alias", "id"]
                },
                o = {
                    region: ["name", "alias", "order", "id"]
                },
                n = {
                    competition: ["name", "order", "id"]
                },
                r = {
                    game: [
                        ["id", "type", "team1_name", "team2_name", "team1_id", "team2_id", "order", "start_ts", "markets_count", "is_blocked", "info", "tv_type", "exclude_ids", "show_type", "text_info", "add_info_name", "tv_info", "is_stat_available", "video_id", "video_id2", "video_id3", "sportcast_id", "match_length", "live_events"]
                    ]
                },
                p = {
                    market: {
                        display_key: "WINNER",
                        display_sub_key: "MATCH"
                    }
                },
                c = {
                    market: {
                        display_key: {
                            "@in": ["WINNER", "HANDICAP", "TOTALS"]
                        },
                        display_sub_key: {
                            "@in": ["MATCH", "PERIOD"]
                        }
                    }
                }
        }
    }
]);
//# sourceMappingURL=31436.0f29886e.chunk.js.map