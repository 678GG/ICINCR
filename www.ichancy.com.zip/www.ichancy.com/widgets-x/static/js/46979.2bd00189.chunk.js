"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [46979], {
        706628: (e, t, r) => {
            var n = r(50130),
                a = r(487066);
            t.A = void 0;
            var o = n(r(319290)),
                c = n(r(329085)),
                l = y(r(365043)),
                d = y(r(548672)),
                u = n(r(498139)),
                i = n(r(219730)),
                f = n(r(695033)),
                s = n(r(207181)),
                p = (n(r(697497)), r(445600)),
                b = n(r(626052));

            function v(e) {
                if ("function" !== typeof WeakMap) return null;
                var t = new WeakMap,
                    r = new WeakMap;
                return (v = function(e) {
                    return e ? r : t
                })(e)
            }

            function y(e, t) {
                if (!t && e && e.__esModule) return e;
                if (null === e || "object" !== a(e) && "function" !== typeof e) return {
                    default: e
                };
                var r = v(t);
                if (r && r.has(e)) return r.get(e);
                var n = {},
                    o = Object.defineProperty && Object.getOwnPropertyDescriptor;
                for (var c in e)
                    if ("default" !== c && Object.prototype.hasOwnProperty.call(e, c)) {
                        var l = o ? Object.getOwnPropertyDescriptor(e, c) : null;
                        l && (l.get || l.set) ? Object.defineProperty(n, c, l) : n[c] = e[c]
                    }
                return n.default = e, r && r.set(e, n), n
            }
            var m = function(e, t) {
                var r = {};
                for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && t.indexOf(n) < 0 && (r[n] = e[n]);
                if (null != e && "function" === typeof Object.getOwnPropertySymbols) {
                    var a = 0;
                    for (n = Object.getOwnPropertySymbols(e); a < n.length; a++) t.indexOf(n[a]) < 0 && Object.prototype.propertyIsEnumerable.call(e, n[a]) && (r[n[a]] = e[n[a]])
                }
                return r
            };

            function O(e) {
                var t, r = e.type,
                    n = e.className,
                    a = e.size,
                    v = e.onEdit,
                    y = e.hideAdd,
                    O = e.centered,
                    w = e.addIcon,
                    P = m(e, ["type", "className", "size", "onEdit", "hideAdd", "centered", "addIcon"]),
                    h = P.prefixCls,
                    j = P.moreIcon,
                    k = void 0 === j ? l.createElement(i.default, null) : j,
                    g = l.useContext(p.ConfigContext),
                    C = g.getPrefixCls,
                    E = g.direction,
                    x = C("tabs", h);
                "editable-card" === r && (t = {
                    onEdit: function(e, t) {
                        var r = t.key,
                            n = t.event;
                        null === v || void 0 === v || v("add" === e ? n : r, e)
                    },
                    removeIcon: l.createElement(s.default, null),
                    addIcon: w || l.createElement(f.default, null),
                    showAdd: !0 !== y
                });
                var I = C();
                return l.createElement(b.default.Consumer, null, (function(e) {
                    var i, f = void 0 !== a ? a : e;
                    return l.createElement(d.default, (0, o.default)({
                        direction: E,
                        moreTransitionName: "".concat(I, "-slide-up")
                    }, P, {
                        className: (0, u.default)((i = {}, (0, c.default)(i, "".concat(x, "-").concat(f), f), (0, c.default)(i, "".concat(x, "-card"), ["card", "editable-card"].includes(r)), (0, c.default)(i, "".concat(x, "-editable-card"), "editable-card" === r), (0, c.default)(i, "".concat(x, "-centered"), O), i), n),
                        editable: t,
                        moreIcon: k,
                        prefixCls: x
                    }))
                }))
            }
            O.TabPane = d.TabPane;
            var w = O;
            t.A = w
        },
        531806: (e, t, r) => {
            r(628035), r(658151)
        },
        658151: (e, t, r) => {
            r.r(t), r.d(t, {
                default: () => n
            });
            const n = {}
        }
    }
]);
//# sourceMappingURL=46979.2bd00189.chunk.js.map