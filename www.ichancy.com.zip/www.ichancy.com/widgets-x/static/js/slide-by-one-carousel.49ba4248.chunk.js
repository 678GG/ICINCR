"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [94038], {
        125708: (e, r, t) => {
            t.r(r), t.d(r, {
                SlideByOne: () => d
            });
            var n = t(365043),
                o = t(889181),
                l = t(735905),
                u = t(179177),
                s = t(55418);
            var i = t(177971),
                c = t(570579);
            const a = u.Ay.IS_RTL;
            a && t.e(48155).then(t.bind(t, 348155));
            const d = (0, n.memo)((e => {
                var r;
                let {
                    items: t,
                    dateCarousel: d,
                    scrollAllToLeft: v,
                    isEvent: f,
                    hideArrows: m,
                    sliderRowsCount: p,
                    customStyle: g,
                    customClick: _,
                    leftPosition: h,
                    noscrollOnDesktop: w,
                    showInactiveArrows: E
                } = e;
                const [C, R] = (0, n.useState)(0), [L, b] = (0, n.useState)(!0), [k, y] = (0, n.useState)(!1), [A, W] = (0, n.useState)(!1), B = (0, n.useRef)(null), S = (0, n.useRef)(null === (r = B.current) || void 0 === r ? void 0 : r.children), O = (0, n.useRef)(!1), x = e => {
                    B.current && (B.current.style.transitionDuration = "0s", B.current.style.transform = `translate(${e}px)`, B.current.style.transitionDuration = "0.25s")
                }, I = () => {
                    var e, r, t;
                    return +((null === (e = B.current) || void 0 === e || null === (r = e.style.transform) || void 0 === r || null === (t = r.split("(")[1]) || void 0 === t ? void 0 : t.split("px")[0]) || 0)
                }, P = () => {
                    var e;
                    if (!S.current) return 0;
                    const r = null === (e = S.current[S.current.length - 1]) || void 0 === e ? void 0 : e.getBoundingClientRect();
                    return r ? r.left + r.width : 0
                }, D = () => {
                    var e;
                    const r = I();
                    return ((null === (e = B.current) || void 0 === e ? void 0 : e.getBoundingClientRect().left) || 0) - r + (h || 0)
                }, T = () => {
                    var e, r, t, n, o;
                    const l = (null === (e = B.current) || void 0 === e ? void 0 : e.clientWidth) || 0,
                        u = (null === (r = B.current) || void 0 === r || null === (t = r.offsetParent) || void 0 === t ? void 0 : t.getBoundingClientRect().left) || 0,
                        s = (null === (n = S.current) || void 0 === n || null === (o = n[S.current.length - 1]) || void 0 === o ? void 0 : o.getBoundingClientRect().width) || 0;
                    return a ? P() <= u + s : P() >= l + u
                }, j = () => {
                    var e;
                    const r = (null === (e = B.current) || void 0 === e ? void 0 : e.clientWidth) || 0,
                        t = D() - (h || 0);
                    return a ? P() + t + r : P() - t - r
                }, M = (e, r, n) => {
                    O.current ? O.current = !1 : (O.current = !0, R((o => {
                        var l, u, s;
                        const i = o + (e ? r ? -o : -1 * (p || 1) : o === t.length - 1 ? -o : n || 1 * (p || 1)),
                            c = ((null === (l = S.current[i]) || void 0 === l ? void 0 : l.getBoundingClientRect().left) || 0) - ((null === (u = S.current[0]) || void 0 === u ? void 0 : u.getBoundingClientRect().left) || 0),
                            d = () => {
                                var e;
                                b(T()), O.current = !1, null === (e = B.current) || void 0 === e || e.removeEventListener("transitionend", d)
                            };
                        if (i > o && _ && _(), null === (s = B.current) || void 0 === s || s.addEventListener("transitionend", d), a) {
                            var v, f;
                            const e = Number(null === (v = B.current) || void 0 === v || null === (f = v.offsetParent) || void 0 === f ? void 0 : f.getBoundingClientRect().left),
                                r = P() > e;
                            x(r ? -c - (P() - e) : -c)
                        } else {
                            const e = I() - j();
                            x(e > -c ? e - 1 : -c)
                        }
                        return r ? 0 : i
                    })))
                }, N = () => {
                    var e, r, t;
                    return ((null === (e = B.current) || void 0 === e || null === (r = e.offsetParent) || void 0 === r ? void 0 : r.getBoundingClientRect().width) || 0) >= ((null === (t = B.current) || void 0 === t ? void 0 : t.scrollWidth) || 0)
                }, F = (0, n.useCallback)((() => {
                    if (!B.current) return;
                    const e = B.current.offsetWidth,
                        r = Array.from(B.current.children).reduce(((e, r) => e += (null === r || void 0 === r ? void 0 : r.offsetWidth) || 0), 0);
                    e && e > r && x(0)
                }), [t]);
                (0, n.useEffect)((() => {
                    F()
                }), [t.length]);
                const z = t.length,
                    G = (0, i.Z)(z);
                (0, n.useEffect)((() => {
                    G && G < z && b(T())
                }), [G]), (0, n.useEffect)((() => {
                    W(N())
                }), [A, t]), (e => {
                    let {
                        carouselWrapperRef: r,
                        isWrapperBiger: t,
                        getCurrentTransform: o,
                        setWraperTransform: l,
                        setLeftItemIndex: u,
                        isScrollOutOfWrapper: i,
                        rtl: c,
                        customClick: a,
                        noscrollOnDesktop: d
                    } = e;
                    (0, n.useEffect)((() => {
                        if (!d && r.current) {
                            let d, v = !1;
                            const f = e => {
                                    var n;
                                    if (e.button || t()) return;
                                    r.current && (r.current.style.transition = "0s"), e.preventDefault();
                                    const s = e.x,
                                        f = o();
                                    v = !1;
                                    const m = e => {
                                            if (v = !0, !i() && !c && r.current) {
                                                const r = f + e.x - s;
                                                l(r)
                                            }
                                        },
                                        p = t => {
                                            var n;
                                            if (r.current && (r.current.style.transition = "0.25s"), null === (n = r.current) || void 0 === n || n.removeEventListener("mousemove", m), v) {
                                                document.removeEventListener("mouseup", p);
                                                const r = t.pageX < e.pageX;
                                                u(!0, r), r && a && a()
                                            }
                                        };
                                    d = () => document.removeEventListener("mouseup", p), d(), null === (n = r.current) || void 0 === n || n.addEventListener("mousemove", m), document.addEventListener("mouseup", p)
                                },
                                m = e => {
                                    v && e.stopPropagation()
                                };
                            r.current.addEventListener("mousedown", f);
                            const p = () => {
                                a && a()
                            };
                            var e, n;
                            return a && (0, s.F)() && (null === (e = r.current) || void 0 === e || null === (n = e.parentNode) || void 0 === n || n.addEventListener("scroll", p, !1)), r.current.addEventListener("click", m), () => {
                                var e;
                                document.removeEventListener("mousedown", f), document.removeEventListener("scroll", p), null === (e = d) || void 0 === e || e()
                            }
                        }
                    }), [a])
                })({
                    carouselWrapperRef: B,
                    isWrapperBiger: N,
                    getCurrentTransform: I,
                    setWraperTransform: x,
                    setLeftItemIndex: function(e) {
                        let r = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
                        if (a) return;
                        if (!S.current) return;
                        let t = I();
                        const n = D();
                        let o = !1;
                        const l = j();
                        !a && l < 0 && (o = !0, t -= l);
                        for (let i = 0; i < S.current.length; i++) {
                            var u;
                            const c = ((null === (u = S.current[i]) || void 0 === u ? void 0 : u.getBoundingClientRect().left) || 0) - (l < 0 ? l : 0);
                            let a = c - n;
                            if (c > 0 && a > 0) {
                                if (e || 0 == i || o) {
                                    let e = 0;
                                    var s;
                                    if (!r && 0 != i && !o) e = (null === (s = S.current[i]) || void 0 === s ? void 0 : s.getBoundingClientRect().width) || 0;
                                    r && (a = 0), x(t - a + e)
                                }
                                R(r || o || 0 == i ? i : i - 1), b(T());
                                break
                            }
                        }
                    },
                    isScrollOutOfWrapper: () => j() < -200 || I() > 200,
                    rtl: a,
                    customClick: _,
                    noscrollOnDesktop: w
                }), (0, n.useEffect)((() => {
                    var e;
                    t && (S.current = null === (e = B.current) || void 0 === e ? void 0 : e.children)
                }), [t]), (0, n.useEffect)((() => {
                    v && M(!0, !0)
                }), [v]), (0, n.useEffect)((() => {
                    var e;
                    const r = (null === (e = B.current) || void 0 === e ? void 0 : e.childElementCount) || 0;
                    let n = 0;
                    t.some(((e, r) => {
                        var t;
                        if (null !== e && void 0 !== e && null !== (t = e.props) && void 0 !== t && t.active) return n = r, !0
                    })), n > r && M(!1, !1, n - r)
                }), []), (0, n.useEffect)((() => {
                    v && (O.current = !1, b(T()))
                }), [v]);
                const U = (0, n.useMemo)((() => !m && L && (!A || !N()) && (k || !(null === u.Ay || void 0 === u.Ay || !u.Ay.CAROUSEL_ARROWS) || d)), [m, L, A, d, k]),
                    X = (C > 0 || E) && (!A || !N()) && (k || !(null === u.Ay || void 0 === u.Ay || !u.Ay.CAROUSEL_ARROWS) || d || _ || E);
                return (0, c.jsxs)(c.Fragment, {
                    children: [X && (0, c.jsx)(l.GlobalIcon, {
                        lib: "generic",
                        name: "caretLeft",
                        theme: "default",
                        size: d ? 10 : 12,
                        position: "absolute",
                        className: (0, o.A)(["carousel__arrow one_slide_arrow", "carousel__arrow-left", d ? "carousel__arrow-data" : "carousel__arrow-classic", {
                            "carousel__arrow-disabled": C <= 0,
                            "carousel__arrow-event": f
                        }]),
                        onMouseEnter: () => y(!0),
                        onClick: e => {
                            e.stopPropagation(), C <= 0 || M(!0)
                        }
                    }), (0, c.jsx)("div", {
                        className: "carousel__wrapper",
                        ref: B,
                        style: g || {},
                        onMouseEnter: () => y(!0),
                        onMouseLeave: () => y(!1),
                        children: t.map(((e, r) => (0, c.jsx)(n.Fragment, {
                            children: e
                        }, r)))
                    }), (U || _ || E) && (0, c.jsx)(l.GlobalIcon, {
                        lib: "generic",
                        name: "caretRight",
                        theme: "default",
                        size: d ? 10 : 12,
                        position: "absolute",
                        className: (0, o.A)(["carousel__arrow one_slide_arrow", "carousel__arrow-right", d ? "carousel__arrow-data" : "carousel__arrow-classic", {
                            "carousel__arrow-disabled": !L,
                            "carousel__arrow-event": f
                        }]),
                        onMouseEnter: () => y(!0),
                        onClick: e => {
                            e.stopPropagation(), L && M(!1)
                        }
                    })]
                })
            }))
        }
    }
]);
//# sourceMappingURL=slide-by-one-carousel.49ba4248.chunk.js.map