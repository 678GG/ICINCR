"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [46749], {
        312388: (o, c, a) => {
            a.r(c), a.d(c, {
                MobileLayout: () => r
            });
            var t = a(839736),
                s = a(870905),
                e = a(995392),
                l = a(889181),
                i = a(575558),
                d = a(384716),
                n = a(570579);
            const r = o => {
                const c = (0, e.W6)(),
                    a = (0, t.oe)(),
                    {
                        t: r
                    } = (0, s.B)(),
                    {
                        updateAccountModal: u
                    } = (0, t.DS)(),
                    k = (0, d.o)();
                return (0, n.jsxs)(n.Fragment, {
                    children: [(0, n.jsx)(i.j, {
                        title: a.title || "",
                        goBack: a.hideBack ? void 0 : () => {
                            c.goBack()
                        },
                        extra: a.extra || (k.booking_id ? null : (0, n.jsx)("div", {
                            "data-testid": "close-button",
                            className: "accountModal__closeButton",
                            onClick: c => {
                                o.closeModal(c), u({
                                    class: "",
                                    hideBack: !0
                                })
                            },
                            children: r("account.closeModal")
                        })),
                        isLogin: a.title === r("account.signUp")
                    }), (0, n.jsx)("div", {
                        className: (0, l.A)(["accountModal accountModal--mobile", {
                            "accountModal--dark": k["bet-history"]
                        }]),
                        children: o.children
                    }), (0, n.jsx)("div", {
                        id: "fixed-footer",
                        className: a.class
                    })]
                })
            }
        }
    }
]);
//# sourceMappingURL=accounts-mobile-layout.cee4d31b.chunk.js.map