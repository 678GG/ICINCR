"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [20543], {
        20543: (t, e, r) => {
            r.r(e), r.d(e, {
                default: () => i
            });
            var n, l = r(365043);

            function a() {
                return a = Object.assign ? Object.assign.bind() : function(t) {
                    for (var e = 1; e < arguments.length; e++) {
                        var r = arguments[e];
                        for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (t[n] = r[n])
                    }
                    return t
                }, a.apply(this, arguments)
            }

            function o(t, e) {
                let {
                    title: r,
                    titleId: o,
                    ...s
                } = t;
                return l.createElement("svg", a({
                    width: 32,
                    height: 32,
                    viewBox: "0 0 32 32",
                    fill: "currentColor",
                    xmlns: "http://www.w3.org/2000/svg",
                    ref: e,
                    "aria-labelledby": o
                }, s), r ? l.createElement("title", {
                    id: o
                }, r) : null, n || (n = l.createElement("path", {
                    d: "M6.8589 16.0003C6.85942 15.7248 6.9146 15.4521 7.02126 15.198C7.12791 14.944 7.28391 14.7136 7.48023 14.5203L21.5842 0.570964C21.9869 0.202636 22.5154 0.0026129 23.061 0.0120373C23.6066 0.0214616 24.1279 0.239617 24.5176 0.621631C24.9045 1.00321 25.1266 1.52124 25.1361 2.06462C25.1455 2.60801 24.9417 3.13347 24.5682 3.5283L11.9576 16.0083L24.5682 28.4883C24.9417 28.8831 25.1455 29.4086 25.1361 29.952C25.1266 30.4954 24.9045 31.0134 24.5176 31.395C24.1279 31.777 23.6066 31.9951 23.061 32.0046C22.5154 32.014 21.9869 31.814 21.5842 31.4456L7.47756 17.4883C7.28077 17.2938 7.1247 17.062 7.01848 16.8066C6.91226 16.5511 6.85801 16.277 6.8589 16.0003V16.0003Z"
                })))
            }
            const s = l.forwardRef(o),
                i = (r.p, s)
        }
    }
]);
//# sourceMappingURL=20543.b1326b7b.chunk.js.map