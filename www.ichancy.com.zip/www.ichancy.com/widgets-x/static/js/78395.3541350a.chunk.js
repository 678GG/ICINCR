"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [78395], {
        478395: (e, r, t) => {
            t.d(r, {
                w: () => s
            });
            var n = t(365043);

            function s(e, r) {
                const t = function() {
                    const e = (0, n.useRef)(!0);
                    return e.current ? (e.current = !1, !0) : e.current
                }();
                (0, n.useEffect)((() => {
                    if (!t) return e()
                }), r)
            }
        }
    }
]);
//# sourceMappingURL=78395.3541350a.chunk.js.map