"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [82463], {
        482463: (o, l, d) => {
            d.d(l, {
                I: () => v
            });
            const v = (o, l, d) => {
                const v = l || "order",
                    i = d || "asc";
                return o.sort(((o, l) => {
                    var d, n, u, s, r, e;
                    return (null !== (d = null === o || void 0 === o ? void 0 : o[v]) && void 0 !== d ? d : 0) === (null !== (n = null === l || void 0 === l ? void 0 : l[v]) && void 0 !== n ? n : 0) ? 0 : "desc" === i ? (null !== (u = null === o || void 0 === o ? void 0 : o[v]) && void 0 !== u ? u : 0) < (null !== (s = null === l || void 0 === l ? void 0 : l[v]) && void 0 !== s ? s : 1) ? 1 : -1 : (null !== (r = null === o || void 0 === o ? void 0 : o[v]) && void 0 !== r ? r : 0) > (null !== (e = null === l || void 0 === l ? void 0 : l[v]) && void 0 !== e ? e : 1) ? 1 : -1
                }))
            }
        }
    }
]);
//# sourceMappingURL=82463.71797a96.chunk.js.map