"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [27012], {
        927012: (e, t, l) => {
            l.d(t, {
                W: () => d,
                x: () => c
            });
            var s = l(365043),
                n = l(989618),
                o = l(850245),
                r = l(555329),
                u = l(570579);
            const {
                MenuUnderline: i
            } = (0, n.R)((() => Promise.all([l.e(28151), l.e(85762), l.e(50245), l.e(99885)]).then(l.bind(l, 699885)))), {
                MenuFill: m
            } = (0, n.R)((() => Promise.all([l.e(28151), l.e(85762), l.e(42828), l.e(55329), l.e(21920)]).then(l.bind(l, 421920)))), a = {
                underline: {
                    view: i,
                    skeleton: o.t
                },
                fill: {
                    view: m,
                    skeleton: r.G
                }
            }, c = (0, s.createContext)({
                items: [],
                groupItems: [],
                selectedItem: null,
                onSelectItem: () => {},
                toggleGroupState: () => {}
            }), d = (0, s.memo)((e => {
                let {
                    FavMenuItem: t,
                    layout: l,
                    items: n,
                    groupItems: o = null,
                    selectedItem: r,
                    onSelectItem: i,
                    orderIsLoading: m,
                    toggleGroupState: d
                } = e;
                const p = a[l];
                return (0, u.jsx)(c.Provider, {
                    value: {
                        items: n,
                        groupItems: o,
                        FavMenuItem: t,
                        selectedItem: r,
                        onSelectItem: i,
                        toggleGroupState: d
                    },
                    children: null !== n && void 0 !== n && n.length && !m ? (0, u.jsx)(s.Suspense, {
                        fallback: (0, u.jsx)(p.skeleton, {}),
                        children: (0, u.jsx)(p.view, {})
                    }) : (0, u.jsx)(p.skeleton, {})
                })
            }))
        }
    }
]);
//# sourceMappingURL=27012.4450f668.chunk.js.map