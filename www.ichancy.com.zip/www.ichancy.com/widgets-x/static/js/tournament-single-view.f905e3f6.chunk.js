"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [80055], {
        430984: (e, n, t) => {
            t.d(n, {
                W: () => r,
                Y: () => o
            });
            t(270757);
            var i = t(694227),
                s = (t(7035), t(738281), t(947550), t(570579));
            const a = (0, s.jsx)(i.A, {
                    title: {
                        style: {
                            width: "100%"
                        }
                    },
                    paragraph: !0,
                    active: !0
                }),
                o = () => (0, s.jsxs)("div", {
                    className: "tabsWrapper tabsWrapper--notIsCasino",
                    children: [(0, s.jsx)("div", {
                        className: "sidebarRow",
                        children: a
                    }), (0, s.jsx)("div", {
                        className: "sidebarRow",
                        children: a
                    }), (0, s.jsx)("div", {
                        className: "sidebarRow",
                        children: a
                    })]
                }),
                r = () => (0, s.jsxs)(s.Fragment, {
                    children: [(0, s.jsx)("div", {
                        className: "tournamentSingleView__banner tournamentSingleView__banner__img",
                        children: (0, s.jsx)(i.A.Image, {
                            style: {
                                width: "100%",
                                height: 450
                            }
                        })
                    }), (0, s.jsxs)("div", {
                        className: "tournamentSingleView__infoContainer",
                        children: [(0, s.jsxs)("div", {
                            className: "tournamentSingleView__infoContainer__mainSection",
                            children: [(0, s.jsx)("div", {
                                className: "tournamentSingleView__infoContainer__mainSection__tournamentInfo",
                                children: (0, s.jsx)(i.A, {
                                    title: {
                                        style: {
                                            width: "100%"
                                        }
                                    },
                                    paragraph: !0,
                                    active: !0
                                })
                            }), (0, s.jsx)("div", {
                                className: "tournamentSingleView__infoContainer__mainSection__tournamentInfo",
                                children: (0, s.jsx)(i.A, {
                                    title: {
                                        style: {
                                            width: "100%"
                                        }
                                    },
                                    paragraph: !0,
                                    active: !0
                                })
                            }), (0, s.jsx)("div", {
                                className: "tournamentSingleView__infoContainer__mainSection__subSection",
                                children: a
                            })]
                        }), (0, s.jsx)(o, {})]
                    })]
                })
        },
        132712: (e, n, t) => {
            t.r(n), t.d(n, {
                TournamentSingleView: () => x
            });
            var i = t(365043),
                s = t(507712),
                a = t(995392),
                o = t(555113),
                r = t(542699),
                l = t(679559),
                d = t(989618),
                c = t(430984),
                u = t(185762),
                m = t(490440),
                _ = t(384716),
                h = t(55418),
                p = t(570579);
            const {
                MobileTournamentSingleView: v
            } = (0, d.R)((() => Promise.all([t.e(87161), t.e(34426), t.e(55608), t.e(84107), t.e(81927), t.e(35834), t.e(70136), t.e(90363), t.e(15243), t.e(85123), t.e(77484), t.e(82685), t.e(11216), t.e(23973), t.e(94574), t.e(80192), t.e(40854), t.e(35905), t.e(58073), t.e(87154), t.e(40999), t.e(24757), t.e(95459), t.e(42146), t.e(10795), t.e(90286), t.e(71139), t.e(41591), t.e(82463), t.e(99805)]).then(t.bind(t, 679963)))), {
                DesktopTournamentSingleView: f
            } = (0, d.R)((() => Promise.all([t.e(87161), t.e(34426), t.e(55608), t.e(84107), t.e(81927), t.e(35834), t.e(70136), t.e(90363), t.e(15243), t.e(85123), t.e(77484), t.e(82685), t.e(11216), t.e(23973), t.e(6635), t.e(46979), t.e(31528), t.e(70289), t.e(94574), t.e(18574), t.e(80192), t.e(81643), t.e(11115), t.e(40854), t.e(5256), t.e(61190), t.e(35905), t.e(58073), t.e(87154), t.e(26921)]).then(t.bind(t, 796189)))), x = function(e) {
                let {
                    notNeedSkeleton: n,
                    fromIndex: t
                } = e;
                const d = (0, s.d4)(r.px),
                    x = (0, s.d4)(r.ol),
                    g = (0, _.o)(),
                    {
                        mounted: S
                    } = (0, m.q)(),
                    [b, j] = (0, i.useState)(!1),
                    [w, I] = (0, i.useState)(!0),
                    N = (0, a.zy)(),
                    V = (0, s.d4)(l.wz),
                    k = (0, s.d4)(l.eP),
                    [y, C] = (0, i.useState)(null),
                    [T, P] = (0, i.useState)(null),
                    R = 2 === (null === y || void 0 === y ? void 0 : y.ProductTypeId),
                    A = g.tournamentId;
                return (0, i.useEffect)((() => {
                    document.documentElement.scrollTop = 0, document.body.scrollTop = 0
                }), []), (0, i.useEffect)((() => {
                    if (V.pending || n || !(0, h.F)() && t || !A) y && C(null);
                    else {
                        if (j(!0), x && d[x].length) {
                            const e = d[x].find((e => e.Id === +A));
                            e && C(e)
                        }
                        I(!0), (0, o.OU)(+A, (e => {
                            S.current && (I(!1), C(e.result))
                        }))
                    }!A && b && j(!1)
                }), [N.search, !!V.pending, k]), (0, i.useEffect)((() => {
                    if (!(0, h.F)() && t) return;
                    const e = setInterval((() => {
                        A && (0, o.j2)(+A, (e => {
                            P(null === e || void 0 === e ? void 0 : e.result[0])
                        }))
                    }), 3e4);
                    return () => {
                        e && clearInterval(e)
                    }
                }), [b]), (0, p.jsx)(u.L, {
                    desktop: f,
                    mobile: v,
                    fallback: n || t ? (0, p.jsx)("div", {}) : (0, p.jsx)(c.W, {}),
                    innerProps: {
                        tournamentData: y,
                        visible: b,
                        setVisible: j,
                        loading: w,
                        isSportsTournament: R,
                        fromIndex: t,
                        topPlayerList: T
                    }
                })
            }
        },
        947550: () => {}
    }
]);
//# sourceMappingURL=tournament-single-view.f905e3f6.chunk.js.map