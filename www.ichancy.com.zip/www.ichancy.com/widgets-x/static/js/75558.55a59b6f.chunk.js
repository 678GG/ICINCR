"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [75558], {
        575558: (e, o, t) => {
            t.d(o, {
                j: () => c
            });
            t(365043);
            var i = t(70990),
                s = t(294574);
            const a = s.Ay.div.withConfig({
                    displayName: "style__Container",
                    componentId: "sc-1ko561m-0"
                })(["background-color:var(--v3-black-0);border-bottom:1px solid var(--v3-black-6);justify-content:center;align-items:center;position:relative;padding:0 60px;flex-shrink:0;display:flex;height:48px;z-index:10;left:0;right:0;top:0;"]),
                n = s.Ay.div.withConfig({
                    displayName: "style__BackWrapper",
                    componentId: "sc-1ko561m-1"
                })(["position:absolute;left:0;top:0;bottom:0;display:flex;padding:12px;align-items:center;"]),
                p = s.Ay.span.withConfig({
                    displayName: "style__Title",
                    componentId: "sc-1ko561m-2"
                })(["font-size:18px;color:var(--v3-text-color);font-weight:600;"]),
                l = s.Ay.span.withConfig({
                    displayName: "style__Extra",
                    componentId: "sc-1ko561m-3"
                })(["position:absolute;top:0;right:0;bottom:0;padding:12px;display:flex;align-items:center;"]);
            var r = t(570579);
            const c = e => (0, r.jsxs)(a, {
                className: e.isLogin ? "popup-header" : "",
                children: [e.goBack && (0, r.jsx)(n, {
                    className: "back-wrapper",
                    children: (0, r.jsx)(i.o, {
                        onClick: e.goBack
                    })
                }), (0, r.jsx)(p, {
                    children: e.title
                }), (0, r.jsx)(l, {
                    className: "extra-wrapper",
                    children: e.extra
                })]
            })
        }
    }
]);
//# sourceMappingURL=75558.55a59b6f.chunk.js.map