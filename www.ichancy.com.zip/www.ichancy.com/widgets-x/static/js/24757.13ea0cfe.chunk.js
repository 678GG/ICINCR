"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [24757], {
        971247: (e, t, n) => {
            n.d(t, {
                E: () => o
            });
            let o = function(e) {
                return e.topLeague = "topLeague", e.boostedOdds = "boostedOdds", e.todayEvents = "todayEvents", e.topMatches = "topMatches", e.multiples = "multiples", e.outright = "outright", e.AllESports = "AllESports", e.all = "all", e.favourites = "favourites", e.team = "team", e.myBets = "myBets", e.betBuilder = "betBuilder", e.coupon = "coupon", e
            }({})
        },
        424757: (e, t, n) => {
            n.d(t, {
                Gf: () => $,
                M3: () => O,
                Mw: () => u,
                NI: () => g,
                Vv: () => S,
                Ye: () => f,
                de: () => s,
                e2: () => w,
                fi: () => _,
                i9: () => h,
                ic: () => p,
                nm: () => A
            });
            var o = n(971247),
                i = n(179177),
                l = n(263847),
                c = n(10922),
                r = n(718402),
                a = n(55418);
            const s = e => {
                    const t = (e = decodeURI(e)).indexOf("?");
                    t > -1 && (e = e.slice(0, t));
                    const n = e.indexOf(`/${i.Ay.SPORTSBOOK_MOUNT_PATH}/`);
                    n > -1 && (e = e.slice(0, n));
                    const o = e.indexOf(`/${i.Ay.CASINO_MOUNT_PATH}/`);
                    return o > -1 && (e = e.slice(0, o)), e.replace(/\/$/, "")
                },
                d = e => {
                    if (e = (e = decodeURI(e)).replace(/([^:]\/)\/+/g, "$1"), !i.Ay.SHOW_GAMBLING_AREAS || !i.Ay.GAMBLING_AREAS) return !1;
                    if (i.Ay.SHOW_GAMBLING_AREAS && i.Ay.GAMBLING_AREAS && !i.Ay.MOCKED_DATA) {
                        const t = i.Ay.GAMBLING_AREAS,
                            n = f();
                        let o = null;
                        return Object.keys(t).forEach((n => {
                            t[n].forEach((t => {
                                s(e) === s(t) && (o = n)
                            }))
                        })), !(!n || !o || o === s(n)) && (window.postMessage({
                            action: "gambling_area_changed",
                            destinationUrl: e
                        }, "*"), !0)
                    }
                    return !0
                },
                A = function(e) {
                    let t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                    return `${e.replace(/\/:.*/i,"").replace(/\/$/,"")}${t?`/${i.Ay.SPORTSBOOK_MOUNT_PATH}`:""}`
                };

            function p(e) {
                let t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
                    n = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
                const o = n ? arguments.length > 3 && void 0 !== arguments[3] && arguments[3] ? "" : i.Ay.CASINO_MOUNT_PATH : `${i.Ay.SPORTSBOOK_MOUNT_PATH}`,
                    l = new RegExp(`/${o}(?![-a-zA-Z0-9]).*$`),
                    c = e.match(l);
                if (null !== c && void 0 !== c && c.length) {
                    const n = e.lastIndexOf(c.pop()),
                        i = `${e.slice(0,n)}/${o}`.replace(/(\/)\/+/g, "$1");
                    return t ? [!1, i] : i
                }
                let r = `${e}/${o}`.replace(/(\/)\/+/g, "$1");
                return n && (r = r.replace(/\/$/, "")), t ? [!c, `${r}${n?window.location.search:""}`] : r
            }
            const O = e => `${e.sport?`/${e.sport}`:""}${e.region?`/${e.region}`:""}${e.competition?`/${e.competition}`:""}${e.game?`/${e.game}`:""}`,
                $ = e => {
                    const t = r.dB.join("|"),
                        n = new RegExp(`/${i.Ay.SPORTSBOOK_MOUNT_PATH}/(${t})`, "gi");
                    let l;
                    return window.getPathname().search(n) > -1 ? (window.getPathname().includes(o.E.team) && e.includes(":competition") && (0, a.F)() && (e = e.replace(":competition", ":competition?")), l = `${p(window.getPathname())}/:category${e}`) : l = `${p(window.getPathname())}${e}`, l
                },
                g = e => {
                    const t = new RegExp(`/${i.Ay.SPORTSBOOK_MOUNT_PATH}.*$`),
                        n = e.match(t);
                    if (null !== n && void 0 !== n && n.length) {
                        const t = e.lastIndexOf(n.pop());
                        return e.slice(t)
                    }
                    return e
                },
                u = e => {
                    const t = e.replace(/\?.*$/, "").replace(/\/$/, ""),
                        n = decodeURIComponent(window.location.href.replace(/\?.*$/, "").replace(/\/$/, "")),
                        o = new RegExp(`/(${i.Ay.CASINO_MOUNT_PATH}|${i.Ay.SPORTSBOOK_MOUNT_PATH})/`),
                        [l] = t.split(o),
                        [c] = n.split(o);
                    return l !== (c || "")
                },
                _ = e => e.slice(window.origin.length),
                h = () => {
                    var e;
                    const t = window.location.pathname.slice(window.location.pathname.lastIndexOf(i.Ay.CASINO_MOUNT_PATH) + (null === (e = i.Ay.CASINO_MOUNT_PATH) || void 0 === e ? void 0 : e.length) + 1),
                        n = {},
                        [o, r, a] = t.split("/");
                    if (a) {
                        const [e, t] = (0, l.P)(a, "-"), [o, i] = (0, l.P)(t, "-");
                        n.gameId = e, n.gameExternalId = o, n.gameName = (0, c.J)(i)
                    }
                    return r && (n.providerName = (0, c.J)(r)), o && (n.categoryId = o), n
                },
                w = function(e) {
                    let t = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
                        n = arguments.length > 3 ? arguments[3] : void 0,
                        o = arguments.length > 4 ? arguments[4] : void 0;
                    if (arguments.length > 1 && void 0 !== arguments[1] && arguments[1]) {
                        const t = `${window.location.origin}${n?`/${n}`:""}/${e}`,
                            i = new URL(t);
                        i.search = "", d(t) || ("_blank" === o ? window.open(i.toString(), o) : window.location.href = i.toString())
                    }
                    t && (d(e) || ("_blank" === o ? window.open(e, o) : window.location.href = e))
                },
                f = () => {
                    let e = null;
                    if (i.Ay.SHOW_GAMBLING_AREAS && i.Ay.GAMBLING_AREAS && !i.Ay.MOCKED_DATA) {
                        const t = i.Ay.GAMBLING_AREAS;
                        Object.keys(t).forEach((n => {
                            t[n].forEach((t => {
                                s(window.location.href) === s(t) && (e = n)
                            }))
                        }))
                    }
                    return e
                },
                S = function(e, t) {
                    let n = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
                    let o = `${e.replace(/\/:.*/i,"").replace(/\/$/,"")}${n?`/${i.Ay.SPORTSBOOK_MOUNT_PATH}`:""}`;
                    return t && (o = `${o.slice(0,o.lastIndexOf("/"))}/${t}${o.slice(o.lastIndexOf("/"))}`), o
                }
        },
        10922: (e, t, n) => {
            n.d(t, {
                J: () => o,
                a: () => i
            });
            const o = e => e.replace(/[-]/g, " ").replace(/(^|\s)\S/g, (e => e.toUpperCase())).trim(),
                i = e => e.trim().toLowerCase().replace(/\s/g, "-").replace(/#/g, "")
        },
        263847: (e, t, n) => {
            n.d(t, {
                P: () => o
            });
            const o = function(e) {
                let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
                return [null === e || void 0 === e ? void 0 : e.slice(0, e.indexOf(t)), null === e || void 0 === e ? void 0 : e.slice(e.indexOf(t) + 1)]
            }
        }
    }
]);
//# sourceMappingURL=24757.13ea0cfe.chunk.js.map