"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [12967], {
        512967: (e, n, t) => {
            t.r(n), t.d(n, {
                default: () => h
            });
            var r = t(662179),
                o = t(991462),
                c = t(476867),
                a = t(392488),
                s = t(56476),
                u = t(253218),
                i = t(69834),
                l = t(545501),
                p = t(365043),
                d = t(498139),
                f = t.n(d),
                y = function(e) {
                    (0, i.A)(t, e);
                    var n = (0, l.A)(t);

                    function t(e) {
                        var r;
                        (0, s.A)(this, t), (r = n.call(this, e)).handleChange = function(e) {
                            var n = r.props,
                                t = n.disabled,
                                o = n.onChange;
                            t || ("checked" in r.props || r.setState({
                                checked: e.target.checked
                            }), o && o({
                                target: (0, a.A)((0, a.A)({}, r.props), {}, {
                                    checked: e.target.checked
                                }),
                                stopPropagation: function() {
                                    e.stopPropagation()
                                },
                                preventDefault: function() {
                                    e.preventDefault()
                                },
                                nativeEvent: e.nativeEvent
                            }))
                        }, r.saveInput = function(e) {
                            r.input = e
                        };
                        var o = "checked" in e ? e.checked : e.defaultChecked;
                        return r.state = {
                            checked: o
                        }, r
                    }
                    return (0, u.A)(t, [{
                        key: "focus",
                        value: function() {
                            this.input.focus()
                        }
                    }, {
                        key: "blur",
                        value: function() {
                            this.input.blur()
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e, n = this.props,
                                t = n.prefixCls,
                                a = n.className,
                                s = n.style,
                                u = n.name,
                                i = n.id,
                                l = n.type,
                                d = n.disabled,
                                y = n.readOnly,
                                h = n.tabIndex,
                                b = n.onClick,
                                k = n.onFocus,
                                v = n.onBlur,
                                O = n.onKeyDown,
                                g = n.onKeyPress,
                                m = n.onKeyUp,
                                P = n.autoFocus,
                                j = n.value,
                                C = n.required,
                                A = (0, c.A)(n, ["prefixCls", "className", "style", "name", "id", "type", "disabled", "readOnly", "tabIndex", "onClick", "onFocus", "onBlur", "onKeyDown", "onKeyPress", "onKeyUp", "autoFocus", "value", "required"]),
                                w = Object.keys(A).reduce((function(e, n) {
                                    return "aria-" !== n.substr(0, 5) && "data-" !== n.substr(0, 5) && "role" !== n || (e[n] = A[n]), e
                                }), {}),
                                K = this.state.checked,
                                D = f()(t, a, (e = {}, (0, o.A)(e, "".concat(t, "-checked"), K), (0, o.A)(e, "".concat(t, "-disabled"), d), e));
                            return p.createElement("span", {
                                className: D,
                                style: s
                            }, p.createElement("input", (0, r.A)({
                                name: u,
                                id: i,
                                type: l,
                                required: C,
                                readOnly: y,
                                disabled: d,
                                tabIndex: h,
                                className: "".concat(t, "-input"),
                                checked: !!K,
                                onClick: b,
                                onFocus: k,
                                onBlur: v,
                                onKeyUp: m,
                                onKeyDown: O,
                                onKeyPress: g,
                                onChange: this.handleChange,
                                autoFocus: P,
                                ref: this.saveInput,
                                value: j
                            }, w)), p.createElement("span", {
                                className: "".concat(t, "-inner")
                            }))
                        }
                    }], [{
                        key: "getDerivedStateFromProps",
                        value: function(e, n) {
                            return "checked" in e ? (0, a.A)((0, a.A)({}, n), {}, {
                                checked: e.checked
                            }) : null
                        }
                    }]), t
                }(p.Component);
            y.defaultProps = {
                prefixCls: "rc-checkbox",
                className: "",
                style: {},
                type: "checkbox",
                defaultChecked: !1,
                onFocus: function() {},
                onBlur: function() {},
                onChange: function() {},
                onKeyDown: function() {},
                onKeyPress: function() {},
                onKeyUp: function() {}
            };
            const h = y
        },
        392488: (e, n, t) => {
            t.d(n, {
                A: () => c
            });
            var r = t(991462);

            function o(e, n) {
                var t = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    n && (r = r.filter((function(n) {
                        return Object.getOwnPropertyDescriptor(e, n).enumerable
                    }))), t.push.apply(t, r)
                }
                return t
            }

            function c(e) {
                for (var n = 1; n < arguments.length; n++) {
                    var t = null != arguments[n] ? arguments[n] : {};
                    n % 2 ? o(Object(t), !0).forEach((function(n) {
                        (0, r.A)(e, n, t[n])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : o(Object(t)).forEach((function(n) {
                        Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(t, n))
                    }))
                }
                return e
            }
        },
        476867: (e, n, t) => {
            function r(e, n) {
                if (null == e) return {};
                var t, r, o = function(e, n) {
                    if (null == e) return {};
                    var t, r, o = {},
                        c = Object.keys(e);
                    for (r = 0; r < c.length; r++) t = c[r], n.indexOf(t) >= 0 || (o[t] = e[t]);
                    return o
                }(e, n);
                if (Object.getOwnPropertySymbols) {
                    var c = Object.getOwnPropertySymbols(e);
                    for (r = 0; r < c.length; r++) t = c[r], n.indexOf(t) >= 0 || Object.prototype.propertyIsEnumerable.call(e, t) && (o[t] = e[t])
                }
                return o
            }
            t.d(n, {
                A: () => r
            })
        }
    }
]);
//# sourceMappingURL=12967.f7239d01.chunk.js.map