"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [14971], {
        714971: (e, n, o) => {
            o.d(n, {
                a: () => C,
                P: () => w
            });
            var i = o(365043),
                t = o(151238),
                a = o(507712),
                l = o(841591),
                d = o(701616),
                s = o(273549),
                r = o(735905),
                c = (o(461243), o(923233)),
                m = o(294574),
                p = o(55418);
            const x = (0, m.Ay)(c.A).withConfig({
                    displayName: "style__ModalWrapper",
                    componentId: "sc-xfnom2-0"
                })(["[class*='-modal-content']{border:", ";}", ""], (e => e.hideBorder ? "none" : "1px solid var(--v3-black-6)"), (e => {
                    var n, o, i;
                    return (0, p.F)() ? "\n      border-radius: 5px !important;\n  " : `${null!==(n=!(null!==(o=e.style)&&void 0!==o&&o.padding))&&void 0!==n?n:"padding: 32px 0 !important"};\n        max-width: ${e.maxWidth}${"string"===typeof e.maxWidth?"":"px"} !important;\n\n        [class*='-modal-content'] {\n          height: 100%;\n          overflow: hidden;\n          min-height: 220px;\n          border-radius: 12px;\n          box-shadow: var(--v3-shadow-1-down);\n          padding: ${null!==(i=e.contentPadding)&&void 0!==i?i:24}px;\n          &.status-checker-modal{\n            height:auto;\n            box-shadow:none;\n            padding:0;\n          }\n        }`
                })),
                h = m.Ay.div.withConfig({
                    displayName: "style__ImageWrapper",
                    componentId: "sc-xfnom2-1"
                })(["min-height:16px;margin-bottom:12px;"]),
                g = m.Ay.div.withConfig({
                    displayName: "style__Title",
                    componentId: "sc-xfnom2-2"
                })(["line-height:1;font-size:24px;font-weight:600;text-align:center;margin-bottom:12px;letter-spacing:0.48px;color:var(--v3-primary-6);"]),
                u = m.Ay.div.withConfig({
                    displayName: "style__Body",
                    componentId: "sc-xfnom2-3"
                })(["height:100%;a{text-decoration:underline;color:var(--v3-text-color);font-weight:600;}ul{padding:8px 0px 0px 18px;}"]),
                b = m.Ay.div.withConfig({
                    displayName: "style__Footer",
                    componentId: "sc-xfnom2-4"
                })(["gap:8px;display:flex;margin-top:24px;flex-direction:", ";color:var(--v3-text-color);& > button{flex:1;&:first-child{margin:0 !important;}}"], (e => e.direction));
            var v = o(140999),
                y = o(384716),
                f = o(570579);
            const _ = e => {
                    let {
                        title: n,
                        iconLib: o,
                        iconName: i,
                        iconTheme: t,
                        onCancel: a
                    } = e;
                    return (0, f.jsxs)("div", {
                        className: "modalCustomHeader",
                        children: [(0, f.jsxs)("div", {
                            className: "modalCustomHeader__iconContainer",
                            children: [(0, f.jsx)(r.GlobalIcon, {
                                lib: o,
                                name: i,
                                theme: t,
                                size: 24,
                                className: "modalCustomHeader__icon"
                            }), (0, f.jsx)("span", {
                                className: "modalCustomHeader__title",
                                children: n
                            })]
                        }), (0, f.jsx)(r.GlobalIcon, {
                            lib: "generic",
                            name: "close",
                            theme: "default",
                            size: 20,
                            className: "modal__close-icon",
                            onClick: a
                        })]
                    })
                },
                C = e => {
                    let {
                        title: n,
                        image: o,
                        children: c,
                        zIndex: m,
                        align: b = "left",
                        maxWidth: C = 1272,
                        padding: w,
                        wrapperPadding: N,
                        bodyStyle: I,
                        style: j,
                        closeIcon: z,
                        visible: k,
                        renderInBody: A = !1,
                        preventScrollDisable: W = !1,
                        hideBorder: $,
                        destroyOnClose: B = !0,
                        customHeader: H,
                        contentPadding: P,
                        ...F
                    } = e;
                    const G = (0, a.wA)(),
                        S = (0, a.d4)(l.I1),
                        T = (0, a.d4)(s.Co),
                        L = (0, i.useRef)((0, t.A)()),
                        {
                            accounts: O
                        } = (0, y.o)(),
                        M = (0, i.useMemo)((() => !!O || S.size > 0 || T && (0, p.F)() || W), [O, S.size, T, W]);
                    (0, v.v)(k, M);
                    const R = e => {
                        const n = new Set(S);
                        n[e](L.current), G((0, d.mO)(n))
                    };
                    return (0, i.useEffect)((() => {
                        if (k) return R("add"), () => {
                            R("delete")
                        }
                    }), [k]), (0, f.jsxs)(x, { ...F,
                        hideBorder: $,
                        zIndex: m,
                        maxWidth: C,
                        footer: null,
                        destroyOnClose: B,
                        getContainer: A && document.body,
                        contentPadding: H ? 0 : P,
                        bodyStyle: I || {
                            padding: `${H?0:null!==w&&void 0!==w?w:12}px`,
                            textAlign: b
                        },
                        style: j || {
                            borderRadius: "12px",
                            padding: `${null!==N&&void 0!==N?N:8}px`
                        },
                        closeIcon: z || (0, f.jsx)(r.GlobalIcon, {
                            lib: "generic",
                            name: "closeFill",
                            theme: "default",
                            size: 24,
                            className: "modal__close-icon"
                        }),
                        visible: k,
                        children: [H && (0, f.jsx)(_, {
                            iconName: H.iconName,
                            iconTheme: H.iconTheme,
                            iconLib: H.iconLib,
                            title: H.title,
                            onCancel: () => {
                                H.onClose && H.onClose()
                            }
                        }), o && (0, f.jsx)(h, {
                            className: "modalImageWrapper",
                            children: (0, f.jsx)(r.GlobalIcon, {
                                lib: o.lib,
                                name: o.name,
                                theme: o.theme,
                                size: o.size ? o.size : 72,
                                className: "modal__icon"
                            })
                        }), !!n && (0, f.jsx)(g, {
                            className: "modal-title",
                            children: n
                        }), (0, f.jsx)(u, {
                            children: c
                        })]
                    })
                },
                w = e => {
                    let {
                        direction: n = "row",
                        children: o,
                        className: i,
                        ...t
                    } = e;
                    return (0, f.jsx)(b, {
                        className: i,
                        direction: n,
                        ...t,
                        children: o
                    })
                }
        }
    }
]);
//# sourceMappingURL=14971.464dabd1.chunk.js.map