"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [99701], {
        199701: (e, s, o) => {
            Object.defineProperty(s, "__esModule", {
                value: !0
            }), s.PresetStatusColorTypes = s.PresetColorTypes = void 0;
            var r = o(288285),
                l = (0, r.tuple)("success", "processing", "error", "default", "warning");
            s.PresetStatusColorTypes = l;
            var t = (0, r.tuple)("pink", "red", "yellow", "orange", "cyan", "green", "blue", "purple", "geekblue", "magenta", "volcano", "gold", "lime");
            s.PresetColorTypes = t
        }
    }
]);
//# sourceMappingURL=99701.ba1e3752.chunk.js.map