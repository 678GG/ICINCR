"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [48070], {
        48070: (e, a, s) => {
            s.d(a, {
                D: () => l
            });
            s(270757);
            var o = s(694227),
                t = s(889181),
                r = s(55418),
                i = (s(183215), s(687886), s(224532), s(570579));
            const l = e => {
                let {
                    extraStyle: a
                } = e;
                return (0, i.jsx)("div", {
                    className: (0, t.A)([{
                        "x-casinoGameCardMobile": (0, r.F)(),
                        "x-casinoGameCardDesktop": !(0, r.F)(),
                        cardSkeleton__position: a
                    }]),
                    children: (0, i.jsx)("div", {
                        className: "x-casinoGameCardImageWrapper x-casinoGameCardImageWrapper__skeleton",
                        children: (0, i.jsx)(o.A.Image, {
                            className: "x-casinoGameCardImageSkeleton",
                            style: {
                                position: "absolute",
                                left: 0,
                                top: 0,
                                right: 0,
                                bottom: 0,
                                width: "100%",
                                height: "100%"
                            }
                        })
                    })
                })
            }
        },
        687886: () => {},
        224532: () => {},
        183215: () => {}
    }
]);
//# sourceMappingURL=48070.74b93770.chunk.js.map