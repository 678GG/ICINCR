"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [80192], {
        280192: (n, e, t) => {
            t.d(e, {
                Mz: () => c
            });
            var r = "NOT_FOUND";
            var u = function(n, e) {
                return n === e
            };

            function o(n, e) {
                var t = "object" === typeof e ? e : {
                        equalityCheck: e
                    },
                    o = t.equalityCheck,
                    i = void 0 === o ? u : o,
                    c = t.maxSize,
                    f = void 0 === c ? 1 : c,
                    a = t.resultEqualityCheck,
                    l = function(n) {
                        return function(e, t) {
                            if (null === e || null === t || e.length !== t.length) return !1;
                            for (var r = e.length, u = 0; u < r; u++)
                                if (!n(e[u], t[u])) return !1;
                            return !0
                        }
                    }(i),
                    p = 1 === f ? function(n) {
                        var e;
                        return {
                            get: function(t) {
                                return e && n(e.key, t) ? e.value : r
                            },
                            put: function(n, t) {
                                e = {
                                    key: n,
                                    value: t
                                }
                            },
                            getEntries: function() {
                                return e ? [e] : []
                            },
                            clear: function() {
                                e = void 0
                            }
                        }
                    }(l) : function(n, e) {
                        var t = [];

                        function u(n) {
                            var u = t.findIndex((function(t) {
                                return e(n, t.key)
                            }));
                            if (u > -1) {
                                var o = t[u];
                                return u > 0 && (t.splice(u, 1), t.unshift(o)), o.value
                            }
                            return r
                        }
                        return {
                            get: u,
                            put: function(e, o) {
                                u(e) === r && (t.unshift({
                                    key: e,
                                    value: o
                                }), t.length > n && t.pop())
                            },
                            getEntries: function() {
                                return t
                            },
                            clear: function() {
                                t = []
                            }
                        }
                    }(f, l);

                function s() {
                    var e = p.get(arguments);
                    if (e === r) {
                        if (e = n.apply(null, arguments), a) {
                            var t = p.getEntries().find((function(n) {
                                return a(n.value, e)
                            }));
                            t && (e = t.value)
                        }
                        p.put(arguments, e)
                    }
                    return e
                }
                return s.clearCache = function() {
                    return p.clear()
                }, s
            }

            function i(n) {
                for (var e = arguments.length, t = new Array(e > 1 ? e - 1 : 0), r = 1; r < e; r++) t[r - 1] = arguments[r];
                return function() {
                    for (var e = arguments.length, r = new Array(e), u = 0; u < e; u++) r[u] = arguments[u];
                    var o, i = 0,
                        c = {
                            memoizeOptions: void 0
                        },
                        f = r.pop();
                    if ("object" === typeof f && (c = f, f = r.pop()), "function" !== typeof f) throw new Error("createSelector expects an output function after the inputs, but received: [" + typeof f + "]");
                    var a = c.memoizeOptions,
                        l = void 0 === a ? t : a,
                        p = Array.isArray(l) ? l : [l],
                        s = function(n) {
                            var e = Array.isArray(n[0]) ? n[0] : n;
                            if (!e.every((function(n) {
                                    return "function" === typeof n
                                }))) {
                                var t = e.map((function(n) {
                                    return "function" === typeof n ? "function " + (n.name || "unnamed") + "()" : typeof n
                                })).join(", ");
                                throw new Error("createSelector expects all input-selectors to be functions, but received the following types: [" + t + "]")
                            }
                            return e
                        }(r),
                        v = n.apply(void 0, [function() {
                            return i++, f.apply(null, arguments)
                        }].concat(p)),
                        y = n((function() {
                            for (var n = [], e = s.length, t = 0; t < e; t++) n.push(s[t].apply(null, arguments));
                            return o = v.apply(null, n)
                        }));
                    return Object.assign(y, {
                        resultFunc: f,
                        memoizedResultFunc: v,
                        dependencies: s,
                        lastResult: function() {
                            return o
                        },
                        recomputations: function() {
                            return i
                        },
                        resetRecomputations: function() {
                            return i = 0
                        }
                    }), y
                }
            }
            var c = i(o)
        }
    }
]);
//# sourceMappingURL=80192.c4fbc21c.chunk.js.map