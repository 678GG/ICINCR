"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [66712], {
        66712: (e, t, l) => {
            l.r(t), l.d(t, {
                default: () => E
            });
            var a, r, n, L, i, C, c, f, p, h = l(365043);

            function o() {
                return o = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var l = arguments[t];
                        for (var a in l) Object.prototype.hasOwnProperty.call(l, a) && (e[a] = l[a])
                    }
                    return e
                }, o.apply(this, arguments)
            }

            function s(e, t) {
                let {
                    title: l,
                    titleId: s,
                    ...d
                } = e;
                return h.createElement("svg", o({
                    width: 32,
                    height: 32,
                    viewBox: "0 0 32 32",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    ref: t,
                    "aria-labelledby": s
                }, d), l ? h.createElement("title", {
                    id: s
                }, l) : null, a || (a = h.createElement("path", {
                    d: "M21.8252 11.4043L27.5269 12.9597L31.6738 8.81289L29.0818 4.14777L21.8252 11.4043Z",
                    fill: "#26B99A"
                })), r || (r = h.createElement("path", {
                    d: "M20.2697 9.84955L18.7148 4.14783L22.8617 0.000976562L27.5268 2.59298L20.2697 9.84955Z",
                    fill: "#14A085"
                })), n || (n = h.createElement("path", {
                    d: "M17.419 14.2554C17.7116 14.548 17.8773 14.9171 17.9293 15.3L29.0819 4.14798C29.4922 3.68627 29.5173 3.03084 29.0807 2.59427C28.6441 2.1577 27.9888 2.18284 27.5271 2.59313L16.375 13.7451C16.7573 13.7977 17.127 13.9634 17.419 14.2554Z",
                    fill: "#BAD4E2"
                })), L || (L = h.createElement("path", {
                    d: "M6.30101 25.9449L5.72958 25.3734C5.17412 24.818 5.17412 23.9089 5.72958 23.3529L15.113 13.9694C15.6684 13.414 16.5776 13.414 17.1336 13.9694L17.705 14.5409C18.2604 15.0963 18.2604 16.0054 17.705 16.5614L8.32158 25.9449C7.76558 26.5003 6.85644 26.5003 6.30101 25.9449Z",
                    fill: "#ECF0F1"
                })), i || (i = h.createElement("path", {
                    d: "M6.76172 22.3225L9.35372 24.9145L10.1618 24.1063L7.56983 21.5143L6.76172 22.3225Z",
                    fill: "#BDC3C7"
                })), C || (C = h.createElement("path", {
                    d: "M8.72095 20.3626L11.313 22.9546L12.1211 22.1465L9.52906 19.5545L8.72095 20.3626Z",
                    fill: "#BDC3C7"
                })), c || (c = h.createElement("path", {
                    d: "M10.7922 18.2894L13.3839 20.881L14.192 20.0729L11.6004 17.4813L10.7922 18.2894Z",
                    fill: "#BDC3C7"
                })), f || (f = h.createElement("path", {
                    d: "M13.6748 15.4072L12.8667 16.2153L15.4587 18.8073L16.2668 17.9992L13.6748 15.4072Z",
                    fill: "#BDC3C7"
                })), p || (p = h.createElement("path", {
                    d: "M6.30131 25.9449L5.72989 25.3734C5.68929 25.3329 5.65843 25.2872 5.62357 25.2432L0.167571 30.6992C-0.0558571 30.9226 -0.0558571 31.2837 0.167571 31.5072C0.279 31.6186 0.425286 31.6746 0.571571 31.6746C0.717857 31.6746 0.864143 31.6186 0.975571 31.5072L6.43154 26.0512C6.3876 26.0163 6.34189 25.9854 6.30131 25.9449Z",
                    fill: "#BDC3C7"
                })))
            }
            const d = h.forwardRef(s),
                E = (l.p, d)
        }
    }
]);
//# sourceMappingURL=66712.e9ada3c1.chunk.js.map