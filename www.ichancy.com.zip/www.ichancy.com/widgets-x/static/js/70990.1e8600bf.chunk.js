"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [70990], {
        70990: (e, o, s) => {
            s.d(o, {
                o: () => a
            });
            var t = s(735905),
                n = s(570579);
            const a = e => (0, n.jsx)(t.GlobalIcon, {
                lib: "generic",
                name: "arrowLeft",
                theme: "default",
                size: 12,
                className: "backButton backButton__btn",
                onClick: e.onClick,
                skeleton: !0,
                keepInCache: !0
            })
        }
    }
]);
//# sourceMappingURL=70990.1e8600bf.chunk.js.map