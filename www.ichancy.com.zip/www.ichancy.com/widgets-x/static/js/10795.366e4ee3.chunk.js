"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [10795], {
        810795: (o, s, e) => {
            e.d(s, {
                R: () => i
            });
            var n = e(365043),
                t = e(995392),
                a = e(816343),
                c = e(384716),
                l = e(424757),
                u = e(242146);
            const i = () => {
                const o = (0, t.W6)(),
                    {
                        mode: s
                    } = (0, c.o)();
                return (0, n.useMemo)((() => () => {
                    let e;
                    "real" === s && (e = `${(0,l.ic)(window.location.pathname,!1,!0)}/${u.Hk.all.id}`), (0, a.qx)("login", e), o.push((0, a.U7)({
                        accounts: "*",
                        login: "*"
                    }))
                }), [])
            }
        }
    }
]);
//# sourceMappingURL=10795.366e4ee3.chunk.js.map