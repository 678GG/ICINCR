"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [62330], {
        462330: (o, n, i) => {
            i.d(n, {
                I: () => E
            });
            var e = i(322908),
                t = i.n(e),
                l = i(179177),
                A = i(123213),
                d = i(320308),
                _ = i(556785),
                a = i(55418),
                c = i(816343),
                r = i(424757),
                s = i(261988),
                g = i(797760),
                I = i(589910);
            const L = `Launch${l.Ay.SHOW_GAMBLING_WITH_LOGO&&(0,a.F)()?"Uk":""}Game`,
                E = function(o) {
                    var n;
                    let i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "fun",
                        e = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
                        E = arguments.length > 3 ? arguments[3] : void 0,
                        u = arguments.length > 4 ? arguments[4] : void 0,
                        R = arguments.length > 5 ? arguments[5] : void 0,
                        w = arguments.length > 6 ? arguments[6] : void 0,
                        y = arguments.length > 7 ? arguments[7] : void 0;
                    const G = document.documentElement.lang,
                        v = (0, I.F)(),
                        N = R ? `${window.location.origin}${(0,c.XZ)("casinoStartingRoute",!1,!1)||(0,r.ic)(window.location.pathname,!1,!0)}` : w ? window.location.origin : window.location.href,
                        O = `https://${l.Ay.CASINO_GAME_URL_PREFIX}.${v}/${u?"":L}?`;
                    let U = 1;
                    l.c6 ? U = 4 : l.AX ? U = 3 : (0, a.F)() && (U = 2);
                    const h = {
                        partnerId: l.Ay.DECENTRALIZED_CASINO_PARTNER_ID || l.Ay.PARTNER_ID,
                        devicetypeid: U,
                        gameId: o,
                        language: y || (null === (n = window.currentLanguageObject) || void 0 === n ? void 0 : n.casinoLangPrefix) || s.WB[G] || s.WB[G.slice(0, 2)] || l.Ay.CURRENT_LANGUAGE.slice(0, 2),
                        openType: i,
                        isMobile: (0, a.F)(),
                        deposit_url: l.Ay.CURRENT_LANGUAGE_PREFIX === l.Ay.DEFAULT_LANGUAGE_PREFIX ? `${window.location.origin}${g.L.deposit}` : `${window.location.origin}/${l.Ay.CURRENT_LANGUAGE_PREFIX}${g.L.deposit}`,
                        browserUrl: window.location.href,
                        logo_url: l.Ay.SITE_LOGO_URL || void 0,
                        exitUrl: N
                    };
                    if (l.Ay.CASINO_MOBILE_IFRAME && (0, a.F)() && "hidden" !== document.body.style.overflow && !E && document.body.classList.add("no-scroll"), "real" === i) {
                        var p;
                        const o = null === (p = JSON.parse(A.A.getItem((0, _.U)("account", "AUTH_DATA")))) || void 0 === p ? void 0 : p.auth_token;
                        o ? h.token = o : (0, a.F)() && (0, d.$)("User not logged in for playing REAL")
                    }
                    let $ = `${O}${t().stringify(h)}`;
                    return e && ($ += `&${e.split('"').join("")}`), u && ($ += u), l.Ay.SHOW_GAMBLING_WITH_LOGO && !l.Ay.CASINO_MOBILE_IFRAME && ($ += `&gambcomURL=${l.Ay.CASINO_GAMBLING_LOGO_URL}`), $
                }
        }
    }
]);
//# sourceMappingURL=62330.b0730378.chunk.js.map