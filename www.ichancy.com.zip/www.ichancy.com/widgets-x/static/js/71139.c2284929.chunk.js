"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [71139], {
        971139: (T, p, a) => {
            a.d(p, {
                DF: () => d,
                Mc: () => s,
                NW: () => o,
                QI: () => k,
                RL: () => S,
                UG: () => t,
                XO: () => e,
                XU: () => E,
                dr: () => l,
                tL: () => _
            });
            var y = a(203754);
            const E = T => ({
                    type: y.k.SET_DATE,
                    payload: T
                }),
                k = T => ({
                    type: y.k.SET_COMPETITION,
                    payload: T
                }),
                t = T => ({
                    type: y.k.SET_TEAM,
                    payload: T
                }),
                S = T => ({
                    type: y.k.SET_STATUS,
                    payload: T
                }),
                _ = T => ({
                    type: y.k.SET_SPORT,
                    payload: T
                }),
                e = T => ({
                    type: y.k.SET_DATA,
                    payload: T
                }),
                o = () => ({
                    type: y.k.SET_TRIGGER
                }),
                s = () => ({
                    type: y.k.SET_CURRENT_STATUS
                }),
                d = T => ({
                    type: y.k.SET_DATA_LOADING,
                    payload: T
                }),
                l = () => ({
                    type: y.k.RESET_FILTERS
                })
        }
    }
]);
//# sourceMappingURL=71139.c2284929.chunk.js.map