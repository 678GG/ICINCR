"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [35820], {
        435820: (a, e, t) => {
            t.d(e, {
                $H: () => c,
                $V: () => A,
                Ak: () => M,
                B8: () => T,
                T: () => o,
                VT: () => u,
                Xc: () => n,
                YV: () => y,
                aZ: () => O,
                cl: () => l,
                d4: () => d,
                is: () => m
            });
            var i = t(197262),
                s = t(105305),
                r = t(55418);
            const d = {
                    id: 31,
                    alias: "horse-racing"
                },
                l = {
                    id: 184,
                    alias: "greyhounds-racing"
                },
                n = {
                    id: 180,
                    alias: "future-races"
                },
                c = {
                    id: 153,
                    alias: "special-races"
                },
                o = [d.id, l.id, n.id, c.id],
                A = {
                    "horse-racing": d.id,
                    "greyhounds-racing": l.id,
                    "future-races": n.id,
                    "special-races": c.id
                },
                O = "Favourite",
                u = [O, "2nd Favourite"],
                y = [{
                    label: i.A.t("pages.horseRacing"),
                    alias: d.alias,
                    sport: d.id,
                    icon: "horseracing"
                }, {
                    label: i.A.t("pages.greyhounds"),
                    alias: l.alias,
                    sport: l.id,
                    icon: "sisgreyhound"
                }],
                R = new Date,
                g = {
                    0: {
                        name: i.A.t("date.sunday")
                    },
                    1: {
                        name: i.A.t("date.monday")
                    },
                    2: {
                        name: i.A.t("date.tuesday")
                    },
                    3: {
                        name: i.A.t("date.wednesday")
                    },
                    4: {
                        name: i.A.t("date.thursday")
                    },
                    5: {
                        name: i.A.t("date.friday")
                    },
                    6: {
                        name: i.A.t("date.saturday")
                    }
                },
                m = [...(0, r.F)() ? [{
                    key: s.G7.NEXT_OFF,
                    title: i.A.t("racing.nextOff"),
                    timeFilter: s.MW.TODAY
                }] : [], {
                    key: s.MW.TODAY,
                    title: i.A.t("date.today"),
                    timeFilter: s.MW.TODAY
                }, {
                    key: s.MW.TOMORROW,
                    title: i.A.t("date.tomorrow"),
                    timeFilter: s.MW.TOMORROW
                }, {
                    key: s.MW.DAY_AFTER_TOMORROW,
                    title: R.getDay() + 2 > 6 ? g[0].name : g[R.getDay() + 2].name,
                    timeFilter: s.MW.DAY_AFTER_TOMORROW
                }, {
                    key: n.alias,
                    title: i.A.t("racing.futureRaces"),
                    timeFilter: null
                }, {
                    key: c.alias,
                    title: i.A.t("racing.specialRaces"),
                    timeFilter: null
                }],
                M = [s.MW.TODAY, s.MW.TOMORROW, s.MW.DAY_AFTER_TOMORROW],
                T = [n.alias, c.alias]
        }
    }
]);
//# sourceMappingURL=35820.57a85fff.chunk.js.map