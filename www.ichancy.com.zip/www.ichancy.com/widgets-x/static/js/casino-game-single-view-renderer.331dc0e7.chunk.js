"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [89364, 24541, 83573, 68392, 62956, 96771, 1891, 18056, 64833, 13900, 52056, 91004], {
        596771: (e, t, l) => {
            l.d(t, {
                y: () => n
            });
            const n = (0, l(446987).Ht)()
        },
        535503: (e, t, l) => {
            l.d(t, {
                D: () => h
            });
            var n = l(365043),
                o = l(507712),
                i = l(995392),
                a = l(595459),
                r = l(318056),
                m = l(701616),
                s = l(329675),
                c = l(816343),
                p = l(179177),
                d = l(424757),
                g = l(55418),
                y = l(242146);
            const h = () => {
                const e = (0, o.wA)(),
                    {
                        path: t
                    } = (0, a.d)(),
                    l = (0, i.W6)(),
                    h = (0, o.d4)(s.BH),
                    u = (0, o.d4)(s.jZ);
                return {
                    handleCloseClick: (0, n.useCallback)((() => {
                        e((0, r.zc)(null)), e((0, m.fq)({
                            isVisible: !1,
                            height: 0
                        }));
                        let n = (0, c.XZ)("casinoStartingRoute", !1);
                        h || u || !p.Ay.PAGE_URLS.casino || (0, d.de)(window.location.href) !== (0, d.de)(p.Ay.PAGE_URLS.casino) || (0, d.de)(n) === (0, d.de)(p.Ay.PAGE_URLS.casino) || (n = ""), (0, c.XZ)("casinoSingleGame", !1), l.push({
                            pathname: `${n.split("?")[0]||`${(0,g.F)()?(0,d.nm)(t):(0,d.ic)(t,!1,!0)}/${y.Hk.all.id}`}`,
                            state: null,
                            search: n.split("?")[1]
                        })
                    }), [t])
                }
            }
        },
        424541: (e, t, l) => {
            l.d(t, {
                H: () => s
            });
            var n = l(507712),
                o = l(365043),
                i = l(462956),
                a = l(679559),
                r = l(68392),
                m = l(261190);
            const s = () => {
                const [e, t] = (0, o.useState)(""), {
                    currency: l
                } = (0, n.d4)(a.wz), s = (0, n.d4)(a.eP), c = (0, n.d4)(i.gU);
                (0, o.useLayoutEffect)((() => {
                    s && l ? t(l) : null !== c && void 0 !== c && c.currency && t(c.currency)
                }), [c, s, l]);
                return (0, o.useMemo)((() => {
                    const t = (0, r.N8)(e),
                        l = t.currency === m.Mi ? m.Wq : t.currency;
                    return {
                        currency: l,
                        currencyId: e,
                        placement: t.placement,
                        formatAmount: (0, r.Hv)(l, t.placement)
                    }
                }), [e])
            }
        },
        664833: (e, t, l) => {
            l.d(t, {
                d: () => n
            });
            let n = function(e) {
                return e.Id = "id", e.Category = "category", e
            }({})
        },
        417693: (e, t, l) => {
            l.r(t), l.d(t, {
                CasinoGameSingleViewRenderer: () => z
            });
            var n = l(995392),
                o = l(365043),
                i = l(507712),
                a = l(679559),
                r = l(322908),
                m = l.n(r),
                s = l(55418),
                c = l(989618),
                p = l(120376),
                d = l(384716),
                g = l(816343),
                y = l(424757),
                h = l(595459),
                u = l(318056),
                b = l(329675),
                S = l(930911),
                A = l(701616),
                v = l(841591),
                E = l(57817),
                _ = l(117893),
                T = l(283573),
                N = l(185762),
                C = l(870905),
                f = l(704270),
                R = l(423400),
                I = l(737536);
            var D = l(80489),
                M = l(714971),
                L = l(424541),
                O = l(49770),
                P = l(556785),
                G = l(535503),
                x = l(787154),
                w = l(570579);
            const $ = () => {
                const {
                    t: e
                } = (0, C.B)(), {
                    formatAmount: t
                } = (0, L.H)(), l = (0, n.W6)(), {
                    game: r,
                    mode: m
                } = (0, d.o)(), s = (0, i.d4)(a.eP), [c, p] = (0, o.useState)(!1), [y, h] = (0, o.useState)({
                    CasinoBetTotal: 0,
                    CasinoWinTotal: 0,
                    Profitness: 0,
                    SessionDuration: 0
                }), {
                    handleCloseClick: u
                } = (0, G.D)(), b = (0, o.useMemo)((() => {
                    var e;
                    return null !== (e = JSON.parse(O.A.getItem((0, P.U)("account", "ACTIVE_TIME_IN_CASINO")))) && void 0 !== e ? e : 0
                }), [s]);
                return (0, o.useEffect)((() => {
                    if ("real" === m && b && !c) {
                        const e = setTimeout((() => {
                            var e;
                            e = e => {
                                e && (h(e.details), p(!0))
                            }, f.l.then((t => {
                                t.sendCommand({
                                    command: I.y.GET_CLIENT_CURRENT_SESSION_SLOT_PL,
                                    params: {},
                                    rid: R.A.gForCommand()
                                }, "", e)
                            }))
                        }), 1e3 * b);
                        return () => {
                            clearTimeout(e)
                        }
                    }
                }), [m, r, c, b]), (0, w.jsxs)(M.a, {
                    visible: c,
                    closable: !1,
                    maskClosable: !1,
                    centered: !0,
                    maxWidth: 390,
                    title: e("casino.casinoActivity"),
                    className: "x-casinoLimitModal",
                    image: !1,
                    zIndex: x.uG,
                    children: [(0, w.jsx)("p", {
                        className: "x-casinoLimitModal__description",
                        children: e("casino.continueOrNot")
                    }), (0, w.jsxs)("ul", {
                        className: "x-casinoLimitModal__activityList",
                        children: [(0, w.jsxs)("li", {
                            className: "x-casinoLimitModal__activityList__item",
                            children: [e("casino.playedFor"), (0, w.jsxs)("span", {
                                children: [b / 60, " ", e("account.minute")]
                            })]
                        }), (0, w.jsxs)("li", {
                            className: "x-casinoLimitModal__activityList__item",
                            children: [e("casino.betCount"), (0, w.jsx)("span", {
                                children: t(y.CasinoBetTotal)
                            })]
                        }), (0, w.jsxs)("li", {
                            className: "x-casinoLimitModal__activityList__item",
                            children: [e("casino.winCount"), (0, w.jsx)("span", {
                                children: t(y.CasinoWinTotal)
                            })]
                        }), (0, w.jsxs)("li", {
                            className: "x-casinoLimitModal__activityList__item",
                            children: [e("casino.sessionResult"), (0, w.jsx)("span", {
                                children: t(y.Profitness)
                            })]
                        })]
                    }), (0, w.jsxs)(M.P, {
                        direction: "column",
                        children: [(0, w.jsx)(D.$, {
                            size: "large",
                            type: "primary",
                            onClick: () => p(!1),
                            children: e("casino.continue")
                        }), (0, w.jsx)(D.$, {
                            size: "large",
                            type: "text",
                            onClick: () => {
                                u(), l.push((0, g.oR)({
                                    accounts: "*",
                                    "balance-history": "*"
                                }))
                            },
                            children: e("casino.openBalanceHistory")
                        })]
                    })]
                })
            };
            var B = l(179177),
                U = l(263847),
                F = l(96485);
            var H = l(596771),
                k = l(513900),
                K = l(810795);
            const {
                GameSingleViewMobile: V
            } = (0, c.R)((() => Promise.all([l.e(99989), l.e(75634), l.e(34519), l.e(31528), l.e(70289), l.e(18574), l.e(31437), l.e(34885), l.e(81643), l.e(27989), l.e(23343), l.e(97760), l.e(62330), l.e(89910), l.e(9545), l.e(49662), l.e(90411), l.e(93352), l.e(34767)]).then(l.bind(l, 564477)))), {
                GameSingleViewDesktop: j
            } = (0, c.R)((() => Promise.all([l.e(99989), l.e(75634), l.e(34519), l.e(31528), l.e(70289), l.e(18574), l.e(31437), l.e(34885), l.e(81643), l.e(65506), l.e(27989), l.e(23343), l.e(97760), l.e(62330), l.e(89910), l.e(1162), l.e(83753), l.e(9545), l.e(49662), l.e(90411), l.e(93352), l.e(75949), l.e(45507)]).then(l.bind(l, 743259)))), Z = (0, o.memo)((() => {
                var e;
                (() => {
                    var e, t;
                    const {
                        t: l
                    } = (0, C.B)(), n = (0, i.d4)(b.xx), a = (0, o.useRef)(), r = (0, o.useRef)((null === (e = window.page) || void 0 === e || null === (t = e.seoParams) || void 0 === t ? void 0 : t.pageTitle) || document.title);
                    (0, o.useEffect)((() => {
                        var e;
                        return a.current || (a.current = null === (e = document.querySelector('meta[property="og:url"]')) || void 0 === e ? void 0 : e.content), () => {
                            var e, t;
                            const l = document.querySelector('meta[property="og:title"]'),
                                n = document.querySelector('meta[name="twitter:title"]'),
                                o = document.querySelector('meta[property="og:description"]'),
                                i = document.querySelector('meta[name="description"]'),
                                m = document.querySelector('meta[name="twitter:description"]'),
                                s = document.querySelector('meta[itemprop="description"]'),
                                c = document.querySelector('meta[property="og:url"]'),
                                p = document.querySelector('link[rel="canonical"]');
                            document.title = r.current, null === l || void 0 === l || l.setAttribute("content", (null === (e = window.page) || void 0 === e ? void 0 : e.title) || ""), null === n || void 0 === n || n.setAttribute("content", (null === (t = window.page) || void 0 === t ? void 0 : t.title) || ""), null === c || void 0 === c || c.setAttribute("content", a.current || ""), null === p || void 0 === p || p.setAttribute("href", a.current || ""), null === o || void 0 === o || o.remove(), null === i || void 0 === i || i.remove(), null === m || void 0 === m || m.remove(), null === s || void 0 === s || s.remove()
                        }
                    }), []), (0, o.useEffect)((() => {
                        var e, t, o, i, r;
                        if (B.Ay.MOCKED_DATA) return;
                        const m = (0, y.NI)(window.location.pathname),
                            s = (null === (e = window.partnerConfigs) || void 0 === e ? void 0 : e.siteNameSeparatorInTitles) || " - ";
                        let c, p = !1;
                        null !== (t = a.current) && void 0 !== t && t.endsWith(m) ? (c = a.current, p = !0) : c = (a.current || window.location.origin) + (0, y.NI)(window.location.pathname);
                        const d = l("casino.metaTitle").replace("{gameName}", (null === n || void 0 === n ? void 0 : n.name) || "").replace("{providerName}", (null === n || void 0 === n ? void 0 : n.provider_title) || "").replace("{siteNameSeparator}", s).replace("{pageTitle}", (null === (o = window.page) || void 0 === o ? void 0 : o.title) || ""),
                            g = l("casino.metaDescription").replace("{gameDescripiton}", (null === n || void 0 === n ? void 0 : n.description) || "").replaceAll("{siteNameSeparator}", s).replaceAll("{siteName}", (null === (i = window.partnerConfigs) || void 0 === i ? void 0 : i.siteName) || "").replace("{pageSeoDescription}", (null === (r = window.page) || void 0 === r ? void 0 : r.title) || "");
                        if (document.title === d) return;
                        document.title = d;
                        const h = document.querySelector('meta[property="og:title"]'),
                            u = document.querySelector('meta[name="twitter:title"]'),
                            b = document.querySelector('meta[property="og:description"]'),
                            S = document.querySelector('meta[name="description"]'),
                            A = document.querySelector('meta[name="twitter:description"]'),
                            v = document.querySelector('meta[itemprop="description"]'),
                            E = document.querySelector('meta[property="og:url"]'),
                            _ = document.querySelector('link[rel="canonical"]');
                        h ? h.setAttribute("content", d) : (0, F.g)([{
                            elemAttr: "property",
                            elemValue: "og:title"
                        }, {
                            elemAttr: "content",
                            elemValue: d
                        }]), u ? u.setAttribute("content", d) : (0, F.g)([{
                            elemAttr: "name",
                            elemValue: "twitter:title"
                        }, {
                            elemAttr: "content",
                            elemValue: d
                        }]), b ? b.setAttribute("content", g) : (0, F.g)([{
                            elemAttr: "property",
                            elemValue: "og:description"
                        }, {
                            elemAttr: "content",
                            elemValue: g
                        }]), S ? S.setAttribute("content", g) : (0, F.g)([{
                            elemAttr: "name",
                            elemValue: "description"
                        }, {
                            elemAttr: "content",
                            elemValue: g
                        }]), A ? A.setAttribute("content", g) : (0, F.g)([{
                            elemAttr: "name",
                            elemValue: "twitter:description"
                        }, {
                            elemAttr: "content",
                            elemValue: g
                        }]), v ? v.setAttribute("content", g) : (0, F.g)([{
                            elemAttr: "itemprop",
                            elemValue: "description"
                        }, {
                            elemAttr: "content",
                            elemValue: g
                        }]), E ? p || E.setAttribute("content", c) : (0, F.g)([{
                            elemAttr: "property",
                            elemValue: "og:url"
                        }, {
                            elemAttr: "content",
                            elemValue: c
                        }]), _ ? p || _.setAttribute("href", c) : (0, F.g)([{
                            elemAttr: "rel",
                            elemValue: "canonical"
                        }, {
                            elemAttr: "href",
                            elemValue: c
                        }], "link")
                    }), [n])
                })(), (0, E.n)();
                const t = (0, n.W6)(),
                    l = (0, i.wA)(),
                    r = (0, i.d4)(a.wz),
                    s = (0, i.d4)(a.eP),
                    c = (0, i.d4)(v.tH),
                    p = (0, i.d4)(b.xx),
                    f = (0, i.d4)((0, T.YK)((null === p || void 0 === p ? void 0 : p.id) || "", "casino")),
                    {
                        params: R
                    } = (0, h.d)(),
                    I = (0, K.R)(),
                    {
                        handleCloseClick: D
                    } = (0, G.D)(),
                    {
                        mode: M,
                        gameId: L
                    } = (0, d.o)(),
                    [O, P] = (0, o.useState)(1),
                    [x, Z] = (0, o.useState)(!1),
                    W = (0, o.useRef)(null),
                    q = R.gameCategory || (null === p || void 0 === p || null === (e = p.categories) || void 0 === e ? void 0 : e[0]),
                    [z] = (0, o.useMemo)((() => L ? [L] : (0, U.P)((null === R || void 0 === R ? void 0 : R.game) || "", "-")), [R.game, L]),
                    Y = (0, o.useMemo)((() => {
                        const e = R.gameCategory === k.H || Number(R.gameCategory) === k.A;
                        return B.Ay.CASINO_TIMER_NET_WIN && "real" === M && s && !e
                    }), [M, s]);
                (0, o.useEffect)((() => {
                    z && (p || (0, S.b)([z], !0, !1, !!B.Ay.DECENTRALIZED_CASINO_URL).then((e => l((0, u.zc)(e[0])))))
                }), [z]), (0, o.useEffect)((() => {
                    r.id || r.pending || "real" !== M || (null !== p && void 0 !== p && p.types.funMode ? t.push((0, g.oR)({
                        mode: "fun"
                    })) : (I(), H.y.setAfterSignIn((() => {
                        t.push({
                            pathname: `${t.location.pathname}`,
                            search: m().stringify({
                                mode: "real",
                                accounts: void 0,
                                login: void 0
                            })
                        })
                    }))))
                }), [s, r]), (0, o.useEffect)((() => {
                    l((0, A.rY)(!!B.Ay.SHOW_PLAYER_INFORMATION_IN_CASINO_SINGLE_VIEW && s))
                }), [s]);
                const J = (0, o.useCallback)((() => {
                    p && l((0, _.dwU)({
                        entity: p,
                        groupKey: "casino"
                    }))
                }), [p]);
                return (0, o.useEffect)((() => {
                    if ("real" !== M && "fun" !== M) {
                        const e = B.Ay.CASINO_FUN_MODE ? "fun" : "real";
                        t.push((0, g.U7)({
                            mode: e
                        }))
                    }
                }), [z, M]), (0, w.jsxs)(w.Fragment, {
                    children: [(0, w.jsx)($, {}), (0, w.jsx)(N.L, {
                        desktop: j,
                        mobile: V,
                        innerProps: {
                            headerState: c,
                            category: q || "",
                            gameName: (null === p || void 0 === p ? void 0 : p.name) || "",
                            externalGameId: (null === p || void 0 === p ? void 0 : p.extearnal_game_id) || "",
                            isActive: f,
                            showTimerNetWin: Y,
                            overlay: x,
                            setOverlay: Z,
                            reloadIframe: O,
                            setReloadIframe: P,
                            iframeRef: W,
                            onHeartClick: J,
                            handleCloseClick: D,
                            gameOptions: (null === p || void 0 === p ? void 0 : p.game_options) || null
                        }
                    })]
                })
            }));
            var W = l(242146);
            const {
                CasinoGamePreview: q
            } = (0, c.R)((() => Promise.all([l.e(42699), l.e(55606), l.e(91338), l.e(76790)]).then(l.bind(l, 486490)))), z = (0, o.memo)((() => {
                var e, t;
                const l = (0, i.d4)(a.wz),
                    r = (0, i.d4)(a.eP),
                    c = (0, n.W6)(),
                    h = (0, K.R)(),
                    {
                        mode: u
                    } = (0, d.o)(),
                    b = (0, o.useMemo)((() => (0, y.ic)(window.getPathname(), !1, !0)), [window.location.pathname]),
                    S = null === (e = window.getPathname().split(`/${B.Ay.CASINO_MOUNT_PATH}/`)) || void 0 === e || null === (t = e[1]) || void 0 === t ? void 0 : t.split("/").length;
                return (0, o.useEffect)((() => {
                    if (!B.Ay.CASINO_DISABLE_FUN_MODE || r || l.pending || "fun" !== u) S > 3 && (u || c.push((0, g.U7)({
                        mode: B.Ay.CASINO_FUN_MODE ? "fun" : "real"
                    })), "fun" !== u || B.Ay.CASINO_FUN_MODE || c.push((0, g.U7)({
                        mode: "real"
                    })));
                    else {
                        const e = c.location.pathname;
                        c.push(`${(0,y.ic)(window.getPathname(),!1,!0)}/${W.Hk.all.id}`), h(), H.y.setAfterSignIn((() => {
                            c.push({
                                pathname: e,
                                search: m().stringify({
                                    mode: "fun",
                                    accounts: void 0,
                                    login: void 0
                                })
                            })
                        }))
                    }
                }), [r, l.pending, u, S]), (0, o.useEffect)((() => {
                    const e = { ...m().parse(c.location.search, {
                                ignoreQueryPrefix: !0
                            })
                        },
                        t = window.getPathname();
                    if (!e.preview && t.includes(`/${B.Ay.CASINO_MOUNT_PATH}/`) && !t.includes(`/${W.Hk.all.id}/`) && S) {
                        const e = t.split(`/${B.Ay.CASINO_MOUNT_PATH}/`)[1],
                            l = e.split("/").length,
                            n = 2 === S ? 2 : 3;
                        if ((0, s.F)() && 2 === S && l === n || 2 !== S && l === n) {
                            const l = t.indexOf(e),
                                n = [t.slice(0, l), `${W.Hk.all.id}/`, t.slice(l)].join("");
                            c.push({
                                pathname: n,
                                search: m().stringify(m().parse(window.location.search, {
                                    ignoreQueryPrefix: !0
                                }))
                            })
                        }
                    }
                }), [S]), (0, w.jsxs)(w.Fragment, {
                    children: [(0, s.F)() && 3 === S ? (0, w.jsx)(g.Wy, {
                        excludes: ["mode"],
                        render: () => (0, w.jsx)(n.qh, {
                            path: `${b}/:category/:gameCategory/:game`,
                            children: (0, w.jsx)(o.Suspense, {
                                fallback: null,
                                children: (0, w.jsx)(q, {})
                            })
                        })
                    }) : null, 3 !== S ? (0, w.jsx)(n.qh, {
                        path: `${b}/:category?/:gameCategory?/:provider?/:game?`,
                        children: (0, w.jsx)(g.Wy, {
                            includes: ["mode"],
                            render: () => (0, w.jsx)(p.Z, {
                                children: (0, w.jsx)(Z, {})
                            })
                        })
                    }) : null, (0, w.jsx)(g.Wy, {
                        includes: ["gameId", "mode"],
                        render: () => (0, w.jsx)(p.Z, {
                            children: (0, w.jsx)(Z, {})
                        })
                    }), (0, s.F)() && (0, w.jsx)(g.Wy, {
                        includes: ["gameId"],
                        excludes: ["mode", "key"],
                        render: () => (0, w.jsx)(p.Z, {
                            children: (0, w.jsx)(q, {})
                        })
                    })]
                })
            }))
        },
        57817: (e, t, l) => {
            l.d(t, {
                n: () => g
            });
            var n = l(365043),
                o = l(507712),
                i = l(701616),
                a = l(841591),
                r = l(273549),
                m = l(329675),
                s = l(679559),
                c = l(55418),
                p = l(391004),
                d = l(179177);
            const g = () => {
                const e = (0, o.wA)(),
                    t = (0, o.d4)(s.wz),
                    l = (0, o.d4)(s.eP),
                    g = (0, o.d4)(r.co),
                    y = (0, o.d4)(r.Co),
                    h = (0, o.d4)(m.xx),
                    {
                        isVisible: u,
                        height: b
                    } = (0, o.d4)(a.tH),
                    S = (0, n.useMemo)((() => d.Ay.IS_HEADER_VISIBLE_IN_CASINO && l && !!h), [l, h]),
                    A = (0, n.useMemo)((() => (0, c.F)() && l && y && !g), [l, y, g]),
                    v = () => {
                        (0, p._b)() && ((0, p.e0)(), setTimeout((() => {
                            e((0, i.fq)({
                                isVisible: !1,
                                height: 0
                            }))
                        }), 100))
                    };
                (0, n.useEffect)((() => {
                    if ((0, p._b)()) {
                        if ((S || A) && !u) {
                            (0, p.cf)();
                            const t = () => {
                                const t = (0, p.vF)();
                                b !== t && e((0, i.fq)({
                                    height: t
                                }))
                            };
                            t(), (0, p._b)().addEventListener("resize", t), e((0, i.fq)({
                                isVisible: !0
                            }))
                        }
                        S || A || v()
                    }
                }), [t, A, S]), (0, n.useEffect)((() => v), [])
            }
        },
        930911: (e, t, l) => {
            l.d(t, {
                b: () => p
            });
            var n = l(140854),
                o = l.n(n),
                i = l(664833),
                a = l(179177),
                r = l(224272),
                m = l(55418),
                s = l(320308),
                c = l(457250);
            const p = function(e) {
                let t, l = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
                    n = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
                    p = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
                if (p) t = {
                    partnerId: a.Ay.DECENTRALIZED_CASINO_PARTNER_ID,
                    gameId: e[0]
                };
                else if (t = {
                        partner_id: a.Ay.PARTNER_ID,
                        is_mobile: Number((0, m.F)()),
                        lang: c.Ic,
                        by_key: i.d.Id,
                        use_webp: Number(a.Ay.IS_WEBP_SUPPORTED)
                    }, n && null !== e && void 0 !== e && e.length) t.external_id = e;
                else if (1 === (null === e || void 0 === e ? void 0 : e.length)) t.id = e[0];
                else {
                    if (!((null === e || void 0 === e ? void 0 : e.length) > 1)) return new Promise((e => e([])));
                    t.external_id = e
                }
                const d = null !== a.Ay && void 0 !== a.Ay && a.Ay.DECENTRALIZED_CASINO_URL ? `${a.Ay.DECENTRALIZED_CASINO_URL}${r.j.GET_DECENTRALIZED_GAME}` : `${a.Ay.CASINO_URL}/${r.j.GET_GAMES}`;
                return o().get(d, {
                    params: t
                }).then((e => 200 === e.status && e.data && ("ok" === e.data.status || p) ? p ? [{
                    extearnal_game_id: e.data.externalGameId,
                    types: {
                        realMode: 0,
                        funMode: 0
                    },
                    icon_1: e.data.icon1,
                    icon_2: e.data.icon2,
                    icon_3: e.data.icon3,
                    provider: "ALL",
                    provider_badge: null,
                    provider_title: "ALL",
                    show_as_provider: "ALL",
                    cats: e.data.categories,
                    ...e.data
                }] : Object.values(e.data.games) : (l && (0, s.$)(e.statusText), []))).catch((e => (l && (0, s.$)(e.toString()), [])))
            }
        },
        318056: (e, t, l) => {
            l.d(t, {
                Dn: () => y,
                EF: () => p,
                FU: () => a,
                MK: () => m,
                VF: () => o,
                fm: () => d,
                iW: () => r,
                it: () => h,
                sr: () => s,
                xq: () => g,
                zA: () => i,
                zc: () => c
            });
            var n = l(122757);
            const o = e => ({
                    type: n.b.SET_CASINO_ORIGINAL_CATEGORIES,
                    payload: e
                }),
                i = e => ({
                    type: n.b.SET_CASINO_CUSTOM_CATEGORIES,
                    payload: e
                }),
                a = e => ({
                    type: n.b.SET_CASINO_ORIGINAL_CATEGORIES_SET,
                    payload: e
                }),
                r = e => ({
                    type: n.b.SET_CASINO_ORIGINAL_CATEGORIES_SET_LEFT_SIDEBAR,
                    payload: e
                }),
                m = (e, t) => ({
                    type: n.b.SET_CASINO_PROVIDERS,
                    payload: {
                        category: t,
                        providers: e
                    }
                }),
                s = e => ({
                    type: n.b.SET_CASINO_PROVIDERS_IN_INTERSECTION,
                    payload: e
                }),
                c = e => ({
                    type: n.b.SET_CASINO_CURRENT_GAME,
                    payload: e
                }),
                p = e => ({
                    type: n.b.SET_CASINO_CATEGORY_PROVIDER_IDS,
                    payload: e
                }),
                d = e => ({
                    type: n.b.SET_CAN_REQUEST_CATEGORIES_NESTED_DATA,
                    payload: e
                }),
                g = e => ({
                    type: n.b.SET_CAN_REQUEST_PROVIDERS_NESTED_DATA,
                    payload: e
                }),
                y = e => ({
                    type: n.b.SET_LAST_PLAYED_CAT_SETTINGS,
                    payload: e
                }),
                h = e => ({
                    type: n.b.SET_CATEGORIES_CUSTOM_IDS,
                    payload: e
                })
        },
        283573: (e, t, l) => {
            l.d(t, {
                Gx: () => s,
                Kh: () => u,
                QJ: () => h,
                YK: () => S,
                fn: () => m,
                gI: () => g,
                tx: () => y,
                v6: () => b,
                zc: () => p
            });
            var n = l(280192),
                o = l(534977),
                i = l(827198);
            const a = (0, o.g)("favData"),
                r = a("marketsCount"),
                m = a("dataLoading"),
                s = a("idsLoading"),
                c = a("esport"),
                p = a("casino"),
                d = a("sportsbook"),
                g = a("markets"),
                y = a("competitions"),
                h = (0, n.Mz)([d, c, r], ((e, t, l) => {
                    const n = {
                            live: { ...e.live,
                                data: (0, i.gn)(e.live.data, l)
                            },
                            prematch: { ...e.prematch,
                                data: (0, i.gn)(e.prematch.data, l)
                            }
                        },
                        o = {
                            live: { ...t.live,
                                data: (0, i.gn)(t.live.data, l)
                            },
                            prematch: { ...t.prematch,
                                data: (0, i.gn)(t.prematch.data, l)
                            }
                        },
                        a = { ...n.live.data,
                            ...o.live.data
                        },
                        r = { ...n.prematch.data,
                            ...o.prematch.data
                        };
                    return {
                        all: { ...a,
                            ...r
                        },
                        esport: o,
                        sportsbook: n,
                        liveSports: a,
                        prematchSports: r
                    }
                })),
                u = (0, n.Mz)([c, d], ((e, t) => {
                    const l = [...e.live.ids, ...e.prematch.ids],
                        n = [...t.live.ids, ...t.prematch.ids];
                    return {
                        esport: {
                            live: e.live.ids,
                            prematch: e.prematch.ids,
                            all: l
                        },
                        sportsbook: {
                            live: t.live.ids,
                            prematch: t.prematch.ids,
                            all: n
                        },
                        liveSports: [...e.live.ids, ...t.live.ids],
                        prematchSports: [...e.prematch.ids, ...t.prematch.ids],
                        all: [...n, ...l]
                    }
                })),
                b = (0, n.Mz)([c, d, p, y], ((e, t, l, n) => {
                    const o = l.length,
                        i = n.length,
                        a = e.live.ids.length + e.prematch.ids.length,
                        r = t.live.ids.length + t.prematch.ids.length;
                    return {
                        esport: a,
                        casino: o,
                        sportsbook: r,
                        competitions: i,
                        sports: r + a,
                        total: a + r + o + i,
                        sportsWithCompetitions: r + a + i,
                        liveSports: e.live.ids.length + t.live.ids.length,
                        prematchSports: e.prematch.ids.length + t.prematch.ids.length,
                        onlyLiveSports: {
                            ids: [...e.live.ids, ...t.live.ids],
                            count: e.live.ids.length + t.live.ids.length
                        }
                    }
                })),
                S = function() {
                    for (var e = arguments.length, t = new Array(e), l = 0; l < e; l++) t[l] = arguments[l];
                    const [o, i] = t;
                    switch (i) {
                        case "casino":
                            return (0, n.Mz)([p], (e => e.some((e => {
                                let {
                                    id: t
                                } = e;
                                return o === t
                            }))));
                        case "competitions":
                            return (0, n.Mz)([y], (e => e.some((e => e.id === o))));
                        case "esport":
                        case "sportsbook":
                            return (0, n.Mz)([u], (e => {
                                let {
                                    all: t
                                } = e;
                                return t.includes(o)
                            }));
                        case "markets":
                            return (0, n.Mz)([g], (e => e.includes(o)))
                    }
                }
        },
        329675: (e, t, l) => {
            l.d(t, {
                BH: () => d,
                Dc: () => r,
                SP: () => c,
                hO: () => y,
                iU: () => s,
                jZ: () => g,
                ld: () => a,
                oC: () => h,
                py: () => m,
                xx: () => p
            });
            var n = l(280192);
            const o = (0, l(534977).g)("newCasinoStore"),
                i = o("categories"),
                a = (0, n.Mz)([i], (e => e.original)),
                r = (0, n.Mz)([i], (e => e.custom)),
                m = (0, n.Mz)([i], (e => e.originalSet)),
                s = (0, n.Mz)([i], (e => e.originalSetLeftSideBar)),
                c = o("providers"),
                p = (o("casinoCategoriesProviderIds"), o("providersInIntersection"), o("currentGame")),
                d = o("canRequestCategoriesNestedData"),
                g = o("canRequestProvidersNestedData"),
                y = o("lastPlayedCatSettings"),
                h = o("categoryCustomIds")
        },
        462956: (e, t, l) => {
            l.d(t, {
                Ot: () => a,
                es: () => i,
                gU: () => o
            });
            const n = (0, l(534977).g)("socket"),
                o = n("partnerConfigs"),
                i = n("jackpots"),
                a = n("isConnected")
        },
        96485: (e, t, l) => {
            l.d(t, {
                g: () => n
            });
            const n = function(e) {
                let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "meta",
                    l = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : void 0;
                const n = document.createElement(t);
                e.forEach((e => {
                    n.setAttribute(e.elemAttr, e.elemValue)
                })), l && (n.textContent = l), document.getElementsByTagName("head")[0].appendChild(n)
            }
        },
        224272: (e, t, l) => {
            l.d(t, {
                j: () => n
            });
            const n = {
                GET_OPTIONS: "getOptions",
                GET_GAMES: "getGames",
                GET_PROMOTED_GAMES: "getPromotedGames",
                GET_TOURNAMENT_GAMES: "getTournamentGames",
                GET_GAME_TOURNAMENTS: "getTournaments",
                GET_GROUPED_PROVIDER_OPTIONS: "getGroupedProviderOptions",
                GET_DECENTRALIZED_GAMES: "games",
                GET_DECENTRALIZED_GAME: "game",
                GET_DECENTRALIZED_CATEGORIES: "categories"
            }
        },
        513900: (e, t, l) => {
            l.d(t, {
                A: () => o,
                H: () => n
            });
            const n = "uncategorized",
                o = 28
        },
        68392: (e, t, l) => {
            l.d(t, {
                N8: () => a,
                HN: () => m,
                Hv: () => r
            });
            const n = {
                AFA: {
                    symbol: "\u060b",
                    placement: "right"
                },
                ALL: {
                    symbol: "Lek",
                    placement: "right"
                },
                DZD: {
                    symbol: "\u062f\u062c",
                    placement: "right"
                },
                AOA: {
                    symbol: "Kz",
                    placement: "right"
                },
                ARS: {
                    symbol: "$",
                    placement: "left"
                },
                AMD: {
                    symbol: "\u058f",
                    placement: "right"
                },
                AWG: {
                    symbol: "\u0192",
                    placement: "right"
                },
                AUD: {
                    symbol: "$",
                    placement: "left"
                },
                AZN: {
                    symbol: "\u20bc",
                    placement: "right"
                },
                BSD: {
                    symbol: "B$",
                    placement: "right"
                },
                BHD: {
                    symbol: ".\u062f.\u0628",
                    placement: "right"
                },
                BDT: {
                    symbol: "\u09f3",
                    placement: "right"
                },
                BBD: {
                    symbol: "Bds$",
                    placement: "right"
                },
                BYR: {
                    symbol: "Br",
                    placement: "right"
                },
                BYN: {
                    symbol: "Br",
                    placement: "right"
                },
                BEF: {
                    symbol: "fr",
                    placement: "right"
                },
                BZD: {
                    symbol: "BZ$",
                    placement: "right"
                },
                BMD: {
                    symbol: "$",
                    placement: "left"
                },
                BTN: {
                    symbol: "Nu.",
                    placement: "right"
                },
                BOB: {
                    symbol: "Bs.",
                    placement: "right"
                },
                BAM: {
                    symbol: "KM",
                    placement: "right"
                },
                BWP: {
                    symbol: "P",
                    placement: "right"
                },
                BRL: {
                    symbol: "R$",
                    placement: "right"
                },
                GBP: {
                    symbol: "\xa3",
                    placement: "right"
                },
                BND: {
                    symbol: "B$",
                    placement: "right"
                },
                BGN: {
                    symbol: "\u041b\u0432.",
                    placement: "right"
                },
                BIF: {
                    symbol: "FBu",
                    placement: "right"
                },
                KHR: {
                    symbol: "\u17db",
                    placement: "right"
                },
                CAD: {
                    symbol: "C$",
                    placement: "left"
                },
                CVE: {
                    symbol: "$",
                    placement: "left"
                },
                CYP: {
                    symbol: "\xa3",
                    placement: "right"
                },
                KYD: {
                    symbol: "$",
                    placement: "left"
                },
                XOF: {
                    symbol: "CFA",
                    placement: "right"
                },
                XAF: {
                    symbol: "FCFA",
                    placement: "right"
                },
                XPF: {
                    symbol: "\u20a3",
                    placement: "right"
                },
                CLP: {
                    symbol: "$",
                    placement: "left"
                },
                CNY: {
                    symbol: "\xa5",
                    placement: "right"
                },
                COP: {
                    symbol: "$",
                    placement: "left"
                },
                KMF: {
                    symbol: "CF",
                    placement: "right"
                },
                CDF: {
                    symbol: "FC",
                    placement: "right"
                },
                CRC: {
                    symbol: "\u20a1",
                    placement: "right"
                },
                HRK: {
                    symbol: "kn",
                    placement: "right"
                },
                CUC: {
                    symbol: "CUC$",
                    placement: "right"
                },
                CUP: {
                    symbol: "\u20b1",
                    placement: "right"
                },
                CZK: {
                    symbol: "K\u010d",
                    placement: "right"
                },
                DKK: {
                    symbol: "Kr.",
                    placement: "right"
                },
                DJF: {
                    symbol: "Fdj",
                    placement: "right"
                },
                DOP: {
                    symbol: "RD$",
                    placement: "right"
                },
                XCD: {
                    symbol: "$",
                    placement: "left"
                },
                EGP: {
                    symbol: "E\xa3",
                    placement: "right"
                },
                ERN: {
                    symbol: "\u1293\u1255\u134b",
                    placement: "right"
                },
                EEK: {
                    symbol: "kr",
                    placement: "right"
                },
                ETB: {
                    symbol: "\u1265\u122d",
                    placement: "right"
                },
                EUR: {
                    symbol: "\u20ac",
                    placement: "left"
                },
                FKP: {
                    symbol: "\xa3",
                    placement: "right"
                },
                FJD: {
                    symbol: "FJ$",
                    placement: "right"
                },
                GMD: {
                    symbol: "D",
                    placement: "right"
                },
                GEL: {
                    symbol: "\u10da",
                    placement: "right"
                },
                DEM: {
                    symbol: "DM",
                    placement: "right"
                },
                GHC: {
                    symbol: "GH\u20b5",
                    placement: "right"
                },
                GHS: {
                    symbol: "GH\u20b5",
                    placement: "right"
                },
                GIP: {
                    symbol: "\xa3",
                    placement: "right"
                },
                GRD: {
                    symbol: "\u20af",
                    placement: "right"
                },
                GTQ: {
                    symbol: "Q",
                    placement: "right"
                },
                GGP: {
                    symbol: "\xa3",
                    placement: "right"
                },
                GNF: {
                    symbol: "FG",
                    placement: "right"
                },
                GYD: {
                    symbol: "$",
                    placement: "left"
                },
                HTG: {
                    symbol: "G",
                    placement: "right"
                },
                HNL: {
                    symbol: "L",
                    placement: "right"
                },
                HKD: {
                    symbol: "HK$",
                    placement: "left"
                },
                HUF: {
                    symbol: "Ft",
                    placement: "right"
                },
                ISK: {
                    symbol: "kr",
                    placement: "right"
                },
                INR: {
                    symbol: "\u20b9",
                    placement: "right"
                },
                IDR: {
                    symbol: "Rp",
                    placement: "right"
                },
                IRR: {
                    symbol: "\ufdfc",
                    placement: "right"
                },
                IQD: {
                    symbol: "\u062f.\u0639",
                    placement: "right"
                },
                IMP: {
                    symbol: "\xa3",
                    placement: "right"
                },
                ILS: {
                    symbol: "\u20aa",
                    placement: "right"
                },
                ITL: {
                    symbol: "L,\xa3",
                    placement: "right"
                },
                JMD: {
                    symbol: "J$",
                    placement: "right"
                },
                JPY: {
                    symbol: "\xa5",
                    placement: "right"
                },
                JEP: {
                    symbol: "\xa3",
                    placement: "right"
                },
                JOD: {
                    symbol: "\u0627.\u062f",
                    placement: "right"
                },
                KZT: {
                    symbol: "\u043b\u0432",
                    placement: "right"
                },
                KES: {
                    symbol: "KSh",
                    placement: "right"
                },
                KWD: {
                    symbol: "\u0643.\u062f",
                    placement: "right"
                },
                KGS: {
                    symbol: "\u043b\u0432",
                    placement: "right"
                },
                LAK: {
                    symbol: "\u20ad",
                    placement: "right"
                },
                LVL: {
                    symbol: "Ls",
                    placement: "right"
                },
                LBP: {
                    symbol: "\xa3",
                    placement: "right"
                },
                LSL: {
                    symbol: "L",
                    placement: "right"
                },
                LRD: {
                    symbol: "$",
                    placement: "left"
                },
                LYD: {
                    symbol: "\u062f.\u0644",
                    placement: "right"
                },
                LTL: {
                    symbol: "Lt",
                    placement: "right"
                },
                MTL: {
                    symbol: "\u20a4M",
                    placement: "right"
                },
                MOP: {
                    symbol: "$",
                    placement: "left"
                },
                MKD: {
                    symbol: "\u0434\u0435\u043d",
                    placement: "right"
                },
                MGA: {
                    symbol: "Ar",
                    placement: "right"
                },
                MWK: {
                    symbol: "MK",
                    placement: "right"
                },
                MYR: {
                    symbol: "RM",
                    placement: "right"
                },
                MVR: {
                    symbol: "Rf",
                    placement: "right"
                },
                MRO: {
                    symbol: "MRU",
                    placement: "right"
                },
                MUR: {
                    symbol: "\u20a8",
                    placement: "right"
                },
                MXN: {
                    symbol: "$",
                    placement: "left"
                },
                MDL: {
                    symbol: "L",
                    placement: "right"
                },
                MNT: {
                    symbol: "\u20ae",
                    placement: "right"
                },
                MZN: {
                    symbol: "MT",
                    placement: "right"
                },
                MAD: {
                    symbol: "MAD",
                    placement: "right"
                },
                MZM: {
                    symbol: "MT",
                    placement: "right"
                },
                MMK: {
                    symbol: "K",
                    placement: "right"
                },
                NAD: {
                    symbol: "$",
                    placement: "left"
                },
                NPR: {
                    symbol: "\u20a8",
                    placement: "right"
                },
                ANG: {
                    symbol: "\u0192",
                    placement: "right"
                },
                TWD: {
                    symbol: "NT$",
                    placement: "right"
                },
                NZD: {
                    symbol: "$",
                    placement: "left"
                },
                NIO: {
                    symbol: "C$",
                    placement: "right"
                },
                NGN: {
                    symbol: "\u20a6",
                    placement: "right"
                },
                KPW: {
                    symbol: "\u20a9",
                    placement: "right"
                },
                NOK: {
                    symbol: "kr",
                    placement: "right"
                },
                OMR: {
                    symbol: "\u0631.\u0639.",
                    placement: "right"
                },
                PKR: {
                    symbol: "\u20a8",
                    placement: "right"
                },
                PAB: {
                    symbol: "B/.",
                    placement: "right"
                },
                PGK: {
                    symbol: "K",
                    placement: "right"
                },
                PYG: {
                    symbol: "\u20b2",
                    placement: "right"
                },
                PEN: {
                    symbol: "S/.",
                    placement: "right"
                },
                PHP: {
                    symbol: "\u20b1",
                    placement: "right"
                },
                PLN: {
                    symbol: "z\u0142",
                    placement: "right"
                },
                QAR: {
                    symbol: "\u0631.\u0642",
                    placement: "right"
                },
                RON: {
                    symbol: "lei",
                    placement: "right"
                },
                RUB: {
                    symbol: "\u20bd",
                    placement: "right"
                },
                RWF: {
                    symbol: "FRw",
                    placement: "right"
                },
                SVC: {
                    symbol: "\u20a1",
                    placement: "right"
                },
                WST: {
                    symbol: "SAT",
                    placement: "right"
                },
                SAR: {
                    symbol: "\ufdfc",
                    placement: "right"
                },
                RSD: {
                    symbol: "\u0414\u0438\u043d.",
                    placement: "right"
                },
                SCR: {
                    symbol: "SRe",
                    placement: "right"
                },
                SLL: {
                    symbol: "Le",
                    placement: "right"
                },
                SGD: {
                    symbol: "$",
                    placement: "left"
                },
                SKK: {
                    symbol: "Sk",
                    placement: "right"
                },
                SBD: {
                    symbol: "Si$",
                    placement: "right"
                },
                SOS: {
                    symbol: "Sh.so.",
                    placement: "right"
                },
                ZAR: {
                    symbol: "R",
                    placement: "right"
                },
                KRW: {
                    symbol: "\u20a9",
                    placement: "right"
                },
                XDR: {
                    symbol: "SDR",
                    placement: "right"
                },
                LKR: {
                    symbol: "Rs",
                    placement: "right"
                },
                SHP: {
                    symbol: "\xa3",
                    placement: "right"
                },
                SDG: {
                    symbol: ".\u0633.\u062c",
                    placement: "right"
                },
                SSP: {
                    symbol: "\xa3",
                    placement: "right"
                },
                SRD: {
                    symbol: "$",
                    placement: "left"
                },
                SZL: {
                    symbol: "E",
                    placement: "right"
                },
                SEK: {
                    symbol: "kr",
                    placement: "right"
                },
                CHF: {
                    symbol: "CHf",
                    placement: "right"
                },
                SYP: {
                    symbol: "\xa3S",
                    placement: "right"
                },
                STD: {
                    symbol: "Db",
                    placement: "right"
                },
                TJS: {
                    symbol: "SM",
                    placement: "right"
                },
                TZS: {
                    symbol: "TSh",
                    placement: "right"
                },
                THB: {
                    symbol: "\u0e3f",
                    placement: "right"
                },
                TOP: {
                    symbol: "$",
                    placement: "left"
                },
                TTD: {
                    symbol: "TT$",
                    placement: "right"
                },
                TND: {
                    symbol: "\u062a.\u062f",
                    placement: "right"
                },
                TRY: {
                    symbol: "\u20ba",
                    placement: "right"
                },
                TMM: {
                    symbol: "T",
                    placement: "right"
                },
                TMT: {
                    symbol: "T",
                    placement: "right"
                },
                TVD: {
                    symbol: "$",
                    placement: "left"
                },
                UGX: {
                    symbol: "USh",
                    placement: "right"
                },
                UAH: {
                    symbol: "\u20b4",
                    placement: "right"
                },
                AED: {
                    symbol: "\u062f.\u0625",
                    placement: "right"
                },
                UYU: {
                    symbol: "$U",
                    placement: "right"
                },
                USD: {
                    symbol: "$",
                    placement: "left"
                },
                UZS: {
                    symbol: "\u043b\u0432",
                    placement: "right"
                },
                VUV: {
                    symbol: "VT",
                    placement: "right"
                },
                VEF: {
                    symbol: "Bs",
                    placement: "right"
                },
                VND: {
                    symbol: "\u20ab",
                    placement: "right"
                },
                YER: {
                    symbol: "\ufdfc",
                    placement: "right"
                },
                ZMK: {
                    symbol: "ZK",
                    placement: "right"
                },
                ZWD: {
                    symbol: "Z$",
                    placement: "right"
                },
                BTC: {
                    symbol: "\u0e3f\u20bf",
                    placement: "right"
                },
                ETH: {
                    symbol: "\u039e",
                    placement: "right"
                },
                USDT: {
                    symbol: "\u20ae",
                    placement: "right"
                },
                TUS: {
                    symbol: "\u20ae",
                    placement: "right"
                },
                FTN: {
                    symbol: "FTN",
                    placement: "right"
                },
                NSP: {
                    symbol: "NSP",
                    placement: "right"
                }
            };
            var o = l(179177);
            const i = e => ({
                    default: e,
                    left: "left",
                    right: "right"
                }[o.Ay.CURRENCY_PLACEMENT]),
                a = function() {
                    let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
                    if (e) {
                        const t = n[e];
                        return t ? o.Ay.CURRENCIES_WITH_SYMBOLS ? {
                            currency: t.symbol,
                            placement: i(t.placement)
                        } : {
                            currency: e,
                            placement: i(t.placement)
                        } : {
                            currency: e,
                            placement: "right"
                        }
                    }
                    return {
                        currency: e,
                        placement: "right"
                    }
                },
                r = (e, t) => function(l, n) {
                    return !1 === n ? `${l}` : "left" === t ? `${e} ${l}` : `${l} ${e}`
                },
                m = (e, t) => r(a(e).currency, a(e).placement)(t)
        },
        391004: (e, t, l) => {
            l.d(t, {
                _b: () => o,
                cf: () => r,
                e0: () => m,
                vF: () => a
            });
            const n = (0, l(55418).F)() ? "fixed-header--mobile" : "fixed-header",
                o = () => document.querySelector("header.header-rows");
            let i = null;
            const a = () => {
                    const e = o();
                    return e ? e.clientHeight || e.offsetHeight : 0
                },
                r = () => {
                    const e = o();
                    if (e && !e.classList.contains(n)) {
                        const t = e.clientHeight || e.offsetHeight;
                        if ((() => {
                                var e, t;
                                const l = o(),
                                    n = l.parentElement;
                                ((null === n || void 0 === n || null === (e = n.style) || void 0 === e ? void 0 : e.paddingTop) || l.style.marginTop || (null === n || void 0 === n || null === (t = n.style) || void 0 === t ? void 0 : t.paddingBottom)) && !i && (i = {
                                    margin: l.style.marginTop,
                                    padding: null === n || void 0 === n ? void 0 : n.style.paddingTop,
                                    paddingBottom: null === n || void 0 === n ? void 0 : n.style.paddingBottom
                                })
                            })(), e.style.marginTop = `-${t}px`, e.parentElement) {
                            const l = window.getComputedStyle(e.parentElement, null).getPropertyValue("padding-top"),
                                n = window.getComputedStyle(e.parentElement, null).getPropertyValue("padding-bottom");
                            e.parentElement.style.paddingTop = `${t+ +l.replace("px","")}px`, e.parentElement.style.paddingBottom = `${t+ +n.replace("px","")}px`
                        }
                        e.classList.add(n)
                    }
                },
                m = () => {
                    const e = o();
                    var t, l, a;
                    e && (e.classList.remove(n), e.style.marginTop = (null === (t = i) || void 0 === t ? void 0 : t.margin) || "", e.parentElement && (e.parentElement.style.paddingTop = (null === (l = i) || void 0 === l ? void 0 : l.padding) || "", e.parentElement.style.paddingBottom = (null === (a = i) || void 0 === a ? void 0 : a.paddingBottom) || ""));
                    i = null
                }
        }
    }
]);
//# sourceMappingURL=casino-game-single-view-renderer.331dc0e7.chunk.js.map