"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [97525], {
        897525: (s, o, e) => {
            e.r(o), e.d(o, {
                default: () => k
            });
            const k = {}
        }
    }
]);
//# sourceMappingURL=97525.19aa76d7.chunk.js.map