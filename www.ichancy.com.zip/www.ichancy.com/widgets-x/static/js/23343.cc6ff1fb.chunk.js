"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [23343], {
        123343: (e, o, s) => {
            s.d(o, {
                R: () => r
            });
            var a = s(365043),
                l = s(735905),
                n = s(570579);
            const r = e => {
                let {
                    size: o,
                    className: s = "",
                    onAfterLoad: r,
                    onBeforeLoad: c
                } = e;
                return (0, a.useLayoutEffect)((() => null === c || void 0 === c ? void 0 : c()), []), (0, a.useEffect)((() => () => null === r || void 0 === r ? void 0 : r()), []), (0, n.jsx)("div", {
                    className: `loading__container ${s}`,
                    children: (0, n.jsx)(l.GlobalIcon, {
                        lib: "generic",
                        name: "spin",
                        theme: "default",
                        size: o || 32,
                        color: "var(--v3-primary-color)",
                        keepInCache: !0
                    })
                })
            }
        }
    }
]);
//# sourceMappingURL=23343.cc6ff1fb.chunk.js.map