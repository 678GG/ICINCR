"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [6327], {
        906327: (o, e, a) => {
            a.d(e, {
                b: () => C
            });
            var n = a(365043),
                i = a(995392),
                t = a(507712),
                s = a(679559),
                c = a(322908),
                d = a.n(c),
                r = a(318056),
                l = a(117893),
                u = a(596771),
                m = a(816343),
                v = a(424757),
                _ = a(10922),
                A = a(123213),
                $ = a(556785),
                g = a(513900),
                p = a(179177),
                h = a(810795),
                S = a(384716),
                k = a(595459),
                y = a(242146);
            const C = o => {
                const e = (0, t.d4)(s.eP),
                    a = (0, i.W6)(),
                    c = (0, t.wA)(),
                    C = (0, h.R)(),
                    I = (0, v.Ye)(),
                    {
                        tournamentId: b
                    } = (0, S.o)(),
                    f = (0, k.d)(`${(0,v.ic)(location.pathname,!1,!0)}/:category`),
                    E = (0, n.useCallback)(((o, e) => {
                        var n, i;
                        A.A.setItem((0, $.U)("casino", "GAMES_FETCHED"), "true");
                        const t = `${p.Ay.DECENTRALIZED_CASINO_URL?o.cats[0]:(null===(n=o.cats[0])||void 0===n?void 0:n.id)||g.H}`,
                            s = `${(0,_.a)(o.provider_title)}`,
                            u = `${o.id}-${o.extearnal_game_id}-${(0,_.a)(o.name)}`,
                            h = [(null === f || void 0 === f || null === (i = f.params) || void 0 === i ? void 0 : i.category) || y.Hk.all.id, t, s, u];
                        if (I && "casino" !== I) return void(0, v.e2)(`${p.Ay.PAGE_URLS.casino}/${p.Ay.CASINO_MOUNT_PATH}/${h.join("/")}?mode=${e}`, !1, !0);
                        c((0, l.$sl)(o)), c((0, r.zc)(o));
                        const S = d().parse(a.location.search, {
                            ignoreQueryPrefix: !0
                        });
                        a.location.pathname.includes(`/${p.Ay.SPORTSBOOK_MOUNT_PATH}/`) ? a.push((0, m.U7)({
                            gameId: o.id,
                            mode: e,
                            accounts: void 0,
                            login: void 0
                        })) : a.push({
                            pathname: `${(0,v.ic)(window.getPathname(),!1,!0)}/${h.join("/")}`,
                            search: d().stringify({ ...S,
                                mode: e,
                                accounts: void 0,
                                login: void 0,
                                tournamentId: b
                            })
                        })
                    }), [b, o, f]);
                return (0, n.useCallback)(((o, a) => {
                    const n = (0, m.qx)("casinoSingleGame", void 0, !0);
                    if (!e && "real" === o) return C(), void u.y.setAfterSignIn((() => {
                        (0, m.qx)("casinoSingleGame", n), E(a, o)
                    }));
                    (0, m.qx)("casinoSingleGame", n), E(a, o)
                }), [a, E, e])
            }
        }
    }
]);
//# sourceMappingURL=6327.e47e894d.chunk.js.map