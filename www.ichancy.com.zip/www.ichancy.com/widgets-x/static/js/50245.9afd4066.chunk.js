"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [50245], {
        117076: (e, s, a) => {
            a.d(s, {
                L: () => i
            });
            a(270757);
            var r = a(694227),
                t = (a(943144), a(570579));
            const i = () => (0, t.jsx)("div", {
                className: "menuWrapperDesktop",
                children: (0, t.jsx)("div", {
                    className: "menuWrapperDesktop__menu",
                    children: [...Array(15).keys()].map((e => (0, t.jsxs)("div", {
                        className: "menuItemDesktop",
                        children: [(0, t.jsx)(r.A.Avatar, {
                            size: 32,
                            active: !0
                        }), (0, t.jsx)(r.A, {
                            title: {
                                style: {
                                    height: 9,
                                    width: 70,
                                    margin: "5px 10px"
                                }
                            },
                            paragraph: !1,
                            active: !0
                        })]
                    }, e)))
                })
            })
        },
        361506: (e, s, a) => {
            a.d(s, {
                B: () => i
            });
            a(270757);
            var r = a(694227),
                t = (a(227846), a(570579));
            const i = e => {
                let {
                    isAtoZ: s
                } = e;
                return (0, t.jsx)("div", {
                    className: "menuWrapperMobile",
                    children: (0, t.jsx)("div", {
                        className: "menuWrapperMobile__menu",
                        children: [...Array(10).keys()].map((e => (0, t.jsxs)("div", {
                            className: "menuItemMobile",
                            children: [s ? (0, t.jsx)("div", {
                                className: "skeletonWrapper"
                            }) : (0, t.jsx)(r.A.Avatar, {
                                size: 24,
                                active: !0
                            }), (0, t.jsx)(r.A, {
                                title: {
                                    style: {
                                        height: 9,
                                        width: 50,
                                        margin: "5px 10px"
                                    }
                                },
                                paragraph: !1,
                                active: !0
                            })]
                        }, e)))
                    })
                })
            }
        },
        850245: (e, s, a) => {
            a.d(s, {
                t: () => m
            });
            var r = a(685787),
                t = a(117076),
                i = a(361506),
                p = a(55418),
                n = a(179177),
                c = a(399866),
                l = a(570579);
            const m = () => {
                const e = (0, c.$)(),
                    s = e.pageType === r.cM.live;
                return (0, p.F)() ? (0, l.jsx)(i.B, {}) : +n.Ay.LEFT_SIDE_BAR_SPORTS && +n.Ay.LEFT_SIDE_BAR && !s && 2 !== +e.pageType ? (0, l.jsx)("span", {}) : (0, l.jsx)(t.L, {})
            }
        },
        943144: () => {},
        227846: () => {}
    }
]);
//# sourceMappingURL=50245.9afd4066.chunk.js.map