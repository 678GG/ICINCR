"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [78882], {
        478882: (e, t, r) => {
            r.r(t), r.d(t, {
                default: () => f
            });
            var l, a, n, i = r(365043);

            function o() {
                return o = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = arguments[t];
                        for (var l in r) Object.prototype.hasOwnProperty.call(r, l) && (e[l] = r[l])
                    }
                    return e
                }, o.apply(this, arguments)
            }

            function C(e, t) {
                let {
                    title: r,
                    titleId: C,
                    ...c
                } = e;
                return i.createElement("svg", o({
                    width: 32,
                    height: 32,
                    viewBox: "0 0 32 32",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    ref: t,
                    "aria-labelledby": C
                }, c), r ? i.createElement("title", {
                    id: C
                }, r) : null, l || (l = i.createElement("circle", {
                    cx: 16,
                    cy: 15.999,
                    r: 16,
                    fill: "#4578EF"
                })), a || (a = i.createElement("g", {
                    filter: "url(#filter0_d_226_2465)"
                }, i.createElement("path", {
                    d: "M10.5148 13.4413C10.4088 13.2853 10.2328 13.1833 10.0328 13.1833C10.0308 13.1833 10.0288 13.1833 10.0268 13.1833H6.22976C8.08276 15.3263 9.79576 17.3373 11.5938 19.4313C10.4898 19.4313 9.51476 19.4053 8.53876 19.4313C8.49176 19.4353 8.43776 19.4383 8.38176 19.4383C7.91576 19.4383 7.49176 19.2574 7.17776 18.9614L7.17876 18.9623C6.92276 18.7313 6.74276 18.7563 6.51076 18.9883C5.79276 19.6873 5.02576 20.3844 4.30476 21.0824C4.17976 21.2074 3.91876 21.3413 4.02476 21.5503C4.13076 21.7593 4.38476 21.6524 4.56376 21.6524H14.1598C14.6478 21.6524 15.1088 21.5504 15.3408 21.0594C15.5968 20.5423 15.5968 20.0273 15.2388 19.5353C13.7238 17.4423 12.1328 15.4293 10.5148 13.4403V13.4413Z",
                    fill: "white"
                }), i.createElement("path", {
                    d: "M19.5507 16.9013C19.3707 15.9973 19.2947 15.0693 19.5257 14.1393C19.7047 13.2873 19.6017 13.1843 18.7047 13.1843H17.8567C16.0077 13.1843 16.0077 13.1843 15.6757 14.9913C15.6587 15.0903 15.6487 15.2043 15.6487 15.3203C15.6487 15.3413 15.6487 15.3613 15.6497 15.3823V15.3793C15.5457 17.3933 16.3427 18.9933 17.8307 20.2843C19.6267 21.8583 21.6807 21.9883 23.7057 21.0583C24.0287 20.8883 24.2857 20.6313 24.4507 20.3183L24.4557 20.3083C24.3977 20.2783 24.3297 20.2523 24.2587 20.2323L24.2507 20.2303C22.2457 20.7223 19.9357 19.0963 19.5507 16.9013Z",
                    fill: "white"
                }), i.createElement("path", {
                    d: "M27.1206 10.0334C24.7096 10.0334 22.2966 10.1374 19.8846 10.0084C18.4716 9.92942 17.4206 10.3434 16.5996 11.4534C16.4956 11.5784 16.2656 11.6854 16.3196 11.8654C16.3976 12.0974 16.6536 11.9904 16.8336 11.9904H23.2456C23.6816 11.9904 24.1206 11.9904 24.4006 12.4044C24.5016 12.5294 24.6056 12.6364 24.7856 12.5084C25.8126 11.7584 26.8646 11.0084 27.9106 10.2364C27.6606 9.95242 27.3786 10.0604 27.1206 10.0334Z",
                    fill: "white"
                }), i.createElement("path", {
                    d: "M15.0577 10.0333H7.20768C6.25768 10.0333 5.74468 10.5233 5.69268 11.3493C5.64268 11.8163 5.76968 11.9943 6.28368 11.9943C8.03368 11.9693 9.77368 11.9943 11.5147 11.9693C12.1047 11.9433 12.5687 12.0453 12.9267 12.5383C13.1567 12.8733 13.3617 12.8473 13.6197 12.5383C14.1587 11.9133 14.7447 11.2983 15.3137 10.6783C15.4387 10.5533 15.7247 10.4203 15.5937 10.1623C15.4897 9.93028 15.2377 10.0333 15.0577 10.0333Z",
                    fill: "white"
                }))), n || (n = i.createElement("defs", null, i.createElement("filter", {
                    id: "filter0_d_226_2465",
                    x: 0,
                    y: 9.99902,
                    width: 31.9106,
                    height: 19.6807,
                    filterUnits: "userSpaceOnUse",
                    colorInterpolationFilters: "sRGB"
                }, i.createElement("feFlood", {
                    floodOpacity: 0,
                    result: "BackgroundImageFix"
                }), i.createElement("feColorMatrix", { in: "SourceAlpha",
                    type: "matrix",
                    values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",
                    result: "hardAlpha"
                }), i.createElement("feOffset", {
                    dy: 4
                }), i.createElement("feGaussianBlur", {
                    stdDeviation: 2
                }), i.createElement("feComposite", {
                    in2: "hardAlpha",
                    operator: "out"
                }), i.createElement("feColorMatrix", {
                    type: "matrix",
                    values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.04 0"
                }), i.createElement("feBlend", {
                    mode: "normal",
                    in2: "BackgroundImageFix",
                    result: "effect1_dropShadow_226_2465"
                }), i.createElement("feBlend", {
                    mode: "normal",
                    in: "SourceGraphic",
                    in2: "effect1_dropShadow_226_2465",
                    result: "shape"
                })))))
            }
            const c = i.forwardRef(C),
                f = (r.p, c)
        }
    }
]);
//# sourceMappingURL=78882.8858bc1e.chunk.js.map