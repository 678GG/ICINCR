"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [64833], {
        664833: (e, o, s) => {
            s.d(o, {
                d: () => t
            });
            let t = function(e) {
                return e.Id = "id", e.Category = "category", e
            }({})
        }
    }
]);
//# sourceMappingURL=64833.78d64bbc.chunk.js.map