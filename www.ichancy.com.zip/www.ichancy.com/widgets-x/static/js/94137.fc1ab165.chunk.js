"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [94137], {
        294137: (c, n, r) => {
            r.d(n, {
                d: () => e,
                s: () => u
            });
            const e = {
                    FTNF: {
                        chainId: 5165,
                        currency: "FTN"
                    },
                    USDT: {
                        chainId: 1,
                        currency: "USDT"
                    },
                    USDC: {
                        chainId: 1,
                        currency: "USDC"
                    },
                    ETH: {
                        chainId: 1,
                        currency: "ETH"
                    },
                    BUSD: {
                        chainId: 1,
                        currency: "BUSD"
                    },
                    BNB: {
                        chainId: 1,
                        currency: "BNB"
                    },
                    SHIB: {
                        chainId: 1,
                        currency: "SHIB"
                    },
                    FTN: {
                        chainId: 1,
                        currency: "FTN"
                    },
                    DAI: {
                        chainId: 1,
                        currency: "DAI"
                    },
                    USDT_T: {
                        chainId: 0,
                        currency: "USDT"
                    },
                    USDB: {
                        chainId: 0,
                        currency: "USDT"
                    }
                },
                u = 5
        }
    }
]);
//# sourceMappingURL=94137.fc1ab165.chunk.js.map