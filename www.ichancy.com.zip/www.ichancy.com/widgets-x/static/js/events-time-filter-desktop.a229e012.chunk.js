"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [96282], {
        785843: (e, t, r) => {
            r.r(t), r.d(t, {
                EventsTimeFilterDesktop: () => g
            });
            r(718591);
            var n = r(273941),
                o = r(365043),
                i = r(889181),
                l = r(507712),
                a = r(218660),
                u = r(685527),
                c = r(133230),
                s = r(197262),
                f = r(256694),
                p = r(735905),
                d = r(950694),
                v = r(401162),
                m = (r(444487), r(570579));
            const b = e => {
                    const t = e / 60;
                    return `${t>1?t:e} ${s.A.t("generic."+(t>1?"hours":"minutes"))}`
                },
                g = (0, o.memo)((() => {
                    const e = (0, f.A)(),
                        t = (0, l.wA)(),
                        r = (0, l.d4)(a.KI)[(null === e || void 0 === e ? void 0 : e.moduleId) || ""] || +((null === e || void 0 === e ? void 0 : e.defaultEventsMinutes) || 0) || c.hA.HALF_HOUR,
                        s = t => {
                            const r = document.querySelector(`#${null===e||void 0===e?void 0:e.componentId}`);
                            r && (0, v.g)(r, t)
                        },
                        g = (0, o.useCallback)((t => {
                            if (null !== e && void 0 !== e && e.componentId) {
                                s(t ? 1 : -1)
                            }
                        }), []);
                    return (0, m.jsx)(n.default, {
                        placement: "bottom",
                        overlay: (0, m.jsx)("div", {
                            className: "eventsTimeFilter--desktop",
                            children: d.HC.map((n => (0, m.jsx)("div", {
                                onClick: () => {
                                    s(-1), t((0, u.Mz)({
                                        [(null === e || void 0 === e ? void 0 : e.moduleId) || ""]: n
                                    }))
                                },
                                className: (0, i.A)(["eventsTimeFilter--desktop__button", {
                                    "eventsTimeFilter--desktop__button__active": r === n
                                }]),
                                children: b(n)
                            }, n)))
                        }),
                        trigger: ["click"],
                        className: "eventsTimeFilter--desktop__dropdown",
                        getPopupContainer: e => e || document.body,
                        onVisibleChange: g,
                        children: (0, m.jsxs)("span", {
                            children: [b(r), (0, m.jsx)(p.GlobalIcon, {
                                lib: "generic",
                                keepInCache: !0,
                                name: "caretDownSmall",
                                theme: "default",
                                size: 20
                            }, "caretDownSmall")]
                        })
                    })
                }))
        },
        369536: (e, t) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            t.default = {
                icon: {
                    tag: "svg",
                    attrs: {
                        viewBox: "64 64 896 896",
                        focusable: "false"
                    },
                    children: [{
                        tag: "path",
                        attrs: {
                            d: "M176 511a56 56 0 10112 0 56 56 0 10-112 0zm280 0a56 56 0 10112 0 56 56 0 10-112 0zm280 0a56 56 0 10112 0 56 56 0 10-112 0z"
                        }
                    }]
                },
                name: "ellipsis",
                theme: "outlined"
            }
        },
        219730: (e, t, r) => {
            var n;
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = (n = r(539657)) && n.__esModule ? n : {
                default: n
            };
            t.default = o, e.exports = o
        },
        539657: (e, t, r) => {
            var n = r(245288),
                o = r(310684);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = n(r(601459)),
                l = function(e, t) {
                    if (!t && e && e.__esModule) return e;
                    if (null === e || "object" != o(e) && "function" != typeof e) return {
                        default: e
                    };
                    var r = c(t);
                    if (r && r.has(e)) return r.get(e);
                    var n = {
                            __proto__: null
                        },
                        i = Object.defineProperty && Object.getOwnPropertyDescriptor;
                    for (var l in e)
                        if ("default" !== l && Object.prototype.hasOwnProperty.call(e, l)) {
                            var a = i ? Object.getOwnPropertyDescriptor(e, l) : null;
                            a && (a.get || a.set) ? Object.defineProperty(n, l, a) : n[l] = e[l]
                        }
                    return n.default = e, r && r.set(e, n), n
                }(r(365043)),
                a = n(r(369536)),
                u = n(r(942740));

            function c(e) {
                if ("function" != typeof WeakMap) return null;
                var t = new WeakMap,
                    r = new WeakMap;
                return (c = function(e) {
                    return e ? r : t
                })(e)
            }
            var s = function(e, t) {
                    return l.createElement(u.default, (0, i.default)((0, i.default)({}, e), {}, {
                        ref: t,
                        icon: a.default
                    }))
                },
                f = l.forwardRef(s);
            t.default = f
        },
        685109: (e, t, r) => {
            function n(e, t, r) {
                return t in e ? Object.defineProperty(e, t, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = r, e
            }

            function o(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function i(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? o(Object(r), !0).forEach((function(t) {
                        n(e, t, r[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : o(Object(r)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    }))
                }
                return e
            }

            function l(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
                return n
            }

            function a(e, t) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, t) {
                    var r = null == e ? null : "undefined" !== typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                    if (null != r) {
                        var n, o, i = [],
                            l = !0,
                            a = !1;
                        try {
                            for (r = r.call(e); !(l = (n = r.next()).done) && (i.push(n.value), !t || i.length !== t); l = !0);
                        } catch (u) {
                            a = !0, o = u
                        } finally {
                            try {
                                l || null == r.return || r.return()
                            } finally {
                                if (a) throw o
                            }
                        }
                        return i
                    }
                }(e, t) || function(e, t) {
                    if (e) {
                        if ("string" === typeof e) return l(e, t);
                        var r = Object.prototype.toString.call(e).slice(8, -1);
                        return "Object" === r && e.constructor && (r = e.constructor.name), "Map" === r || "Set" === r ? Array.from(e) : "Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r) ? l(e, t) : void 0
                    }
                }(e, t) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function u(e, t) {
                if (null == e) return {};
                var r, n, o = function(e, t) {
                    if (null == e) return {};
                    var r, n, o = {},
                        i = Object.keys(e);
                    for (n = 0; n < i.length; n++) r = i[n], t.indexOf(r) >= 0 || (o[r] = e[r]);
                    return o
                }(e, t);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    for (n = 0; n < i.length; n++) r = i[n], t.indexOf(r) >= 0 || Object.prototype.propertyIsEnumerable.call(e, r) && (o[r] = e[r])
                }
                return o
            }
            r.r(t), r.d(t, {
                default: () => j
            });
            var c = r(365043),
                s = r(731528),
                f = r(498139),
                p = r.n(f),
                d = {
                    adjustX: 1,
                    adjustY: 1
                },
                v = [0, 0];
            const m = {
                topLeft: {
                    points: ["bl", "tl"],
                    overflow: d,
                    offset: [0, -4],
                    targetOffset: v
                },
                topCenter: {
                    points: ["bc", "tc"],
                    overflow: d,
                    offset: [0, -4],
                    targetOffset: v
                },
                topRight: {
                    points: ["br", "tr"],
                    overflow: d,
                    offset: [0, -4],
                    targetOffset: v
                },
                bottomLeft: {
                    points: ["tl", "bl"],
                    overflow: d,
                    offset: [0, 4],
                    targetOffset: v
                },
                bottomCenter: {
                    points: ["tc", "bc"],
                    overflow: d,
                    offset: [0, 4],
                    targetOffset: v
                },
                bottomRight: {
                    points: ["tr", "br"],
                    overflow: d,
                    offset: [0, 4],
                    targetOffset: v
                }
            };
            var b = r(25001),
                g = b.A.ESC,
                y = b.A.TAB;
            var h = r(113758),
                w = ["arrow", "prefixCls", "transitionName", "animation", "align", "placement", "placements", "getPopupContainer", "showAction", "hideAction", "overlayClassName", "overlayStyle", "visible", "trigger"];

            function O(e, t) {
                var r = e.arrow,
                    o = void 0 !== r && r,
                    l = e.prefixCls,
                    f = void 0 === l ? "rc-dropdown" : l,
                    d = e.transitionName,
                    v = e.animation,
                    b = e.align,
                    O = e.placement,
                    j = void 0 === O ? "bottomLeft" : O,
                    C = e.placements,
                    k = void 0 === C ? m : C,
                    P = e.getPopupContainer,
                    _ = e.showAction,
                    A = e.hideAction,
                    x = e.overlayClassName,
                    S = e.overlayStyle,
                    E = e.visible,
                    M = e.trigger,
                    N = void 0 === M ? ["hover"] : M,
                    R = u(e, w),
                    I = a(c.useState(), 2),
                    T = I[0],
                    D = I[1],
                    V = "visible" in e ? E : T,
                    F = c.useRef(null);
                c.useImperativeHandle(t, (function() {
                    return F.current
                }));
                var L = c.useRef(null),
                    W = "".concat(f, "-menu");
                ! function(e) {
                    var t = e.visible,
                        r = e.setTriggerVisible,
                        n = e.triggerRef,
                        o = e.menuRef,
                        i = e.onVisibleChange,
                        l = c.useRef(!1),
                        a = function() {
                            var e, o, l, a;
                            t && n.current && (null === (e = n.current) || void 0 === e || null === (o = e.triggerRef) || void 0 === o || null === (l = o.current) || void 0 === l || null === (a = l.focus) || void 0 === a || a.call(l), r(!1), "function" === typeof i && i(!1))
                        },
                        u = function(e) {
                            var t;
                            switch (e.keyCode) {
                                case g:
                                    a();
                                    break;
                                case y:
                                    !l.current && (null === (t = o.current) || void 0 === t ? void 0 : t.focus) ? (e.preventDefault(), o.current.focus(), l.current = !0) : a()
                            }
                        };
                    c.useEffect((function() {
                        return t ? (window.addEventListener("keydown", u), function() {
                            window.removeEventListener("keydown", u), l.current = !1
                        }) : function() {
                            return null
                        }
                    }), [t])
                }({
                    visible: V,
                    setTriggerVisible: D,
                    triggerRef: F,
                    menuRef: L,
                    onVisibleChange: e.onVisibleChange
                });
                var z = function() {
                        var t = e.overlay;
                        return "function" === typeof t ? t() : t
                    },
                    H = function(t) {
                        var r = e.onOverlayClick,
                            n = z().props;
                        D(!1), r && r(t), n.onClick && n.onClick(t)
                    },
                    $ = function() {
                        var e, t = z(),
                            r = (0, h.K4)(L, t.ref),
                            i = (n(e = {
                                prefixCls: W
                            }, "data-dropdown-inject", !0), n(e, "onClick", H), n(e, "ref", (0, h.f3)(t) ? r : void 0), e);
                        return "string" === typeof t.type && (delete i.prefixCls, delete i["data-dropdown-inject"]), c.createElement(c.Fragment, null, o && c.createElement("div", {
                            className: "".concat(f, "-arrow")
                        }), c.cloneElement(t, i))
                    },
                    B = A;
                return B || -1 === N.indexOf("contextMenu") || (B = ["click"]), c.createElement(s.A, i(i({
                    builtinPlacements: k
                }, R), {}, {
                    prefixCls: f,
                    ref: F,
                    popupClassName: p()(x, n({}, "".concat(f, "-show-arrow"), o)),
                    popupStyle: S,
                    action: N,
                    showAction: _,
                    hideAction: B || [],
                    popupPlacement: j,
                    popupAlign: b,
                    popupTransitionName: d,
                    popupAnimation: v,
                    popupVisible: V,
                    stretch: function() {
                        var t = e.minOverlayWidthMatchTrigger,
                            r = e.alignPoint;
                        return "minOverlayWidthMatchTrigger" in e ? t : !r
                    }() ? "minWidth" : "",
                    popup: "function" === typeof e.overlay ? $ : $(),
                    onPopupVisibleChange: function(t) {
                        var r = e.onVisibleChange;
                        D(t), "function" === typeof r && r(t)
                    },
                    getPopupContainer: P
                }), function() {
                    var t = e.children,
                        r = t.props ? t.props : {},
                        n = p()(r.className, function() {
                            var t = e.openClassName;
                            return void 0 !== t ? t : "".concat(f, "-open")
                        }());
                    return V && t ? c.cloneElement(t, {
                        className: n
                    }) : t
                }())
            }
            const j = c.forwardRef(O)
        }
    }
]);
//# sourceMappingURL=events-time-filter-desktop.a229e012.chunk.js.map