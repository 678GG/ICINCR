"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [99384], {
        899384: (t, e, i) => {
            i.d(e, {
                k: () => s,
                y: () => a
            });
            var o = i(294574),
                n = i(55418);
            const s = o.Ay.div.withConfig({
                    displayName: "style__ResultTitle",
                    componentId: "sc-wfn9y1-0"
                })(["font-size:", "px;font-weight:600;line-height:1.2;padding-bottom:", "px;color:var(--v3-primary-5);"], (0, n.F)() ? 18 : 24, (0, n.F)() ? 8 : 12),
                a = o.Ay.div.withConfig({
                    displayName: "style__ResultSubTitle",
                    componentId: "sc-wfn9y1-1"
                })(["width:308px;max-width:100%;margin:0 auto;text-align:center;font-size:14px;font-weight:400;color:var(--v3-black-65);line-height:1.5;"])
        }
    }
]);
//# sourceMappingURL=99384.205bdf49.chunk.js.map