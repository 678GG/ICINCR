"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [58073], {
        558073: (e, a, r) => {
            r.d(a, {
                i: () => o
            });
            var t = r(179177);
            const d = {
                    date: "",
                    separator: " ",
                    includeWeekday: !1,
                    weekdaySeparator: ""
                },
                o = e => {
                    const {
                        date: a,
                        separator: r,
                        time: o,
                        dateTimeSeparator: s,
                        includeWeekday: p,
                        weekdaySeparator: k
                    } = { ...d,
                        ...e
                    }, c = a.replace(/ /g, r);
                    return `${p&&!t.Ay.USE_CA_USA_DATE_FORMATTING?`ddd${k} `:""}${c}${o&&s?s+o:""}`
                }
        }
    }
]);
//# sourceMappingURL=58073.3943e428.chunk.js.map