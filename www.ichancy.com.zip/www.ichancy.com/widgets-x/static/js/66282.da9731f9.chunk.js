"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [66282], {
        66282: (e, t, r) => {
            r.r(t), r.d(t, {
                default: () => f
            });
            var l, a, n, i = r(365043);

            function o() {
                return o = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = arguments[t];
                        for (var l in r) Object.prototype.hasOwnProperty.call(r, l) && (e[l] = r[l])
                    }
                    return e
                }, o.apply(this, arguments)
            }

            function c(e, t) {
                let {
                    title: r,
                    titleId: c,
                    ...s
                } = e;
                return i.createElement("svg", o({
                    width: 32,
                    height: 32,
                    viewBox: "0 0 32 32",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    ref: t,
                    "aria-labelledby": c
                }, s), r ? i.createElement("title", {
                    id: c
                }, r) : null, l || (l = i.createElement("circle", {
                    cx: 16,
                    cy: 15.999,
                    r: 16,
                    fill: "#F36A10"
                })), a || (a = i.createElement("g", {
                    filter: "url(#filter0_d_226_2584)"
                }, i.createElement("path", {
                    d: "M23.036 7.44202L20.941 9.87202C18.105 7.68302 14.095 7.62502 11.242 9.87202L9.14697 7.44202C11.03 5.92002 13.453 4.99902 16.092 4.99902C18.731 4.99902 21.154 5.92002 23.058 7.45902L23.037 7.44302L23.036 7.44202Z",
                    fill: "white"
                }), i.createElement("path", {
                    d: "M8.43196 8.06692C8.47696 8.02592 8.51696 7.97892 8.56696 7.94192C9.26429 8.75125 9.96096 9.56025 10.657 10.3689C10.634 10.3989 10.61 10.4249 10.583 10.4479L10.582 10.4489C9.11396 11.8809 8.20396 13.8779 8.20396 16.0879C8.20396 16.5879 8.25096 17.0769 8.33996 17.5519L8.33196 17.5029C8.49696 18.4239 8.80496 19.2459 9.23396 19.9889L9.21396 19.9519L13.534 15.7679L15.677 11.1549C15.709 13.4879 15.671 15.8239 15.678 18.1579L11.34 22.3829C14.016 24.4659 18.227 24.5369 20.867 22.3619L16.555 18.1579C16.457 15.9239 16.556 13.4279 16.559 11.1639L18.7 15.7669L22.981 19.9149C23.011 19.8689 23.042 19.8149 23.07 19.7579L23.075 19.7479C23.643 18.6869 23.977 17.4259 23.977 16.0879C23.977 13.9169 23.099 11.9509 21.678 10.5259C21.628 10.4729 21.569 10.4259 21.524 10.3689C22.21 9.55292 22.918 8.74792 23.615 7.94092C24.075 8.36492 24.492 8.82092 24.868 9.30992L24.887 9.33492C26.319 11.1859 27.182 13.5409 27.182 16.0959C27.182 17.9639 26.721 19.7249 25.906 21.2699L25.935 21.2089C25.071 22.8409 23.872 24.1889 22.42 25.2009L22.384 25.2249C18.298 28.0379 12.769 27.8209 8.95396 24.5839C8.32296 24.0539 7.76696 23.4699 7.27896 22.8319L7.25996 22.8059C3.87896 18.3479 4.30896 11.9679 8.43296 8.06692H8.43196Z",
                    fill: "white"
                }))), n || (n = i.createElement("defs", null, i.createElement("filter", {
                    id: "filter0_d_226_2584",
                    x: 1,
                    y: 4.99902,
                    width: 30.1819,
                    height: 30.1855,
                    filterUnits: "userSpaceOnUse",
                    colorInterpolationFilters: "sRGB"
                }, i.createElement("feFlood", {
                    floodOpacity: 0,
                    result: "BackgroundImageFix"
                }), i.createElement("feColorMatrix", { in: "SourceAlpha",
                    type: "matrix",
                    values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",
                    result: "hardAlpha"
                }), i.createElement("feOffset", {
                    dy: 4
                }), i.createElement("feGaussianBlur", {
                    stdDeviation: 2
                }), i.createElement("feComposite", {
                    in2: "hardAlpha",
                    operator: "out"
                }), i.createElement("feColorMatrix", {
                    type: "matrix",
                    values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.04 0"
                }), i.createElement("feBlend", {
                    mode: "normal",
                    in2: "BackgroundImageFix",
                    result: "effect1_dropShadow_226_2584"
                }), i.createElement("feBlend", {
                    mode: "normal",
                    in: "SourceGraphic",
                    in2: "effect1_dropShadow_226_2584",
                    result: "shape"
                })))))
            }
            const s = i.forwardRef(c),
                f = (r.p, s)
        }
    }
]);
//# sourceMappingURL=66282.da9731f9.chunk.js.map