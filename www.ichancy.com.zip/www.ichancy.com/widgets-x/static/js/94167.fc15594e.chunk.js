"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [94167], {
        994167: (e, t, s) => {
            s.d(t, {
                RC: () => y,
                qr: () => E
            });
            var i = s(365043),
                n = s(716806);

            function r(e) {
                return "object" === typeof e && null !== e && e.constructor && "Object" === Object.prototype.toString.call(e).slice(8, -1)
            }

            function a(e, t) {
                const s = ["__proto__", "constructor", "prototype"];
                Object.keys(t).filter((e => s.indexOf(e) < 0)).forEach((s => {
                    "undefined" === typeof e[s] ? e[s] = t[s] : r(t[s]) && r(e[s]) && Object.keys(t[s]).length > 0 ? t[s].__swiper__ ? e[s] = t[s] : a(e[s], t[s]) : e[s] = t[s]
                }))
            }

            function l() {
                let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                return e.navigation && "undefined" === typeof e.navigation.nextEl && "undefined" === typeof e.navigation.prevEl
            }

            function o() {
                let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                return e.pagination && "undefined" === typeof e.pagination.el
            }

            function d() {
                let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                return e.scrollbar && "undefined" === typeof e.scrollbar.el
            }

            function c() {
                const e = (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "").split(" ").map((e => e.trim())).filter((e => !!e)),
                    t = [];
                return e.forEach((e => {
                    t.indexOf(e) < 0 && t.push(e)
                })), t.join(" ")
            }

            function p() {
                let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
                return e ? e.includes("swiper-wrapper") ? e : `swiper-wrapper ${e}` : "swiper-wrapper"
            }
            const u = ["eventsPrefix", "injectStyles", "injectStylesUrls", "modules", "init", "_direction", "oneWayMovement", "touchEventsTarget", "initialSlide", "_speed", "cssMode", "updateOnWindowResize", "resizeObserver", "nested", "focusableElements", "_enabled", "_width", "_height", "preventInteractionOnTransition", "userAgent", "url", "_edgeSwipeDetection", "_edgeSwipeThreshold", "_freeMode", "_autoHeight", "setWrapperSize", "virtualTranslate", "_effect", "breakpoints", "_spaceBetween", "_slidesPerView", "maxBackfaceHiddenSlides", "_grid", "_slidesPerGroup", "_slidesPerGroupSkip", "_slidesPerGroupAuto", "_centeredSlides", "_centeredSlidesBounds", "_slidesOffsetBefore", "_slidesOffsetAfter", "normalizeSlideIndex", "_centerInsufficientSlides", "_watchOverflow", "roundLengths", "touchRatio", "touchAngle", "simulateTouch", "_shortSwipes", "_longSwipes", "longSwipesRatio", "longSwipesMs", "_followFinger", "allowTouchMove", "_threshold", "touchMoveStopPropagation", "touchStartPreventDefault", "touchStartForcePreventDefault", "touchReleaseOnEdges", "uniqueNavElements", "_resistance", "_resistanceRatio", "_watchSlidesProgress", "_grabCursor", "preventClicks", "preventClicksPropagation", "_slideToClickedSlide", "_loop", "loopedSlides", "loopPreventsSliding", "_rewind", "_allowSlidePrev", "_allowSlideNext", "_swipeHandler", "_noSwiping", "noSwipingClass", "noSwipingSelector", "passiveListeners", "containerModifierClass", "slideClass", "slideActiveClass", "slideVisibleClass", "slideNextClass", "slidePrevClass", "wrapperClass", "lazyPreloaderClass", "lazyPreloadPrevNext", "runCallbacksOnInit", "observer", "observeParents", "observeSlideChildren", "a11y", "_autoplay", "_controller", "coverflowEffect", "cubeEffect", "fadeEffect", "flipEffect", "creativeEffect", "cardsEffect", "hashNavigation", "history", "keyboard", "mousewheel", "_navigation", "_pagination", "parallax", "_scrollbar", "_thumbs", "virtual", "zoom", "control"];

            function f(e) {
                return e.type && e.type.displayName && e.type.displayName.includes("SwiperSlide")
            }

            function m(e) {
                const t = [];
                return i.Children.toArray(e).forEach((e => {
                    f(e) ? t.push(e) : e.props && e.props.children && m(e.props.children).forEach((e => t.push(e)))
                })), t
            }

            function h(e) {
                const t = [],
                    s = {
                        "container-start": [],
                        "container-end": [],
                        "wrapper-start": [],
                        "wrapper-end": []
                    };
                return i.Children.toArray(e).forEach((e => {
                    if (f(e)) t.push(e);
                    else if (e.props && e.props.slot && s[e.props.slot]) s[e.props.slot].push(e);
                    else if (e.props && e.props.children) {
                        const i = m(e.props.children);
                        i.length > 0 ? i.forEach((e => t.push(e))) : s["container-end"].push(e)
                    } else s["container-end"].push(e)
                })), {
                    slides: t,
                    slots: s
                }
            }

            function g(e, t) {
                return "undefined" === typeof window ? (0, i.useEffect)(e, t) : (0, i.useLayoutEffect)(e, t)
            }
            const v = (0, i.createContext)(null),
                w = (0, i.createContext)(null);

            function b() {
                return b = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var s = arguments[t];
                        for (var i in s) Object.prototype.hasOwnProperty.call(s, i) && (e[i] = s[i])
                    }
                    return e
                }, b.apply(this, arguments)
            }
            const y = (0, i.forwardRef)((function(e, t) {
                let {
                    className: s,
                    tag: f = "div",
                    wrapperTag: m = "div",
                    children: v,
                    onSwiper: y,
                    ...S
                } = void 0 === e ? {} : e, E = !1;
                const [T, x] = (0, i.useState)("swiper"), [C, M] = (0, i.useState)(null), [P, L] = (0, i.useState)(!1), k = (0, i.useRef)(!1), O = (0, i.useRef)(null), A = (0, i.useRef)(null), I = (0, i.useRef)(null), z = (0, i.useRef)(null), _ = (0, i.useRef)(null), G = (0, i.useRef)(null), $ = (0, i.useRef)(null), D = (0, i.useRef)(null), {
                    params: N,
                    passedParams: B,
                    rest: F,
                    events: j
                } = function() {
                    let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                        t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
                    const s = {
                            on: {}
                        },
                        i = {},
                        l = {};
                    a(s, n.Ay.defaults), a(s, n.Ay.extendedDefaults), s._emitClasses = !0, s.init = !1;
                    const o = {},
                        d = u.map((e => e.replace(/_/, ""))),
                        c = Object.assign({}, e);
                    return Object.keys(c).forEach((n => {
                        "undefined" !== typeof e[n] && (d.indexOf(n) >= 0 ? r(e[n]) ? (s[n] = {}, l[n] = {}, a(s[n], e[n]), a(l[n], e[n])) : (s[n] = e[n], l[n] = e[n]) : 0 === n.search(/on[A-Z]/) && "function" === typeof e[n] ? t ? i[`${n[2].toLowerCase()}${n.substr(3)}`] = e[n] : s.on[`${n[2].toLowerCase()}${n.substr(3)}`] = e[n] : o[n] = e[n])
                    })), ["navigation", "pagination", "scrollbar"].forEach((e => {
                        !0 === s[e] && (s[e] = {}), !1 === s[e] && delete s[e]
                    })), {
                        params: s,
                        passedParams: l,
                        rest: o,
                        events: i
                    }
                }(S), {
                    slides: H,
                    slots: V
                } = h(v), R = () => {
                    L(!P)
                };
                Object.assign(N.on, {
                    _containerClasses(e, t) {
                        x(t)
                    }
                });
                const q = () => {
                    Object.assign(N.on, j), E = !0;
                    const e = { ...N
                    };
                    if (delete e.wrapperClass, A.current = new n.Ay(e), A.current.virtual && A.current.params.virtual.enabled) {
                        A.current.virtual.slides = H;
                        const e = {
                            cache: !1,
                            slides: H,
                            renderExternal: M,
                            renderExternalUpdate: !1
                        };
                        a(A.current.params.virtual, e), a(A.current.originalParams.virtual, e)
                    }
                };
                O.current || q(), A.current && A.current.on("_beforeBreakpoint", R);
                return (0, i.useEffect)((() => () => {
                    A.current && A.current.off("_beforeBreakpoint", R)
                })), (0, i.useEffect)((() => {
                    !k.current && A.current && (A.current.emitSlidesClasses(), k.current = !0)
                })), g((() => {
                    if (t && (t.current = O.current), O.current) return A.current.destroyed && q(),
                        function(e, t) {
                            let {
                                el: s,
                                nextEl: i,
                                prevEl: n,
                                paginationEl: r,
                                scrollbarEl: a,
                                swiper: c
                            } = e;
                            l(t) && i && n && (c.params.navigation.nextEl = i, c.originalParams.navigation.nextEl = i, c.params.navigation.prevEl = n, c.originalParams.navigation.prevEl = n), o(t) && r && (c.params.pagination.el = r, c.originalParams.pagination.el = r), d(t) && a && (c.params.scrollbar.el = a, c.originalParams.scrollbar.el = a), c.init(s)
                        }({
                            el: O.current,
                            nextEl: _.current,
                            prevEl: G.current,
                            paginationEl: $.current,
                            scrollbarEl: D.current,
                            swiper: A.current
                        }, N), y && y(A.current), () => {
                            A.current && !A.current.destroyed && A.current.destroy(!0, !1)
                        }
                }), []), g((() => {
                    !E && j && A.current && Object.keys(j).forEach((e => {
                        A.current.on(e, j[e])
                    }));
                    const e = function(e, t, s, i, n) {
                        const a = [];
                        if (!t) return a;
                        const l = e => {
                            a.indexOf(e) < 0 && a.push(e)
                        };
                        if (s && i) {
                            const e = i.map(n),
                                t = s.map(n);
                            e.join("") !== t.join("") && l("children"), i.length !== s.length && l("children")
                        }
                        return u.filter((e => "_" === e[0])).map((e => e.replace(/_/, ""))).forEach((s => {
                            if (s in e && s in t)
                                if (r(e[s]) && r(t[s])) {
                                    const i = Object.keys(e[s]),
                                        n = Object.keys(t[s]);
                                    i.length !== n.length ? l(s) : (i.forEach((i => {
                                        e[s][i] !== t[s][i] && l(s)
                                    })), n.forEach((i => {
                                        e[s][i] !== t[s][i] && l(s)
                                    })))
                                } else e[s] !== t[s] && l(s)
                        })), a
                    }(B, I.current, H, z.current, (e => e.key));
                    return I.current = B, z.current = H, e.length && A.current && !A.current.destroyed && function(e) {
                        let {
                            swiper: t,
                            slides: s,
                            passedParams: i,
                            changedParams: n,
                            nextEl: l,
                            prevEl: o,
                            scrollbarEl: d,
                            paginationEl: c
                        } = e;
                        const p = n.filter((e => "children" !== e && "direction" !== e && "wrapperClass" !== e)),
                            {
                                params: u,
                                pagination: f,
                                navigation: m,
                                scrollbar: h,
                                virtual: g,
                                thumbs: v
                            } = t;
                        let w, b, y, S, E, T, x, C;
                        n.includes("thumbs") && i.thumbs && i.thumbs.swiper && u.thumbs && !u.thumbs.swiper && (w = !0), n.includes("controller") && i.controller && i.controller.control && u.controller && !u.controller.control && (b = !0), n.includes("pagination") && i.pagination && (i.pagination.el || c) && (u.pagination || !1 === u.pagination) && f && !f.el && (y = !0), n.includes("scrollbar") && i.scrollbar && (i.scrollbar.el || d) && (u.scrollbar || !1 === u.scrollbar) && h && !h.el && (S = !0), n.includes("navigation") && i.navigation && (i.navigation.prevEl || o) && (i.navigation.nextEl || l) && (u.navigation || !1 === u.navigation) && m && !m.prevEl && !m.nextEl && (E = !0);
                        const M = e => {
                            t[e] && (t[e].destroy(), "navigation" === e ? (t.isElement && (t[e].prevEl.remove(), t[e].nextEl.remove()), u[e].prevEl = void 0, u[e].nextEl = void 0, t[e].prevEl = void 0, t[e].nextEl = void 0) : (t.isElement && t[e].el.remove(), u[e].el = void 0, t[e].el = void 0))
                        };
                        n.includes("loop") && t.isElement && (u.loop && !i.loop ? T = !0 : !u.loop && i.loop ? x = !0 : C = !0), p.forEach((e => {
                            if (r(u[e]) && r(i[e])) a(u[e], i[e]), "navigation" !== e && "pagination" !== e && "scrollbar" !== e || !("enabled" in i[e]) || i[e].enabled || M(e);
                            else {
                                const t = i[e];
                                !0 !== t && !1 !== t || "navigation" !== e && "pagination" !== e && "scrollbar" !== e ? u[e] = i[e] : !1 === t && M(e)
                            }
                        })), p.includes("controller") && !b && t.controller && t.controller.control && u.controller && u.controller.control && (t.controller.control = u.controller.control), n.includes("children") && s && g && u.virtual.enabled && (g.slides = s, g.update(!0)), n.includes("children") && s && u.loop && (C = !0), w && v.init() && v.update(!0);
                        b && (t.controller.control = u.controller.control), y && (!t.isElement || c && "string" !== typeof c || (c = document.createElement("div"), c.classList.add("swiper-pagination"), t.el.shadowEl.appendChild(c)), c && (u.pagination.el = c), f.init(), f.render(), f.update()), S && (!t.isElement || d && "string" !== typeof d || (d = document.createElement("div"), d.classList.add("swiper-scrollbar"), t.el.shadowEl.appendChild(d)), d && (u.scrollbar.el = d), h.init(), h.updateSize(), h.setTranslate()), E && (t.isElement && (l && "string" !== typeof l || (l = document.createElement("div"), l.classList.add("swiper-button-next"), t.el.shadowEl.appendChild(l)), o && "string" !== typeof o || (o = document.createElement("div"), o.classList.add("swiper-button-prev"), t.el.shadowEl.appendChild(o))), l && (u.navigation.nextEl = l), o && (u.navigation.prevEl = o), m.init(), m.update()), n.includes("allowSlideNext") && (t.allowSlideNext = i.allowSlideNext), n.includes("allowSlidePrev") && (t.allowSlidePrev = i.allowSlidePrev), n.includes("direction") && t.changeDirection(i.direction, !1), (T || C) && t.loopDestroy(), (x || C) && t.loopCreate(), t.update()
                    }({
                        swiper: A.current,
                        slides: H,
                        passedParams: B,
                        changedParams: e,
                        nextEl: _.current,
                        prevEl: G.current,
                        scrollbarEl: D.current,
                        paginationEl: $.current
                    }), () => {
                        j && A.current && Object.keys(j).forEach((e => {
                            A.current.off(e, j[e])
                        }))
                    }
                })), g((() => {
                    var e;
                    !(e = A.current) || e.destroyed || !e.params.virtual || e.params.virtual && !e.params.virtual.enabled || (e.updateSlides(), e.updateProgress(), e.updateSlidesClasses(), e.parallax && e.params.parallax && e.params.parallax.enabled && e.parallax.setTranslate())
                }), [C]), i.createElement(f, b({
                    ref: O,
                    className: c(`${T}${s?` ${s}`:""}`)
                }, F), i.createElement(w.Provider, {
                    value: A.current
                }, V["container-start"], i.createElement(m, {
                    className: p(N.wrapperClass)
                }, V["wrapper-start"], N.virtual ? function(e, t, s) {
                    if (!s) return null;
                    const n = e => {
                            let s = e;
                            return e < 0 ? s = t.length + e : s >= t.length && (s -= t.length), s
                        },
                        r = e.isHorizontal() ? {
                            [e.rtlTranslate ? "right" : "left"]: `${s.offset}px`
                        } : {
                            top: `${s.offset}px`
                        },
                        {
                            from: a,
                            to: l
                        } = s,
                        o = e.params.loop ? -t.length : 0,
                        d = e.params.loop ? 2 * t.length : t.length,
                        c = [];
                    for (let i = o; i < d; i += 1) i >= a && i <= l && c.push(t[n(i)]);
                    return c.map(((t, s) => i.cloneElement(t, {
                        swiper: e,
                        style: r,
                        key: `slide-${s}`
                    })))
                }(A.current, H, C) : H.map(((e, t) => i.cloneElement(e, {
                    swiper: A.current,
                    swiperSlideIndex: t
                }))), V["wrapper-end"]), l(N) && i.createElement(i.Fragment, null, i.createElement("div", {
                    ref: G,
                    className: "swiper-button-prev"
                }), i.createElement("div", {
                    ref: _,
                    className: "swiper-button-next"
                })), d(N) && i.createElement("div", {
                    ref: D,
                    className: "swiper-scrollbar"
                }), o(N) && i.createElement("div", {
                    ref: $,
                    className: "swiper-pagination"
                }), V["container-end"]))
            }));

            function S() {
                return S = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var s = arguments[t];
                        for (var i in s) Object.prototype.hasOwnProperty.call(s, i) && (e[i] = s[i])
                    }
                    return e
                }, S.apply(this, arguments)
            }
            y.displayName = "Swiper";
            const E = (0, i.forwardRef)((function(e, t) {
                let {
                    tag: s = "div",
                    children: n,
                    className: r = "",
                    swiper: a,
                    zoom: l,
                    lazy: o,
                    virtualIndex: d,
                    swiperSlideIndex: p,
                    ...u
                } = void 0 === e ? {} : e;
                const f = (0, i.useRef)(null),
                    [m, h] = (0, i.useState)("swiper-slide"),
                    [w, b] = (0, i.useState)(!1);

                function y(e, t, s) {
                    t === f.current && h(s)
                }
                g((() => {
                    if ("undefined" !== typeof p && (f.current.swiperSlideIndex = p), t && (t.current = f.current), f.current && a) {
                        if (!a.destroyed) return a.on("_slideClass", y), () => {
                            a && a.off("_slideClass", y)
                        };
                        "swiper-slide" !== m && h("swiper-slide")
                    }
                })), g((() => {
                    a && f.current && !a.destroyed && h(a.getSlideClasses(f.current))
                }), [a]);
                const E = {
                        isActive: m.indexOf("swiper-slide-active") >= 0,
                        isVisible: m.indexOf("swiper-slide-visible") >= 0,
                        isPrev: m.indexOf("swiper-slide-prev") >= 0,
                        isNext: m.indexOf("swiper-slide-next") >= 0
                    },
                    T = () => "function" === typeof n ? n(E) : n;
                return i.createElement(s, S({
                    ref: f,
                    className: c(`${m}${r?` ${r}`:""}`),
                    "data-swiper-slide-index": d,
                    onLoad: () => {
                        b(!0)
                    }
                }, u), l && i.createElement(v.Provider, {
                    value: E
                }, i.createElement("div", {
                    className: "swiper-zoom-container",
                    "data-swiper-zoom": "number" === typeof l ? l : void 0
                }, T(), o && !w && i.createElement("div", {
                    className: "swiper-lazy-preloader"
                }))), !l && i.createElement(v.Provider, {
                    value: E
                }, T(), o && !w && i.createElement("div", {
                    className: "swiper-lazy-preloader"
                })))
            }));
            E.displayName = "SwiperSlide"
        },
        716806: (e, t, s) => {
            function i(e) {
                return null !== e && "object" === typeof e && "constructor" in e && e.constructor === Object
            }

            function n() {
                let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                    t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                Object.keys(t).forEach((s => {
                    "undefined" === typeof e[s] ? e[s] = t[s] : i(t[s]) && i(e[s]) && Object.keys(t[s]).length > 0 && n(e[s], t[s])
                }))
            }
            s.d(t, {
                Ij: () => ne,
                Vx: () => te,
                dK: () => ie,
                Ay: () => Q
            });
            const r = {
                body: {},
                addEventListener() {},
                removeEventListener() {},
                activeElement: {
                    blur() {},
                    nodeName: ""
                },
                querySelector: () => null,
                querySelectorAll: () => [],
                getElementById: () => null,
                createEvent: () => ({
                    initEvent() {}
                }),
                createElement: () => ({
                    children: [],
                    childNodes: [],
                    style: {},
                    setAttribute() {},
                    getElementsByTagName: () => []
                }),
                createElementNS: () => ({}),
                importNode: () => null,
                location: {
                    hash: "",
                    host: "",
                    hostname: "",
                    href: "",
                    origin: "",
                    pathname: "",
                    protocol: "",
                    search: ""
                }
            };

            function a() {
                const e = "undefined" !== typeof document ? document : {};
                return n(e, r), e
            }
            const l = {
                document: r,
                navigator: {
                    userAgent: ""
                },
                location: {
                    hash: "",
                    host: "",
                    hostname: "",
                    href: "",
                    origin: "",
                    pathname: "",
                    protocol: "",
                    search: ""
                },
                history: {
                    replaceState() {},
                    pushState() {},
                    go() {},
                    back() {}
                },
                CustomEvent: function() {
                    return this
                },
                addEventListener() {},
                removeEventListener() {},
                getComputedStyle: () => ({
                    getPropertyValue: () => ""
                }),
                Image() {},
                Date() {},
                screen: {},
                setTimeout() {},
                clearTimeout() {},
                matchMedia: () => ({}),
                requestAnimationFrame: e => "undefined" === typeof setTimeout ? (e(), null) : setTimeout(e, 0),
                cancelAnimationFrame(e) {
                    "undefined" !== typeof setTimeout && clearTimeout(e)
                }
            };

            function o() {
                const e = "undefined" !== typeof window ? window : {};
                return n(e, l), e
            }

            function d(e) {
                return setTimeout(e, arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0)
            }

            function c() {
                return Date.now()
            }

            function p(e) {
                let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "x";
                const s = o();
                let i, n, r;
                const a = function(e) {
                    const t = o();
                    let s;
                    return t.getComputedStyle && (s = t.getComputedStyle(e, null)), !s && e.currentStyle && (s = e.currentStyle), s || (s = e.style), s
                }(e);
                return s.WebKitCSSMatrix ? (n = a.transform || a.webkitTransform, n.split(",").length > 6 && (n = n.split(", ").map((e => e.replace(",", "."))).join(", ")), r = new s.WebKitCSSMatrix("none" === n ? "" : n)) : (r = a.MozTransform || a.OTransform || a.MsTransform || a.msTransform || a.transform || a.getPropertyValue("transform").replace("translate(", "matrix(1, 0, 0, 1,"), i = r.toString().split(",")), "x" === t && (n = s.WebKitCSSMatrix ? r.m41 : 16 === i.length ? parseFloat(i[12]) : parseFloat(i[4])), "y" === t && (n = s.WebKitCSSMatrix ? r.m42 : 16 === i.length ? parseFloat(i[13]) : parseFloat(i[5])), n || 0
            }

            function u(e) {
                return "object" === typeof e && null !== e && e.constructor && "Object" === Object.prototype.toString.call(e).slice(8, -1)
            }

            function f() {
                const e = Object(arguments.length <= 0 ? void 0 : arguments[0]),
                    t = ["__proto__", "constructor", "prototype"];
                for (let i = 1; i < arguments.length; i += 1) {
                    const n = i < 0 || arguments.length <= i ? void 0 : arguments[i];
                    if (void 0 !== n && null !== n && (s = n, !("undefined" !== typeof window && "undefined" !== typeof window.HTMLElement ? s instanceof HTMLElement : s && (1 === s.nodeType || 11 === s.nodeType)))) {
                        const s = Object.keys(Object(n)).filter((e => t.indexOf(e) < 0));
                        for (let t = 0, i = s.length; t < i; t += 1) {
                            const i = s[t],
                                r = Object.getOwnPropertyDescriptor(n, i);
                            void 0 !== r && r.enumerable && (u(e[i]) && u(n[i]) ? n[i].__swiper__ ? e[i] = n[i] : f(e[i], n[i]) : !u(e[i]) && u(n[i]) ? (e[i] = {}, n[i].__swiper__ ? e[i] = n[i] : f(e[i], n[i])) : e[i] = n[i])
                        }
                    }
                }
                var s;
                return e
            }

            function m(e, t, s) {
                e.style.setProperty(t, s)
            }

            function h(e) {
                let {
                    swiper: t,
                    targetPosition: s,
                    side: i
                } = e;
                const n = o(),
                    r = -t.translate;
                let a, l = null;
                const d = t.params.speed;
                t.wrapperEl.style.scrollSnapType = "none", n.cancelAnimationFrame(t.cssModeFrameID);
                const c = s > r ? "next" : "prev",
                    p = (e, t) => "next" === c && e >= t || "prev" === c && e <= t,
                    u = () => {
                        a = (new Date).getTime(), null === l && (l = a);
                        const e = Math.max(Math.min((a - l) / d, 1), 0),
                            o = .5 - Math.cos(e * Math.PI) / 2;
                        let c = r + o * (s - r);
                        if (p(c, s) && (c = s), t.wrapperEl.scrollTo({
                                [i]: c
                            }), p(c, s)) return t.wrapperEl.style.overflow = "hidden", t.wrapperEl.style.scrollSnapType = "", setTimeout((() => {
                            t.wrapperEl.style.overflow = "", t.wrapperEl.scrollTo({
                                [i]: c
                            })
                        })), void n.cancelAnimationFrame(t.cssModeFrameID);
                        t.cssModeFrameID = n.requestAnimationFrame(u)
                    };
                u()
            }

            function g(e) {
                let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
                return [...e.children].filter((e => e.matches(t)))
            }

            function v(e) {
                let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [];
                const s = document.createElement(e);
                return s.classList.add(...Array.isArray(t) ? t : [t]), s
            }

            function w(e, t) {
                return o().getComputedStyle(e, null).getPropertyValue(t)
            }

            function b(e) {
                let t, s = e;
                if (s) {
                    for (t = 0; null !== (s = s.previousSibling);) 1 === s.nodeType && (t += 1);
                    return t
                }
            }

            function y(e, t) {
                const s = [];
                let i = e.parentElement;
                for (; i;) t ? i.matches(t) && s.push(i) : s.push(i), i = i.parentElement;
                return s
            }

            function S(e, t, s) {
                const i = o();
                return s ? e["width" === t ? "offsetWidth" : "offsetHeight"] + parseFloat(i.getComputedStyle(e, null).getPropertyValue("width" === t ? "margin-right" : "margin-top")) + parseFloat(i.getComputedStyle(e, null).getPropertyValue("width" === t ? "margin-left" : "margin-bottom")) : e.offsetWidth
            }
            let E, T, x;

            function C() {
                return E || (E = function() {
                    const e = o(),
                        t = a();
                    return {
                        smoothScroll: t.documentElement && t.documentElement.style && "scrollBehavior" in t.documentElement.style,
                        touch: !!("ontouchstart" in e || e.DocumentTouch && t instanceof e.DocumentTouch)
                    }
                }()), E
            }

            function M() {
                return T || (T = function() {
                    let {
                        userAgent: e
                    } = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                    const t = C(),
                        s = o(),
                        i = s.navigator.platform,
                        n = e || s.navigator.userAgent,
                        r = {
                            ios: !1,
                            android: !1
                        },
                        a = s.screen.width,
                        l = s.screen.height,
                        d = n.match(/(Android);?[\s\/]+([\d.]+)?/);
                    let c = n.match(/(iPad).*OS\s([\d_]+)/);
                    const p = n.match(/(iPod)(.*OS\s([\d_]+))?/),
                        u = !c && n.match(/(iPhone\sOS|iOS)\s([\d_]+)/),
                        f = "Win32" === i;
                    let m = "MacIntel" === i;
                    return !c && m && t.touch && ["1024x1366", "1366x1024", "834x1194", "1194x834", "834x1112", "1112x834", "768x1024", "1024x768", "820x1180", "1180x820", "810x1080", "1080x810"].indexOf(`${a}x${l}`) >= 0 && (c = n.match(/(Version)\/([\d.]+)/), c || (c = [0, 1, "13_0_0"]), m = !1), d && !f && (r.os = "android", r.android = !0), (c || u || p) && (r.os = "ios", r.ios = !0), r
                }(arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {})), T
            }

            function P() {
                return x || (x = function() {
                    const e = o();
                    let t = !1;

                    function s() {
                        const t = e.navigator.userAgent.toLowerCase();
                        return t.indexOf("safari") >= 0 && t.indexOf("chrome") < 0 && t.indexOf("android") < 0
                    }
                    if (s()) {
                        const s = String(e.navigator.userAgent);
                        if (s.includes("Version/")) {
                            const [e, i] = s.split("Version/")[1].split(" ")[0].split(".").map((e => Number(e)));
                            t = e < 16 || 16 === e && i < 2
                        }
                    }
                    return {
                        isSafari: t || s(),
                        needPerspectiveFix: t,
                        isWebView: /(iPhone|iPod|iPad).*AppleWebKit(?!.*Safari)/i.test(e.navigator.userAgent)
                    }
                }()), x
            }
            const L = {
                on(e, t, s) {
                    const i = this;
                    if (!i.eventsListeners || i.destroyed) return i;
                    if ("function" !== typeof t) return i;
                    const n = s ? "unshift" : "push";
                    return e.split(" ").forEach((e => {
                        i.eventsListeners[e] || (i.eventsListeners[e] = []), i.eventsListeners[e][n](t)
                    })), i
                },
                once(e, t, s) {
                    const i = this;
                    if (!i.eventsListeners || i.destroyed) return i;
                    if ("function" !== typeof t) return i;

                    function n() {
                        i.off(e, n), n.__emitterProxy && delete n.__emitterProxy;
                        for (var s = arguments.length, r = new Array(s), a = 0; a < s; a++) r[a] = arguments[a];
                        t.apply(i, r)
                    }
                    return n.__emitterProxy = t, i.on(e, n, s)
                },
                onAny(e, t) {
                    const s = this;
                    if (!s.eventsListeners || s.destroyed) return s;
                    if ("function" !== typeof e) return s;
                    const i = t ? "unshift" : "push";
                    return s.eventsAnyListeners.indexOf(e) < 0 && s.eventsAnyListeners[i](e), s
                },
                offAny(e) {
                    const t = this;
                    if (!t.eventsListeners || t.destroyed) return t;
                    if (!t.eventsAnyListeners) return t;
                    const s = t.eventsAnyListeners.indexOf(e);
                    return s >= 0 && t.eventsAnyListeners.splice(s, 1), t
                },
                off(e, t) {
                    const s = this;
                    return !s.eventsListeners || s.destroyed ? s : s.eventsListeners ? (e.split(" ").forEach((e => {
                        "undefined" === typeof t ? s.eventsListeners[e] = [] : s.eventsListeners[e] && s.eventsListeners[e].forEach(((i, n) => {
                            (i === t || i.__emitterProxy && i.__emitterProxy === t) && s.eventsListeners[e].splice(n, 1)
                        }))
                    })), s) : s
                },
                emit() {
                    const e = this;
                    if (!e.eventsListeners || e.destroyed) return e;
                    if (!e.eventsListeners) return e;
                    let t, s, i;
                    for (var n = arguments.length, r = new Array(n), a = 0; a < n; a++) r[a] = arguments[a];
                    "string" === typeof r[0] || Array.isArray(r[0]) ? (t = r[0], s = r.slice(1, r.length), i = e) : (t = r[0].events, s = r[0].data, i = r[0].context || e), s.unshift(i);
                    return (Array.isArray(t) ? t : t.split(" ")).forEach((t => {
                        e.eventsAnyListeners && e.eventsAnyListeners.length && e.eventsAnyListeners.forEach((e => {
                            e.apply(i, [t, ...s])
                        })), e.eventsListeners && e.eventsListeners[t] && e.eventsListeners[t].forEach((e => {
                            e.apply(i, s)
                        }))
                    })), e
                }
            };
            const k = (e, t) => {
                    if (!e || e.destroyed || !e.params) return;
                    const s = t.closest(e.isElement ? "swiper-slide" : `.${e.params.slideClass}`);
                    if (s) {
                        const t = s.querySelector(`.${e.params.lazyPreloaderClass}`);
                        t && t.remove()
                    }
                },
                O = (e, t) => {
                    if (!e.slides[t]) return;
                    const s = e.slides[t].querySelector('[loading="lazy"]');
                    s && s.removeAttribute("loading")
                },
                A = e => {
                    if (!e || e.destroyed || !e.params) return;
                    let t = e.params.lazyPreloadPrevNext;
                    const s = e.slides.length;
                    if (!s || !t || t < 0) return;
                    t = Math.min(t, s);
                    const i = "auto" === e.params.slidesPerView ? e.slidesPerViewDynamic() : Math.ceil(e.params.slidesPerView),
                        n = e.activeIndex;
                    if (e.params.grid && e.params.grid.rows > 1) {
                        const s = n,
                            r = [s - t];
                        return r.push(...Array.from({
                            length: t
                        }).map(((e, t) => s + i + t))), void e.slides.forEach(((t, s) => {
                            r.includes(t.column) && O(e, s)
                        }))
                    }
                    const r = n + i - 1;
                    if (e.params.rewind || e.params.loop)
                        for (let a = n - t; a <= r + t; a += 1) {
                            const t = (a % s + s) % s;
                            (t < n || t > r) && O(e, t)
                        } else
                            for (let a = Math.max(n - t, 0); a <= Math.min(r + t, s - 1); a += 1) a !== n && (a > r || a < n) && O(e, a)
                };
            const I = {
                updateSize: function() {
                    const e = this;
                    let t, s;
                    const i = e.el;
                    t = "undefined" !== typeof e.params.width && null !== e.params.width ? e.params.width : i.clientWidth, s = "undefined" !== typeof e.params.height && null !== e.params.height ? e.params.height : i.clientHeight, 0 === t && e.isHorizontal() || 0 === s && e.isVertical() || (t = t - parseInt(w(i, "padding-left") || 0, 10) - parseInt(w(i, "padding-right") || 0, 10), s = s - parseInt(w(i, "padding-top") || 0, 10) - parseInt(w(i, "padding-bottom") || 0, 10), Number.isNaN(t) && (t = 0), Number.isNaN(s) && (s = 0), Object.assign(e, {
                        width: t,
                        height: s,
                        size: e.isHorizontal() ? t : s
                    }))
                },
                updateSlides: function() {
                    const e = this;

                    function t(t) {
                        return e.isHorizontal() ? t : {
                            width: "height",
                            "margin-top": "margin-left",
                            "margin-bottom ": "margin-right",
                            "margin-left": "margin-top",
                            "margin-right": "margin-bottom",
                            "padding-left": "padding-top",
                            "padding-right": "padding-bottom",
                            marginRight: "marginBottom"
                        }[t]
                    }

                    function s(e, s) {
                        return parseFloat(e.getPropertyValue(t(s)) || 0)
                    }
                    const i = e.params,
                        {
                            wrapperEl: n,
                            slidesEl: r,
                            size: a,
                            rtlTranslate: l,
                            wrongRTL: o
                        } = e,
                        d = e.virtual && i.virtual.enabled,
                        c = d ? e.virtual.slides.length : e.slides.length,
                        p = g(r, `.${e.params.slideClass}, swiper-slide`),
                        u = d ? e.virtual.slides.length : p.length;
                    let f = [];
                    const h = [],
                        v = [];
                    let b = i.slidesOffsetBefore;
                    "function" === typeof b && (b = i.slidesOffsetBefore.call(e));
                    let y = i.slidesOffsetAfter;
                    "function" === typeof y && (y = i.slidesOffsetAfter.call(e));
                    const E = e.snapGrid.length,
                        T = e.slidesGrid.length;
                    let x = i.spaceBetween,
                        C = -b,
                        M = 0,
                        P = 0;
                    if ("undefined" === typeof a) return;
                    "string" === typeof x && x.indexOf("%") >= 0 ? x = parseFloat(x.replace("%", "")) / 100 * a : "string" === typeof x && (x = parseFloat(x)), e.virtualSize = -x, p.forEach((e => {
                        l ? e.style.marginLeft = "" : e.style.marginRight = "", e.style.marginBottom = "", e.style.marginTop = ""
                    })), i.centeredSlides && i.cssMode && (m(n, "--swiper-centered-offset-before", ""), m(n, "--swiper-centered-offset-after", ""));
                    const L = i.grid && i.grid.rows > 1 && e.grid;
                    let k;
                    L && e.grid.initSlides(u);
                    const O = "auto" === i.slidesPerView && i.breakpoints && Object.keys(i.breakpoints).filter((e => "undefined" !== typeof i.breakpoints[e].slidesPerView)).length > 0;
                    for (let m = 0; m < u; m += 1) {
                        let n;
                        if (k = 0, p[m] && (n = p[m]), L && e.grid.updateSlide(m, n, u, t), !p[m] || "none" !== w(n, "display")) {
                            if ("auto" === i.slidesPerView) {
                                O && (p[m].style[t("width")] = "");
                                const r = getComputedStyle(n),
                                    a = n.style.transform,
                                    l = n.style.webkitTransform;
                                if (a && (n.style.transform = "none"), l && (n.style.webkitTransform = "none"), i.roundLengths) k = e.isHorizontal() ? S(n, "width", !0) : S(n, "height", !0);
                                else {
                                    const e = s(r, "width"),
                                        t = s(r, "padding-left"),
                                        i = s(r, "padding-right"),
                                        a = s(r, "margin-left"),
                                        l = s(r, "margin-right"),
                                        o = r.getPropertyValue("box-sizing");
                                    if (o && "border-box" === o) k = e + a + l;
                                    else {
                                        const {
                                            clientWidth: s,
                                            offsetWidth: r
                                        } = n;
                                        k = e + t + i + a + l + (r - s)
                                    }
                                }
                                a && (n.style.transform = a), l && (n.style.webkitTransform = l), i.roundLengths && (k = Math.floor(k))
                            } else k = (a - (i.slidesPerView - 1) * x) / i.slidesPerView, i.roundLengths && (k = Math.floor(k)), p[m] && (p[m].style[t("width")] = `${k}px`);
                            p[m] && (p[m].swiperSlideSize = k), v.push(k), i.centeredSlides ? (C = C + k / 2 + M / 2 + x, 0 === M && 0 !== m && (C = C - a / 2 - x), 0 === m && (C = C - a / 2 - x), Math.abs(C) < .001 && (C = 0), i.roundLengths && (C = Math.floor(C)), P % i.slidesPerGroup === 0 && f.push(C), h.push(C)) : (i.roundLengths && (C = Math.floor(C)), (P - Math.min(e.params.slidesPerGroupSkip, P)) % e.params.slidesPerGroup === 0 && f.push(C), h.push(C), C = C + k + x), e.virtualSize += k + x, M = k, P += 1
                        }
                    }
                    if (e.virtualSize = Math.max(e.virtualSize, a) + y, l && o && ("slide" === i.effect || "coverflow" === i.effect) && (n.style.width = `${e.virtualSize+x}px`), i.setWrapperSize && (n.style[t("width")] = `${e.virtualSize+x}px`), L && e.grid.updateWrapperSize(k, f, t), !i.centeredSlides) {
                        const t = [];
                        for (let s = 0; s < f.length; s += 1) {
                            let n = f[s];
                            i.roundLengths && (n = Math.floor(n)), f[s] <= e.virtualSize - a && t.push(n)
                        }
                        f = t, Math.floor(e.virtualSize - a) - Math.floor(f[f.length - 1]) > 1 && f.push(e.virtualSize - a)
                    }
                    if (d && i.loop) {
                        const t = v[0] + x;
                        if (i.slidesPerGroup > 1) {
                            const s = Math.ceil((e.virtual.slidesBefore + e.virtual.slidesAfter) / i.slidesPerGroup),
                                n = t * i.slidesPerGroup;
                            for (let e = 0; e < s; e += 1) f.push(f[f.length - 1] + n)
                        }
                        for (let s = 0; s < e.virtual.slidesBefore + e.virtual.slidesAfter; s += 1) 1 === i.slidesPerGroup && f.push(f[f.length - 1] + t), h.push(h[h.length - 1] + t), e.virtualSize += t
                    }
                    if (0 === f.length && (f = [0]), 0 !== x) {
                        const s = e.isHorizontal() && l ? "marginLeft" : t("marginRight");
                        p.filter(((e, t) => !(i.cssMode && !i.loop) || t !== p.length - 1)).forEach((e => {
                            e.style[s] = `${x}px`
                        }))
                    }
                    if (i.centeredSlides && i.centeredSlidesBounds) {
                        let e = 0;
                        v.forEach((t => {
                            e += t + (x || 0)
                        })), e -= x;
                        const t = e - a;
                        f = f.map((e => e <= 0 ? -b : e > t ? t + y : e))
                    }
                    if (i.centerInsufficientSlides) {
                        let e = 0;
                        if (v.forEach((t => {
                                e += t + (x || 0)
                            })), e -= x, e < a) {
                            const t = (a - e) / 2;
                            f.forEach(((e, s) => {
                                f[s] = e - t
                            })), h.forEach(((e, s) => {
                                h[s] = e + t
                            }))
                        }
                    }
                    if (Object.assign(e, {
                            slides: p,
                            snapGrid: f,
                            slidesGrid: h,
                            slidesSizesGrid: v
                        }), i.centeredSlides && i.cssMode && !i.centeredSlidesBounds) {
                        m(n, "--swiper-centered-offset-before", -f[0] + "px"), m(n, "--swiper-centered-offset-after", e.size / 2 - v[v.length - 1] / 2 + "px");
                        const t = -e.snapGrid[0],
                            s = -e.slidesGrid[0];
                        e.snapGrid = e.snapGrid.map((e => e + t)), e.slidesGrid = e.slidesGrid.map((e => e + s))
                    }
                    if (u !== c && e.emit("slidesLengthChange"), f.length !== E && (e.params.watchOverflow && e.checkOverflow(), e.emit("snapGridLengthChange")), h.length !== T && e.emit("slidesGridLengthChange"), i.watchSlidesProgress && e.updateSlidesOffset(), !d && !i.cssMode && ("slide" === i.effect || "fade" === i.effect)) {
                        const t = `${i.containerModifierClass}backface-hidden`,
                            s = e.el.classList.contains(t);
                        u <= i.maxBackfaceHiddenSlides ? s || e.el.classList.add(t) : s && e.el.classList.remove(t)
                    }
                },
                updateAutoHeight: function(e) {
                    const t = this,
                        s = [],
                        i = t.virtual && t.params.virtual.enabled;
                    let n, r = 0;
                    "number" === typeof e ? t.setTransition(e) : !0 === e && t.setTransition(t.params.speed);
                    const a = e => i ? t.slides[t.getSlideIndexByData(e)] : t.slides[e];
                    if ("auto" !== t.params.slidesPerView && t.params.slidesPerView > 1)
                        if (t.params.centeredSlides)(t.visibleSlides || []).forEach((e => {
                            s.push(e)
                        }));
                        else
                            for (n = 0; n < Math.ceil(t.params.slidesPerView); n += 1) {
                                const e = t.activeIndex + n;
                                if (e > t.slides.length && !i) break;
                                s.push(a(e))
                            } else s.push(a(t.activeIndex));
                    for (n = 0; n < s.length; n += 1)
                        if ("undefined" !== typeof s[n]) {
                            const e = s[n].offsetHeight;
                            r = e > r ? e : r
                        }(r || 0 === r) && (t.wrapperEl.style.height = `${r}px`)
                },
                updateSlidesOffset: function() {
                    const e = this,
                        t = e.slides,
                        s = e.isElement ? e.isHorizontal() ? e.wrapperEl.offsetLeft : e.wrapperEl.offsetTop : 0;
                    for (let i = 0; i < t.length; i += 1) t[i].swiperSlideOffset = (e.isHorizontal() ? t[i].offsetLeft : t[i].offsetTop) - s - e.cssOverflowAdjustment()
                },
                updateSlidesProgress: function() {
                    let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this && this.translate || 0;
                    const t = this,
                        s = t.params,
                        {
                            slides: i,
                            rtlTranslate: n,
                            snapGrid: r
                        } = t;
                    if (0 === i.length) return;
                    "undefined" === typeof i[0].swiperSlideOffset && t.updateSlidesOffset();
                    let a = -e;
                    n && (a = e), i.forEach((e => {
                        e.classList.remove(s.slideVisibleClass)
                    })), t.visibleSlidesIndexes = [], t.visibleSlides = [];
                    let l = s.spaceBetween;
                    "string" === typeof l && l.indexOf("%") >= 0 ? l = parseFloat(l.replace("%", "")) / 100 * t.size : "string" === typeof l && (l = parseFloat(l));
                    for (let o = 0; o < i.length; o += 1) {
                        const e = i[o];
                        let d = e.swiperSlideOffset;
                        s.cssMode && s.centeredSlides && (d -= i[0].swiperSlideOffset);
                        const c = (a + (s.centeredSlides ? t.minTranslate() : 0) - d) / (e.swiperSlideSize + l),
                            p = (a - r[0] + (s.centeredSlides ? t.minTranslate() : 0) - d) / (e.swiperSlideSize + l),
                            u = -(a - d),
                            f = u + t.slidesSizesGrid[o];
                        (u >= 0 && u < t.size - 1 || f > 1 && f <= t.size || u <= 0 && f >= t.size) && (t.visibleSlides.push(e), t.visibleSlidesIndexes.push(o), i[o].classList.add(s.slideVisibleClass)), e.progress = n ? -c : c, e.originalProgress = n ? -p : p
                    }
                },
                updateProgress: function(e) {
                    const t = this;
                    if ("undefined" === typeof e) {
                        const s = t.rtlTranslate ? -1 : 1;
                        e = t && t.translate && t.translate * s || 0
                    }
                    const s = t.params,
                        i = t.maxTranslate() - t.minTranslate();
                    let {
                        progress: n,
                        isBeginning: r,
                        isEnd: a,
                        progressLoop: l
                    } = t;
                    const o = r,
                        d = a;
                    if (0 === i) n = 0, r = !0, a = !0;
                    else {
                        n = (e - t.minTranslate()) / i;
                        const s = Math.abs(e - t.minTranslate()) < 1,
                            l = Math.abs(e - t.maxTranslate()) < 1;
                        r = s || n <= 0, a = l || n >= 1, s && (n = 0), l && (n = 1)
                    }
                    if (s.loop) {
                        const s = t.getSlideIndexByData(0),
                            i = t.getSlideIndexByData(t.slides.length - 1),
                            n = t.slidesGrid[s],
                            r = t.slidesGrid[i],
                            a = t.slidesGrid[t.slidesGrid.length - 1],
                            o = Math.abs(e);
                        l = o >= n ? (o - n) / a : (o + a - r) / a, l > 1 && (l -= 1)
                    }
                    Object.assign(t, {
                        progress: n,
                        progressLoop: l,
                        isBeginning: r,
                        isEnd: a
                    }), (s.watchSlidesProgress || s.centeredSlides && s.autoHeight) && t.updateSlidesProgress(e), r && !o && t.emit("reachBeginning toEdge"), a && !d && t.emit("reachEnd toEdge"), (o && !r || d && !a) && t.emit("fromEdge"), t.emit("progress", n)
                },
                updateSlidesClasses: function() {
                    const e = this,
                        {
                            slides: t,
                            params: s,
                            slidesEl: i,
                            activeIndex: n
                        } = e,
                        r = e.virtual && s.virtual.enabled,
                        a = e => g(i, `.${s.slideClass}${e}, swiper-slide${e}`)[0];
                    let l;
                    if (t.forEach((e => {
                            e.classList.remove(s.slideActiveClass, s.slideNextClass, s.slidePrevClass)
                        })), r)
                        if (s.loop) {
                            let t = n - e.virtual.slidesBefore;
                            t < 0 && (t = e.virtual.slides.length + t), t >= e.virtual.slides.length && (t -= e.virtual.slides.length), l = a(`[data-swiper-slide-index="${t}"]`)
                        } else l = a(`[data-swiper-slide-index="${n}"]`);
                    else l = t[n];
                    if (l) {
                        l.classList.add(s.slideActiveClass);
                        let e = function(e, t) {
                            const s = [];
                            for (; e.nextElementSibling;) {
                                const i = e.nextElementSibling;
                                t ? i.matches(t) && s.push(i) : s.push(i), e = i
                            }
                            return s
                        }(l, `.${s.slideClass}, swiper-slide`)[0];
                        s.loop && !e && (e = t[0]), e && e.classList.add(s.slideNextClass);
                        let i = function(e, t) {
                            const s = [];
                            for (; e.previousElementSibling;) {
                                const i = e.previousElementSibling;
                                t ? i.matches(t) && s.push(i) : s.push(i), e = i
                            }
                            return s
                        }(l, `.${s.slideClass}, swiper-slide`)[0];
                        s.loop && 0 === !i && (i = t[t.length - 1]), i && i.classList.add(s.slidePrevClass)
                    }
                    e.emitSlidesClasses()
                },
                updateActiveIndex: function(e) {
                    const t = this,
                        s = t.rtlTranslate ? t.translate : -t.translate,
                        {
                            snapGrid: i,
                            params: n,
                            activeIndex: r,
                            realIndex: a,
                            snapIndex: l
                        } = t;
                    let o, d = e;
                    const c = e => {
                        let s = e - t.virtual.slidesBefore;
                        return s < 0 && (s = t.virtual.slides.length + s), s >= t.virtual.slides.length && (s -= t.virtual.slides.length), s
                    };
                    if ("undefined" === typeof d && (d = function(e) {
                            const {
                                slidesGrid: t,
                                params: s
                            } = e, i = e.rtlTranslate ? e.translate : -e.translate;
                            let n;
                            for (let r = 0; r < t.length; r += 1) "undefined" !== typeof t[r + 1] ? i >= t[r] && i < t[r + 1] - (t[r + 1] - t[r]) / 2 ? n = r : i >= t[r] && i < t[r + 1] && (n = r + 1) : i >= t[r] && (n = r);
                            return s.normalizeSlideIndex && (n < 0 || "undefined" === typeof n) && (n = 0), n
                        }(t)), i.indexOf(s) >= 0) o = i.indexOf(s);
                    else {
                        const e = Math.min(n.slidesPerGroupSkip, d);
                        o = e + Math.floor((d - e) / n.slidesPerGroup)
                    }
                    if (o >= i.length && (o = i.length - 1), d === r) return o !== l && (t.snapIndex = o, t.emit("snapIndexChange")), void(t.params.loop && t.virtual && t.params.virtual.enabled && (t.realIndex = c(d)));
                    let p;
                    p = t.virtual && n.virtual.enabled && n.loop ? c(d) : t.slides[d] ? parseInt(t.slides[d].getAttribute("data-swiper-slide-index") || d, 10) : d, Object.assign(t, {
                        previousSnapIndex: l,
                        snapIndex: o,
                        previousRealIndex: a,
                        realIndex: p,
                        previousIndex: r,
                        activeIndex: d
                    }), t.initialized && A(t), t.emit("activeIndexChange"), t.emit("snapIndexChange"), a !== p && t.emit("realIndexChange"), (t.initialized || t.params.runCallbacksOnInit) && t.emit("slideChange")
                },
                updateClickedSlide: function(e) {
                    const t = this,
                        s = t.params,
                        i = e.closest(`.${s.slideClass}, swiper-slide`);
                    let n, r = !1;
                    if (i)
                        for (let a = 0; a < t.slides.length; a += 1)
                            if (t.slides[a] === i) {
                                r = !0, n = a;
                                break
                            }
                    if (!i || !r) return t.clickedSlide = void 0, void(t.clickedIndex = void 0);
                    t.clickedSlide = i, t.virtual && t.params.virtual.enabled ? t.clickedIndex = parseInt(i.getAttribute("data-swiper-slide-index"), 10) : t.clickedIndex = n, s.slideToClickedSlide && void 0 !== t.clickedIndex && t.clickedIndex !== t.activeIndex && t.slideToClickedSlide()
                }
            };
            const z = {
                getTranslate: function() {
                    let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this.isHorizontal() ? "x" : "y";
                    const {
                        params: t,
                        rtlTranslate: s,
                        translate: i,
                        wrapperEl: n
                    } = this;
                    if (t.virtualTranslate) return s ? -i : i;
                    if (t.cssMode) return i;
                    let r = p(n, e);
                    return r += this.cssOverflowAdjustment(), s && (r = -r), r || 0
                },
                setTranslate: function(e, t) {
                    const s = this,
                        {
                            rtlTranslate: i,
                            params: n,
                            wrapperEl: r,
                            progress: a
                        } = s;
                    let l, o = 0,
                        d = 0;
                    s.isHorizontal() ? o = i ? -e : e : d = e, n.roundLengths && (o = Math.floor(o), d = Math.floor(d)), s.previousTranslate = s.translate, s.translate = s.isHorizontal() ? o : d, n.cssMode ? r[s.isHorizontal() ? "scrollLeft" : "scrollTop"] = s.isHorizontal() ? -o : -d : n.virtualTranslate || (s.isHorizontal() ? o -= s.cssOverflowAdjustment() : d -= s.cssOverflowAdjustment(), r.style.transform = `translate3d(${o}px, ${d}px, 0px)`);
                    const c = s.maxTranslate() - s.minTranslate();
                    l = 0 === c ? 0 : (e - s.minTranslate()) / c, l !== a && s.updateProgress(e), s.emit("setTranslate", s.translate, t)
                },
                minTranslate: function() {
                    return -this.snapGrid[0]
                },
                maxTranslate: function() {
                    return -this.snapGrid[this.snapGrid.length - 1]
                },
                translateTo: function() {
                    let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
                        t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this.params.speed,
                        s = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2],
                        i = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3],
                        n = arguments.length > 4 ? arguments[4] : void 0;
                    const r = this,
                        {
                            params: a,
                            wrapperEl: l
                        } = r;
                    if (r.animating && a.preventInteractionOnTransition) return !1;
                    const o = r.minTranslate(),
                        d = r.maxTranslate();
                    let c;
                    if (c = i && e > o ? o : i && e < d ? d : e, r.updateProgress(c), a.cssMode) {
                        const e = r.isHorizontal();
                        if (0 === t) l[e ? "scrollLeft" : "scrollTop"] = -c;
                        else {
                            if (!r.support.smoothScroll) return h({
                                swiper: r,
                                targetPosition: -c,
                                side: e ? "left" : "top"
                            }), !0;
                            l.scrollTo({
                                [e ? "left" : "top"]: -c,
                                behavior: "smooth"
                            })
                        }
                        return !0
                    }
                    return 0 === t ? (r.setTransition(0), r.setTranslate(c), s && (r.emit("beforeTransitionStart", t, n), r.emit("transitionEnd"))) : (r.setTransition(t), r.setTranslate(c), s && (r.emit("beforeTransitionStart", t, n), r.emit("transitionStart")), r.animating || (r.animating = !0, r.onTranslateToWrapperTransitionEnd || (r.onTranslateToWrapperTransitionEnd = function(e) {
                        r && !r.destroyed && e.target === this && (r.wrapperEl.removeEventListener("transitionend", r.onTranslateToWrapperTransitionEnd), r.onTranslateToWrapperTransitionEnd = null, delete r.onTranslateToWrapperTransitionEnd, s && r.emit("transitionEnd"))
                    }), r.wrapperEl.addEventListener("transitionend", r.onTranslateToWrapperTransitionEnd))), !0
                }
            };

            function _(e) {
                let {
                    swiper: t,
                    runCallbacks: s,
                    direction: i,
                    step: n
                } = e;
                const {
                    activeIndex: r,
                    previousIndex: a
                } = t;
                let l = i;
                if (l || (l = r > a ? "next" : r < a ? "prev" : "reset"), t.emit(`transition${n}`), s && r !== a) {
                    if ("reset" === l) return void t.emit(`slideResetTransition${n}`);
                    t.emit(`slideChangeTransition${n}`), "next" === l ? t.emit(`slideNextTransition${n}`) : t.emit(`slidePrevTransition${n}`)
                }
            }
            const G = {
                slideTo: function() {
                    let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
                        t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this.params.speed,
                        s = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2],
                        i = arguments.length > 3 ? arguments[3] : void 0,
                        n = arguments.length > 4 ? arguments[4] : void 0;
                    "string" === typeof e && (e = parseInt(e, 10));
                    const r = this;
                    let a = e;
                    a < 0 && (a = 0);
                    const {
                        params: l,
                        snapGrid: o,
                        slidesGrid: d,
                        previousIndex: c,
                        activeIndex: p,
                        rtlTranslate: u,
                        wrapperEl: f,
                        enabled: m
                    } = r;
                    if (r.animating && l.preventInteractionOnTransition || !m && !i && !n) return !1;
                    const g = Math.min(r.params.slidesPerGroupSkip, a);
                    let v = g + Math.floor((a - g) / r.params.slidesPerGroup);
                    v >= o.length && (v = o.length - 1);
                    const w = -o[v];
                    if (l.normalizeSlideIndex)
                        for (let h = 0; h < d.length; h += 1) {
                            const e = -Math.floor(100 * w),
                                t = Math.floor(100 * d[h]),
                                s = Math.floor(100 * d[h + 1]);
                            "undefined" !== typeof d[h + 1] ? e >= t && e < s - (s - t) / 2 ? a = h : e >= t && e < s && (a = h + 1) : e >= t && (a = h)
                        }
                    if (r.initialized && a !== p) {
                        if (!r.allowSlideNext && (u ? w > r.translate && w > r.minTranslate() : w < r.translate && w < r.minTranslate())) return !1;
                        if (!r.allowSlidePrev && w > r.translate && w > r.maxTranslate() && (p || 0) !== a) return !1
                    }
                    let b;
                    if (a !== (c || 0) && s && r.emit("beforeSlideChangeStart"), r.updateProgress(w), b = a > p ? "next" : a < p ? "prev" : "reset", u && -w === r.translate || !u && w === r.translate) return r.updateActiveIndex(a), l.autoHeight && r.updateAutoHeight(), r.updateSlidesClasses(), "slide" !== l.effect && r.setTranslate(w), "reset" !== b && (r.transitionStart(s, b), r.transitionEnd(s, b)), !1;
                    if (l.cssMode) {
                        const e = r.isHorizontal(),
                            s = u ? w : -w;
                        if (0 === t) {
                            const t = r.virtual && r.params.virtual.enabled;
                            t && (r.wrapperEl.style.scrollSnapType = "none", r._immediateVirtual = !0), t && !r._cssModeVirtualInitialSet && r.params.initialSlide > 0 ? (r._cssModeVirtualInitialSet = !0, requestAnimationFrame((() => {
                                f[e ? "scrollLeft" : "scrollTop"] = s
                            }))) : f[e ? "scrollLeft" : "scrollTop"] = s, t && requestAnimationFrame((() => {
                                r.wrapperEl.style.scrollSnapType = "", r._immediateVirtual = !1
                            }))
                        } else {
                            if (!r.support.smoothScroll) return h({
                                swiper: r,
                                targetPosition: s,
                                side: e ? "left" : "top"
                            }), !0;
                            f.scrollTo({
                                [e ? "left" : "top"]: s,
                                behavior: "smooth"
                            })
                        }
                        return !0
                    }
                    return r.setTransition(t), r.setTranslate(w), r.updateActiveIndex(a), r.updateSlidesClasses(), r.emit("beforeTransitionStart", t, i), r.transitionStart(s, b), 0 === t ? r.transitionEnd(s, b) : r.animating || (r.animating = !0, r.onSlideToWrapperTransitionEnd || (r.onSlideToWrapperTransitionEnd = function(e) {
                        r && !r.destroyed && e.target === this && (r.wrapperEl.removeEventListener("transitionend", r.onSlideToWrapperTransitionEnd), r.onSlideToWrapperTransitionEnd = null, delete r.onSlideToWrapperTransitionEnd, r.transitionEnd(s, b))
                    }), r.wrapperEl.addEventListener("transitionend", r.onSlideToWrapperTransitionEnd)), !0
                },
                slideToLoop: function() {
                    let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
                        t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this.params.speed,
                        s = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2],
                        i = arguments.length > 3 ? arguments[3] : void 0;
                    if ("string" === typeof e) {
                        e = parseInt(e, 10)
                    }
                    const n = this;
                    let r = e;
                    return n.params.loop && (n.virtual && n.params.virtual.enabled ? r += n.virtual.slidesBefore : r = n.getSlideIndexByData(r)), n.slideTo(r, t, s, i)
                },
                slideNext: function() {
                    let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this.params.speed,
                        t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
                        s = arguments.length > 2 ? arguments[2] : void 0;
                    const i = this,
                        {
                            enabled: n,
                            params: r,
                            animating: a
                        } = i;
                    if (!n) return i;
                    let l = r.slidesPerGroup;
                    "auto" === r.slidesPerView && 1 === r.slidesPerGroup && r.slidesPerGroupAuto && (l = Math.max(i.slidesPerViewDynamic("current", !0), 1));
                    const o = i.activeIndex < r.slidesPerGroupSkip ? 1 : l,
                        d = i.virtual && r.virtual.enabled;
                    if (r.loop) {
                        if (a && !d && r.loopPreventsSliding) return !1;
                        i.loopFix({
                            direction: "next"
                        }), i._clientLeft = i.wrapperEl.clientLeft
                    }
                    return r.rewind && i.isEnd ? i.slideTo(0, e, t, s) : i.slideTo(i.activeIndex + o, e, t, s)
                },
                slidePrev: function() {
                    let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this.params.speed,
                        t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
                        s = arguments.length > 2 ? arguments[2] : void 0;
                    const i = this,
                        {
                            params: n,
                            snapGrid: r,
                            slidesGrid: a,
                            rtlTranslate: l,
                            enabled: o,
                            animating: d
                        } = i;
                    if (!o) return i;
                    const c = i.virtual && n.virtual.enabled;
                    if (n.loop) {
                        if (d && !c && n.loopPreventsSliding) return !1;
                        i.loopFix({
                            direction: "prev"
                        }), i._clientLeft = i.wrapperEl.clientLeft
                    }

                    function p(e) {
                        return e < 0 ? -Math.floor(Math.abs(e)) : Math.floor(e)
                    }
                    const u = p(l ? i.translate : -i.translate),
                        f = r.map((e => p(e)));
                    let m = r[f.indexOf(u) - 1];
                    if ("undefined" === typeof m && n.cssMode) {
                        let e;
                        r.forEach(((t, s) => {
                            u >= t && (e = s)
                        })), "undefined" !== typeof e && (m = r[e > 0 ? e - 1 : e])
                    }
                    let h = 0;
                    if ("undefined" !== typeof m && (h = a.indexOf(m), h < 0 && (h = i.activeIndex - 1), "auto" === n.slidesPerView && 1 === n.slidesPerGroup && n.slidesPerGroupAuto && (h = h - i.slidesPerViewDynamic("previous", !0) + 1, h = Math.max(h, 0))), n.rewind && i.isBeginning) {
                        const n = i.params.virtual && i.params.virtual.enabled && i.virtual ? i.virtual.slides.length - 1 : i.slides.length - 1;
                        return i.slideTo(n, e, t, s)
                    }
                    return i.slideTo(h, e, t, s)
                },
                slideReset: function() {
                    let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this.params.speed,
                        t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
                        s = arguments.length > 2 ? arguments[2] : void 0;
                    return this.slideTo(this.activeIndex, e, t, s)
                },
                slideToClosest: function() {
                    let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this.params.speed,
                        t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
                        s = arguments.length > 2 ? arguments[2] : void 0,
                        i = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : .5;
                    const n = this;
                    let r = n.activeIndex;
                    const a = Math.min(n.params.slidesPerGroupSkip, r),
                        l = a + Math.floor((r - a) / n.params.slidesPerGroup),
                        o = n.rtlTranslate ? n.translate : -n.translate;
                    if (o >= n.snapGrid[l]) {
                        const e = n.snapGrid[l];
                        o - e > (n.snapGrid[l + 1] - e) * i && (r += n.params.slidesPerGroup)
                    } else {
                        const e = n.snapGrid[l - 1];
                        o - e <= (n.snapGrid[l] - e) * i && (r -= n.params.slidesPerGroup)
                    }
                    return r = Math.max(r, 0), r = Math.min(r, n.slidesGrid.length - 1), n.slideTo(r, e, t, s)
                },
                slideToClickedSlide: function() {
                    const e = this,
                        {
                            params: t,
                            slidesEl: s
                        } = e,
                        i = "auto" === t.slidesPerView ? e.slidesPerViewDynamic() : t.slidesPerView;
                    let n, r = e.clickedIndex;
                    const a = e.isElement ? "swiper-slide" : `.${t.slideClass}`;
                    if (t.loop) {
                        if (e.animating) return;
                        n = parseInt(e.clickedSlide.getAttribute("data-swiper-slide-index"), 10), t.centeredSlides ? r < e.loopedSlides - i / 2 || r > e.slides.length - e.loopedSlides + i / 2 ? (e.loopFix(), r = e.getSlideIndex(g(s, `${a}[data-swiper-slide-index="${n}"]`)[0]), d((() => {
                            e.slideTo(r)
                        }))) : e.slideTo(r) : r > e.slides.length - i ? (e.loopFix(), r = e.getSlideIndex(g(s, `${a}[data-swiper-slide-index="${n}"]`)[0]), d((() => {
                            e.slideTo(r)
                        }))) : e.slideTo(r)
                    } else e.slideTo(r)
                }
            };
            const $ = {
                loopCreate: function(e) {
                    const t = this,
                        {
                            params: s,
                            slidesEl: i
                        } = t;
                    if (!s.loop || t.virtual && t.params.virtual.enabled) return;
                    g(i, `.${s.slideClass}, swiper-slide`).forEach(((e, t) => {
                        e.setAttribute("data-swiper-slide-index", t)
                    })), t.loopFix({
                        slideRealIndex: e,
                        direction: s.centeredSlides ? void 0 : "next"
                    })
                },
                loopFix: function() {
                    let {
                        slideRealIndex: e,
                        slideTo: t = !0,
                        direction: s,
                        setTranslate: i,
                        activeSlideIndex: n,
                        byController: r,
                        byMousewheel: a
                    } = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                    const l = this;
                    if (!l.params.loop) return;
                    l.emit("beforeLoopFix");
                    const {
                        slides: o,
                        allowSlidePrev: d,
                        allowSlideNext: c,
                        slidesEl: p,
                        params: u
                    } = l;
                    if (l.allowSlidePrev = !0, l.allowSlideNext = !0, l.virtual && u.virtual.enabled) return t && (u.centeredSlides || 0 !== l.snapIndex ? u.centeredSlides && l.snapIndex < u.slidesPerView ? l.slideTo(l.virtual.slides.length + l.snapIndex, 0, !1, !0) : l.snapIndex === l.snapGrid.length - 1 && l.slideTo(l.virtual.slidesBefore, 0, !1, !0) : l.slideTo(l.virtual.slides.length, 0, !1, !0)), l.allowSlidePrev = d, l.allowSlideNext = c, void l.emit("loopFix");
                    const f = "auto" === u.slidesPerView ? l.slidesPerViewDynamic() : Math.ceil(parseFloat(u.slidesPerView, 10));
                    let m = u.loopedSlides || f;
                    m % u.slidesPerGroup !== 0 && (m += u.slidesPerGroup - m % u.slidesPerGroup), l.loopedSlides = m;
                    const h = [],
                        g = [];
                    let v = l.activeIndex;
                    "undefined" === typeof n ? n = l.getSlideIndex(l.slides.filter((e => e.classList.contains(u.slideActiveClass)))[0]) : v = n;
                    const w = "next" === s || !s,
                        b = "prev" === s || !s;
                    let y = 0,
                        S = 0;
                    if (n < m) {
                        y = Math.max(m - n, u.slidesPerGroup);
                        for (let e = 0; e < m - n; e += 1) {
                            const t = e - Math.floor(e / o.length) * o.length;
                            h.push(o.length - t - 1)
                        }
                    } else if (n > l.slides.length - 2 * m) {
                        S = Math.max(n - (l.slides.length - 2 * m), u.slidesPerGroup);
                        for (let e = 0; e < S; e += 1) {
                            const t = e - Math.floor(e / o.length) * o.length;
                            g.push(t)
                        }
                    }
                    if (b && h.forEach((e => {
                            l.slides[e].swiperLoopMoveDOM = !0, p.prepend(l.slides[e]), l.slides[e].swiperLoopMoveDOM = !1
                        })), w && g.forEach((e => {
                            l.slides[e].swiperLoopMoveDOM = !0, p.append(l.slides[e]), l.slides[e].swiperLoopMoveDOM = !1
                        })), l.recalcSlides(), "auto" === u.slidesPerView && l.updateSlides(), u.watchSlidesProgress && l.updateSlidesOffset(), t)
                        if (h.length > 0 && b)
                            if ("undefined" === typeof e) {
                                const e = l.slidesGrid[v],
                                    t = l.slidesGrid[v + y] - e;
                                a ? l.setTranslate(l.translate - t) : (l.slideTo(v + y, 0, !1, !0), i && (l.touches[l.isHorizontal() ? "startX" : "startY"] += t))
                            } else i && l.slideToLoop(e, 0, !1, !0);
                    else if (g.length > 0 && w)
                        if ("undefined" === typeof e) {
                            const e = l.slidesGrid[v],
                                t = l.slidesGrid[v - S] - e;
                            a ? l.setTranslate(l.translate - t) : (l.slideTo(v - S, 0, !1, !0), i && (l.touches[l.isHorizontal() ? "startX" : "startY"] += t))
                        } else l.slideToLoop(e, 0, !1, !0);
                    if (l.allowSlidePrev = d, l.allowSlideNext = c, l.controller && l.controller.control && !r) {
                        const t = {
                            slideRealIndex: e,
                            slideTo: !1,
                            direction: s,
                            setTranslate: i,
                            activeSlideIndex: n,
                            byController: !0
                        };
                        Array.isArray(l.controller.control) ? l.controller.control.forEach((e => {
                            !e.destroyed && e.params.loop && e.loopFix(t)
                        })) : l.controller.control instanceof l.constructor && l.controller.control.params.loop && l.controller.control.loopFix(t)
                    }
                    l.emit("loopFix")
                },
                loopDestroy: function() {
                    const e = this,
                        {
                            params: t,
                            slidesEl: s
                        } = e;
                    if (!t.loop || e.virtual && e.params.virtual.enabled) return;
                    e.recalcSlides();
                    const i = [];
                    e.slides.forEach((e => {
                        const t = "undefined" === typeof e.swiperSlideIndex ? 1 * e.getAttribute("data-swiper-slide-index") : e.swiperSlideIndex;
                        i[t] = e
                    })), e.slides.forEach((e => {
                        e.removeAttribute("data-swiper-slide-index")
                    })), i.forEach((e => {
                        s.append(e)
                    })), e.recalcSlides(), e.slideTo(e.realIndex, 0)
                }
            };

            function D(e) {
                const t = this,
                    s = a(),
                    i = o(),
                    n = t.touchEventsData;
                n.evCache.push(e);
                const {
                    params: r,
                    touches: l,
                    enabled: d
                } = t;
                if (!d) return;
                if (!r.simulateTouch && "mouse" === e.pointerType) return;
                if (t.animating && r.preventInteractionOnTransition) return;
                !t.animating && r.cssMode && r.loop && t.loopFix();
                let p = e;
                p.originalEvent && (p = p.originalEvent);
                let u = p.target;
                if ("wrapper" === r.touchEventsTarget && !t.wrapperEl.contains(u)) return;
                if ("which" in p && 3 === p.which) return;
                if ("button" in p && p.button > 0) return;
                if (n.isTouched && n.isMoved) return;
                const f = !!r.noSwipingClass && "" !== r.noSwipingClass,
                    m = e.composedPath ? e.composedPath() : e.path;
                f && p.target && p.target.shadowRoot && m && (u = m[0]);
                const h = r.noSwipingSelector ? r.noSwipingSelector : `.${r.noSwipingClass}`,
                    g = !(!p.target || !p.target.shadowRoot);
                if (r.noSwiping && (g ? function(e) {
                        return function t(s) {
                            if (!s || s === a() || s === o()) return null;
                            s.assignedSlot && (s = s.assignedSlot);
                            const i = s.closest(e);
                            return i || s.getRootNode ? i || t(s.getRootNode().host) : null
                        }(arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this)
                    }(h, u) : u.closest(h))) return void(t.allowClick = !0);
                if (r.swipeHandler && !u.closest(r.swipeHandler)) return;
                l.currentX = p.pageX, l.currentY = p.pageY;
                const v = l.currentX,
                    w = l.currentY,
                    b = r.edgeSwipeDetection || r.iOSEdgeSwipeDetection,
                    y = r.edgeSwipeThreshold || r.iOSEdgeSwipeThreshold;
                if (b && (v <= y || v >= i.innerWidth - y)) {
                    if ("prevent" !== b) return;
                    e.preventDefault()
                }
                Object.assign(n, {
                    isTouched: !0,
                    isMoved: !1,
                    allowTouchCallbacks: !0,
                    isScrolling: void 0,
                    startMoving: void 0
                }), l.startX = v, l.startY = w, n.touchStartTime = c(), t.allowClick = !0, t.updateSize(), t.swipeDirection = void 0, r.threshold > 0 && (n.allowThresholdMove = !1);
                let S = !0;
                u.matches(n.focusableElements) && (S = !1, "SELECT" === u.nodeName && (n.isTouched = !1)), s.activeElement && s.activeElement.matches(n.focusableElements) && s.activeElement !== u && s.activeElement.blur();
                const E = S && t.allowTouchMove && r.touchStartPreventDefault;
                !r.touchStartForcePreventDefault && !E || u.isContentEditable || p.preventDefault(), r.freeMode && r.freeMode.enabled && t.freeMode && t.animating && !r.cssMode && t.freeMode.onTouchStart(), t.emit("touchStart", p)
            }

            function N(e) {
                const t = a(),
                    s = this,
                    i = s.touchEventsData,
                    {
                        params: n,
                        touches: r,
                        rtlTranslate: l,
                        enabled: o
                    } = s;
                if (!o) return;
                if (!n.simulateTouch && "mouse" === e.pointerType) return;
                let d = e;
                if (d.originalEvent && (d = d.originalEvent), !i.isTouched) return void(i.startMoving && i.isScrolling && s.emit("touchMoveOpposite", d));
                const p = i.evCache.findIndex((e => e.pointerId === d.pointerId));
                p >= 0 && (i.evCache[p] = d);
                const u = i.evCache.length > 1 ? i.evCache[0] : d,
                    f = u.pageX,
                    m = u.pageY;
                if (d.preventedByNestedSwiper) return r.startX = f, void(r.startY = m);
                if (!s.allowTouchMove) return d.target.matches(i.focusableElements) || (s.allowClick = !1), void(i.isTouched && (Object.assign(r, {
                    startX: f,
                    startY: m,
                    prevX: s.touches.currentX,
                    prevY: s.touches.currentY,
                    currentX: f,
                    currentY: m
                }), i.touchStartTime = c()));
                if (n.touchReleaseOnEdges && !n.loop)
                    if (s.isVertical()) {
                        if (m < r.startY && s.translate <= s.maxTranslate() || m > r.startY && s.translate >= s.minTranslate()) return i.isTouched = !1, void(i.isMoved = !1)
                    } else if (f < r.startX && s.translate <= s.maxTranslate() || f > r.startX && s.translate >= s.minTranslate()) return;
                if (t.activeElement && d.target === t.activeElement && d.target.matches(i.focusableElements)) return i.isMoved = !0, void(s.allowClick = !1);
                if (i.allowTouchCallbacks && s.emit("touchMove", d), d.targetTouches && d.targetTouches.length > 1) return;
                r.currentX = f, r.currentY = m;
                const h = r.currentX - r.startX,
                    g = r.currentY - r.startY;
                if (s.params.threshold && Math.sqrt(h ** 2 + g ** 2) < s.params.threshold) return;
                if ("undefined" === typeof i.isScrolling) {
                    let e;
                    s.isHorizontal() && r.currentY === r.startY || s.isVertical() && r.currentX === r.startX ? i.isScrolling = !1 : h * h + g * g >= 25 && (e = 180 * Math.atan2(Math.abs(g), Math.abs(h)) / Math.PI, i.isScrolling = s.isHorizontal() ? e > n.touchAngle : 90 - e > n.touchAngle)
                }
                if (i.isScrolling && s.emit("touchMoveOpposite", d), "undefined" === typeof i.startMoving && (r.currentX === r.startX && r.currentY === r.startY || (i.startMoving = !0)), i.isScrolling || s.zoom && s.params.zoom && s.params.zoom.enabled && i.evCache.length > 1) return void(i.isTouched = !1);
                if (!i.startMoving) return;
                s.allowClick = !1, !n.cssMode && d.cancelable && d.preventDefault(), n.touchMoveStopPropagation && !n.nested && d.stopPropagation();
                let v = s.isHorizontal() ? h : g,
                    w = s.isHorizontal() ? r.currentX - r.previousX : r.currentY - r.previousY;
                n.oneWayMovement && (v = Math.abs(v) * (l ? 1 : -1), w = Math.abs(w) * (l ? 1 : -1)), r.diff = v, v *= n.touchRatio, l && (v = -v, w = -w);
                const b = s.touchesDirection;
                s.swipeDirection = v > 0 ? "prev" : "next", s.touchesDirection = w > 0 ? "prev" : "next";
                const y = s.params.loop && !n.cssMode;
                if (!i.isMoved) {
                    if (y && s.loopFix({
                            direction: s.swipeDirection
                        }), i.startTranslate = s.getTranslate(), s.setTransition(0), s.animating) {
                        const e = new window.CustomEvent("transitionend", {
                            bubbles: !0,
                            cancelable: !0
                        });
                        s.wrapperEl.dispatchEvent(e)
                    }
                    i.allowMomentumBounce = !1, !n.grabCursor || !0 !== s.allowSlideNext && !0 !== s.allowSlidePrev || s.setGrabCursor(!0), s.emit("sliderFirstMove", d)
                }
                let S;
                i.isMoved && b !== s.touchesDirection && y && Math.abs(v) >= 1 && (s.loopFix({
                    direction: s.swipeDirection,
                    setTranslate: !0
                }), S = !0), s.emit("sliderMove", d), i.isMoved = !0, i.currentTranslate = v + i.startTranslate;
                let E = !0,
                    T = n.resistanceRatio;
                if (n.touchReleaseOnEdges && (T = 0), v > 0 ? (y && !S && i.currentTranslate > (n.centeredSlides ? s.minTranslate() - s.size / 2 : s.minTranslate()) && s.loopFix({
                        direction: "prev",
                        setTranslate: !0,
                        activeSlideIndex: 0
                    }), i.currentTranslate > s.minTranslate() && (E = !1, n.resistance && (i.currentTranslate = s.minTranslate() - 1 + (-s.minTranslate() + i.startTranslate + v) ** T))) : v < 0 && (y && !S && i.currentTranslate < (n.centeredSlides ? s.maxTranslate() + s.size / 2 : s.maxTranslate()) && s.loopFix({
                        direction: "next",
                        setTranslate: !0,
                        activeSlideIndex: s.slides.length - ("auto" === n.slidesPerView ? s.slidesPerViewDynamic() : Math.ceil(parseFloat(n.slidesPerView, 10)))
                    }), i.currentTranslate < s.maxTranslate() && (E = !1, n.resistance && (i.currentTranslate = s.maxTranslate() + 1 - (s.maxTranslate() - i.startTranslate - v) ** T))), E && (d.preventedByNestedSwiper = !0), !s.allowSlideNext && "next" === s.swipeDirection && i.currentTranslate < i.startTranslate && (i.currentTranslate = i.startTranslate), !s.allowSlidePrev && "prev" === s.swipeDirection && i.currentTranslate > i.startTranslate && (i.currentTranslate = i.startTranslate), s.allowSlidePrev || s.allowSlideNext || (i.currentTranslate = i.startTranslate), n.threshold > 0) {
                    if (!(Math.abs(v) > n.threshold || i.allowThresholdMove)) return void(i.currentTranslate = i.startTranslate);
                    if (!i.allowThresholdMove) return i.allowThresholdMove = !0, r.startX = r.currentX, r.startY = r.currentY, i.currentTranslate = i.startTranslate, void(r.diff = s.isHorizontal() ? r.currentX - r.startX : r.currentY - r.startY)
                }
                n.followFinger && !n.cssMode && ((n.freeMode && n.freeMode.enabled && s.freeMode || n.watchSlidesProgress) && (s.updateActiveIndex(), s.updateSlidesClasses()), n.freeMode && n.freeMode.enabled && s.freeMode && s.freeMode.onTouchMove(), s.updateProgress(i.currentTranslate), s.setTranslate(i.currentTranslate))
            }

            function B(e) {
                const t = this,
                    s = t.touchEventsData,
                    i = s.evCache.findIndex((t => t.pointerId === e.pointerId));
                if (i >= 0 && s.evCache.splice(i, 1), ["pointercancel", "pointerout", "pointerleave"].includes(e.type)) {
                    if (!("pointercancel" === e.type && (t.browser.isSafari || t.browser.isWebView))) return
                }
                const {
                    params: n,
                    touches: r,
                    rtlTranslate: a,
                    slidesGrid: l,
                    enabled: o
                } = t;
                if (!o) return;
                if (!n.simulateTouch && "mouse" === e.pointerType) return;
                let p = e;
                if (p.originalEvent && (p = p.originalEvent), s.allowTouchCallbacks && t.emit("touchEnd", p), s.allowTouchCallbacks = !1, !s.isTouched) return s.isMoved && n.grabCursor && t.setGrabCursor(!1), s.isMoved = !1, void(s.startMoving = !1);
                n.grabCursor && s.isMoved && s.isTouched && (!0 === t.allowSlideNext || !0 === t.allowSlidePrev) && t.setGrabCursor(!1);
                const u = c(),
                    f = u - s.touchStartTime;
                if (t.allowClick) {
                    const e = p.path || p.composedPath && p.composedPath();
                    t.updateClickedSlide(e && e[0] || p.target), t.emit("tap click", p), f < 300 && u - s.lastClickTime < 300 && t.emit("doubleTap doubleClick", p)
                }
                if (s.lastClickTime = c(), d((() => {
                        t.destroyed || (t.allowClick = !0)
                    })), !s.isTouched || !s.isMoved || !t.swipeDirection || 0 === r.diff || s.currentTranslate === s.startTranslate) return s.isTouched = !1, s.isMoved = !1, void(s.startMoving = !1);
                let m;
                if (s.isTouched = !1, s.isMoved = !1, s.startMoving = !1, m = n.followFinger ? a ? t.translate : -t.translate : -s.currentTranslate, n.cssMode) return;
                if (n.freeMode && n.freeMode.enabled) return void t.freeMode.onTouchEnd({
                    currentPos: m
                });
                let h = 0,
                    g = t.slidesSizesGrid[0];
                for (let d = 0; d < l.length; d += d < n.slidesPerGroupSkip ? 1 : n.slidesPerGroup) {
                    const e = d < n.slidesPerGroupSkip - 1 ? 1 : n.slidesPerGroup;
                    "undefined" !== typeof l[d + e] ? m >= l[d] && m < l[d + e] && (h = d, g = l[d + e] - l[d]) : m >= l[d] && (h = d, g = l[l.length - 1] - l[l.length - 2])
                }
                let v = null,
                    w = null;
                n.rewind && (t.isBeginning ? w = n.virtual && n.virtual.enabled && t.virtual ? t.virtual.slides.length - 1 : t.slides.length - 1 : t.isEnd && (v = 0));
                const b = (m - l[h]) / g,
                    y = h < n.slidesPerGroupSkip - 1 ? 1 : n.slidesPerGroup;
                if (f > n.longSwipesMs) {
                    if (!n.longSwipes) return void t.slideTo(t.activeIndex);
                    "next" === t.swipeDirection && (b >= n.longSwipesRatio ? t.slideTo(n.rewind && t.isEnd ? v : h + y) : t.slideTo(h)), "prev" === t.swipeDirection && (b > 1 - n.longSwipesRatio ? t.slideTo(h + y) : null !== w && b < 0 && Math.abs(b) > n.longSwipesRatio ? t.slideTo(w) : t.slideTo(h))
                } else {
                    if (!n.shortSwipes) return void t.slideTo(t.activeIndex);
                    t.navigation && (p.target === t.navigation.nextEl || p.target === t.navigation.prevEl) ? p.target === t.navigation.nextEl ? t.slideTo(h + y) : t.slideTo(h) : ("next" === t.swipeDirection && t.slideTo(null !== v ? v : h + y), "prev" === t.swipeDirection && t.slideTo(null !== w ? w : h))
                }
            }

            function F() {
                const e = this,
                    {
                        params: t,
                        el: s
                    } = e;
                if (s && 0 === s.offsetWidth) return;
                t.breakpoints && e.setBreakpoint();
                const {
                    allowSlideNext: i,
                    allowSlidePrev: n,
                    snapGrid: r
                } = e, a = e.virtual && e.params.virtual.enabled;
                e.allowSlideNext = !0, e.allowSlidePrev = !0, e.updateSize(), e.updateSlides(), e.updateSlidesClasses();
                const l = a && t.loop;
                !("auto" === t.slidesPerView || t.slidesPerView > 1) || !e.isEnd || e.isBeginning || e.params.centeredSlides || l ? e.params.loop && !a ? e.slideToLoop(e.realIndex, 0, !1, !0) : e.slideTo(e.activeIndex, 0, !1, !0) : e.slideTo(e.slides.length - 1, 0, !1, !0), e.autoplay && e.autoplay.running && e.autoplay.paused && (clearTimeout(e.autoplay.resizeTimeout), e.autoplay.resizeTimeout = setTimeout((() => {
                    e.autoplay && e.autoplay.running && e.autoplay.paused && e.autoplay.resume()
                }), 500)), e.allowSlidePrev = n, e.allowSlideNext = i, e.params.watchOverflow && r !== e.snapGrid && e.checkOverflow()
            }

            function j(e) {
                const t = this;
                t.enabled && (t.allowClick || (t.params.preventClicks && e.preventDefault(), t.params.preventClicksPropagation && t.animating && (e.stopPropagation(), e.stopImmediatePropagation())))
            }

            function H() {
                const e = this,
                    {
                        wrapperEl: t,
                        rtlTranslate: s,
                        enabled: i
                    } = e;
                if (!i) return;
                let n;
                e.previousTranslate = e.translate, e.isHorizontal() ? e.translate = -t.scrollLeft : e.translate = -t.scrollTop, 0 === e.translate && (e.translate = 0), e.updateActiveIndex(), e.updateSlidesClasses();
                const r = e.maxTranslate() - e.minTranslate();
                n = 0 === r ? 0 : (e.translate - e.minTranslate()) / r, n !== e.progress && e.updateProgress(s ? -e.translate : e.translate), e.emit("setTranslate", e.translate, !1)
            }

            function V(e) {
                const t = this;
                k(t, e.target), t.params.cssMode || "auto" !== t.params.slidesPerView && !t.params.autoHeight || t.update()
            }
            let R = !1;

            function q() {}
            const W = (e, t) => {
                const s = a(),
                    {
                        params: i,
                        el: n,
                        wrapperEl: r,
                        device: l
                    } = e,
                    o = !!i.nested,
                    d = "on" === t ? "addEventListener" : "removeEventListener",
                    c = t;
                n[d]("pointerdown", e.onTouchStart, {
                    passive: !1
                }), s[d]("pointermove", e.onTouchMove, {
                    passive: !1,
                    capture: o
                }), s[d]("pointerup", e.onTouchEnd, {
                    passive: !0
                }), s[d]("pointercancel", e.onTouchEnd, {
                    passive: !0
                }), s[d]("pointerout", e.onTouchEnd, {
                    passive: !0
                }), s[d]("pointerleave", e.onTouchEnd, {
                    passive: !0
                }), (i.preventClicks || i.preventClicksPropagation) && n[d]("click", e.onClick, !0), i.cssMode && r[d]("scroll", e.onScroll), i.updateOnWindowResize ? e[c](l.ios || l.android ? "resize orientationchange observerUpdate" : "resize observerUpdate", F, !0) : e[c]("observerUpdate", F, !0), n[d]("load", e.onLoad, {
                    capture: !0
                })
            };
            const X = (e, t) => e.grid && t.grid && t.grid.rows > 1;
            const Y = {
                init: !0,
                direction: "horizontal",
                oneWayMovement: !1,
                touchEventsTarget: "wrapper",
                initialSlide: 0,
                speed: 300,
                cssMode: !1,
                updateOnWindowResize: !0,
                resizeObserver: !0,
                nested: !1,
                createElements: !1,
                enabled: !0,
                focusableElements: "input, select, option, textarea, button, video, label",
                width: null,
                height: null,
                preventInteractionOnTransition: !1,
                userAgent: null,
                url: null,
                edgeSwipeDetection: !1,
                edgeSwipeThreshold: 20,
                autoHeight: !1,
                setWrapperSize: !1,
                virtualTranslate: !1,
                effect: "slide",
                breakpoints: void 0,
                breakpointsBase: "window",
                spaceBetween: 0,
                slidesPerView: 1,
                slidesPerGroup: 1,
                slidesPerGroupSkip: 0,
                slidesPerGroupAuto: !1,
                centeredSlides: !1,
                centeredSlidesBounds: !1,
                slidesOffsetBefore: 0,
                slidesOffsetAfter: 0,
                normalizeSlideIndex: !0,
                centerInsufficientSlides: !1,
                watchOverflow: !0,
                roundLengths: !1,
                touchRatio: 1,
                touchAngle: 45,
                simulateTouch: !0,
                shortSwipes: !0,
                longSwipes: !0,
                longSwipesRatio: .5,
                longSwipesMs: 300,
                followFinger: !0,
                allowTouchMove: !0,
                threshold: 5,
                touchMoveStopPropagation: !1,
                touchStartPreventDefault: !0,
                touchStartForcePreventDefault: !1,
                touchReleaseOnEdges: !1,
                uniqueNavElements: !0,
                resistance: !0,
                resistanceRatio: .85,
                watchSlidesProgress: !1,
                grabCursor: !1,
                preventClicks: !0,
                preventClicksPropagation: !0,
                slideToClickedSlide: !1,
                loop: !1,
                loopedSlides: null,
                loopPreventsSliding: !0,
                rewind: !1,
                allowSlidePrev: !0,
                allowSlideNext: !0,
                swipeHandler: null,
                noSwiping: !0,
                noSwipingClass: "swiper-no-swiping",
                noSwipingSelector: null,
                passiveListeners: !0,
                maxBackfaceHiddenSlides: 10,
                containerModifierClass: "swiper-",
                slideClass: "swiper-slide",
                slideActiveClass: "swiper-slide-active",
                slideVisibleClass: "swiper-slide-visible",
                slideNextClass: "swiper-slide-next",
                slidePrevClass: "swiper-slide-prev",
                wrapperClass: "swiper-wrapper",
                lazyPreloaderClass: "swiper-lazy-preloader",
                lazyPreloadPrevNext: 0,
                runCallbacksOnInit: !0,
                _emitClasses: !1
            };

            function U(e, t) {
                return function() {
                    let s = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                    const i = Object.keys(s)[0],
                        n = s[i];
                    "object" === typeof n && null !== n ? (["navigation", "pagination", "scrollbar"].indexOf(i) >= 0 && !0 === e[i] && (e[i] = {
                        auto: !0
                    }), i in e && "enabled" in n ? (!0 === e[i] && (e[i] = {
                        enabled: !0
                    }), "object" !== typeof e[i] || "enabled" in e[i] || (e[i].enabled = !0), e[i] || (e[i] = {
                        enabled: !1
                    }), f(t, s)) : f(t, s)) : f(t, s)
                }
            }
            const K = {
                    eventsEmitter: L,
                    update: I,
                    translate: z,
                    transition: {
                        setTransition: function(e, t) {
                            const s = this;
                            s.params.cssMode || (s.wrapperEl.style.transitionDuration = `${e}ms`), s.emit("setTransition", e, t)
                        },
                        transitionStart: function() {
                            let e = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0],
                                t = arguments.length > 1 ? arguments[1] : void 0;
                            const s = this,
                                {
                                    params: i
                                } = s;
                            i.cssMode || (i.autoHeight && s.updateAutoHeight(), _({
                                swiper: s,
                                runCallbacks: e,
                                direction: t,
                                step: "Start"
                            }))
                        },
                        transitionEnd: function() {
                            let e = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0],
                                t = arguments.length > 1 ? arguments[1] : void 0;
                            const s = this,
                                {
                                    params: i
                                } = s;
                            s.animating = !1, i.cssMode || (s.setTransition(0), _({
                                swiper: s,
                                runCallbacks: e,
                                direction: t,
                                step: "End"
                            }))
                        }
                    },
                    slide: G,
                    loop: $,
                    grabCursor: {
                        setGrabCursor: function(e) {
                            const t = this;
                            if (!t.params.simulateTouch || t.params.watchOverflow && t.isLocked || t.params.cssMode) return;
                            const s = "container" === t.params.touchEventsTarget ? t.el : t.wrapperEl;
                            t.isElement && (t.__preventObserver__ = !0), s.style.cursor = "move", s.style.cursor = e ? "grabbing" : "grab", t.isElement && requestAnimationFrame((() => {
                                t.__preventObserver__ = !1
                            }))
                        },
                        unsetGrabCursor: function() {
                            const e = this;
                            e.params.watchOverflow && e.isLocked || e.params.cssMode || (e.isElement && (e.__preventObserver__ = !0), e["container" === e.params.touchEventsTarget ? "el" : "wrapperEl"].style.cursor = "", e.isElement && requestAnimationFrame((() => {
                                e.__preventObserver__ = !1
                            })))
                        }
                    },
                    events: {
                        attachEvents: function() {
                            const e = this,
                                t = a(),
                                {
                                    params: s
                                } = e;
                            e.onTouchStart = D.bind(e), e.onTouchMove = N.bind(e), e.onTouchEnd = B.bind(e), s.cssMode && (e.onScroll = H.bind(e)), e.onClick = j.bind(e), e.onLoad = V.bind(e), R || (t.addEventListener("touchstart", q), R = !0), W(e, "on")
                        },
                        detachEvents: function() {
                            W(this, "off")
                        }
                    },
                    breakpoints: {
                        setBreakpoint: function() {
                            const e = this,
                                {
                                    realIndex: t,
                                    initialized: s,
                                    params: i,
                                    el: n
                                } = e,
                                r = i.breakpoints;
                            if (!r || r && 0 === Object.keys(r).length) return;
                            const a = e.getBreakpoint(r, e.params.breakpointsBase, e.el);
                            if (!a || e.currentBreakpoint === a) return;
                            const l = (a in r ? r[a] : void 0) || e.originalParams,
                                o = X(e, i),
                                d = X(e, l),
                                c = i.enabled;
                            o && !d ? (n.classList.remove(`${i.containerModifierClass}grid`, `${i.containerModifierClass}grid-column`), e.emitContainerClasses()) : !o && d && (n.classList.add(`${i.containerModifierClass}grid`), (l.grid.fill && "column" === l.grid.fill || !l.grid.fill && "column" === i.grid.fill) && n.classList.add(`${i.containerModifierClass}grid-column`), e.emitContainerClasses()), ["navigation", "pagination", "scrollbar"].forEach((t => {
                                if ("undefined" === typeof l[t]) return;
                                const s = i[t] && i[t].enabled,
                                    n = l[t] && l[t].enabled;
                                s && !n && e[t].disable(), !s && n && e[t].enable()
                            }));
                            const p = l.direction && l.direction !== i.direction,
                                u = i.loop && (l.slidesPerView !== i.slidesPerView || p);
                            p && s && e.changeDirection(), f(e.params, l);
                            const m = e.params.enabled;
                            Object.assign(e, {
                                allowTouchMove: e.params.allowTouchMove,
                                allowSlideNext: e.params.allowSlideNext,
                                allowSlidePrev: e.params.allowSlidePrev
                            }), c && !m ? e.disable() : !c && m && e.enable(), e.currentBreakpoint = a, e.emit("_beforeBreakpoint", l), u && s && (e.loopDestroy(), e.loopCreate(t), e.updateSlides()), e.emit("breakpoint", l)
                        },
                        getBreakpoint: function(e) {
                            let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "window",
                                s = arguments.length > 2 ? arguments[2] : void 0;
                            if (!e || "container" === t && !s) return;
                            let i = !1;
                            const n = o(),
                                r = "window" === t ? n.innerHeight : s.clientHeight,
                                a = Object.keys(e).map((e => {
                                    if ("string" === typeof e && 0 === e.indexOf("@")) {
                                        const t = parseFloat(e.substr(1));
                                        return {
                                            value: r * t,
                                            point: e
                                        }
                                    }
                                    return {
                                        value: e,
                                        point: e
                                    }
                                }));
                            a.sort(((e, t) => parseInt(e.value, 10) - parseInt(t.value, 10)));
                            for (let l = 0; l < a.length; l += 1) {
                                const {
                                    point: e,
                                    value: r
                                } = a[l];
                                "window" === t ? n.matchMedia(`(min-width: ${r}px)`).matches && (i = e) : r <= s.clientWidth && (i = e)
                            }
                            return i || "max"
                        }
                    },
                    checkOverflow: {
                        checkOverflow: function() {
                            const e = this,
                                {
                                    isLocked: t,
                                    params: s
                                } = e,
                                {
                                    slidesOffsetBefore: i
                                } = s;
                            if (i) {
                                const t = e.slides.length - 1,
                                    s = e.slidesGrid[t] + e.slidesSizesGrid[t] + 2 * i;
                                e.isLocked = e.size > s
                            } else e.isLocked = 1 === e.snapGrid.length;
                            !0 === s.allowSlideNext && (e.allowSlideNext = !e.isLocked), !0 === s.allowSlidePrev && (e.allowSlidePrev = !e.isLocked), t && t !== e.isLocked && (e.isEnd = !1), t !== e.isLocked && e.emit(e.isLocked ? "lock" : "unlock")
                        }
                    },
                    classes: {
                        addClasses: function() {
                            const e = this,
                                {
                                    classNames: t,
                                    params: s,
                                    rtl: i,
                                    el: n,
                                    device: r
                                } = e,
                                a = function(e, t) {
                                    const s = [];
                                    return e.forEach((e => {
                                        "object" === typeof e ? Object.keys(e).forEach((i => {
                                            e[i] && s.push(t + i)
                                        })) : "string" === typeof e && s.push(t + e)
                                    })), s
                                }(["initialized", s.direction, {
                                    "free-mode": e.params.freeMode && s.freeMode.enabled
                                }, {
                                    autoheight: s.autoHeight
                                }, {
                                    rtl: i
                                }, {
                                    grid: s.grid && s.grid.rows > 1
                                }, {
                                    "grid-column": s.grid && s.grid.rows > 1 && "column" === s.grid.fill
                                }, {
                                    android: r.android
                                }, {
                                    ios: r.ios
                                }, {
                                    "css-mode": s.cssMode
                                }, {
                                    centered: s.cssMode && s.centeredSlides
                                }, {
                                    "watch-progress": s.watchSlidesProgress
                                }], s.containerModifierClass);
                            t.push(...a), n.classList.add(...t), e.emitContainerClasses()
                        },
                        removeClasses: function() {
                            const {
                                el: e,
                                classNames: t
                            } = this;
                            e.classList.remove(...t), this.emitContainerClasses()
                        }
                    }
                },
                Z = {};
            class J {
                constructor() {
                    let e, t;
                    for (var s = arguments.length, i = new Array(s), n = 0; n < s; n++) i[n] = arguments[n];
                    1 === i.length && i[0].constructor && "Object" === Object.prototype.toString.call(i[0]).slice(8, -1) ? t = i[0] : [e, t] = i, t || (t = {}), t = f({}, t), e && !t.el && (t.el = e);
                    const r = a();
                    if (t.el && "string" === typeof t.el && r.querySelectorAll(t.el).length > 1) {
                        const e = [];
                        return r.querySelectorAll(t.el).forEach((s => {
                            const i = f({}, t, {
                                el: s
                            });
                            e.push(new J(i))
                        })), e
                    }
                    const l = this;
                    l.__swiper__ = !0, l.support = C(), l.device = M({
                        userAgent: t.userAgent
                    }), l.browser = P(), l.eventsListeners = {}, l.eventsAnyListeners = [], l.modules = [...l.__modules__], t.modules && Array.isArray(t.modules) && l.modules.push(...t.modules);
                    const o = {};
                    l.modules.forEach((e => {
                        e({
                            params: t,
                            swiper: l,
                            extendParams: U(t, o),
                            on: l.on.bind(l),
                            once: l.once.bind(l),
                            off: l.off.bind(l),
                            emit: l.emit.bind(l)
                        })
                    }));
                    const d = f({}, Y, o);
                    return l.params = f({}, d, Z, t), l.originalParams = f({}, l.params), l.passedParams = f({}, t), l.params && l.params.on && Object.keys(l.params.on).forEach((e => {
                        l.on(e, l.params.on[e])
                    })), l.params && l.params.onAny && l.onAny(l.params.onAny), Object.assign(l, {
                        enabled: l.params.enabled,
                        el: e,
                        classNames: [],
                        slides: [],
                        slidesGrid: [],
                        snapGrid: [],
                        slidesSizesGrid: [],
                        isHorizontal: () => "horizontal" === l.params.direction,
                        isVertical: () => "vertical" === l.params.direction,
                        activeIndex: 0,
                        realIndex: 0,
                        isBeginning: !0,
                        isEnd: !1,
                        translate: 0,
                        previousTranslate: 0,
                        progress: 0,
                        velocity: 0,
                        animating: !1,
                        cssOverflowAdjustment() {
                            return Math.trunc(this.translate / 2 ** 23) * 2 ** 23
                        },
                        allowSlideNext: l.params.allowSlideNext,
                        allowSlidePrev: l.params.allowSlidePrev,
                        touchEventsData: {
                            isTouched: void 0,
                            isMoved: void 0,
                            allowTouchCallbacks: void 0,
                            touchStartTime: void 0,
                            isScrolling: void 0,
                            currentTranslate: void 0,
                            startTranslate: void 0,
                            allowThresholdMove: void 0,
                            focusableElements: l.params.focusableElements,
                            lastClickTime: 0,
                            clickTimeout: void 0,
                            velocities: [],
                            allowMomentumBounce: void 0,
                            startMoving: void 0,
                            evCache: []
                        },
                        allowClick: !0,
                        allowTouchMove: l.params.allowTouchMove,
                        touches: {
                            startX: 0,
                            startY: 0,
                            currentX: 0,
                            currentY: 0,
                            diff: 0
                        },
                        imagesToLoad: [],
                        imagesLoaded: 0
                    }), l.emit("_swiper"), l.params.init && l.init(), l
                }
                getSlideIndex(e) {
                    const {
                        slidesEl: t,
                        params: s
                    } = this, i = b(g(t, `.${s.slideClass}, swiper-slide`)[0]);
                    return b(e) - i
                }
                getSlideIndexByData(e) {
                    return this.getSlideIndex(this.slides.filter((t => 1 * t.getAttribute("data-swiper-slide-index") === e))[0])
                }
                recalcSlides() {
                    const {
                        slidesEl: e,
                        params: t
                    } = this;
                    this.slides = g(e, `.${t.slideClass}, swiper-slide`)
                }
                enable() {
                    const e = this;
                    e.enabled || (e.enabled = !0, e.params.grabCursor && e.setGrabCursor(), e.emit("enable"))
                }
                disable() {
                    const e = this;
                    e.enabled && (e.enabled = !1, e.params.grabCursor && e.unsetGrabCursor(), e.emit("disable"))
                }
                setProgress(e, t) {
                    const s = this;
                    e = Math.min(Math.max(e, 0), 1);
                    const i = s.minTranslate(),
                        n = (s.maxTranslate() - i) * e + i;
                    s.translateTo(n, "undefined" === typeof t ? 0 : t), s.updateActiveIndex(), s.updateSlidesClasses()
                }
                emitContainerClasses() {
                    const e = this;
                    if (!e.params._emitClasses || !e.el) return;
                    const t = e.el.className.split(" ").filter((t => 0 === t.indexOf("swiper") || 0 === t.indexOf(e.params.containerModifierClass)));
                    e.emit("_containerClasses", t.join(" "))
                }
                getSlideClasses(e) {
                    const t = this;
                    return t.destroyed ? "" : e.className.split(" ").filter((e => 0 === e.indexOf("swiper-slide") || 0 === e.indexOf(t.params.slideClass))).join(" ")
                }
                emitSlidesClasses() {
                    const e = this;
                    if (!e.params._emitClasses || !e.el) return;
                    const t = [];
                    e.slides.forEach((s => {
                        const i = e.getSlideClasses(s);
                        t.push({
                            slideEl: s,
                            classNames: i
                        }), e.emit("_slideClass", s, i)
                    })), e.emit("_slideClasses", t)
                }
                slidesPerViewDynamic() {
                    let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "current",
                        t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                    const {
                        params: s,
                        slides: i,
                        slidesGrid: n,
                        slidesSizesGrid: r,
                        size: a,
                        activeIndex: l
                    } = this;
                    let o = 1;
                    if (s.centeredSlides) {
                        let e, t = i[l] ? i[l].swiperSlideSize : 0;
                        for (let s = l + 1; s < i.length; s += 1) i[s] && !e && (t += i[s].swiperSlideSize, o += 1, t > a && (e = !0));
                        for (let s = l - 1; s >= 0; s -= 1) i[s] && !e && (t += i[s].swiperSlideSize, o += 1, t > a && (e = !0))
                    } else if ("current" === e)
                        for (let d = l + 1; d < i.length; d += 1) {
                            (t ? n[d] + r[d] - n[l] < a : n[d] - n[l] < a) && (o += 1)
                        } else
                            for (let d = l - 1; d >= 0; d -= 1) {
                                n[l] - n[d] < a && (o += 1)
                            }
                    return o
                }
                update() {
                    const e = this;
                    if (!e || e.destroyed) return;
                    const {
                        snapGrid: t,
                        params: s
                    } = e;

                    function i() {
                        const t = e.rtlTranslate ? -1 * e.translate : e.translate,
                            s = Math.min(Math.max(t, e.maxTranslate()), e.minTranslate());
                        e.setTranslate(s), e.updateActiveIndex(), e.updateSlidesClasses()
                    }
                    let n;
                    if (s.breakpoints && e.setBreakpoint(), [...e.el.querySelectorAll('[loading="lazy"]')].forEach((t => {
                            t.complete && k(e, t)
                        })), e.updateSize(), e.updateSlides(), e.updateProgress(), e.updateSlidesClasses(), s.freeMode && s.freeMode.enabled && !s.cssMode) i(), s.autoHeight && e.updateAutoHeight();
                    else {
                        if (("auto" === s.slidesPerView || s.slidesPerView > 1) && e.isEnd && !s.centeredSlides) {
                            const t = e.virtual && s.virtual.enabled ? e.virtual.slides : e.slides;
                            n = e.slideTo(t.length - 1, 0, !1, !0)
                        } else n = e.slideTo(e.activeIndex, 0, !1, !0);
                        n || i()
                    }
                    s.watchOverflow && t !== e.snapGrid && e.checkOverflow(), e.emit("update")
                }
                changeDirection(e) {
                    let t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
                    const s = this,
                        i = s.params.direction;
                    return e || (e = "horizontal" === i ? "vertical" : "horizontal"), e === i || "horizontal" !== e && "vertical" !== e || (s.el.classList.remove(`${s.params.containerModifierClass}${i}`), s.el.classList.add(`${s.params.containerModifierClass}${e}`), s.emitContainerClasses(), s.params.direction = e, s.slides.forEach((t => {
                        "vertical" === e ? t.style.width = "" : t.style.height = ""
                    })), s.emit("changeDirection"), t && s.update()), s
                }
                changeLanguageDirection(e) {
                    const t = this;
                    t.rtl && "rtl" === e || !t.rtl && "ltr" === e || (t.rtl = "rtl" === e, t.rtlTranslate = "horizontal" === t.params.direction && t.rtl, t.rtl ? (t.el.classList.add(`${t.params.containerModifierClass}rtl`), t.el.dir = "rtl") : (t.el.classList.remove(`${t.params.containerModifierClass}rtl`), t.el.dir = "ltr"), t.update())
                }
                mount(e) {
                    const t = this;
                    if (t.mounted) return !0;
                    let s = e || t.params.el;
                    if ("string" === typeof s && (s = document.querySelector(s)), !s) return !1;
                    s.swiper = t, s.shadowEl && (t.isElement = !0);
                    const i = () => `.${(t.params.wrapperClass||"").trim().split(" ").join(".")}`;
                    let n = (() => {
                        if (s && s.shadowRoot && s.shadowRoot.querySelector) {
                            return s.shadowRoot.querySelector(i())
                        }
                        return g(s, i())[0]
                    })();
                    return !n && t.params.createElements && (n = v("div", t.params.wrapperClass), s.append(n), g(s, `.${t.params.slideClass}`).forEach((e => {
                        n.append(e)
                    }))), Object.assign(t, {
                        el: s,
                        wrapperEl: n,
                        slidesEl: t.isElement ? s : n,
                        mounted: !0,
                        rtl: "rtl" === s.dir.toLowerCase() || "rtl" === w(s, "direction"),
                        rtlTranslate: "horizontal" === t.params.direction && ("rtl" === s.dir.toLowerCase() || "rtl" === w(s, "direction")),
                        wrongRTL: "-webkit-box" === w(n, "display")
                    }), !0
                }
                init(e) {
                    const t = this;
                    if (t.initialized) return t;
                    return !1 === t.mount(e) || (t.emit("beforeInit"), t.params.breakpoints && t.setBreakpoint(), t.addClasses(), t.updateSize(), t.updateSlides(), t.params.watchOverflow && t.checkOverflow(), t.params.grabCursor && t.enabled && t.setGrabCursor(), t.params.loop && t.virtual && t.params.virtual.enabled ? t.slideTo(t.params.initialSlide + t.virtual.slidesBefore, 0, t.params.runCallbacksOnInit, !1, !0) : t.slideTo(t.params.initialSlide, 0, t.params.runCallbacksOnInit, !1, !0), t.params.loop && t.loopCreate(), t.attachEvents(), [...t.el.querySelectorAll('[loading="lazy"]')].forEach((e => {
                        e.complete ? k(t, e) : e.addEventListener("load", (e => {
                            k(t, e.target)
                        }))
                    })), A(t), t.initialized = !0, A(t), t.emit("init"), t.emit("afterInit")), t
                }
                destroy() {
                    let e = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0],
                        t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
                    const s = this,
                        {
                            params: i,
                            el: n,
                            wrapperEl: r,
                            slides: a
                        } = s;
                    return "undefined" === typeof s.params || s.destroyed || (s.emit("beforeDestroy"), s.initialized = !1, s.detachEvents(), i.loop && s.loopDestroy(), t && (s.removeClasses(), n.removeAttribute("style"), r.removeAttribute("style"), a && a.length && a.forEach((e => {
                        e.classList.remove(i.slideVisibleClass, i.slideActiveClass, i.slideNextClass, i.slidePrevClass), e.removeAttribute("style"), e.removeAttribute("data-swiper-slide-index")
                    }))), s.emit("destroy"), Object.keys(s.eventsListeners).forEach((e => {
                        s.off(e)
                    })), !1 !== e && (s.el.swiper = null, function(e) {
                        const t = e;
                        Object.keys(t).forEach((e => {
                            try {
                                t[e] = null
                            } catch (s) {}
                            try {
                                delete t[e]
                            } catch (s) {}
                        }))
                    }(s)), s.destroyed = !0), null
                }
                static extendDefaults(e) {
                    f(Z, e)
                }
                static get extendedDefaults() {
                    return Z
                }
                static get defaults() {
                    return Y
                }
                static installModule(e) {
                    J.prototype.__modules__ || (J.prototype.__modules__ = []);
                    const t = J.prototype.__modules__;
                    "function" === typeof e && t.indexOf(e) < 0 && t.push(e)
                }
                static use(e) {
                    return Array.isArray(e) ? (e.forEach((e => J.installModule(e))), J) : (J.installModule(e), J)
                }
            }
            Object.keys(K).forEach((e => {
                Object.keys(K[e]).forEach((t => {
                    J.prototype[t] = K[e][t]
                }))
            })), J.use([function(e) {
                let {
                    swiper: t,
                    on: s,
                    emit: i
                } = e;
                const n = o();
                let r = null,
                    a = null;
                const l = () => {
                        t && !t.destroyed && t.initialized && (i("beforeResize"), i("resize"))
                    },
                    d = () => {
                        t && !t.destroyed && t.initialized && i("orientationchange")
                    };
                s("init", (() => {
                    t.params.resizeObserver && "undefined" !== typeof n.ResizeObserver ? t && !t.destroyed && t.initialized && (r = new ResizeObserver((e => {
                        a = n.requestAnimationFrame((() => {
                            const {
                                width: s,
                                height: i
                            } = t;
                            let n = s,
                                r = i;
                            e.forEach((e => {
                                let {
                                    contentBoxSize: s,
                                    contentRect: i,
                                    target: a
                                } = e;
                                a && a !== t.el || (n = i ? i.width : (s[0] || s).inlineSize, r = i ? i.height : (s[0] || s).blockSize)
                            })), n === s && r === i || l()
                        }))
                    })), r.observe(t.el)) : (n.addEventListener("resize", l), n.addEventListener("orientationchange", d))
                })), s("destroy", (() => {
                    a && n.cancelAnimationFrame(a), r && r.unobserve && t.el && (r.unobserve(t.el), r = null), n.removeEventListener("resize", l), n.removeEventListener("orientationchange", d)
                }))
            }, function(e) {
                let {
                    swiper: t,
                    extendParams: s,
                    on: i,
                    emit: n
                } = e;
                const r = [],
                    a = o(),
                    l = function(e) {
                        let s = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                        const i = new(a.MutationObserver || a.WebkitMutationObserver)((e => {
                            if (t.__preventObserver__) return;
                            if (1 === e.length) return void n("observerUpdate", e[0]);
                            const s = function() {
                                n("observerUpdate", e[0])
                            };
                            a.requestAnimationFrame ? a.requestAnimationFrame(s) : a.setTimeout(s, 0)
                        }));
                        i.observe(e, {
                            attributes: "undefined" === typeof s.attributes || s.attributes,
                            childList: "undefined" === typeof s.childList || s.childList,
                            characterData: "undefined" === typeof s.characterData || s.characterData
                        }), r.push(i)
                    };
                s({
                    observer: !1,
                    observeParents: !1,
                    observeSlideChildren: !1
                }), i("init", (() => {
                    if (t.params.observer) {
                        if (t.params.observeParents) {
                            const e = y(t.el);
                            for (let t = 0; t < e.length; t += 1) l(e[t])
                        }
                        l(t.el, {
                            childList: t.params.observeSlideChildren
                        }), l(t.wrapperEl, {
                            attributes: !1
                        })
                    }
                })), i("destroy", (() => {
                    r.forEach((e => {
                        e.disconnect()
                    })), r.splice(0, r.length)
                }))
            }]);
            const Q = J;

            function ee(e, t, s, i) {
                return e.params.createElements && Object.keys(i).forEach((n => {
                    if (!s[n] && !0 === s.auto) {
                        let r = g(e.el, `.${i[n]}`)[0];
                        r || (r = v("div", i[n]), r.className = i[n], e.el.append(r)), s[n] = r, t[n] = r
                    }
                })), s
            }

            function te(e) {
                let {
                    swiper: t,
                    extendParams: s,
                    on: i,
                    emit: n
                } = e;
                s({
                    navigation: {
                        nextEl: null,
                        prevEl: null,
                        hideOnClick: !1,
                        disabledClass: "swiper-button-disabled",
                        hiddenClass: "swiper-button-hidden",
                        lockClass: "swiper-button-lock",
                        navigationDisabledClass: "swiper-navigation-disabled"
                    }
                }), t.navigation = {
                    nextEl: null,
                    prevEl: null
                };
                const r = e => (Array.isArray(e) || (e = [e].filter((e => !!e))), e);

                function a(e) {
                    let s;
                    return e && "string" === typeof e && t.isElement && (s = t.el.shadowRoot.querySelector(e), s) ? s : (e && ("string" === typeof e && (s = [...document.querySelectorAll(e)]), t.params.uniqueNavElements && "string" === typeof e && s.length > 1 && 1 === t.el.querySelectorAll(e).length && (s = t.el.querySelector(e))), e && !s ? e : s)
                }

                function l(e, s) {
                    const i = t.params.navigation;
                    (e = r(e)).forEach((e => {
                        e && (e.classList[s ? "add" : "remove"](...i.disabledClass.split(" ")), "BUTTON" === e.tagName && (e.disabled = s), t.params.watchOverflow && t.enabled && e.classList[t.isLocked ? "add" : "remove"](i.lockClass))
                    }))
                }

                function o() {
                    const {
                        nextEl: e,
                        prevEl: s
                    } = t.navigation;
                    if (t.params.loop) return l(s, !1), void l(e, !1);
                    l(s, t.isBeginning && !t.params.rewind), l(e, t.isEnd && !t.params.rewind)
                }

                function d(e) {
                    e.preventDefault(), (!t.isBeginning || t.params.loop || t.params.rewind) && (t.slidePrev(), n("navigationPrev"))
                }

                function c(e) {
                    e.preventDefault(), (!t.isEnd || t.params.loop || t.params.rewind) && (t.slideNext(), n("navigationNext"))
                }

                function p() {
                    const e = t.params.navigation;
                    if (t.params.navigation = ee(t, t.originalParams.navigation, t.params.navigation, {
                            nextEl: "swiper-button-next",
                            prevEl: "swiper-button-prev"
                        }), !e.nextEl && !e.prevEl) return;
                    let s = a(e.nextEl),
                        i = a(e.prevEl);
                    Object.assign(t.navigation, {
                        nextEl: s,
                        prevEl: i
                    }), s = r(s), i = r(i);
                    const n = (s, i) => {
                        s && s.addEventListener("click", "next" === i ? c : d), !t.enabled && s && s.classList.add(...e.lockClass.split(" "))
                    };
                    s.forEach((e => n(e, "next"))), i.forEach((e => n(e, "prev")))
                }

                function u() {
                    let {
                        nextEl: e,
                        prevEl: s
                    } = t.navigation;
                    e = r(e), s = r(s);
                    const i = (e, s) => {
                        e.removeEventListener("click", "next" === s ? c : d), e.classList.remove(...t.params.navigation.disabledClass.split(" "))
                    };
                    e.forEach((e => i(e, "next"))), s.forEach((e => i(e, "prev")))
                }
                i("init", (() => {
                    !1 === t.params.navigation.enabled ? f() : (p(), o())
                })), i("toEdge fromEdge lock unlock", (() => {
                    o()
                })), i("destroy", (() => {
                    u()
                })), i("enable disable", (() => {
                    let {
                        nextEl: e,
                        prevEl: s
                    } = t.navigation;
                    e = r(e), s = r(s), [...e, ...s].filter((e => !!e)).forEach((e => e.classList[t.enabled ? "remove" : "add"](t.params.navigation.lockClass)))
                })), i("click", ((e, s) => {
                    let {
                        nextEl: i,
                        prevEl: a
                    } = t.navigation;
                    i = r(i), a = r(a);
                    const l = s.target;
                    if (t.params.navigation.hideOnClick && !a.includes(l) && !i.includes(l)) {
                        if (t.pagination && t.params.pagination && t.params.pagination.clickable && (t.pagination.el === l || t.pagination.el.contains(l))) return;
                        let e;
                        i.length ? e = i[0].classList.contains(t.params.navigation.hiddenClass) : a.length && (e = a[0].classList.contains(t.params.navigation.hiddenClass)), n(!0 === e ? "navigationShow" : "navigationHide"), [...i, ...a].filter((e => !!e)).forEach((e => e.classList.toggle(t.params.navigation.hiddenClass)))
                    }
                }));
                const f = () => {
                    t.el.classList.add(...t.params.navigation.navigationDisabledClass.split(" ")), u()
                };
                Object.assign(t.navigation, {
                    enable: () => {
                        t.el.classList.remove(...t.params.navigation.navigationDisabledClass.split(" ")), p(), o()
                    },
                    disable: f,
                    update: o,
                    init: p,
                    destroy: u
                })
            }

            function se() {
                return `.${(arguments.length>0&&void 0!==arguments[0]?arguments[0]:"").trim().replace(/([\.:!+\/])/g,"\\$1").replace(/ /g,".")}`
            }

            function ie(e) {
                let {
                    swiper: t,
                    extendParams: s,
                    on: i,
                    emit: n
                } = e;
                const r = "swiper-pagination";
                let a;
                s({
                    pagination: {
                        el: null,
                        bulletElement: "span",
                        clickable: !1,
                        hideOnClick: !1,
                        renderBullet: null,
                        renderProgressbar: null,
                        renderFraction: null,
                        renderCustom: null,
                        progressbarOpposite: !1,
                        type: "bullets",
                        dynamicBullets: !1,
                        dynamicMainBullets: 1,
                        formatFractionCurrent: e => e,
                        formatFractionTotal: e => e,
                        bulletClass: `${r}-bullet`,
                        bulletActiveClass: `${r}-bullet-active`,
                        modifierClass: `${r}-`,
                        currentClass: `${r}-current`,
                        totalClass: `${r}-total`,
                        hiddenClass: `${r}-hidden`,
                        progressbarFillClass: `${r}-progressbar-fill`,
                        progressbarOppositeClass: `${r}-progressbar-opposite`,
                        clickableClass: `${r}-clickable`,
                        lockClass: `${r}-lock`,
                        horizontalClass: `${r}-horizontal`,
                        verticalClass: `${r}-vertical`,
                        paginationDisabledClass: `${r}-disabled`
                    }
                }), t.pagination = {
                    el: null,
                    bullets: []
                };
                let l = 0;
                const o = e => (Array.isArray(e) || (e = [e].filter((e => !!e))), e);

                function d() {
                    return !t.params.pagination.el || !t.pagination.el || Array.isArray(t.pagination.el) && 0 === t.pagination.el.length
                }

                function c(e, s) {
                    const {
                        bulletActiveClass: i
                    } = t.params.pagination;
                    e && (e = e[("prev" === s ? "previous" : "next") + "ElementSibling"]) && (e.classList.add(`${i}-${s}`), (e = e[("prev" === s ? "previous" : "next") + "ElementSibling"]) && e.classList.add(`${i}-${s}-${s}`))
                }

                function p(e) {
                    const s = e.target.closest(se(t.params.pagination.bulletClass));
                    if (!s) return;
                    e.preventDefault();
                    const i = b(s) * t.params.slidesPerGroup;
                    if (t.params.loop) {
                        if (t.realIndex === i) return;
                        const e = t.getSlideIndexByData(i),
                            s = t.getSlideIndexByData(t.realIndex);
                        e > t.slides.length - t.loopedSlides && t.loopFix({
                            direction: e > s ? "next" : "prev",
                            activeSlideIndex: e,
                            slideTo: !1
                        }), t.slideToLoop(i)
                    } else t.slideTo(i)
                }

                function u() {
                    const e = t.rtl,
                        s = t.params.pagination;
                    if (d()) return;
                    let i, r, p = t.pagination.el;
                    p = o(p);
                    const u = t.virtual && t.params.virtual.enabled ? t.virtual.slides.length : t.slides.length,
                        f = t.params.loop ? Math.ceil(u / t.params.slidesPerGroup) : t.snapGrid.length;
                    if (t.params.loop ? (r = t.previousRealIndex || 0, i = t.params.slidesPerGroup > 1 ? Math.floor(t.realIndex / t.params.slidesPerGroup) : t.realIndex) : "undefined" !== typeof t.snapIndex ? (i = t.snapIndex, r = t.previousSnapIndex) : (r = t.previousIndex || 0, i = t.activeIndex || 0), "bullets" === s.type && t.pagination.bullets && t.pagination.bullets.length > 0) {
                        const n = t.pagination.bullets;
                        let o, d, u;
                        if (s.dynamicBullets && (a = S(n[0], t.isHorizontal() ? "width" : "height", !0), p.forEach((e => {
                                e.style[t.isHorizontal() ? "width" : "height"] = a * (s.dynamicMainBullets + 4) + "px"
                            })), s.dynamicMainBullets > 1 && void 0 !== r && (l += i - (r || 0), l > s.dynamicMainBullets - 1 ? l = s.dynamicMainBullets - 1 : l < 0 && (l = 0)), o = Math.max(i - l, 0), d = o + (Math.min(n.length, s.dynamicMainBullets) - 1), u = (d + o) / 2), n.forEach((e => {
                                const t = [...["", "-next", "-next-next", "-prev", "-prev-prev", "-main"].map((e => `${s.bulletActiveClass}${e}`))].map((e => "string" === typeof e && e.includes(" ") ? e.split(" ") : e)).flat();
                                e.classList.remove(...t)
                            })), p.length > 1) n.forEach((e => {
                            const n = b(e);
                            n === i ? e.classList.add(...s.bulletActiveClass.split(" ")) : t.isElement && e.setAttribute("part", "bullet"), s.dynamicBullets && (n >= o && n <= d && e.classList.add(...`${s.bulletActiveClass}-main`.split(" ")), n === o && c(e, "prev"), n === d && c(e, "next"))
                        }));
                        else {
                            const e = n[i];
                            if (e && e.classList.add(...s.bulletActiveClass.split(" ")), t.isElement && n.forEach(((e, t) => {
                                    e.setAttribute("part", t === i ? "bullet-active" : "bullet")
                                })), s.dynamicBullets) {
                                const e = n[o],
                                    t = n[d];
                                for (let i = o; i <= d; i += 1) n[i] && n[i].classList.add(...`${s.bulletActiveClass}-main`.split(" "));
                                c(e, "prev"), c(t, "next")
                            }
                        }
                        if (s.dynamicBullets) {
                            const i = Math.min(n.length, s.dynamicMainBullets + 4),
                                r = (a * i - a) / 2 - u * a,
                                l = e ? "right" : "left";
                            n.forEach((e => {
                                e.style[t.isHorizontal() ? l : "top"] = `${r}px`
                            }))
                        }
                    }
                    p.forEach(((e, r) => {
                        if ("fraction" === s.type && (e.querySelectorAll(se(s.currentClass)).forEach((e => {
                                e.textContent = s.formatFractionCurrent(i + 1)
                            })), e.querySelectorAll(se(s.totalClass)).forEach((e => {
                                e.textContent = s.formatFractionTotal(f)
                            }))), "progressbar" === s.type) {
                            let n;
                            n = s.progressbarOpposite ? t.isHorizontal() ? "vertical" : "horizontal" : t.isHorizontal() ? "horizontal" : "vertical";
                            const r = (i + 1) / f;
                            let a = 1,
                                l = 1;
                            "horizontal" === n ? a = r : l = r, e.querySelectorAll(se(s.progressbarFillClass)).forEach((e => {
                                e.style.transform = `translate3d(0,0,0) scaleX(${a}) scaleY(${l})`, e.style.transitionDuration = `${t.params.speed}ms`
                            }))
                        }
                        "custom" === s.type && s.renderCustom ? (e.innerHTML = s.renderCustom(t, i + 1, f), 0 === r && n("paginationRender", e)) : (0 === r && n("paginationRender", e), n("paginationUpdate", e)), t.params.watchOverflow && t.enabled && e.classList[t.isLocked ? "add" : "remove"](s.lockClass)
                    }))
                }

                function f() {
                    const e = t.params.pagination;
                    if (d()) return;
                    const s = t.virtual && t.params.virtual.enabled ? t.virtual.slides.length : t.slides.length;
                    let i = t.pagination.el;
                    i = o(i);
                    let r = "";
                    if ("bullets" === e.type) {
                        let i = t.params.loop ? Math.ceil(s / t.params.slidesPerGroup) : t.snapGrid.length;
                        t.params.freeMode && t.params.freeMode.enabled && i > s && (i = s);
                        for (let s = 0; s < i; s += 1) e.renderBullet ? r += e.renderBullet.call(t, s, e.bulletClass) : r += `<${e.bulletElement} ${t.isElement?'part="bullet"':""} class="${e.bulletClass}"></${e.bulletElement}>`
                    }
                    "fraction" === e.type && (r = e.renderFraction ? e.renderFraction.call(t, e.currentClass, e.totalClass) : `<span class="${e.currentClass}"></span> / <span class="${e.totalClass}"></span>`), "progressbar" === e.type && (r = e.renderProgressbar ? e.renderProgressbar.call(t, e.progressbarFillClass) : `<span class="${e.progressbarFillClass}"></span>`), t.pagination.bullets = [], i.forEach((s => {
                        "custom" !== e.type && (s.innerHTML = r || ""), "bullets" === e.type && t.pagination.bullets.push(...s.querySelectorAll(se(e.bulletClass)))
                    })), "custom" !== e.type && n("paginationRender", i[0])
                }

                function m() {
                    t.params.pagination = ee(t, t.originalParams.pagination, t.params.pagination, {
                        el: "swiper-pagination"
                    });
                    const e = t.params.pagination;
                    if (!e.el) return;
                    let s;
                    "string" === typeof e.el && t.isElement && (s = t.el.shadowRoot.querySelector(e.el)), s || "string" !== typeof e.el || (s = [...document.querySelectorAll(e.el)]), s || (s = e.el), s && 0 !== s.length && (t.params.uniqueNavElements && "string" === typeof e.el && Array.isArray(s) && s.length > 1 && (s = [...t.el.querySelectorAll(e.el)], s.length > 1 && (s = s.filter((e => y(e, ".swiper")[0] === t.el))[0])), Array.isArray(s) && 1 === s.length && (s = s[0]), Object.assign(t.pagination, {
                        el: s
                    }), s = o(s), s.forEach((s => {
                        "bullets" === e.type && e.clickable && s.classList.add(e.clickableClass), s.classList.add(e.modifierClass + e.type), s.classList.add(t.isHorizontal() ? e.horizontalClass : e.verticalClass), "bullets" === e.type && e.dynamicBullets && (s.classList.add(`${e.modifierClass}${e.type}-dynamic`), l = 0, e.dynamicMainBullets < 1 && (e.dynamicMainBullets = 1)), "progressbar" === e.type && e.progressbarOpposite && s.classList.add(e.progressbarOppositeClass), e.clickable && s.addEventListener("click", p), t.enabled || s.classList.add(e.lockClass)
                    })))
                }

                function h() {
                    const e = t.params.pagination;
                    if (d()) return;
                    let s = t.pagination.el;
                    s && (s = o(s), s.forEach((s => {
                        s.classList.remove(e.hiddenClass), s.classList.remove(e.modifierClass + e.type), s.classList.remove(t.isHorizontal() ? e.horizontalClass : e.verticalClass), e.clickable && s.removeEventListener("click", p)
                    }))), t.pagination.bullets && t.pagination.bullets.forEach((t => t.classList.remove(...e.bulletActiveClass.split(" "))))
                }
                i("changeDirection", (() => {
                    if (!t.pagination || !t.pagination.el) return;
                    const e = t.params.pagination;
                    let {
                        el: s
                    } = t.pagination;
                    s = o(s), s.forEach((s => {
                        s.classList.remove(e.horizontalClass, e.verticalClass), s.classList.add(t.isHorizontal() ? e.horizontalClass : e.verticalClass)
                    }))
                })), i("init", (() => {
                    !1 === t.params.pagination.enabled ? g() : (m(), f(), u())
                })), i("activeIndexChange", (() => {
                    "undefined" === typeof t.snapIndex && u()
                })), i("snapIndexChange", (() => {
                    u()
                })), i("snapGridLengthChange", (() => {
                    f(), u()
                })), i("destroy", (() => {
                    h()
                })), i("enable disable", (() => {
                    let {
                        el: e
                    } = t.pagination;
                    e && (e = o(e), e.forEach((e => e.classList[t.enabled ? "remove" : "add"](t.params.pagination.lockClass))))
                })), i("lock unlock", (() => {
                    u()
                })), i("click", ((e, s) => {
                    const i = s.target;
                    let {
                        el: r
                    } = t.pagination;
                    if (Array.isArray(r) || (r = [r].filter((e => !!e))), t.params.pagination.el && t.params.pagination.hideOnClick && r && r.length > 0 && !i.classList.contains(t.params.pagination.bulletClass)) {
                        if (t.navigation && (t.navigation.nextEl && i === t.navigation.nextEl || t.navigation.prevEl && i === t.navigation.prevEl)) return;
                        const e = r[0].classList.contains(t.params.pagination.hiddenClass);
                        n(!0 === e ? "paginationShow" : "paginationHide"), r.forEach((e => e.classList.toggle(t.params.pagination.hiddenClass)))
                    }
                }));
                const g = () => {
                    t.el.classList.add(t.params.pagination.paginationDisabledClass);
                    let {
                        el: e
                    } = t.pagination;
                    e && (e = o(e), e.forEach((e => e.classList.add(t.params.pagination.paginationDisabledClass)))), h()
                };
                Object.assign(t.pagination, {
                    enable: () => {
                        t.el.classList.remove(t.params.pagination.paginationDisabledClass);
                        let {
                            el: e
                        } = t.pagination;
                        e && (e = o(e), e.forEach((e => e.classList.remove(t.params.pagination.paginationDisabledClass)))), m(), f(), u()
                    },
                    disable: g,
                    render: f,
                    update: u,
                    init: m,
                    destroy: h
                })
            }

            function ne(e) {
                let t, s, {
                    swiper: i,
                    extendParams: n,
                    on: r,
                    emit: l,
                    params: o
                } = e;
                i.autoplay = {
                    running: !1,
                    paused: !1,
                    timeLeft: 0
                }, n({
                    autoplay: {
                        enabled: !1,
                        delay: 3e3,
                        waitForTransition: !0,
                        disableOnInteraction: !0,
                        stopOnLastSlide: !1,
                        reverseDirection: !1,
                        pauseOnMouseEnter: !1
                    }
                });
                let d, c, p, u, f, m, h, g = o && o.autoplay ? o.autoplay.delay : 3e3,
                    v = o && o.autoplay ? o.autoplay.delay : 3e3,
                    w = (new Date).getTime;

                function b(e) {
                    i && !i.destroyed && i.wrapperEl && e.target === i.wrapperEl && (i.wrapperEl.removeEventListener("transitionend", b), C())
                }
                const y = () => {
                        if (i.destroyed || !i.autoplay.running) return;
                        i.autoplay.paused ? c = !0 : c && (v = d, c = !1);
                        const e = i.autoplay.paused ? d : w + v - (new Date).getTime();
                        i.autoplay.timeLeft = e, l("autoplayTimeLeft", e, e / g), s = requestAnimationFrame((() => {
                            y()
                        }))
                    },
                    S = e => {
                        if (i.destroyed || !i.autoplay.running) return;
                        cancelAnimationFrame(s), y();
                        let n = "undefined" === typeof e ? i.params.autoplay.delay : e;
                        g = i.params.autoplay.delay, v = i.params.autoplay.delay;
                        const r = (() => {
                            let e;
                            if (e = i.virtual && i.params.virtual.enabled ? i.slides.filter((e => e.classList.contains("swiper-slide-active")))[0] : i.slides[i.activeIndex], !e) return;
                            return parseInt(e.getAttribute("data-swiper-autoplay"), 10)
                        })();
                        !Number.isNaN(r) && r > 0 && "undefined" === typeof e && (n = r, g = r, v = r), d = n;
                        const a = i.params.speed,
                            o = () => {
                                i && !i.destroyed && (i.params.autoplay.reverseDirection ? !i.isBeginning || i.params.loop || i.params.rewind ? (i.slidePrev(a, !0, !0), l("autoplay")) : i.params.autoplay.stopOnLastSlide || (i.slideTo(i.slides.length - 1, a, !0, !0), l("autoplay")) : !i.isEnd || i.params.loop || i.params.rewind ? (i.slideNext(a, !0, !0), l("autoplay")) : i.params.autoplay.stopOnLastSlide || (i.slideTo(0, a, !0, !0), l("autoplay")), i.params.cssMode && (w = (new Date).getTime(), requestAnimationFrame((() => {
                                    S()
                                }))))
                            };
                        return n > 0 ? (clearTimeout(t), t = setTimeout((() => {
                            o()
                        }), n)) : requestAnimationFrame((() => {
                            o()
                        })), n
                    },
                    E = () => {
                        i.autoplay.running = !0, S(), l("autoplayStart")
                    },
                    T = () => {
                        i.autoplay.running = !1, clearTimeout(t), cancelAnimationFrame(s), l("autoplayStop")
                    },
                    x = (e, s) => {
                        if (i.destroyed || !i.autoplay.running) return;
                        clearTimeout(t), e || (h = !0);
                        const n = () => {
                            l("autoplayPause"), i.params.autoplay.waitForTransition ? i.wrapperEl.addEventListener("transitionend", b) : C()
                        };
                        if (i.autoplay.paused = !0, s) return m && (d = i.params.autoplay.delay), m = !1, void n();
                        const r = d || i.params.autoplay.delay;
                        d = r - ((new Date).getTime() - w), i.isEnd && d < 0 && !i.params.loop || (d < 0 && (d = 0), n())
                    },
                    C = () => {
                        i.isEnd && d < 0 && !i.params.loop || i.destroyed || !i.autoplay.running || (w = (new Date).getTime(), h ? (h = !1, S(d)) : S(), i.autoplay.paused = !1, l("autoplayResume"))
                    },
                    M = () => {
                        if (i.destroyed || !i.autoplay.running) return;
                        const e = a();
                        "hidden" === e.visibilityState && (h = !0, x(!0)), "visible" === e.visibilityState && C()
                    },
                    P = e => {
                        "mouse" === e.pointerType && (h = !0, x(!0))
                    },
                    L = e => {
                        "mouse" === e.pointerType && i.autoplay.paused && C()
                    };
                r("init", (() => {
                    i.params.autoplay.enabled && (i.params.autoplay.pauseOnMouseEnter && (i.el.addEventListener("pointerenter", P), i.el.addEventListener("pointerleave", L)), a().addEventListener("visibilitychange", M), w = (new Date).getTime(), E())
                })), r("destroy", (() => {
                    i.el.removeEventListener("pointerenter", P), i.el.removeEventListener("pointerleave", L), a().removeEventListener("visibilitychange", M), i.autoplay.running && T()
                })), r("beforeTransitionStart", ((e, t, s) => {
                    !i.destroyed && i.autoplay.running && (s || !i.params.autoplay.disableOnInteraction ? x(!0, !0) : T())
                })), r("sliderFirstMove", (() => {
                    !i.destroyed && i.autoplay.running && (i.params.autoplay.disableOnInteraction ? T() : (p = !0, u = !1, h = !1, f = setTimeout((() => {
                        h = !0, u = !0, x(!0)
                    }), 200)))
                })), r("touchEnd", (() => {
                    if (!i.destroyed && i.autoplay.running && p) {
                        if (clearTimeout(f), clearTimeout(t), i.params.autoplay.disableOnInteraction) return u = !1, void(p = !1);
                        u && i.params.cssMode && C(), u = !1, p = !1
                    }
                })), r("slideChange", (() => {
                    !i.destroyed && i.autoplay.running && (m = !0)
                })), Object.assign(i.autoplay, {
                    start: E,
                    stop: T,
                    pause: x,
                    resume: C
                })
            }
        }
    }
]);
//# sourceMappingURL=94167.fc15594e.chunk.js.map