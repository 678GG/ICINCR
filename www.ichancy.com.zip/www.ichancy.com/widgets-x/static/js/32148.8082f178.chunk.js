"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [32148], {
        432148: (s, o, k) => {
            k.d(o, {
                P: () => e
            });
            const e = k(179177).Ay.IS_RTL
        }
    }
]);
//# sourceMappingURL=32148.8082f178.chunk.js.map