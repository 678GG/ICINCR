"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [55113], {
        555113: (n, m, o) => {
            o.d(m, {
                CX: () => l,
                OU: () => s,
                j2: () => t,
                lo: () => e
            });
            var a = o(704270),
                d = o(423400),
                r = o(737536);
            const e = function(n, m) {
                    let o = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null;
                    a.l.then((a => {
                        a.sendCommand({
                            command: r.y.GET_TOURNAMENT_LIST,
                            params: n,
                            rid: d.A.gForCommand()
                        }, "", m, null, o)
                    }))
                },
                s = (n, m) => {
                    a.l.then((o => {
                        o.sendCommand({
                            command: r.y.GET_TOURNAMENT,
                            params: {
                                tournament_id: n
                            },
                            rid: d.A.gForCommand()
                        }, "", m)
                    }))
                },
                t = (n, m) => {
                    a.l.then((o => {
                        o.sendCommand({
                            command: r.y.GET_TOURNAMENT_STATS,
                            params: {
                                tournament_id: n
                            },
                            rid: d.A.gForCommand()
                        }, "", m)
                    }))
                },
                l = (n, m, o) => {
                    a.l.then((a => {
                        a.sendCommand({
                            command: r.y.JOIN_TO_TOURNAMENT,
                            params: {
                                tournament_id: n
                            },
                            rid: d.A.gForCommand()
                        }, "", m, null, o)
                    }))
                }
        }
    }
]);
//# sourceMappingURL=55113.07afeb66.chunk.js.map