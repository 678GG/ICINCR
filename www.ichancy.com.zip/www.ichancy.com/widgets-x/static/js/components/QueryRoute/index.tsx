import { ReactElement } from 'react';
import qs, { ParsedQs } from 'qs';
import { Route, Redirect, useHistory } from 'react-router-dom';
import type { LocationState, Location } from 'history';
import { getUser } from 'store/selectors/user-data';
import { useSelector } from 'react-redux';

import LocalStorage from 'utils/bom-dom-manipulation/local-storage';
import SessionStorage from 'utils/bom-dom-manipulation/session-storage';
import { storageKeyName } from 'utils/generic/storage-key-name';

type Props = {
  component?: any;
  render?: Function;
  includes?: Array<string>;
  excludes?: Array<string>;
  auth?: boolean;
  shouldMount?: () => boolean;
  onCatch?: () => void;
};

export const QueryRoute = ({
  shouldMount = () => true,
  onCatch,
  ...props
}: Props): ReactElement => {
  const history = useHistory();
  const user = useSelector(getUser);

  const auth_data_x = JSON.parse(
    LocalStorage.getItem(storageKeyName('account', 'AUTH_DATA'))
  );

  return (
    <Route
      render={routeProps => {
        const queries = qs.parse(routeProps.location.search, {
          ignoreQueryPrefix: true
        });

        const inc = (props?.includes || []).every(item => item in queries);
        const exc = !(props?.excludes || []).some(item => item in queries);

        if (queries.settings && user?.owner_id) {
          return;
        }

        if (inc && exc) {
          if (!auth_data_x && props.auth) {
            saveCurrentLocation();
            const url = `${history.location.pathname}?accounts=%2A&login=%2A`;

            return <Redirect to={url} />;
          }

          if (shouldMount()) {
            if (props.render) {
              return props.render(routeProps);
            }

            if (props.component) {
              return <props.component {...routeProps} />;
            }
          } else {
            onCatch?.();
          }
        }

        return null;
      }}
    />
  );
};

export const updateQuery = (
  params: ParsedQs,
  appendPathName = '',
  state: LocationState = undefined,
  scrollToTop = false
): Location => {
  const nextHistory = {
    search: qs.stringify(params, {
      addQueryPrefix: true
    }),
    state
  } as Location;

  if (appendPathName.length > 0 && process.env.REACT_APP_ENV !== 'widgets') {
    nextHistory.pathname = appendPathName;
  }

  if (scrollToTop) {
    window.scrollTo(0, 0);
  }

  return nextHistory;
};

export const addQuery = (
  params: ParsedQs,
  appendPathName = '',
  state: LocationState = undefined
): Location => {
  const currentParams = qs.parse(window.location.search, {
    ignoreQueryPrefix: true
  });

  const nextHistory = {
    search: qs.stringify(
      { ...currentParams, ...params },
      { addQueryPrefix: true }
    ),
    state
  } as Location;

  if (appendPathName.length > 0 && process.env.REACT_APP_ENV !== 'widgets') {
    nextHistory.pathname = appendPathName;
  }

  return nextHistory;
};

export const saveCurrentLocation = (
  key: 'casinoSingleGame' | 'login' | 'mobileSportsbookGames' = 'login',
  externalRoute?: string,
  skipStoring = false
): string | undefined => {
  const { game, category, type } = qs.parse(window.location.search, {
    ignoreQueryPrefix: true
  });

  if (game && category && type && key === 'casinoSingleGame') {
    return;
  }

  const route =
    externalRoute || `${window.location.pathname}${window.location.search}`;

  if (skipStoring) {
    return route;
  }

  const prevRoutes =
    JSON.parse(SessionStorage.getItem(storageKeyName('app', 'PREVIOUS_URL'))) ||
    {};

  if (key === 'casinoSingleGame' && !prevRoutes.casinoSingleGame) {
    prevRoutes['casinoStartingRoute'] = route;
  }

  prevRoutes[key] = route;

  SessionStorage.setItem(
    storageKeyName('app', 'PREVIOUS_URL'),
    JSON.stringify(prevRoutes)
  );

  return route;
};

export function getSavedLocation(
  key:
    | 'casinoSingleGame'
    | 'login'
    | 'casinoStartingRoute'
    | 'mobileSportsbookGames' = 'login',
  returnCurrentPathname = true,
  removeSavedLocation = true
): string {
  const routes =
    JSON.parse(SessionStorage.getItem(storageKeyName('app', 'PREVIOUS_URL'))) ||
    {};

  const lastRoute = routes[key];

  if (removeSavedLocation) {
    delete routes[key];

    SessionStorage.setItem(
      storageKeyName('app', 'PREVIOUS_URL'),
      JSON.stringify(routes)
    );
  }

  return lastRoute || (returnCurrentPathname ? window.location.pathname : '');
}
