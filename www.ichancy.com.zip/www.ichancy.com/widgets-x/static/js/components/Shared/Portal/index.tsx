import {
  memo,
  useState,
  useEffect,
  ReactPortal,
  ReactElement,
  useLayoutEffect
} from 'react';
import { createPortal } from 'react-dom';

type Props = {
  rootId?: string;
  children: ReactElement;
};

export const Portal = memo(
  ({ rootId, children }: Props): ReactPortal | null => {
    const [container, setContainer] = useState<HTMLElement | null>();

    useLayoutEffect(() => {
      const root = rootId ? document.getElementById(rootId) : null;

      if (root) {
        setContainer(root);
      }
    }, [rootId]);

    useEffect(() => {
      setContainer(rootId ? document.getElementById(rootId) : document.body);
    }, [rootId]);

    return container ? createPortal(children, container) : null;
  }
);
