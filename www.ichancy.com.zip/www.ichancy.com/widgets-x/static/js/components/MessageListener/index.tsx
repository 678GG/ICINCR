import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { setUserLoggedIn } from 'store/actions/user-data';
import { useHistory } from 'react-router-dom';
import { getIsLoggedIn } from 'store/selectors/user-data';

import SpringConfigs from 'utils/constants/swarm/spring-configs';
import { useRestoreLogin } from 'hooks/auth/useRestoreLogin';
import { useAccountLogout } from 'hooks/auth/useAccountLogout';
import { arrayFindBy } from 'utils/collection-manipulation/array-find-by';
import { ODD_FORMATS } from 'utils/constants/betslip/odd-formats';
import { useChangeOddFormat } from 'hooks/betslip/useChangeOddFormat';
import { saveCurrentLocation, updateQuery } from '../QueryRoute';
import { IframeApiOpenProfilePages } from 'utils/constants/account/iframe-api-open-profile-pages';

const EVENT_ORIGIN = 'https://vbet.com';

export const MessageListener = function (): null {
  const dispatch = useDispatch();
  const restoreLogin = useRestoreLogin(true);
  const accountLogout = useAccountLogout();
  const changeOddFormat = useChangeOddFormat();
  const history = useHistory();
  const isLoggedIn = useSelector(getIsLoggedIn);

  const messageListener = (event: MessageEvent) => {
    const { data } = event;

    if (data?.action === 'login' && data?.credentials) {
      restoreLogin({
        auth_token: data.credentials.auth_token,
        user_id: data.credentials.playerId
      });
    }

    if (SpringConfigs.IFRAME_SPORTSBOOK) {
      if (data?.action === 'logout') {
        accountLogout(true);
      }

      if (data?.action === 'changeOddType') {
        const format = {
          ...arrayFindBy(ODD_FORMATS, 'value', data.type, false)
        };

        const { id, value } = format;
        changeOddFormat(id, value);
      }

      if (
        data?.action === 'openProfile' &&
        data?.page &&
        IframeApiOpenProfilePages[data.page]
      ) {
        saveCurrentLocation();
        history.push(updateQuery(IframeApiOpenProfilePages[data.page]));
      }
    }

    if (event.origin !== EVENT_ORIGIN) {
      return;
    }

    if (data?.action === 'login') {
      dispatch(setUserLoggedIn(!!data?.params));
    }
  };

  useEffect(() => {
    window.onmessage = messageListener;
    // window.addEventListener('message', messageListener, false);

    return () => {
      window.onmessage = null;
      //   window.removeEventListener('message', messageListener);
    };
  }, [isLoggedIn]);

  return null;
};
