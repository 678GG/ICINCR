"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [84716], {
        384716: (s, e, r) => {
            r.d(e, {
                o: () => c
            });
            var o = r(322908),
                n = r.n(o),
                t = r(995392);
            const c = s => {
                const e = (0, t.zy)();
                return n().parse(s || e.search, {
                    ignoreQueryPrefix: !0
                })
            }
        }
    }
]);
//# sourceMappingURL=84716.dab69fe8.chunk.js.map