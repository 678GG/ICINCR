"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [41751], {
        641751: (e, t, l) => {
            l.r(t), l.d(t, {
                default: () => m
            });
            var a, r, n, C, L, i, c, f, p, E, h = l(365043);

            function o() {
                return o = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var l = arguments[t];
                        for (var a in l) Object.prototype.hasOwnProperty.call(l, a) && (e[a] = l[a])
                    }
                    return e
                }, o.apply(this, arguments)
            }

            function s(e, t) {
                let {
                    title: l,
                    titleId: s,
                    ...d
                } = e;
                return h.createElement("svg", o({
                    width: 32,
                    height: 32,
                    viewBox: "0 0 32 33",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    ref: t,
                    "aria-labelledby": s
                }, d), l ? h.createElement("title", {
                    id: s
                }, l) : null, a || (a = h.createElement("path", {
                    d: "M23 3.06586H9L1.38 5.55386C0.556 5.82186 0 6.58986 0 7.45586V30.0039C0 31.1079 0.896 32.0039 2 32.0039H30C31.104 32.0039 32 31.1079 32 30.0039V7.45586C32 6.58986 31.444 5.82386 30.62 5.55386L23 3.06586Z",
                    fill: "#455A64"
                })), r || (r = h.createElement("path", {
                    d: "M9 3.06586L16 24.0039L23 3.06586H9Z",
                    fill: "#CFD8DC"
                })), n || (n = h.createElement("path", {
                    d: "M14 5.00391H18L16 10.0039L14 5.00391Z",
                    fill: "#EF5350"
                })), C || (C = h.createElement("path", {
                    d: "M10 0.00390625H22L16 5.00391L10 0.00390625Z",
                    fill: "#B0BEC5"
                })), L || (L = h.createElement("path", {
                    d: "M12 18.0039L15 7.00391H17L20 18.0039L16 24.0039L12 18.0039Z",
                    fill: "#EF5350"
                })), i || (i = h.createElement("path", {
                    d: "M16 30.0039C16.5523 30.0039 17 29.5562 17 29.0039C17 28.4516 16.5523 28.0039 16 28.0039C15.4477 28.0039 15 28.4516 15 29.0039C15 29.5562 15.4477 30.0039 16 30.0039Z",
                    fill: "#37474F"
                })), c || (c = h.createElement("path", {
                    d: "M16.9439 23.6734L9.94394 3.67341C9.82394 3.33141 9.52594 3.07941 9.16794 3.01941C8.81594 2.95941 8.44794 3.09741 8.21794 3.37941L4.21795 8.3794C3.99995 8.6514 3.94195 9.0174 4.05995 9.3454C4.17995 9.6734 4.46195 9.9154 4.80395 9.9834L7.97194 10.6174L6.29194 12.2954C5.92994 12.6594 5.89994 13.2394 6.22594 13.6354L15.2259 24.6354C15.4219 24.8774 15.7079 25.0034 15.9999 25.0034C16.1659 25.0034 16.3339 24.9614 16.4879 24.8774C16.9119 24.6374 17.1039 24.1294 16.9439 23.6734Z",
                    fill: "#546E7A"
                })), f || (f = h.createElement("path", {
                    d: "M15.0556 23.6737L22.0556 3.67374C22.1776 3.32974 22.4736 3.07974 22.8316 3.01774C23.1836 2.95774 23.5516 3.09574 23.7816 3.37774L27.7816 8.37774C27.9996 8.65174 28.0596 9.01774 27.9396 9.34574C27.8196 9.67374 27.5376 9.91574 27.1956 9.98374L24.0276 10.6177L25.7056 12.2957C26.0696 12.6597 26.0976 13.2377 25.7736 13.6357L16.7736 24.6357C16.5776 24.8777 16.2916 25.0037 15.9996 25.0037C15.8336 25.0037 15.6656 24.9617 15.5116 24.8777C15.0876 24.6377 14.8956 24.1297 15.0556 23.6737Z",
                    fill: "#546E7A"
                })), p || (p = h.createElement("path", {
                    d: "M22 0.00390625L23 3.06591L20 9.00391L16 5.00391L22 0.00390625Z",
                    fill: "#ECEFF1"
                })), E || (E = h.createElement("path", {
                    d: "M10 0.00390625L9 3.06591L12 9.00391L16 5.00391L10 0.00390625Z",
                    fill: "#ECEFF1"
                })))
            }
            const d = h.forwardRef(s),
                m = (l.p, d)
        }
    }
]);
//# sourceMappingURL=41751.27ee3370.chunk.js.map