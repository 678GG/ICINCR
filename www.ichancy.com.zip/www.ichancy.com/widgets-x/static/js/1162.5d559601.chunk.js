"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [1162], {
        401162: (e, t, o) => {
            o.d(t, {
                g: () => n
            });
            const n = function(e, t) {
                let o = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : ".row-container",
                    n = arguments.length > 4 ? arguments[4] : void 0;
                const l = arguments.length > 2 && void 0 !== arguments[2] && arguments[2] ? e : null === e || void 0 === e ? void 0 : e.closest(o);
                if (!l) return null;
                n && (l.style.zIndex = "3");
                let s = +window.getComputedStyle(l, "").getPropertyValue("z-index");
                return s && (s += t, l.style.zIndex = s.toString()), l
            }
        }
    }
]);
//# sourceMappingURL=1162.5d559601.chunk.js.map