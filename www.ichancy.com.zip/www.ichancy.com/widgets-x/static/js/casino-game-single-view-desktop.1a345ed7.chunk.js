"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [45507], {
        743259: (e, a, i) => {
            i.r(a), i.d(a, {
                GameSingleViewDesktop: () => T
            });
            i(461243);
            var n = i(923233),
                s = i(365043),
                l = i(507712),
                o = i(679559),
                r = i(329675),
                c = i(875949),
                _ = i(841591),
                m = i(889181),
                t = i(870905),
                d = i(998285),
                x = i(888332),
                b = i(454071),
                h = i(735905),
                S = i(697328),
                u = i(853291),
                g = i(179177),
                G = i(384716),
                N = i(365506),
                p = i(570579);
            const I = () => (0, p.jsx)("div", {
                className: "x-casinoGameSingleView__sidebar x-casinoGameSingleView__sidebar--loader"
            });
            var w = i(513900),
                j = i(787154),
                f = i(401162),
                v = i(989618),
                A = i(683753),
                C = i(68392);
            g.Ay.IS_RTL && i.e(89049).then(i.bind(i, 989049));
            const {
                CasinoTimerNetWin: y
            } = (0, v.R)((() => Promise.all([i.e(12635), i.e(8509)]).then(i.bind(i, 410256)))), {
                CasinoGameSidebar: O
            } = (0, v.R)((() => Promise.all([i.e(68843), i.e(46979), i.e(11115), i.e(46179), i.e(74421), i.e(8333), i.e(5256), i.e(99384), i.e(6327), i.e(91338), i.e(44148), i.e(43541), i.e(41365), i.e(65822), i.e(38281), i.e(78788), i.e(7035), i.e(85705), i.e(59620), i.e(24747), i.e(33025), i.e(66131), i.e(99783)]).then(i.bind(i, 351910)))), {
                CasinoBlockUser: V
            } = (0, v.R)((() => Promise.all([i.e(26038), i.e(6880)]).then(i.bind(i, 22709)))), {
                CasinoGamblingCommission: k
            } = (0, v.R)((() => i.e(55760).then(i.bind(i, 972332)))), {
                CasinoGameInfo: E
            } = (0, v.R)((() => i.e(666).then(i.bind(i, 878604)))), {
                CasinoQuickDepositTrigger: W
            } = (0, v.R)((() => Promise.all([i.e(99701), i.e(22093), i.e(45375), i.e(76481), i.e(90363), i.e(15243), i.e(20509), i.e(85123), i.e(77484), i.e(82685), i.e(74027), i.e(11216), i.e(23973), i.e(68843), i.e(8198), i.e(9297), i.e(36273), i.e(61579), i.e(57008), i.e(82675), i.e(69478), i.e(46179), i.e(80840), i.e(52106), i.e(82463), i.e(99384), i.e(37053), i.e(93019), i.e(17366), i.e(41746)]).then(i.bind(i, 167748)))), T = (0, s.memo)((e => {
                var a;
                let {
                    headerState: i,
                    category: v,
                    gameName: T,
                    externalGameId: R,
                    isActive: M,
                    showTimerNetWin: H,
                    overlay: B,
                    setOverlay: z,
                    reloadIframe: D,
                    setReloadIframe: L,
                    iframeRef: P,
                    onHeartClick: U,
                    handleCloseClick: F,
                    gameOptions: $
                } = e;
                const {
                    t: q
                } = (0, t.B)(), Q = (0, l.d4)(o.wz), X = (0, l.d4)(_.d1), Y = (0, s.useRef)(null), [Z, J] = (0, s.useState)(!1), K = (0, l.d4)(_.tB), ee = (0, l.d4)(o.eP), ae = (0, l.d4)(r.xx), {
                    setIsLoading: ie
                } = (0, x.I)(), {
                    mode: ne
                } = (0, G.o)(), {
                    height: se,
                    isVisible: le
                } = i, oe = ee;
                (0, s.useEffect)((() => {
                    if (K) return;
                    let e = null;
                    return Y.current && (e = (0, f.g)(Y.current, 5)), document.body.classList.add("no-scroll"), () => {
                        e && (0, f.g)(e, -5, !0), document.body.classList.remove("no-scroll"), setTimeout((() => {
                            document.body.style.overflow = "", document.documentElement.style.overflow = ""
                        }))
                    }
                }), []);
                const re = (0, s.useMemo)((() => v === w.H), [v]),
                    ce = (0, s.useMemo)((() => ({
                        height: `calc(100vh - ${se}px)`
                    })), [se]),
                    _e = (0, s.useMemo)((() => ({
                        background: "var(--v3-black-4)",
                        height: `calc(100vh - ${se}px)`,
                        marginTop: `${se}px`
                    })), [se]),
                    me = !re && g.Ay.CASINO_GAME_SWITCHING_DURING_GAME_SESSION && g.Ay.CASINO_GAME_SIDEBAR_ENABLED;
                return (0, p.jsx)("div", {
                    style: {
                        "--my-var": `${se}px`
                    },
                    id: "casino-game-modal",
                    children: (0, p.jsx)(n.A, {
                        zIndex: j.so,
                        className: (0, m.A)(["x-casinoGameSingleView", {
                            "x-casinoGameSingleView__header--visible": le
                        }]),
                        style: ce,
                        width: "100%",
                        closable: !1,
                        footer: !1,
                        wrapClassName: le ? "modal__with__fixed__header" : "",
                        getContainer: "#casino-game-modal",
                        bodyStyle: ce,
                        maskStyle: _e,
                        visible: !0,
                        children: (0, p.jsxs)("div", {
                            className: "x-casinoGameSingleView__container",
                            ref: Y,
                            children: [me && (0, p.jsx)(s.Suspense, {
                                fallback: (0, p.jsx)(I, {}),
                                children: (0, p.jsx)(O, {
                                    category: v,
                                    externalGameId: R
                                })
                            }), (0, p.jsxs)("div", {
                                className: (0, m.A)(["x-casinoGameSingleView__mainbar", {
                                    "x-casinoGameSingleView__mainbar--fullWidth": !me
                                }]),
                                children: [(0, p.jsxs)("div", {
                                    className: "x-casinoGameSingleView__mainbar__row x-casinoGameSingleView__mainbar__row--header",
                                    children: [(0, p.jsxs)("div", {
                                        className: (0, m.A)(["x-casinoGameSingleView__mainbar__row__gameInfo", {
                                            "casino__gameInfo-no-search": !g.Ay.CASINO_GAME_SWITCHING_DURING_GAME_SESSION
                                        }]),
                                        children: [(0, p.jsxs)("div", {
                                            className: "x-casinoGameSingleView__mainbar__row__gameInfo--name",
                                            children: [(0, p.jsx)(N.H, {
                                                icon: (0, p.jsx)(h.GlobalIcon, {
                                                    lib: "generic",
                                                    name: "heart",
                                                    theme: "default",
                                                    skeleton: !1,
                                                    size: 16
                                                }),
                                                size: "md",
                                                className: "x-casinoGameSingleView__favoriteButton",
                                                onClick: U,
                                                active: M
                                            }), (0, p.jsx)("p", {
                                                className: "x-casinoGameSingleView__mainbar__row__gameInfo__title",
                                                children: T
                                            })]
                                        }), (0, p.jsxs)("div", {
                                            className: "x-casinoGameSingleView__mainbar__row__gameInfo--timer",
                                            children: [(H && !re || g.Ay.SHOW_CASINO_TIMER_NET_WIN) && (0, p.jsx)(s.Suspense, {
                                                children: (0, p.jsx)(y, {
                                                    gameId: R,
                                                    showTimerNetWin: H
                                                })
                                            }), g.Ay.CASINO_IFRAME_FROZEN_BALANCE && ee && (0, p.jsxs)("div", {
                                                className: "casinoGame__balance-container",
                                                children: [(0, p.jsxs)("span", {
                                                    "data-testid": "account-balance",
                                                    children: [q("account.balance"), " =", " ", (0, C.HN)(Q.currency, (0, A.Bk)({
                                                        balance: Q.balance
                                                    }, Q.frozen_balance, X || 0))]
                                                }), (0, p.jsxs)("span", {
                                                    className: "casinoGame__bonus-balance",
                                                    "data-testid": "bonus-balance",
                                                    children: [q("account.bonusBalance"), " =", " ", (0, C.HN)(Q.currency, (0, A.e7)(Q))]
                                                }), (0, p.jsxs)("span", {
                                                    "data-testid": "frozen-balance",
                                                    children: [q("account.frozenBalance"), " =", " ", (0, C.HN)(Q.currency, Q.frozen_balance)]
                                                })]
                                            })]
                                        })]
                                    }), g.Ay.CASINO_GAME_SWITCHING_DURING_GAME_SESSION && (0, p.jsx)("div", {
                                        className: "x-casinoGameSingleView__mainbar__row__flexWrapper",
                                        children: (0, p.jsx)(b.CasinoSearch, {
                                            singleGame: !0
                                        })
                                    }), (0, p.jsxs)("div", {
                                        className: "x-casinoGameSingleView__mainbar__row__iconsWrapper",
                                        children: [oe && (0, p.jsx)(s.Suspense, {
                                            fallback: null,
                                            children: (0, p.jsx)(W, {
                                                view: d.Y.ICON_WITH_TEXT,
                                                "data-testid": "quick-deposit",
                                                className: "x-casinoGameSingleView__mainbar__row__iconsWrapper__quickDeposit"
                                            })
                                        }), (0, p.jsx)(h.GlobalIcon, {
                                            lib: "generic",
                                            name: "close",
                                            theme: "default",
                                            size: 16,
                                            className: "x-casinoGameSingleView__mainbar__row__iconsWrapper__closeIcon",
                                            onClick: F
                                        })]
                                    })]
                                }), (0, p.jsx)("div", {
                                    className: "x-casinoGameSingleView__mainbar__iframeContainer",
                                    children: (0, p.jsx)(S.o, {
                                        reloadIframe: D,
                                        externalGameId: R,
                                        type: ne,
                                        iframeRef: P,
                                        overlay: B,
                                        setOverlay: z,
                                        gameOptions: $
                                    })
                                }), (0, p.jsxs)("div", {
                                    className: "x-casinoGameSingleView__mainbar__row",
                                    children: [(0, p.jsx)("div", {
                                        className: "x-casinoGameSingleView__mainbar__row__gameInfo",
                                        children: g.Ay.SHOW_GAMBLING_WITH_LOGO && (0, p.jsx)(s.Suspense, {
                                            children: (0, p.jsx)(k, {})
                                        })
                                    }), (0, p.jsx)("div", {
                                        className: "x-casinoGameSingleView__mainbar__row__flexWrapper",
                                        children: !(null === ae || void 0 === ae || null === (a = ae.types) || void 0 === a || !a.funMode) && !(g.Ay.CASINO_DISABLE_FUN_MODE && !ee) && g.Ay.CASINO_FUN_MODE && (0, p.jsx)(u.u, {
                                            currentGameId: ae.id
                                        })
                                    }), (0, p.jsxs)("div", {
                                        className: "x-casinoGameSingleView__mainbar__row__iconsWrapper",
                                        children: [g.Ay.SHOW_GAMBLING_WITH_LOGO && (0, p.jsx)(c.p, {}), ee && g.Ay.PANIC_BUTTON && (0, p.jsx)(s.Suspense, {
                                            children: (0, p.jsx)(V, {})
                                        }), (0, p.jsx)("span", {
                                            className: "x-casinoGameSingleView__mainbar__row__iconsWrapper__iconContainer",
                                            children: (0, p.jsx)(h.GlobalIcon, {
                                                lib: "generic",
                                                name: "infoOutlined",
                                                theme: "default",
                                                size: 20,
                                                onClick: e => {
                                                    e.stopPropagation(), J(!0)
                                                }
                                            })
                                        }), (0, p.jsx)("span", {
                                            className: "x-casinoGameSingleView__mainbar__row__iconsWrapper__iconContainer",
                                            children: (0, p.jsx)(h.GlobalIcon, {
                                                lib: "generic",
                                                name: "refresh",
                                                theme: "default",
                                                size: 20,
                                                onClick: e => {
                                                    e.stopPropagation(), L((e => e + 1)), ie(!0)
                                                }
                                            })
                                        }), (0, p.jsx)("span", {
                                            className: "x-casinoGameSingleView__mainbar__row__iconsWrapper__iconContainer",
                                            children: (0, p.jsx)(h.GlobalIcon, {
                                                lib: "generic",
                                                name: "fullScreen",
                                                theme: "default",
                                                size: 20,
                                                onClick: () => {
                                                    var e;
                                                    null === (e = P.current) || void 0 === e || e.requestFullscreen()
                                                }
                                            })
                                        })]
                                    })]
                                }), !!ae && Z && (0, p.jsx)(s.Suspense, {
                                    children: (0, p.jsx)(E, {
                                        name: ae.name,
                                        handleClose: () => J(!1),
                                        description: ae.description
                                    })
                                })]
                            })]
                        })
                    })
                })
            }))
        }
    }
]);
//# sourceMappingURL=casino-game-single-view-desktop.1a345ed7.chunk.js.map