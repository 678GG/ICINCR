"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [40763], {
        640763: (e, n, s) => {
            s.d(n, {
                e: () => c
            });
            var o = s(507712),
                r = s(365043),
                t = s(841591),
                u = s(679559),
                a = s(462956);
            const c = () => {
                const e = (0, o.d4)(t.gh),
                    n = (0, o.d4)(u.wz),
                    s = (0, o.d4)(a.gU);
                return (0, r.useMemo)((() => {
                    if (e && !n.pending) {
                        var o;
                        const r = new Set(["accounts:bonuses:refer-friend", "accounts:bonuses:management"]),
                            t = 1 === +e.referAFriend && (s && !s.reffrend_client_cats || !(null === s || void 0 === s || null === (o = s.reffrend_client_cats) || void 0 === o || !o.includes(n.sportsbook_profile_id))),
                            u = 1 === +e.bonusManagement,
                            a = 1 === +e.bonusManagementOnlyVerified;
                        return t && r.delete("accounts:bonuses:refer-friend"), !1 !== n.is_bonus_allowed && u && (!a || a && n.is_verified) && r.delete("accounts:bonuses:management"), 2 === r.size && r.add("accounts:bonuses:bonus"), Array.from(r)
                    }
                    return null
                }), [e, n, s])
            }
        }
    }
]);
//# sourceMappingURL=40763.b7969d75.chunk.js.map