"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [24131], {
        724131: (e, t, a) => {
            a.d(t, {
                $w: () => q,
                AZ: () => n,
                Dl: () => c,
                Ei: () => p,
                Gp: () => d,
                Kh: () => k,
                Ki: () => b,
                Mk: () => r,
                Q0: () => s,
                X7: () => P,
                Z5: () => x,
                b7: () => l,
                dA: () => g,
                iL: () => h,
                is: () => M,
                j4: () => B,
                kf: () => v,
                lG: () => u,
                lo: () => f,
                q1: () => m,
                tK: () => T,
                tN: () => y,
                y6: () => w
            });
            var i = a(860446),
                _ = a.n(i),
                o = a(502825);
            const n = {
                    event: ["name", "id", "price", "base", "order", "type_1", "extra_info", "display_column", "ew_allowed"]
                },
                s = {
                    market: ["name", "order", "main_order", "type", "id", "base", "express_id", "col_count", "group_id", "group_name", "cashout", "point_sequence", "sequence", "is_new", "market_type", "extra_info"]
                },
                r = [...o.AS, ...o.Zp, ...o.yM],
                d = ["P1P2", "P1XP2", "MatchResult", "MatchWinner", "1X12X2", "BothTeamsToScore", "DrawNoBet", "MatchTotal", "TotalGamesOver/Under", "TotalofSets", "BoutBetting", "MatchWinner3Way", "MoneyLine"],
                m = {
                    sport: ["name", "alias", "id", "type", "order"]
                },
                p = {
                    region: ["name", "alias", "order", "id"]
                },
                l = {
                    competition: ["name", "order", "id"]
                },
                c = ["sportcast_id"],
                v = {
                    "@gt": 1
                },
                y = {
                    game: [
                        ["id", "type", "team1_name", "team2_name", "team1_id", "team2_id", "order", "start_ts", "markets_count", "is_blocked", "info", "tv_type", "exclude_ids", "show_type", "text_info", "add_info_name", "tv_info", "is_stat_available", "video_id", "video_id2", "video_id3", "sportcast_id", "match_length", "live_events"]
                    ]
                },
                u = {
                    game: [
                        ["id", "team1_name", "team2_name", "team1_id", "team2_id", "order", "start_ts", "markets_count", "is_blocked", "show_type", "sportcast_id", "sport_id", "is_stat_available"]
                    ],
                    market: ["name", "order", "type", "id", "base", "express_id", "col_count", "main_order"],
                    event: ["name", "id", "price", "base", "order", "type_1"]
                },
                g = {
                    game: {
                        "@or": [{
                            type: {
                                "@in": [0, 2]
                            }
                        }, {
                            visible_in_prematch: 1,
                            type: 1
                        }]
                    },
                    competition: {
                        favorite: !0
                    }
                },
                b = {
                    game: {
                        promoted: !0,
                        "@or": [{
                            type: {
                                "@in": [0, 2]
                            }
                        }, {
                            visible_in_prematch: 1,
                            type: 1
                        }]
                    }
                },
                k = () => ({
                    game: {
                        start_ts: {
                            "@gt": _()().unix(),
                            "@lt": _()().endOf("day").unix()
                        }
                    }
                }),
                h = {
                    sport: ["alias", "id", "type"],
                    region: ["name", "alias", "id"],
                    competition: ["id", "name"],
                    game: [
                        ["id", "team1_id", "team1_name", "team2_id", "team2_name", "start_ts", "is_blocked", "info", "is_live", "type", "is_started", "is_stat_available"]
                    ],
                    market: ["name", "type", "id", "base", "express_id", "group_id"],
                    event: ["name", "type", "id", "price", "base", "order"]
                },
                f = e => ({
                    game: {
                        id: {
                            "@in": e
                        },
                        type: {
                            "@in": [0, 1, 2]
                        }
                    },
                    market: {
                        type: {
                            "@in": o.yM
                        }
                    }
                }),
                x = () => ({
                    sport: {
                        type: {
                            "@ne": 1
                        },
                        alias: {
                            "@in": ["Soccer", "Tennis"]
                        }
                    },
                    game: {
                        "@or": [{
                            type: {
                                "@in": [0, 2]
                            }
                        }, {
                            visible_in_prematch: 1
                        }],
                        "@limit": 5,
                        start_ts: {
                            "@gt": _()().unix(),
                            "@lt": _()().endOf("day").unix()
                        },
                        show_type: {
                            "@nin": ["OUTRIGHT"]
                        },
                        "@node_limit": 1
                    },
                    market: {
                        type: {
                            "@in": ["P1XP2", "P1P2", "MatchWinner", "MatchResult"]
                        }
                    }
                }),
                w = function() {
                    let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                        t = arguments.length > 1 ? arguments[1] : void 0,
                        a = arguments.length > 2 ? arguments[2] : void 0;
                    return {
                        sport: ["id", "name", "alias"],
                        competition: ["name", "id"],
                        game: ["id", "type", "team1_name", "team2_name", "team1_id", "team2_id", "info", "start_ts", "markets_count", "exclude_ids", "team1_reg_name", "team2_reg_name", "video_id", "video_id2", "stats", "score1", "score2", "show_type", "text_info", "is_stat_available", "is_started", "add_info_name", "tv_info", "sportcast_id", "match_length", "live_events", "is_blocked"],
                        market: [...s.market, ...t ? ["prematch_express_id"] : [], ...a ? ["has_early_payout"] : []],
                        event: n.event,
                        ...e
                    }
                },
                M = {
                    sport: m.sport,
                    competition: l.competition,
                    region: p.region,
                    game: [
                        ["id", "start_ts", "team1_name", "team2_name", "team1_id", "team2_id", "type", "info", "events_count", "events", "markets_count", "is_started", "is_blocked", "stats", "tv_type", "video_id", "video_id2", "video_id3", "partner_video_id", "is_stat_available", "game_number", "game_info", "last_event", "text_info"]
                    ],
                    market: ["id", "name", "type", "order", "main_order", "cashout", "col_count", "display_key", "display_sub_key", "market_type", "name_template", "point_sequence", "sequence", "extra_info", "express_id"],
                    event: ["name", "id", "price", "type", "order", "base"]
                },
                P = {
                    sport: m.sport,
                    competition: l.competition,
                    region: p.region,
                    game: ["id", "start_ts", "team1_id", "team2_id", "team1_name", "team2_name", "type", "info", "stats", "live_events", "sport_alias"]
                },
                T = {
                    sport: m.sport,
                    region: p.region,
                    competition: l.competition,
                    market: ["name", "order", "main_order", "type", "id", "base", "express_id", "col_count", "group_id", "group_name", "cashout", "point_sequence", "sequence", "is_new", "market_type", "extra_info", "has_early_payout"],
                    event: ["id", "name", "type", "price", "type_1", "order", "base", "ew_allowed"],
                    game: ["id", "team1_id", "team2_id", "team1_name", "team2_name", "info", "markets_count", "stats", "starts_ts", "type", "is_blocked", "is_feed_available", "tv_type", "video_id", "video_id2", "is_feed_available", "text_info", "live_events", "game_number", "sport_alias", "is_live", "is_stat_available"]
                },
                q = "Main Markets",
                B = ["Soccer", "Basketball"]
        }
    }
]);
//# sourceMappingURL=24131.9ab955e4.chunk.js.map