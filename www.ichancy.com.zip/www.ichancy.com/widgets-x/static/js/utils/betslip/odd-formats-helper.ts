import { ladderIsLoaded, updateOddFormat } from 'store/actions/bet-slip';
import { getPermissibleOdds } from 'services/get-permissible-odds';
import Store from 'store';
import { Ladder, PermissibleOdds } from 'interfaces/bet-data';

import { ODD_FORMATS } from 'utils/constants/betslip/odd-formats';
import SpringConfigs from 'utils/constants/swarm/spring-configs';

const Config = {
  decimalFormatRemove3Digit: false,
  roundDecimalCoeficients: SpringConfigs.ODD_ROUNDING,
  useLadderForFractionalFormat: true
};

const cache: { [key: string]: string } = {};

const {
  oddFormat,
  ladderLoaded
}: { oddFormat: number; ladderLoaded: boolean } = Store.getState().betSlip;

let priceDecimal: number | undefined;

let ladder: Ladder[] | boolean = false;

export async function loadLadder(id = 0): Promise<void> {
  Store.dispatch(ladderIsLoaded());
  getPermissibleOdds(
    (response: PermissibleOdds) => {
      if (response?.details) {
        ladder = response.details;
        Store.dispatch(updateOddFormat(id));
      } else {
        ladder = [];
      }
    },
    () => {
      ladder = [];
    }
  );
}

if (!ladderLoaded) {
  loadLadder(oddFormat);
}

/**
 * Odd converter
 * returns a function to convert decimal odds to corresponding format
 * Usage:
 * convert(odd, formatID)
 * e.g.  const coeficient = convert(1.01, 2)
 */
export function convert(
  val: string | number,
  formatID: number | string,
  type = ''
): string {
  if (isNaN(+val) || +val === Infinity) {
    return '-';
  }

  if ((formatID === 1 || formatID === 'fractional') && !ladder) {
    return '-';
  }

  const format =
    ODD_FORMATS.find(
      format => format.value === formatID || format.id === formatID
    )?.value || 'decimal';

  const value = parseFloat(`${val}`);
  const cacheKey = `${format}${value}`;

  if (isNaN(value)) {
    return '';
  }

  if (cache[cacheKey] === undefined) {
    if (
      format === 'fractional' &&
      Config.useLadderForFractionalFormat &&
      type === 'fictional' &&
      value !== undefined
    ) {
      // use it to calculate express odds as you see on bet365 :)
      cache[cacheKey] = `${Math.round((value - 1) * 100 || 0) / 100}/1`;
    } else {
      const converted = convertLog(value, format, ladder as Ladder[]);
      let roundedConverted = String(converted) || '';

      if (converted && format === 'decimal') {
        if (!priceDecimal) {
          const partnerConfigs = Store.getState().socket.partnerConfigs;
          priceDecimal = partnerConfigs?.price_decimals;
        }

        if (
          priceDecimal &&
          converted &&
          String(converted)?.split('.')?.[1]?.length > priceDecimal
        ) {
          roundedConverted = Number(converted).toFixed(priceDecimal);
        }
      }

      cache[cacheKey] = roundedConverted;
    }
  }

  return cache[cacheKey];
}

function convertLog(value: number, format: string, ladder: Ladder[]) {
  const fValue = value;
  const iValue = Math.floor(value);
  const rValue =
    value !== undefined ? Math.round(fValue * 100 || 0) / 100 : value;

  switch (format) {
    case 'decimal':
      return decimalValue(value, iValue, fValue);

    case 'fractional':
      return fractionalValue(value, fValue, rValue, ladder);

    case 'american':
      return americanValue(value, rValue);

    case 'hongkong':
      return hongKongValue(value, iValue, fValue);

    case 'malay':
      return malayValue(fValue);

    case 'indo':
      return indoValue(fValue);

    default:
      return rValue;
  }
}

function decimalValue(value: number, iValue: number, fValue: number) {
  return value !== undefined
    ? iValue !== fValue &&
      value.toString().split('.')[1] &&
      value.toString().split('.')[1].length > 2 &&
      !Config.decimalFormatRemove3Digit
      ? Math.round(value * Math.pow(10, Config.roundDecimalCoeficients)) /
        Math.pow(10, Config.roundDecimalCoeficients)
      : fValue.toFixed(2)
    : value;
}

function fractionalValue(
  value: number,
  fValue: number,
  rValue: number,
  ladder: Ladder[]
) {
  if (value && Config.useLadderForFractionalFormat) {
    const fracFL = dec2fracFromLadder(fValue, ladder);

    if (fracFL) {
      return fracFL;
    } else {
      const frac = dec2frac(rValue);

      if (frac) {
        return frac;
      }
    }

    return value;
  } else {
    return '-';
  }
}

function americanValue(value: number, rValue: number) {
  return value
    ? rValue > 2
      ? `+${(100 * (rValue - 1)).toString().split('.')[0]}`
      : rValue !== 1
      ? (-100 / (rValue - 1)).toString().split('.')[0]
      : '-'
    : rValue;
}

function hongKongValue(value: number, iValue: number, fValue: number) {
  return value !== undefined
    ? iValue !== fValue && value.toString().split('.')[1].length > 2
      ? Math.round((value - 1) * Math.pow(10, Config.roundDecimalCoeficients)) /
        Math.pow(10, Config.roundDecimalCoeficients)
      : (fValue - 1.0).toFixed(2)
    : value;
}

function malayValue(fValue: number) {
  if (fValue === 2) {
    return '0.000';
  } else if (fValue > 2) {
    return (
      Math.round(
        +(1 / (1 - fValue)).toFixed(Config.roundDecimalCoeficients + 1) *
          Math.pow(10, Config.roundDecimalCoeficients)
      ) / Math.pow(10, Config.roundDecimalCoeficients)
    ).toFixed(Config.roundDecimalCoeficients);
  } else {
    return (fValue - 1).toFixed(Config.roundDecimalCoeficients);
  }
}

function indoValue(fValue: number) {
  if (fValue === 2) {
    return '0.000';
  } else if (fValue > 2) {
    return (fValue - 1).toFixed(Config.roundDecimalCoeficients);
  } else {
    return (
      Math.round(
        +(1 / (1 - fValue)).toFixed(Config.roundDecimalCoeficients + 1) *
          Math.pow(10, Config.roundDecimalCoeficients)
      ) / Math.pow(10, Config.roundDecimalCoeficients)
    ).toFixed(Config.roundDecimalCoeficients);
  }
}

function dec2fracFromLadder(dec: number, ladder: Ladder[]) {
  let frac = '';

  if (ladder.length) {
    let price = 0;
    let issetPriceArray = ladder.find(({ Price }) => Price === dec);

    if (issetPriceArray) {
      frac = `${issetPriceArray.Numerator}/${issetPriceArray.Denominator}`;
    } else {
      for (let i = 0; i < ladder.length; i++) {
        if (ladder[i].Price > price && ladder[i].Price < dec) {
          price = ladder[i].Price;
        }
      }

      issetPriceArray = ladder.find(({ Price }) => Price === price);

      if (issetPriceArray) {
        frac = `${issetPriceArray.Numerator}/${issetPriceArray.Denominator}`;
      }
    }
  }

  return frac;
}

function dec2frac(decVal: number) {
  let Znxt: number;
  let Dnxt: number;
  let Nnxt: number;

  function recCalc(Zcur: number, Dcur?: number, Dprev?: number): string {
    Dcur = Dcur !== undefined ? Dcur : 1;
    Dprev = Dprev !== undefined ? Dprev : 0;
    Znxt = 1 / (Zcur - Math.floor(Zcur));
    Dnxt = Dcur * Math.floor(Znxt) + Dprev;
    Nnxt = Math.round(decVal * Dnxt);

    return Nnxt / Dnxt === decVal
      ? `${Nnxt.toString()}/${Dnxt.toString()}`
      : recCalc(Znxt, Dnxt, Dcur);
  }

  // Use this casting method because of JS number bug for example "2.2 - 1 = 1.1999(9)"
  if (decVal !== Math.floor(decVal)) {
    decVal = parseFloat(
      `${(Math.floor(decVal) - 1).toString()}.${String(decVal).split('.')[1]}`
    );
  } else {
    decVal = decVal - 1;
  }

  return decVal % 1 === 0 ? `${String(decVal)}/1` : String(recCalc(decVal));
}
