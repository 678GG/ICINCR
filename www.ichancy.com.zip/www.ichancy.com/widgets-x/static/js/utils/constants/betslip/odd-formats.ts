import { OddFormat } from 'interfaces/betslip';

import { ODD_TYPES } from 'utils/constants/betslip/bet-types';

const { DECIMAL, FRACTIONAL, AMERICAN, HONGKONG, MALAY, INDO } = ODD_TYPES;

export const ODD_FORMATS: OddFormat[] = [
  {
    id: DECIMAL,
    label: 'Decimal',
    value: 'decimal'
  },
  {
    id: FRACTIONAL,
    label: 'Fractional',
    value: 'fractional'
  },
  {
    id: AMERICAN,
    label: 'American',
    value: 'american'
  },
  {
    id: HONGKONG,
    label: 'Hong Kong',
    value: 'hongkong'
  },
  {
    id: MALAY,
    label: 'Malay',
    value: 'malay'
  },
  {
    id: INDO,
    label: 'Indo',
    value: 'indo'
  }
];
