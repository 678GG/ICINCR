export const IframeApiOpenProfilePages: Record<
  string,
  Record<string, string>
> = {
  profile: { accounts: '*', settings: '*', profile: '*' },
  documents: { accounts: '*', settings: '*', documents: '*' },
  selfExclusion: { accounts: '*', settings: '*', 'self-exclusion': '*' },
  timeout: { accounts: '*', settings: '*', timeout: '*' },
  password: { accounts: '*', settings: '*', password: '*' },
  betHistory: { accounts: '*', 'bet-history': '*' },
  deposit: { accounts: '*', wallet: '*', deposit: '*' },
  balanceHistory: { accounts: '*', wallet: '*', 'balance-history': '*' },
  bonusSportsbook: {
    accounts: '*',
    bonuses: '*',
    bonus: '*',
    bonusType: '1'
  },
  bonusCasino: {
    accounts: '*',
    bonuses: '*',
    bonus: '*',
    bonusType: '2'
  }
};
