import i18n from 'i18next';

export const CountryCodes = [
  {
    code: 'AF',
    alpha3Code: 'AFG',
    name: 'Afghanistan',
    translationName: i18n.t('countries.Afghanistan'),
    phone_code: '93',
    lang: 'tur',
    currency: 'AFN',
    alias: 'afghanistan'
  },
  {
    code: 'AX',
    alpha3Code: 'ALA',
    name: 'Aland Islands',
    translationName: i18n.t('countries.AlandIslands'),
    phone_code: '358 18',
    lang: '',
    currency: '',
    alias: 'aland-islands'
  },
  {
    code: 'AL',
    alpha3Code: 'ALB',
    name: 'Albania',
    translationName: i18n.t('countries.Albania'),
    phone_code: '355',
    lang: '',
    currency: 'ALL',
    alias: 'albania'
  },
  {
    code: 'DZ',
    alpha3Code: 'DZA',
    name: 'Algeria',
    translationName: i18n.t('countries.Algeria'),
    phone_code: '213',
    lang: 'fre',
    currency: 'DZD',
    alias: 'algeria'
  },
  {
    code: 'AS',
    alpha3Code: 'ASM',
    name: 'American Samoa',
    translationName: i18n.t('countries.AmericanSamoa'),
    phone_code: '1 684',
    lang: '',
    currency: 'USD',
    alias: 'american-samoa'
  },
  {
    code: 'AD',
    alpha3Code: 'AND',
    name: 'Andorra',
    translationName: i18n.t('countries.Andorra'),
    phone_code: '376',
    lang: 'fre',
    currency: 'EUR',
    alias: 'andorra'
  },
  {
    code: 'AO',
    alpha3Code: 'AGO',
    name: 'Angola',
    translationName: i18n.t('countries.Angola'),
    phone_code: '244',
    lang: 'por',
    currency: 'AOA',
    alias: 'angola'
  },
  {
    code: 'AI',
    alpha3Code: 'AIA',
    name: 'Anguilla',
    translationName: i18n.t('countries.Anguilla'),
    phone_code: '1 264',
    lang: '',
    currency: 'XCD',
    alias: 'anguilla'
  },
  {
    code: 'AG',
    alpha3Code: 'ATG',
    name: 'Antigua and Barbuda',
    translationName: i18n.t('countries.AntiguaandBarbuda'),
    phone_code: '1 268',
    lang: '',
    currency: 'XCD',
    alias: 'antigua-and-barbuda'
  },
  {
    code: 'AR',
    alpha3Code: 'ARG',
    name: 'Argentina',
    translationName: i18n.t('countries.Argentina'),
    phone_code: '54',
    lang: 'spa',
    currency: 'ARS',
    alias: 'argentina'
  },
  {
    code: 'AM',
    alpha3Code: 'ARM',
    name: 'Armenia',
    translationName: i18n.t('countries.Armenia'),
    phone_code: '374',
    lang: 'arm',
    currency: 'AMD',
    alias: 'armenia'
  },
  {
    code: 'AW',
    alpha3Code: 'ABW',
    name: 'Aruba',
    translationName: i18n.t('countries.Aruba'),
    phone_code: '297',
    lang: '',
    currency: 'AWG',
    alias: 'aruba'
  },
  {
    code: 'AU',
    alpha3Code: 'AUS',
    name: 'Australia',
    translationName: i18n.t('countries.Australia'),
    phone_code: '61',
    lang: '',
    currency: 'AUD',
    alias: 'australia'
  },
  {
    code: 'AT',
    alpha3Code: 'AUT',
    name: 'Austria',
    translationName: i18n.t('countries.Austria'),
    phone_code: '43',
    lang: 'ger',
    currency: 'EUR',
    alias: 'austria'
  },
  {
    code: 'AZ',
    alpha3Code: 'AZE',
    name: 'Azerbaijan',
    translationName: i18n.t('countries.Azerbaijan'),
    phone_code: '994',
    lang: 'tur',
    currency: 'AZN',
    alias: 'azerbaijan'
  },
  {
    code: 'BS',
    alpha3Code: 'BHS',
    name: 'Bahamas',
    translationName: i18n.t('countries.Bahamas'),
    phone_code: '1 242',
    lang: '',
    currency: 'BSD',
    alias: 'bahamas'
  },
  {
    code: 'BH',
    alpha3Code: 'BHR',
    name: 'Bahrain',
    translationName: i18n.t('countries.Bahrain'),
    phone_code: '973',
    lang: '',
    currency: 'BHD',
    alias: 'bahrain'
  },
  {
    code: 'BD',
    alpha3Code: 'BGD',
    name: 'Bangladesh',
    translationName: i18n.t('countries.Bangladesh'),
    phone_code: '880',
    lang: '',
    currency: 'BDT',
    alias: 'bangladesh'
  },
  {
    code: 'BB',
    alpha3Code: 'BRB',
    name: 'Barbados',
    translationName: i18n.t('countries.Barbados'),
    phone_code: '1 246',
    lang: '',
    currency: 'BBD',
    alias: 'barbados'
  },
  {
    code: 'BY',
    alpha3Code: 'BLR',
    name: 'Belarus',
    translationName: i18n.t('countries.Belarus'),
    phone_code: '375',
    lang: 'rus',
    currency: 'BYR',
    alias: 'belarus'
  },
  {
    code: 'BE',
    alpha3Code: 'BEL',
    name: 'Belgium',
    translationName: i18n.t('countries.Belgium'),
    phone_code: '32',
    lang: 'fre',
    currency: 'EUR',
    alias: 'belgium'
  },
  {
    code: 'BZ',
    alpha3Code: 'BLZ',
    name: 'Belize',
    translationName: i18n.t('countries.Belize'),
    phone_code: '501',
    lang: '',
    currency: 'BZD',
    alias: 'belize'
  },
  {
    code: 'BJ',
    alpha3Code: 'BEN',
    name: 'Benin',
    translationName: i18n.t('countries.Benin'),
    phone_code: '229',
    lang: 'fre',
    currency: 'XOF',
    alias: 'benin'
  },
  {
    code: 'BM',
    alpha3Code: 'BMU',
    name: 'Bermuda',
    translationName: i18n.t('countries.Bermuda'),
    phone_code: '1 441',
    lang: '',
    currency: 'BMD',
    alias: 'bermuda'
  },
  {
    code: 'BT',
    alpha3Code: 'BTN',
    name: 'Bhutan',
    translationName: i18n.t('countries.Bhutan'),
    phone_code: '975',
    lang: '',
    currency: 'BTN',
    alias: 'bhutan'
  },
  {
    code: 'BO',
    alpha3Code: 'BOL',
    name: 'Bolivia',
    translationName: i18n.t('countries.Bolivia'),
    phone_code: '591',
    lang: 'spa',
    currency: 'BOB',
    alias: 'bolivia'
  },
  {
    code: 'BQ',
    alpha3Code: 'BES',
    name: 'Bonaire',
    translationName: i18n.t('countries.Bonaire'),
    phone_code: '599 7',
    lang: '',
    currency: '',
    alias: 'bonaire'
  },
  {
    code: 'BA',
    alpha3Code: 'BIH',
    name: 'Bosnia and Herzegovina',
    translationName: i18n.t('countries.BosniaandHerzegovina'),
    phone_code: '387',
    lang: '',
    currency: 'BAM',
    alias: 'bosnia-and-herzegovina'
  },
  {
    code: 'BW',
    alpha3Code: 'BWA',
    name: 'Botswana',
    translationName: i18n.t('countries.Botswana'),
    phone_code: '267',
    lang: '',
    currency: 'BWP',
    alias: 'botswana'
  },
  {
    code: 'BR',
    alpha3Code: 'BRA',
    name: 'Brazil',
    translationName: i18n.t('countries.Brazil'),
    phone_code: '55',
    lang: 'por',
    currency: 'BRL',
    alias: 'brazil'
  },
  {
    code: 'IO',
    alpha3Code: 'IOT',
    name: 'British Indian Ocean Territory',
    translationName: i18n.t('countries.BritishIndianOceanTerritory'),
    phone_code: '246',
    lang: '',
    currency: 'USD',
    alias: 'british-indian-ocean-territory'
  },
  {
    code: 'BN',
    alpha3Code: 'BRN',
    name: 'Brunei Darussalam',
    translationName: i18n.t('countries.BruneiDarussalam'),
    phone_code: '673',
    lang: '',
    currency: 'BND',
    alias: 'brunei'
  },
  {
    code: 'BG',
    alpha3Code: 'BGR',
    name: 'Bulgaria',
    translationName: i18n.t('countries.Bulgaria'),
    phone_code: '359',
    lang: '',
    currency: 'BGN',
    alias: 'bulgaria'
  },
  {
    code: 'BF',
    alpha3Code: 'BFA',
    name: 'Burkina Faso',
    translationName: i18n.t('countries.BurkinaFaso'),
    phone_code: '226',
    lang: 'fre',
    currency: 'XOF',
    alias: 'burkina-faso'
  },
  {
    code: 'BI',
    alpha3Code: 'BDI',
    name: 'Burundi',
    translationName: i18n.t('countries.Burundi'),
    phone_code: '257',
    lang: 'fre',
    currency: 'BIF',
    alias: 'burundi'
  },
  {
    code: 'CV',
    alpha3Code: 'CPV',
    name: 'Cabo Verde',
    translationName: i18n.t('countries.CaboVerde'),
    phone_code: '238',
    lang: 'por',
    currency: 'CVE',
    alias: 'cape-verde'
  },
  {
    code: 'KH',
    alpha3Code: 'KHM',
    name: 'Cambodia',
    translationName: i18n.t('countries.Cambodia'),
    phone_code: '855',
    lang: '',
    currency: 'KHR',
    alias: 'cambodia'
  },
  {
    code: 'CM',
    alpha3Code: 'CMR',
    name: 'Cameroon',
    translationName: i18n.t('countries.Cameroon'),
    phone_code: '237',
    lang: '',
    currency: 'XAF',
    alias: 'cameroon'
  },
  {
    code: 'CA',
    alpha3Code: 'CAN',
    name: 'Canada',
    translationName: i18n.t('countries.Canada'),
    phone_code: '1',
    lang: '',
    currency: 'CAD',
    alias: 'canada'
  },
  {
    code: 'KY',
    alpha3Code: 'CYM',
    name: 'Cayman Islands',
    translationName: i18n.t('countries.CaymanIslands'),
    phone_code: '1 345',
    lang: '',
    currency: 'KYD',
    alias: 'cayman-islands'
  },
  {
    code: 'CF',
    alpha3Code: 'CAF',
    name: 'Central African Republic',
    translationName: i18n.t('countries.CentralAfricanRepublic'),
    phone_code: '236',
    lang: '',
    currency: 'XAF',
    alias: 'central-african-republic'
  },
  {
    code: 'TD',
    alpha3Code: 'TCD',
    name: 'Chad',
    translationName: i18n.t('countries.Chad'),
    phone_code: '235',
    lang: '',
    currency: 'XAF',
    alias: 'chad'
  },
  {
    code: 'CL',
    alpha3Code: 'CHL',
    name: 'Chile',
    translationName: i18n.t('countries.Chile'),
    phone_code: '56',
    lang: 'spa',
    currency: 'CLP',
    alias: 'chile'
  },
  {
    code: 'CN',
    alpha3Code: 'CHN',
    name: 'China',
    translationName: i18n.t('countries.China'),
    phone_code: '86',
    lang: '',
    currency: 'CNY',
    alias: 'china'
  },
  {
    code: 'CX',
    alpha3Code: 'CXR',
    name: 'Christmas Island',
    translationName: i18n.t('countries.ChristmasIsland'),
    phone_code: '61 89164',
    lang: '',
    currency: 'AUD',
    alias: 'christmas-island'
  },
  {
    code: 'CC',
    alpha3Code: 'CCK',
    name: 'Cocos (Keeling) Islands',
    translationName: i18n.t('countries.CocosKeelingIslands'),
    phone_code: '61 89162',
    lang: '',
    currency: 'AUD',
    alias: 'cocos-island'
  },
  {
    code: 'CO',
    alpha3Code: 'COL',
    name: 'Colombia',
    translationName: i18n.t('countries.Colombia'),
    phone_code: '57',
    lang: 'spa',
    currency: 'COP',
    alias: 'colombia'
  },
  {
    code: 'KM',
    alpha3Code: 'COM',
    name: 'Comoros',
    translationName: i18n.t('countries.Comoros'),
    phone_code: '269',
    lang: '',
    currency: 'KMF',
    alias: 'comoros'
  },
  {
    code: 'CG',
    alpha3Code: 'COG',
    name: 'Congo',
    translationName: i18n.t('countries.Congo'),
    phone_code: '242',
    lang: '',
    currency: 'XAF',
    alias: 'republic-of-the-congo'
  },
  {
    code: 'CD',
    alpha3Code: 'COD',
    name: 'Congo, Democratic Republic of the (Zaire)',
    translationName: i18n.t('countries.CongoDemocraticRepublicoftheZaire'),
    phone_code: '243',
    lang: '',
    currency: 'CDF',
    alias: 'democratic-republic-of-congo'
  },
  {
    code: 'CK',
    alpha3Code: 'COK',
    name: 'Cook Islands',
    translationName: i18n.t('countries.CookIslands'),
    phone_code: '682',
    lang: '',
    currency: 'NZD',
    alias: 'cook-islands'
  },
  {
    code: 'CR',
    alpha3Code: 'CRI',
    name: 'Costa Rica',
    translationName: i18n.t('countries.CostaRica'),
    phone_code: '506',
    lang: 'spa',
    currency: 'CRC',
    alias: 'costa-rica'
  },
  {
    code: 'CI',
    alpha3Code: 'CIV',
    name: "Cote d'Ivoire",
    translationName: i18n.t('countries.CotedIvoire'),
    phone_code: '225',
    lang: '',
    currency: 'XOF',
    alias: 'cotedivoire'
  },
  {
    code: 'HR',
    alpha3Code: 'HRV',
    name: 'Croatia',
    translationName: i18n.t('countries.Croatia'),
    phone_code: '385',
    lang: '',
    currency: 'HRK',
    alias: 'croatia'
  },
  {
    code: 'CU',
    alpha3Code: 'CUB',
    name: 'Cuba',
    translationName: i18n.t('countries.Cuba'),
    phone_code: '53',
    lang: 'spa',
    currency: 'CUP',
    alias: 'cuba'
  },
  {
    code: 'CW',
    alpha3Code: 'CUW',
    name: 'Curacao',
    translationName: i18n.t('countries.Curacao'),
    phone_code: '599 9',
    lang: '',
    currency: '',
    alias: 'curacao'
  },
  {
    code: 'CY',
    alpha3Code: 'CYP',
    name: 'Cyprus',
    translationName: i18n.t('countries.Cyprus'),
    phone_code: '357',
    lang: 'tur',
    currency: 'EUR',
    alias: 'cyprus'
  },
  {
    code: 'CZ',
    alpha3Code: 'CZE',
    name: 'Czech Republic',
    translationName: i18n.t('countries.CzechRepublic'),
    phone_code: '420',
    lang: '',
    currency: 'CZK',
    alias: 'czech-republic'
  },
  {
    code: 'DK',
    alpha3Code: 'DNK',
    name: 'Denmark',
    translationName: i18n.t('countries.Denmark'),
    phone_code: '45',
    lang: '',
    currency: 'DKK',
    alias: 'denmark'
  },
  {
    code: 'DJ',
    alpha3Code: 'DJI',
    name: 'Djibouti',
    translationName: i18n.t('countries.Djibouti'),
    phone_code: '253',
    lang: '',
    currency: 'DJF',
    alias: 'djibouti'
  },
  {
    code: 'DM',
    alpha3Code: 'DMA',
    name: 'Dominica',
    translationName: i18n.t('countries.Dominica'),
    phone_code: '1 767',
    lang: '',
    currency: 'XCD',
    alias: 'dominica'
  },
  {
    code: 'DO',
    alpha3Code: 'DOM',
    name: 'Dominican Republic',
    translationName: i18n.t('countries.DominicanRepublic'),
    phone_code: '1 809',
    lang: 'spa',
    currency: 'DOP',
    alias: 'dominican-republic'
  },
  {
    code: 'EC',
    alpha3Code: 'ECU',
    name: 'Ecuador',
    translationName: i18n.t('countries.Ecuador'),
    phone_code: '593',
    lang: '',
    currency: 'ECS',
    alias: 'ecuador'
  },
  {
    code: 'EG',
    alpha3Code: 'EGY',
    name: 'Egypt',
    translationName: i18n.t('countries.Egypt'),
    phone_code: '20',
    lang: '',
    currency: 'EGP',
    alias: 'egypt'
  },
  {
    code: 'SV',
    alpha3Code: 'SLV',
    name: 'El Salvador',
    translationName: i18n.t('countries.ElSalvador'),
    phone_code: '503',
    lang: 'spa',
    currency: 'SVC',
    alias: 'el-salvador'
  },
  {
    code: 'GQ',
    alpha3Code: 'GNQ',
    name: 'Equatorial Guinea',
    translationName: i18n.t('countries.EquatorialGuinea'),
    phone_code: '240',
    lang: '',
    currency: 'XAF',
    alias: 'equatorial-guinea'
  },
  {
    code: 'ER',
    alpha3Code: 'ERI',
    name: 'Eritrea',
    translationName: i18n.t('countries.Eritrea'),
    phone_code: '291',
    lang: '',
    currency: 'ERN',
    alias: 'eritrea'
  },
  {
    code: 'EE',
    alpha3Code: 'EST',
    name: 'Estonia',
    translationName: i18n.t('countries.Estonia'),
    phone_code: '372',
    lang: 'rus',
    currency: 'EUR',
    alias: 'estonia'
  },
  {
    code: 'ET',
    alpha3Code: 'ETH',
    name: 'Ethiopia',
    translationName: i18n.t('countries.Ethiopia'),
    phone_code: '251',
    lang: '',
    currency: 'ETB',
    alias: 'ethiopia'
  },
  {
    code: 'FK',
    alpha3Code: 'FLK',
    name: 'Falkland Islands',
    translationName: i18n.t('countries.FalklandIslands'),
    phone_code: '500',
    lang: '',
    currency: 'FKP',
    alias: 'falkland-islands'
  },
  {
    code: 'FO',
    alpha3Code: 'FRO',
    name: 'Faroe Islands',
    translationName: i18n.t('countries.FaroeIslands'),
    phone_code: '298',
    lang: '',
    currency: 'DKK',
    alias: 'faroe-islands'
  },
  {
    code: 'FJ',
    alpha3Code: 'FJI',
    name: 'Fiji',
    translationName: i18n.t('countries.Fiji'),
    phone_code: '679',
    lang: '',
    currency: 'FJD',
    alias: 'fiji'
  },
  {
    code: 'FI',
    alpha3Code: 'FIN',
    name: 'Finland',
    translationName: i18n.t('countries.Finland'),
    phone_code: '358',
    lang: '',
    currency: 'EUR',
    alias: 'finland'
  },
  {
    code: 'FR',
    alpha3Code: 'FRA',
    name: 'France',
    translationName: i18n.t('countries.France'),
    phone_code: '33',
    lang: 'fre',
    currency: 'EUR',
    alias: 'france'
  },
  {
    code: 'GF',
    alpha3Code: 'GUF',
    name: 'French Guiana',
    translationName: i18n.t('countries.FrenchGuiana'),
    phone_code: '594',
    lang: 'fre',
    currency: 'EUR',
    alias: 'french-guiana'
  },
  {
    code: 'PF',
    alpha3Code: 'PYF',
    name: 'French Polynesia',
    translationName: i18n.t('countries.FrenchPolynesia'),
    phone_code: '689',
    lang: '',
    currency: 'XPF',
    alias: 'french-polynesia'
  },
  {
    code: 'GA',
    alpha3Code: 'GAB',
    name: 'Gabon',
    translationName: i18n.t('countries.Gabon'),
    phone_code: '241',
    lang: '',
    currency: 'XAF',
    alias: 'gabon'
  },
  {
    code: 'GM',
    alpha3Code: 'GMB',
    name: 'Gambia',
    translationName: i18n.t('countries.Gambia'),
    phone_code: '220',
    lang: '',
    currency: 'GMD',
    alias: 'gambia'
  },
  {
    code: 'GE',
    alpha3Code: 'GEO',
    name: 'Georgia',
    translationName: i18n.t('countries.Georgia'),
    phone_code: '995',
    lang: 'rus',
    currency: 'GEL',
    alias: 'georgia'
  },
  {
    code: 'DE',
    alpha3Code: 'DEU',
    name: 'Germany',
    translationName: i18n.t('countries.Germany'),
    phone_code: '49',
    lang: 'ger',
    currency: 'EUR',
    alias: 'germany'
  },
  {
    code: 'GH',
    alpha3Code: 'GHA',
    name: 'Ghana',
    translationName: i18n.t('countries.Ghana'),
    phone_code: '233',
    lang: '',
    currency: 'GHS',
    alias: 'ghana'
  },
  {
    code: 'GI',
    alpha3Code: 'GIB',
    name: 'Gibraltar',
    translationName: i18n.t('countries.Gibraltar'),
    phone_code: '350',
    lang: '',
    currency: 'GIP',
    alias: 'gibraltar'
  },
  {
    code: 'GR',
    alpha3Code: 'GRC',
    name: 'Greece',
    translationName: i18n.t('countries.Greece'),
    phone_code: '30',
    lang: 'gre',
    currency: 'EUR',
    alias: 'greece'
  },
  {
    code: 'GL',
    alpha3Code: 'GRL',
    name: 'Greenland',
    translationName: i18n.t('countries.Greenland'),
    phone_code: '299',
    lang: '',
    currency: 'DKK',
    alias: 'greenland'
  },
  {
    code: 'GD',
    alpha3Code: 'GRD',
    name: 'Grenada',
    translationName: i18n.t('countries.Grenada'),
    phone_code: '1 473',
    lang: '',
    currency: 'XCD',
    alias: 'grenada'
  },
  {
    code: 'GP',
    alpha3Code: 'GLP',
    name: 'Guadeloupe',
    translationName: i18n.t('countries.Guadeloupe'),
    phone_code: '590',
    lang: 'fre',
    currency: 'EUR',
    alias: 'france-guadeloupe'
  },
  {
    code: 'GU',
    alpha3Code: 'GUM',
    name: 'Guam',
    translationName: i18n.t('countries.Guam'),
    phone_code: '1 671',
    lang: '',
    currency: 'USD',
    alias: 'guam'
  },
  {
    code: 'GT',
    alpha3Code: 'GTM',
    name: 'Guatemala',
    translationName: i18n.t('countries.Guatemala'),
    phone_code: '502',
    lang: 'spa',
    currency: 'QTQ',
    alias: 'guatemala'
  },
  {
    code: 'GG',
    alpha3Code: 'GGY',
    name: 'Guernsey',
    translationName: i18n.t('countries.Guernsey'),
    phone_code: '44 1481',
    lang: '',
    currency: 'GGP',
    alias: 'guernsey'
  },
  {
    code: 'GN',
    alpha3Code: 'GIN',
    name: 'Guinea',
    translationName: i18n.t('countries.Guinea'),
    phone_code: '224',
    lang: '',
    currency: 'GNF',
    alias: 'guinea'
  },
  {
    code: 'GW',
    alpha3Code: 'GNB',
    name: 'Guinea-Bissau',
    translationName: i18n.t('countries.GuineaBissau'),
    phone_code: '245',
    lang: '',
    currency: 'GWP',
    alias: 'guinea-bissau'
  },
  {
    code: 'GY',
    alpha3Code: 'GUY',
    name: 'Guyana',
    translationName: i18n.t('countries.Guyana'),
    phone_code: '592',
    lang: '',
    currency: 'GYD',
    alias: 'guyana'
  },
  {
    code: 'HT',
    alpha3Code: 'HTI',
    name: 'Haiti',
    translationName: i18n.t('countries.Haiti'),
    phone_code: '509',
    lang: '',
    currency: 'HTG',
    alias: 'haiti'
  },
  {
    code: 'VA',
    alpha3Code: 'VAT',
    name: 'Holy See',
    translationName: i18n.t('countries.HolySee'),
    phone_code: '379',
    lang: '',
    currency: 'EUR',
    alias: 'vatican-city'
  },
  {
    code: 'HN',
    alpha3Code: 'HND',
    name: 'Honduras',
    translationName: i18n.t('countries.Honduras'),
    phone_code: '504',
    lang: 'spa',
    currency: 'HNL',
    alias: 'honduras'
  },
  {
    code: 'HK',
    alpha3Code: 'HKG',
    name: 'Hong Kong',
    translationName: i18n.t('countries.HongKong'),
    phone_code: '852',
    lang: '',
    currency: 'HKD',
    alias: 'hong-kong'
  },
  {
    code: 'HU',
    alpha3Code: 'HUN',
    name: 'Hungary',
    translationName: i18n.t('countries.Hungary'),
    phone_code: '36',
    lang: '',
    currency: 'HUF',
    alias: 'hungary'
  },
  {
    code: 'IS',
    alpha3Code: 'ISL',
    name: 'Iceland',
    translationName: i18n.t('countries.Iceland'),
    phone_code: '354',
    lang: '',
    currency: 'ISK',
    alias: 'iceland'
  },
  {
    code: 'IN',
    alpha3Code: 'IND',
    name: 'India',
    translationName: i18n.t('countries.India'),
    phone_code: '91',
    lang: '',
    currency: 'INR',
    alias: 'india'
  },
  {
    code: 'ID',
    alpha3Code: 'IDN',
    name: 'Indonesia',
    translationName: i18n.t('countries.Indonesia'),
    phone_code: '62',
    lang: '',
    currency: 'IDR',
    alias: 'indonesia'
  },
  {
    code: 'IR',
    alpha3Code: 'IRN',
    name: 'Iran',
    translationName: i18n.t('countries.Iran'),
    phone_code: '98',
    lang: '',
    currency: 'IRR',
    alias: 'iran'
  },
  {
    code: 'IQ',
    alpha3Code: 'IRQ',
    name: 'Iraq',
    translationName: i18n.t('countries.Iraq'),
    phone_code: '964',
    lang: '',
    currency: 'IQD',
    alias: 'iraq'
  },
  {
    code: 'IE',
    alpha3Code: 'IRL',
    name: 'Ireland',
    translationName: i18n.t('countries.Ireland'),
    phone_code: '353',
    lang: '',
    currency: 'EUR',
    alias: 'ireland'
  },
  {
    code: 'IM',
    alpha3Code: 'IMN',
    name: 'Isle of Man',
    translationName: i18n.t('countries.IsleofMan'),
    phone_code: '44 1624',
    lang: '',
    currency: 'GBP',
    alias: 'isle-of-man'
  },
  {
    code: 'IL',
    alpha3Code: 'ISR',
    name: 'Israel',
    translationName: i18n.t('countries.Israel'),
    phone_code: '972',
    lang: '',
    currency: 'ILS',
    alias: 'israel'
  },
  {
    code: 'IT',
    alpha3Code: 'ITA',
    name: 'Italy',
    translationName: i18n.t('countries.Italy'),
    phone_code: '39',
    lang: 'ita',
    currency: 'EUR',
    alias: 'italy'
  },
  {
    code: 'JM',
    alpha3Code: 'JAM',
    name: 'Jamaica',
    translationName: i18n.t('countries.Jamaica'),
    phone_code: '1 876',
    lang: '',
    currency: 'JMD',
    alias: 'jamaica'
  },
  {
    code: 'JP',
    alpha3Code: 'JPN',
    name: 'Japan',
    translationName: i18n.t('countries.Japan'),
    phone_code: '81',
    lang: '',
    currency: 'JPY',
    alias: 'japan'
  },
  {
    code: 'JE',
    alpha3Code: 'JEY',
    name: 'Jersey',
    translationName: i18n.t('countries.Jersey'),
    phone_code: '44 1534',
    lang: '',
    currency: 'GBP',
    alias: 'jersey'
  },
  {
    code: 'JO',
    alpha3Code: 'JOR',
    name: 'Jordan',
    translationName: i18n.t('countries.Jordan'),
    phone_code: '962',
    lang: '',
    currency: 'JOD',
    alias: 'jordan'
  },
  {
    code: 'KZ',
    alpha3Code: 'KAZ',
    name: 'Kazakhstan',
    translationName: i18n.t('countries.Kazakhstan'),
    phone_code: '7',
    lang: 'rus',
    currency: 'KZT',
    alias: 'kazakhstan'
  },
  {
    code: 'KE',
    alpha3Code: 'KEN',
    name: 'Kenya',
    translationName: i18n.t('countries.Kenya'),
    phone_code: '254',
    lang: '',
    currency: 'KES',
    alias: 'kenya'
  },
  {
    code: 'KI',
    alpha3Code: 'KIR',
    name: 'Kiribati',
    translationName: i18n.t('countries.Kiribati'),
    phone_code: '686',
    lang: '',
    currency: 'AUD',
    alias: 'kiribati'
  },
  {
    code: 'KP',
    alpha3Code: 'PRK',
    name: 'Korea, North',
    translationName: i18n.t('countries.KoreaNorth'),
    phone_code: '850',
    lang: '',
    currency: 'KPW',
    alias: 'north-korea'
  },
  {
    code: 'KW',
    alpha3Code: 'KWT',
    name: 'Kuwait',
    translationName: i18n.t('countries.Kuwait'),
    phone_code: '965',
    lang: '',
    currency: 'KWD',
    alias: 'kuwait'
  },
  {
    code: 'KG',
    alpha3Code: 'KGZ',
    name: 'Kyrgyzstan',
    translationName: i18n.t('countries.Kyrgyzstan'),
    phone_code: '996',
    lang: 'rus',
    currency: 'KGS',
    alias: 'kyrgyzstan'
  },
  {
    code: 'LA',
    alpha3Code: 'LAO',
    name: 'Laos',
    translationName: i18n.t('countries.Laos'),
    phone_code: '856',
    lang: '',
    currency: 'LAK',
    alias: 'laos'
  },
  {
    code: 'LV',
    alpha3Code: 'LVA',
    name: 'Latvia',
    translationName: i18n.t('countries.Latvia'),
    phone_code: '371',
    lang: 'rus',
    currency: 'LVL',
    alias: 'latvia'
  },
  {
    code: 'LB',
    alpha3Code: 'LBN',
    name: 'Lebanon',
    translationName: i18n.t('countries.Lebanon'),
    phone_code: '961',
    lang: '',
    currency: 'LBP',
    alias: 'lebanon'
  },
  {
    code: 'LS',
    alpha3Code: 'LSO',
    name: 'Lesotho',
    translationName: i18n.t('countries.Lesotho'),
    phone_code: '266',
    lang: '',
    currency: 'LSL',
    alias: 'lesotho'
  },
  {
    code: 'LR',
    alpha3Code: 'LBR',
    name: 'Liberia',
    translationName: i18n.t('countries.Liberia'),
    phone_code: '231',
    lang: '',
    currency: 'LRD',
    alias: 'liberia'
  },
  {
    code: 'LY',
    alpha3Code: 'LBY',
    name: 'Libya',
    translationName: i18n.t('countries.Libya'),
    phone_code: '218',
    lang: 'ita',
    currency: 'LYD',
    alias: 'libya'
  },
  {
    code: 'LI',
    alpha3Code: 'LIE',
    name: 'Liechtenstein',
    translationName: i18n.t('countries.Liechtenstein'),
    phone_code: '423',
    lang: '',
    currency: 'CHF',
    alias: 'liechtenstein'
  },
  {
    code: 'LT',
    alpha3Code: 'LTU',
    name: 'Lithuania',
    translationName: i18n.t('countries.Lithuania'),
    phone_code: '370',
    lang: 'rus',
    currency: 'LTL',
    alias: 'lithuania'
  },
  {
    code: 'LU',
    alpha3Code: 'LUX',
    name: 'Luxembourg',
    translationName: i18n.t('countries.Luxembourg'),
    phone_code: '352',
    lang: 'fre',
    currency: 'EUR',
    alias: 'luxembourg'
  },
  {
    code: 'MO',
    alpha3Code: 'MAC',
    name: 'Macao',
    translationName: i18n.t('countries.Macao'),
    phone_code: '853',
    lang: '',
    currency: 'MOP',
    alias: 'macao'
  },
  {
    code: 'MK',
    alpha3Code: 'MKD',
    name: 'Macedonia',
    translationName: i18n.t('countries.Macedonia'),
    phone_code: '389',
    lang: '',
    currency: 'MKD',
    alias: 'republic-of-macedonia'
  },
  {
    code: 'MG',
    alpha3Code: 'MDG',
    name: 'Madagascar',
    translationName: i18n.t('countries.Madagascar'),
    phone_code: '261',
    lang: '',
    currency: 'MGF',
    alias: 'madagascar'
  },
  {
    code: 'MW',
    alpha3Code: 'MWI',
    name: 'Malawi',
    translationName: i18n.t('countries.Malawi'),
    phone_code: '265',
    lang: '',
    currency: 'MWK',
    alias: 'malawi'
  },
  {
    code: 'MY',
    alpha3Code: 'MYS',
    name: 'Malaysia',
    translationName: i18n.t('countries.Malaysia'),
    phone_code: '60',
    lang: '',
    currency: 'MYR',
    alias: 'malaysia'
  },
  {
    code: 'MV',
    alpha3Code: 'MDV',
    name: 'Maldives',
    translationName: i18n.t('countries.Maldives'),
    phone_code: '960',
    lang: '',
    currency: 'MVR',
    alias: 'maldives'
  },
  {
    code: 'ML',
    alpha3Code: 'MLI',
    name: 'Mali',
    translationName: i18n.t('countries.Mali'),
    phone_code: '223',
    lang: '',
    currency: 'XOF',
    alias: 'mali'
  },
  {
    code: 'MT',
    alpha3Code: 'MLT',
    name: 'Malta',
    translationName: i18n.t('countries.Malta'),
    phone_code: '356',
    lang: 'eng',
    currency: 'EUR',
    alias: 'malta'
  },
  {
    code: 'MH',
    alpha3Code: 'MHL',
    name: 'Marshall Islands',
    translationName: i18n.t('countries.MarshallIslands'),
    phone_code: '692',
    lang: '',
    currency: 'USD',
    alias: 'marshall-island'
  },
  {
    code: 'MQ',
    alpha3Code: 'MTQ',
    name: 'Martinique',
    translationName: i18n.t('countries.Martinique'),
    phone_code: '596',
    lang: 'fre',
    currency: 'EUR',
    alias: 'martinique'
  },
  {
    code: 'MR',
    alpha3Code: 'MRT',
    name: 'Mauritania',
    translationName: i18n.t('countries.Mauritania'),
    phone_code: '222',
    lang: '',
    currency: 'MRO',
    alias: 'mauritania'
  },
  {
    code: 'MU',
    alpha3Code: 'MUS',
    name: 'Mauritius',
    translationName: i18n.t('countries.Mauritius'),
    phone_code: '230',
    lang: '',
    currency: 'MUR',
    alias: 'mauritius'
  },
  {
    code: 'YT',
    alpha3Code: 'MYT',
    name: 'Mayotte',
    translationName: i18n.t('countries.Mayotte'),
    phone_code: '262',
    lang: '',
    currency: 'EUR',
    alias: 'mayotte'
  },
  {
    code: 'MX',
    alpha3Code: 'MEX',
    name: 'Mexico',
    translationName: i18n.t('countries.Mexico'),
    phone_code: '52',
    lang: 'spa',
    currency: 'MXN',
    alias: 'mexico'
  },
  {
    code: 'FM',
    alpha3Code: 'FSM',
    name: 'Micronesia, Federated States of',
    translationName: i18n.t('countries.MicronesiaFederatedStatesof'),
    phone_code: '691',
    lang: '',
    currency: 'USD',
    alias: 'micronesia'
  },
  {
    code: 'MD',
    alpha3Code: 'MDA',
    name: 'Moldova',
    translationName: i18n.t('countries.Moldova'),
    phone_code: '373',
    lang: 'rus',
    currency: 'MDL',
    alias: 'moldova'
  },
  {
    code: 'MC',
    alpha3Code: 'MCO',
    name: 'Monaco',
    translationName: i18n.t('countries.Monaco'),
    phone_code: '377',
    lang: '',
    currency: 'EUR',
    alias: 'monaco'
  },
  {
    code: 'MN',
    alpha3Code: 'MNG',
    name: 'Mongolia',
    translationName: i18n.t('countries.Mongolia'),
    phone_code: '976',
    lang: 'rus',
    currency: 'MNT',
    alias: 'mongolia'
  },
  {
    code: 'ME',
    alpha3Code: 'MNE',
    name: 'Montenegro',
    translationName: i18n.t('countries.Montenegro'),
    phone_code: '382',
    lang: '',
    currency: 'EUR',
    alias: 'montenegro'
  },
  {
    code: 'MS',
    alpha3Code: 'MSR',
    name: 'Montserrat',
    translationName: i18n.t('countries.Montserrat'),
    phone_code: '1 664',
    lang: '',
    currency: 'XCD',
    alias: 'montserrat'
  },
  {
    code: 'MA',
    alpha3Code: 'MAR',
    name: 'Morocco',
    translationName: i18n.t('countries.Morocco'),
    phone_code: '212',
    lang: '',
    currency: 'MAD',
    alias: 'morocco'
  },
  {
    code: 'MZ',
    alpha3Code: 'MOZ',
    name: 'Mozambique',
    translationName: i18n.t('countries.Mozambique'),
    phone_code: '258',
    lang: '',
    currency: 'MZN',
    alias: 'mozambique'
  },
  {
    code: 'MM',
    alpha3Code: 'MMR',
    name: 'Myanmar',
    translationName: i18n.t('countries.Myanmar'),
    phone_code: '95',
    lang: '',
    currency: 'MMK',
    alias: 'myanmar'
  },
  {
    code: 'NA',
    alpha3Code: 'NAM',
    name: 'Namibia',
    translationName: i18n.t('countries.Namibia'),
    phone_code: '264',
    lang: '',
    currency: 'NAD',
    alias: 'namibia'
  },
  {
    code: 'NR',
    alpha3Code: 'NRU',
    name: 'Nauru',
    translationName: i18n.t('countries.Nauru'),
    phone_code: '674',
    lang: '',
    currency: 'AUD',
    alias: 'nauru'
  },
  {
    code: 'NP',
    alpha3Code: 'NPL',
    name: 'Nepal',
    translationName: i18n.t('countries.Nepal'),
    phone_code: '977',
    lang: '',
    currency: 'NPR',
    alias: 'nepal'
  },
  {
    code: 'NL',
    alpha3Code: 'NLD',
    name: 'Netherlands',
    translationName: i18n.t('countries.Netherlands'),
    phone_code: '31',
    lang: '',
    currency: 'EUR',
    alias: 'netherlands'
  },
  {
    code: 'NC',
    alpha3Code: 'NCL',
    name: 'New Caledonia',
    translationName: i18n.t('countries.NewCaledonia'),
    phone_code: '687',
    lang: '',
    currency: 'XPF',
    alias: 'new-caledonia'
  },
  {
    code: 'NZ',
    alpha3Code: 'NZL',
    name: 'New Zealand',
    translationName: i18n.t('countries.NewZealand'),
    phone_code: '64',
    lang: '',
    currency: 'NZD',
    alias: 'new-zealand'
  },
  {
    code: 'NI',
    alpha3Code: 'NIC',
    name: 'Nicaragua',
    translationName: i18n.t('countries.Nicaragua'),
    phone_code: '505',
    lang: 'spa',
    currency: 'NIO',
    alias: 'nicaragua'
  },
  {
    code: 'NE',
    alpha3Code: 'NER',
    name: 'Niger',
    translationName: i18n.t('countries.Niger'),
    phone_code: '227',
    lang: '',
    currency: 'XOF',
    alias: 'niger'
  },
  {
    code: 'NG',
    alpha3Code: 'NGA',
    name: 'Nigeria',
    translationName: i18n.t('countries.Nigeria'),
    phone_code: '234',
    lang: '',
    currency: 'NGN',
    alias: 'nigeria'
  },
  {
    code: 'NU',
    alpha3Code: 'NIU',
    name: 'Niue',
    translationName: i18n.t('countries.Niue'),
    phone_code: '683',
    lang: '',
    currency: 'NZD',
    alias: 'niue'
  },
  {
    code: 'NF',
    alpha3Code: 'NFK',
    name: 'Norfolk Island',
    translationName: i18n.t('countries.NorfolkIsland'),
    phone_code: '672 3',
    lang: '',
    currency: 'AUD',
    alias: 'norfolk-island'
  },
  {
    code: 'MP',
    alpha3Code: 'MNP',
    name: 'Northern Mariana Islands',
    translationName: i18n.t('countries.NorthernMarianaIslands'),
    phone_code: '1 670',
    lang: '',
    currency: 'USD',
    alias: 'northern-marianas-islands'
  },
  {
    code: 'NO',
    alpha3Code: 'NOR',
    name: 'Norway',
    translationName: i18n.t('countries.Norway'),
    phone_code: '47',
    lang: '',
    currency: 'NOK',
    alias: 'norway'
  },
  {
    code: 'OM',
    alpha3Code: 'OMN',
    name: 'Oman',
    translationName: i18n.t('countries.Oman'),
    phone_code: '968',
    lang: '',
    currency: 'OMR',
    alias: 'oman'
  },
  {
    code: 'PK',
    alpha3Code: 'PAK',
    name: 'Pakistan',
    translationName: i18n.t('countries.Pakistan'),
    phone_code: '92',
    lang: '',
    currency: 'PKR',
    alias: 'pakistan'
  },
  {
    code: 'PW',
    alpha3Code: 'PLW',
    name: 'Palau',
    translationName: i18n.t('countries.Palau'),
    phone_code: '680',
    lang: '',
    currency: 'USD',
    alias: 'palau'
  },
  {
    code: 'PS',
    alpha3Code: 'PSE',
    name: 'Palestine, State of',
    translationName: i18n.t('countries.PalestineStateof'),
    phone_code: '970',
    lang: '',
    currency: '',
    alias: 'palestine'
  },
  {
    code: 'PA',
    alpha3Code: 'PAN',
    name: 'Panama',
    translationName: i18n.t('countries.Panama'),
    phone_code: '507',
    lang: 'spa',
    currency: 'PAB',
    alias: 'panama'
  },
  {
    code: 'PG',
    alpha3Code: 'PNG',
    name: 'Papua New Guinea',
    translationName: i18n.t('countries.PapuaNewGuinea'),
    phone_code: '675',
    lang: '',
    currency: 'PGK',
    alias: 'papua-new-guinea'
  },
  {
    code: 'PY',
    alpha3Code: 'PRY',
    name: 'Paraguay',
    translationName: i18n.t('countries.Paraguay'),
    phone_code: '595',
    lang: 'spa',
    currency: 'PYG',
    alias: 'paraguay'
  },
  {
    code: 'PE',
    alpha3Code: 'PER',
    name: 'Peru',
    translationName: i18n.t('countries.Peru'),
    phone_code: '51',
    lang: 'spa',
    currency: 'PEN',
    alias: 'peru'
  },
  {
    code: 'PH',
    alpha3Code: 'PHL',
    name: 'Philippines',
    translationName: i18n.t('countries.Philippines'),
    phone_code: '63',
    lang: '',
    currency: 'PHP',
    alias: 'philippines'
  },
  {
    code: 'PL',
    alpha3Code: 'POL',
    name: 'Poland',
    translationName: i18n.t('countries.Poland'),
    phone_code: '48',
    lang: '',
    currency: 'PLN',
    alias: 'poland'
  },
  {
    code: 'PT',
    alpha3Code: 'PRT',
    name: 'Portugal',
    translationName: i18n.t('countries.Portugal'),
    phone_code: '351',
    lang: 'por',
    currency: 'EUR',
    alias: 'portugal'
  },
  {
    code: 'PR',
    alpha3Code: 'PRI',
    name: 'Puerto Rico',
    translationName: i18n.t('countries.PuertoRico'),
    phone_code: '1 787',
    lang: '',
    currency: 'USD',
    alias: 'puerto-rico'
  },
  {
    code: 'QA',
    alpha3Code: 'QAT',
    name: 'Qatar',
    translationName: i18n.t('countries.Qatar'),
    phone_code: '974',
    lang: '',
    currency: 'QAR',
    alias: 'qatar'
  },
  {
    code: 'RE',
    alpha3Code: 'REU',
    name: 'Reunion',
    translationName: i18n.t('countries.Reunion'),
    phone_code: '262',
    lang: 'fre',
    currency: 'EUR',
    alias: 'reunion'
  },
  {
    code: 'RO',
    alpha3Code: 'ROU',
    name: 'Romania',
    translationName: i18n.t('countries.Romania'),
    phone_code: '40',
    lang: '',
    currency: 'RON',
    alias: 'romania'
  },
  {
    code: 'RU',
    alpha3Code: 'RUS',
    name: 'Russia',
    translationName: i18n.t('countries.Russia'),
    phone_code: '7',
    lang: 'rus',
    currency: 'RUB',
    alias: 'russia'
  },
  {
    code: 'RW',
    alpha3Code: 'RWA',
    name: 'Rwanda',
    translationName: i18n.t('countries.Rwanda'),
    phone_code: '250',
    lang: '',
    currency: 'RWF',
    alias: 'rwanda'
  },
  {
    code: 'BL',
    alpha3Code: 'BLM',
    name: 'Saint Barthelemy',
    translationName: i18n.t('countries.SaintBarthelemy'),
    phone_code: '590',
    lang: '',
    currency: '',
    alias: 'st-barts'
  },
  {
    code: 'SH',
    alpha3Code: 'SHN',
    name: 'Saint Helena',
    translationName: i18n.t('countries.SaintHelena'),
    phone_code: '290',
    lang: '',
    currency: 'SHP',
    alias: 'flag_of_saint_helena'
  },
  {
    code: 'KN',
    alpha3Code: 'KNA',
    name: 'Saint Kitts and Nevis',
    translationName: i18n.t('countries.SaintKittsandNevis'),
    phone_code: '1 869',
    lang: '',
    currency: 'XCD',
    alias: 'saint-kitts-and-nevis'
  },
  {
    code: 'LC',
    alpha3Code: 'LCA',
    name: 'Saint Lucia',
    translationName: i18n.t('countries.SaintLucia'),
    phone_code: '1 758',
    lang: '',
    currency: 'XCD',
    alias: 'saint-lucia'
  },
  {
    code: 'MF',
    alpha3Code: 'MAF',
    name: 'Saint Martin (France)',
    translationName: i18n.t('countries.SaintMartinFrance'),
    phone_code: '590',
    lang: '',
    currency: '',
    alias: 'france-saint-martin'
  },
  {
    code: 'PM',
    alpha3Code: 'SPM',
    name: 'Saint Pierre and Miquelon',
    translationName: i18n.t('countries.SaintPierreandMiquelon'),
    phone_code: '508',
    lang: '',
    currency: 'EUR',
    alias: 'france-miquelon'
  },
  {
    code: 'VC',
    alpha3Code: 'VCT',
    name: 'Saint Vincent and the Grenadines',
    translationName: i18n.t('countries.SaintVincentandtheGrenadines'),
    phone_code: '1 784',
    lang: '',
    currency: 'XCD',
    alias: 'flag_of_saint_vincent'
  },
  {
    code: 'WS',
    alpha3Code: 'WSM',
    name: 'Samoa',
    translationName: i18n.t('countries.Samoa'),
    phone_code: '685',
    lang: '',
    currency: 'WST',
    alias: 'samoa'
  },
  {
    code: 'SM',
    alpha3Code: 'SMR',
    name: 'San Marino',
    translationName: i18n.t('countries.SanMarino'),
    phone_code: '378',
    lang: 'ita',
    currency: 'EUR',
    alias: 'san-marino'
  },
  {
    code: 'ST',
    alpha3Code: 'STP',
    name: 'Sao Tome and Principe',
    translationName: i18n.t('countries.SaoTomeandPrincipe'),
    phone_code: '239',
    lang: '',
    currency: 'STD',
    alias: 'sao-tome-and-principe'
  },
  {
    code: 'SA',
    alpha3Code: 'SAU',
    name: 'Saudi Arabia',
    translationName: i18n.t('countries.SaudiArabia'),
    phone_code: '966',
    lang: '',
    currency: 'SAR',
    alias: 'saudi-arabia'
  },
  {
    code: 'SN',
    alpha3Code: 'SEN',
    name: 'Senegal',
    translationName: i18n.t('countries.Senegal'),
    phone_code: '221',
    lang: '',
    currency: 'XOF',
    alias: 'senegal'
  },
  {
    code: 'RS',
    alpha3Code: 'SRB',
    name: 'Serbia',
    translationName: i18n.t('countries.Serbia'),
    phone_code: '381',
    lang: '',
    currency: 'RSD',
    alias: 'serbia'
  },
  {
    code: 'SC',
    alpha3Code: 'SYC',
    name: 'Seychelles',
    translationName: i18n.t('countries.Seychelles'),
    phone_code: '248',
    lang: '',
    currency: 'SCR',
    alias: 'seychelles'
  },
  {
    code: 'SL',
    alpha3Code: 'SLE',
    name: 'Sierra Leone',
    translationName: i18n.t('countries.SierraLeone'),
    phone_code: '232',
    lang: '',
    currency: 'SLL',
    alias: 'sierra-leone'
  },
  {
    code: 'SG',
    alpha3Code: 'SGP',
    name: 'Singapore',
    translationName: i18n.t('countries.Singapore'),
    phone_code: '65',
    lang: '',
    currency: 'SGD',
    alias: 'singapore'
  },
  {
    code: 'SX',
    alpha3Code: 'SXM',
    name: 'Sint Maarten (Netherlands)',
    translationName: i18n.t('countries.SintMaartenNetherlands'),
    phone_code: '1 721',
    lang: '',
    currency: '',
    alias: 'sint-maarten'
  },
  {
    code: 'SK',
    alpha3Code: 'SVK',
    name: 'Slovakia',
    translationName: i18n.t('countries.Slovakia'),
    phone_code: '421',
    lang: '',
    currency: 'EUR',
    alias: 'slovakia'
  },
  {
    code: 'SI',
    alpha3Code: 'SVN',
    name: 'Slovenia',
    translationName: i18n.t('countries.Slovenia'),
    phone_code: '386',
    lang: '',
    currency: 'EUR',
    alias: 'slovenia'
  },
  {
    code: 'SB',
    alpha3Code: 'SLB',
    name: 'Solomon Islands',
    translationName: i18n.t('countries.SolomonIslands'),
    phone_code: '677',
    lang: '',
    currency: 'SBD',
    alias: 'solomon-islands'
  },
  {
    code: 'SO',
    alpha3Code: 'SOM',
    name: 'Somalia',
    translationName: i18n.t('countries.Somalia'),
    phone_code: '252',
    lang: '',
    currency: 'SOS',
    alias: 'somalia'
  },
  {
    code: 'ZA',
    alpha3Code: 'ZAF',
    name: 'South Africa',
    translationName: i18n.t('countries.SouthAfrica'),
    phone_code: '27',
    lang: '',
    currency: 'ZAR',
    alias: 'south-africa'
  },
  {
    code: 'SS',
    alpha3Code: 'SSD',
    name: 'South Sudan',
    translationName: i18n.t('countries.SouthSudan'),
    phone_code: '211',
    lang: '',
    currency: 'SSP',
    alias: 'south-sudan'
  },
  {
    code: 'KR',
    alpha3Code: 'KOR',
    name: 'South Korea',
    translationName: i18n.t('countries.SouthKorea'),
    phone_code: '82',
    lang: '',
    currency: 'KRW',
    alias: 'south-korea'
  },
  {
    code: 'ES',
    alpha3Code: 'ESP',
    name: 'Spain',
    translationName: i18n.t('countries.Spain'),
    phone_code: '34',
    lang: 'spa',
    currency: 'EUR',
    alias: 'spain'
  },
  {
    code: 'LK',
    alpha3Code: 'LKA',
    name: 'Sri Lanka',
    translationName: i18n.t('countries.SriLanka'),
    phone_code: '94',
    lang: '',
    currency: 'LKR',
    alias: 'sri-lanka'
  },
  {
    code: 'SD',
    alpha3Code: 'SDN',
    name: 'Sudan',
    translationName: i18n.t('countries.Sudan'),
    phone_code: '249',
    lang: '',
    currency: 'SDG',
    alias: 'sudan'
  },
  {
    code: 'SR',
    alpha3Code: 'SUR',
    name: 'Suriname',
    translationName: i18n.t('countries.Suriname'),
    phone_code: '597',
    lang: '',
    currency: 'SRD',
    alias: 'suriname'
  },
  {
    code: 'SJ',
    alpha3Code: 'SJM',
    name: 'Svalbard and Jan Mayen',
    translationName: i18n.t('countries.SvalbardandJanMayen'),
    phone_code: '47',
    lang: '',
    currency: 'NOK',
    alias: 'svalbard_and_jan_mayen'
  },
  {
    code: 'SZ',
    name: 'Swaziland',
    alpha3Code: 'SWZ',
    translationName: i18n.t('countries.Swaziland'),
    phone_code: '268',
    lang: '',
    currency: 'SZL',
    alias: 'swaziland'
  },
  {
    code: 'SE',
    alpha3Code: 'SWE',
    name: 'Sweden',
    translationName: i18n.t('countries.Sweden'),
    phone_code: '46',
    lang: 'swe',
    currency: 'SEK',
    alias: 'sweden'
  },
  {
    code: 'CH',
    alpha3Code: 'CHE',
    name: 'Switzerland',
    translationName: i18n.t('countries.Switzerland'),
    phone_code: '41',
    lang: 'fre',
    currency: 'CHF',
    alias: 'switzerland'
  },
  {
    code: 'SY',
    alpha3Code: 'SYR',
    name: 'Syria',
    translationName: i18n.t('countries.Syria'),
    phone_code: '963',
    lang: '',
    currency: 'SYP',
    alias: 'syria'
  },
  {
    code: 'TW',
    alpha3Code: 'TWN',
    name: 'Taiwan',
    translationName: i18n.t('countries.Taiwan'),
    phone_code: '886',
    lang: '',
    currency: 'TWD',
    alias: 'taiwan'
  },
  {
    code: 'TJ',
    alpha3Code: 'TJK',
    name: 'Tajikistan',
    translationName: i18n.t('countries.Tajikistan'),
    phone_code: '992',
    lang: 'rus',
    currency: 'TJS',
    alias: 'tajikistan'
  },
  {
    code: 'TZ',
    alpha3Code: 'TZA',
    name: 'Tanzania',
    translationName: i18n.t('countries.Tanzania'),
    phone_code: '255',
    lang: '',
    currency: 'TZS',
    alias: 'united-republic-of-tanzania'
  },
  {
    code: 'TH',
    alpha3Code: 'THA',
    name: 'Thailand',
    translationName: i18n.t('countries.Thailand'),
    phone_code: '66',
    lang: '',
    currency: 'THB',
    alias: 'thailand'
  },
  {
    code: 'TL',
    alpha3Code: 'TLS',
    name: 'Timor-Leste',
    translationName: i18n.t('countries.TimorLeste'),
    phone_code: '670',
    lang: '',
    currency: '',
    alias: 'timor-leste'
  },
  {
    code: 'TG',
    alpha3Code: 'TGO',
    name: 'Togo',
    translationName: i18n.t('countries.Togo'),
    phone_code: '228',
    lang: '',
    currency: 'XOF',
    alias: 'togo'
  },
  {
    code: 'TK',
    alpha3Code: 'TKL',
    name: 'Tokelau',
    translationName: i18n.t('countries.Tokelau'),
    phone_code: '690',
    lang: '',
    currency: 'NZD',
    alias: 'tokelau'
  },
  {
    code: 'TO',
    alpha3Code: 'TON',
    name: 'Tonga',
    translationName: i18n.t('countries.Tonga'),
    phone_code: '676',
    lang: '',
    currency: 'TOP',
    alias: 'tonga'
  },
  {
    code: 'TT',
    alpha3Code: 'TTO',
    name: 'Trinidad and Tobago',
    translationName: i18n.t('countries.TrinidadandTobago'),
    phone_code: '1 868',
    lang: '',
    currency: 'TTD',
    alias: 'trinidad-and-tobago'
  },
  {
    code: 'TN',
    alpha3Code: 'TUN',
    name: 'Tunisia',
    translationName: i18n.t('countries.Tunisia'),
    phone_code: '216',
    lang: '',
    currency: 'TND',
    alias: 'tunisia'
  },
  {
    code: 'TR',
    alpha3Code: 'TUR',
    name: 'Turkey',
    translationName: i18n.t('countries.Turkey'),
    phone_code: '90',
    lang: '',
    currency: 'TRY',
    alias: 'turkey'
  },
  {
    code: 'TM',
    alpha3Code: 'TKM',
    name: 'Turkmenistan',
    translationName: i18n.t('countries.Turkmenistan'),
    phone_code: '993',
    lang: 'tur',
    currency: 'TMT',
    alias: 'turkmenistan'
  },
  {
    code: 'TC',
    alpha3Code: 'TCA',
    name: 'Turks and Caicos Islands',
    translationName: i18n.t('countries.TurksandCaicosIslands'),
    phone_code: '1 649',
    lang: '',
    currency: 'USD',
    alias: 'turks-and-caicos'
  },
  {
    code: 'TV',
    alpha3Code: 'TUV',
    name: 'Tuvalu',
    translationName: i18n.t('countries.Tuvalu'),
    phone_code: '688',
    lang: '',
    currency: 'AUD',
    alias: 'tuvalu'
  },
  {
    code: 'UG',
    alpha3Code: 'UGA',
    name: 'Uganda',
    translationName: i18n.t('countries.Uganda'),
    phone_code: '256',
    lang: '',
    currency: 'UGX',
    alias: 'uganda'
  },
  {
    code: 'UA',
    alpha3Code: 'UKR',
    name: 'Ukraine',
    translationName: i18n.t('countries.Ukraine'),
    phone_code: '380',
    lang: 'ukr',
    currency: 'UAH',
    alias: 'ukraine'
  },
  {
    code: 'AE',
    alpha3Code: 'ARE',
    name: 'United Arab Emirates',
    translationName: i18n.t('countries.UnitedArabEmirates'),
    phone_code: '971',
    lang: '',
    currency: 'AED',
    alias: 'united-arab-emirates'
  },
  {
    code: 'GB',
    alpha3Code: 'GBR',
    name: 'United Kingdom',
    translationName: i18n.t('countries.UnitedKingdom'),
    phone_code: '44',
    lang: '',
    currency: 'GBP',
    alias: 'united-kingdom'
  },
  {
    code: 'US',
    alpha3Code: 'USA',
    name: 'United States',
    translationName: i18n.t('countries.UnitedStates'),
    phone_code: '1',
    lang: '',
    currency: 'USD',
    alias: 'usa'
  },
  {
    code: 'UY',
    alpha3Code: 'URY',
    name: 'Uruguay',
    translationName: i18n.t('countries.Uruguay'),
    phone_code: '598',
    lang: 'spa',
    currency: 'UYU',
    alias: 'uruguay'
  },
  {
    code: 'UZ',
    alpha3Code: 'UZB',
    name: 'Uzbekistan',
    translationName: i18n.t('countries.Uzbekistan'),
    phone_code: '998',
    lang: 'rus',
    currency: 'UZS',
    alias: 'uzbekistan'
  },
  {
    code: 'VU',
    alpha3Code: 'VUT',
    name: 'Vanuatu',
    translationName: i18n.t('countries.Vanuatu'),
    phone_code: '678',
    lang: '',
    currency: 'VUV',
    alias: 'vanuatu'
  },
  {
    code: 'VE',
    alpha3Code: 'VEN',
    name: 'Venezuela',
    translationName: i18n.t('countries.Venezuela'),
    phone_code: '58',
    lang: 'spa',
    currency: 'VEF',
    alias: 'venezuela'
  },
  {
    code: 'VN',
    alpha3Code: 'VNM',
    name: 'Vietnam',
    translationName: i18n.t('countries.Vietnam'),
    phone_code: '84',
    lang: '',
    currency: 'VND',
    alias: 'vietnam'
  },
  {
    code: 'VG',
    name: 'Virgin Islands, British',
    alpha3Code: 'VGB',
    translationName: i18n.t('countries.VirginIslandsBritish'),
    phone_code: '1',
    lang: '',
    currency: 'USD',
    alias: 'british-virgin-islands'
  },
  {
    code: 'VI',
    alpha3Code: 'VIR',
    name: 'Virgin Islands, U.S.',
    translationName: i18n.t('countries.VirginIslandsUS'),
    phone_code: '1',
    lang: '',
    currency: 'USD',
    alias: 'virgin-islands'
  },
  {
    code: 'WF',
    alpha3Code: 'WLF',
    name: 'Wallis and Futuna',
    translationName: i18n.t('countries.WallisandFutuna'),
    phone_code: '681',
    lang: '',
    currency: 'XPF',
    alias: 'wallis-and-futuna'
  },
  {
    code: 'EH',
    alpha3Code: 'ESH',
    name: 'Western Sahara',
    translationName: i18n.t('countries.WesternSahara'),
    phone_code: '212',
    lang: '',
    currency: 'MAD',
    alias: 'western-sahara'
  },
  {
    code: 'YE',
    alpha3Code: 'YEM',
    name: 'Yemen',
    translationName: i18n.t('countries.Yemen'),
    phone_code: '967',
    lang: '',
    currency: 'YER',
    alias: 'yemen'
  },
  {
    code: 'ZM',
    alpha3Code: 'ZMB',
    name: 'Zambia',
    translationName: i18n.t('countries.Zambia'),
    phone_code: '260',
    lang: '',
    currency: 'ZMW',
    alias: 'zambia'
  },
  {
    code: 'ZW',
    alpha3Code: 'ZWE',
    name: 'Zimbabwe',
    translationName: i18n.t('countries.Zimbabwe'),
    phone_code: '263',
    lang: '',
    currency: 'ZWD',
    alias: 'zimbabwe'
  }
];
