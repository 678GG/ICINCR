import { isMobile } from 'utils/is-mobile';
import SpringConfigs from '../swarm/spring-configs';

export const ACCOUNT_ROW_GUTTER = isMobile() ? 32 : 40;
export const ZINDEX_MODAL = 1014;
export const ZINDEX_HIGH_1 = 1013;
export const ZINDEX_HIGH_2 = 1012;
export const ZINDEX_HIGH_3 = 1011;
export const ZINDEX_TOOLTIP = 10001;

export const datePickerPlacmentleft = !SpringConfigs.IS_RTL
  ? 'bottomLeft'
  : 'bottomRight';

export const datePickerPlacmentRight = !SpringConfigs.IS_RTL
  ? 'bottomRight'
  : 'bottomLeft';
