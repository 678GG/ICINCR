import { CountryCode } from 'interfaces/account-settings';
import i18n from 'i18next';
import { ChildRegion } from 'interfaces/authentication';

import { CountryCodes } from 'utils/constants/account/country-codes';
import SpringConfigs from 'utils/constants/swarm/spring-configs';

const countries = CountryCodes.map(country => ({
  label: country.translationName,
  value: country.code as CountryCode,
  name: country.name,
  currencyCountries: country.currency,
  alpha3Code: country.alpha3Code
}));

export const docType = [
  { label: i18n.t('account.identityCard'), value: '1' },
  { label: i18n.t('account.drivingLicense'), value: '2' },
  { label: i18n.t('account.passport'), value: '3' },
  { label: i18n.t('account.tesseraAt'), value: '4' },
  { label: i18n.t('account.tesseraBt'), value: '5' },
  { label: i18n.t('account.firearmsLicense'), value: '6' },
  { label: i18n.t('account.other'), value: '10' }
];

const incomeSource = [
  { label: i18n.t('account.incomeSourceSalary'), value: '1' },
  { label: i18n.t('account.incomeSourceSelfEmployed'), value: '2' },
  { label: i18n.t('account.incomeSourceInheritance'), value: '3' },
  { label: i18n.t('account.incomeSourceSavings'), value: '4' },
  { label: i18n.t('account.incomeSourceInvestments'), value: '5' },
  { label: i18n.t('account.incomeSourcePension'), value: '6' },
  { label: i18n.t('account.incomeSourceBusinessActivity'), value: '7' },
  { label: i18n.t('account.incomeSourceCompetitions'), value: '8' },
  { label: i18n.t('account.incomeSourceDonation'), value: '9' },
  { label: i18n.t('account.incomeSourceLoan'), value: '10' },
  { label: i18n.t('account.incomeSourceCapital'), value: '11' }
];

const salaryLevels = [
  {
    label1: '0',
    label2: '20,000',
    value: '0,20000'
  },
  {
    label1: '20.000',
    label2: '40,000',
    value: '20000,40000'
  },
  {
    label1: '40,000',
    label2: '60,000',
    value: '40000,60000'
  },
  {
    label1: '60,000',
    label2: '80.000',
    value: '60000,80000'
  },
  {
    label1: '80,000',
    label2: '100,000',
    value: '80000,100000'
  },
  {
    label1: '100.000',
    label2: '150,000',
    value: '100000,150000'
  },
  {
    label: '150,000',
    value: '150000,500000'
  }
];

const cashdeskIdData = [
  {
    label: i18n.t('account.selectOption'),
    value: ''
  },
  {
    label: 'Bénodet',
    value: 21692
  },
  {
    label: 'Biarritz',
    value: 21694
  },
  {
    label: 'Blotzheim',
    value: 21695
  },
  {
    label: 'Bordeaux',
    value: 21696
  },
  {
    label: 'Cannes Le Croisette',
    value: 21697
  },
  {
    label: "Cap d'Adge",
    value: 21698
  },
  {
    label: 'Carry-le-Rouet',
    value: 21699
  },
  {
    label: 'Cassis',
    value: 21700
  },
  {
    label: 'Deauville',
    value: 21701
  },
  {
    label: 'Dinard',
    value: 21702
  },
  {
    label: 'Enghien-les-Bains',
    value: 21703
  },
  {
    label: 'La Baule',
    value: 21704
  },
  {
    label: 'La Rochelle',
    value: 21705
  },
  {
    label: 'Le Ruhl - Nice',
    value: 21706
  },
  {
    label: 'Le Touquet',
    value: 21707
  },
  {
    label: 'Lille',
    value: 21708
  },
  {
    label: 'Menton',
    value: 21709
  },
  {
    label: 'Niederbronn',
    value: 21710
  },
  {
    label: 'Ouistreham',
    value: 21711
  },
  {
    label: 'Ribeauvillé',
    value: 21712
  },
  {
    label: 'Royan',
    value: 21713
  },
  {
    label: 'Sainte-Maxime',
    value: 21714
  },
  {
    label: 'Saint-Malo',
    value: 21715
  },
  {
    label: 'Saint-Raphaël',
    value: 21716
  },
  {
    label: 'Toulouse',
    value: 21717
  },
  {
    label: 'Trouville',
    value: 21718
  },
  {
    label: 'Club Barrière Paris',
    value: 21719
  },
  {
    label: 'Fribourg',
    value: 21720
  },
  {
    label: 'Courrendlin',
    value: 21721
  },
  {
    label: 'Montreux',
    value: 21722
  }
];

const departments = {
  FR: [
    { value: '', label: i18n.t('account.birthDepartmentPlaceholder') },
    { value: '01', label: 'Ain' },
    { value: '02', label: 'Aisne' },
    { value: '03', label: 'Allier' },
    { value: '04', label: 'Alpes-de-Haute-Provence' },
    { value: '05', label: 'Hautes-Alpes' },
    { value: '06', label: 'Alpes-Maritimes' },
    { value: '07', label: 'Ardèche' },
    { value: '08', label: 'Ardennes' },
    { value: '09', label: 'Ariège' },
    { value: '10', label: 'Aube' },
    { value: '11', label: 'Aude' },
    { value: '12', label: 'Aveyron' },
    { value: '13', label: 'Bouches-du-Rhône' },
    { value: '14', label: 'Calvados' },
    { value: '15', label: 'Cantal' },
    { value: '16', label: 'Charente' },
    { value: '17', label: 'Charente-Maritime' },
    { value: '18', label: 'Cher' },
    { value: '19', label: 'Corrèze' },
    { value: '21', label: "Côte-d'Or" },
    { value: '22', label: 'Côtes-dArmor' },
    { value: '23', label: 'Creuse' },
    { value: '24', label: 'Dordogne' },
    { value: '25', label: 'Doubs' },
    { value: '26', label: 'Drôme' },
    { value: '27', label: 'Eure' },
    { value: '28', label: 'Eure-et-Loir' },
    { value: '29', label: 'Finistère' },
    { value: '2A', label: 'Corse-du-Sud' },
    { value: '2B', label: 'Haute-Corse' },
    { value: '30', label: 'Gard' },
    { value: '31', label: 'Haute-Garonne' },
    { value: '32', label: 'Gers' },
    { value: '33', label: 'Gironde' },
    { value: '34', label: 'Hérault' },
    { value: '35', label: 'Ille-et-Vilaine' },
    { value: '36', label: 'Indre' },
    { value: '37', label: 'Indre-et-Loire' },
    { value: '38', label: 'Isère' },
    { value: '39', label: 'Jura' },
    { value: '40', label: 'Landes' },
    { value: '41', label: 'Loir-et-Cher' },
    { value: '42', label: 'Loire' },
    { value: '43', label: 'Haute-Loire' },
    { value: '44', label: 'Loire-Atlantique' },
    { value: '45', label: 'Loiret' },
    { value: '46', label: 'Lot' },
    { value: '47', label: 'Lot-et-Garonne' },
    { value: '48', label: 'Lozère' },
    { value: '49', label: 'Maine-et-Loire' },
    { value: '50', label: 'Manche' },
    { value: '51', label: 'Marne' },
    { value: '52', label: 'Haute-Marne' },
    { value: '53', label: 'Mayenne' },
    { value: '54', label: 'Meurthe-et-Moselle' },
    { value: '55', label: 'Meuse' },
    { value: '56', label: 'Morbihan' },
    { value: '57', label: 'Moselle' },
    { value: '58', label: 'Nièvre' },
    { value: '59', label: 'Nord' },
    { value: '60', label: 'Oise' },
    { value: '61', label: 'Orne' },
    { value: '62', label: 'Pas-de-Calais' },
    { value: '63', label: 'Puy-de-Dôme' },
    { value: '64', label: 'Pyrénées-Atlantiques' },
    { value: '65', label: 'Hautes-Pyrénées' },
    { value: '66', label: 'Pyrénées-Orientales' },
    { value: '67', label: 'Bas-Rhin' },
    { value: '68', label: 'Haut-Rhin' },
    { value: '69', label: 'Rhône' },
    { value: '70', label: 'Haute-Saône' },
    { value: '71', label: 'Saône-et-Loire' },
    { value: '72', label: 'Sarthe' },
    { value: '73', label: 'Savoie' },
    { value: '74', label: 'Haute-Savoie' },
    { value: '75', label: 'Paris' },
    { value: '76', label: 'Seine-Maritime' },
    { value: '77', label: 'Seine-et-Marne' },
    { value: '78', label: 'Yvelines' },
    { value: '79', label: 'Deux-Sèvres' },
    { value: '80', label: 'Somme' },
    { value: '81', label: 'Tarn' },
    { value: '82', label: 'Tarn-et-Garonne' },
    { value: '83', label: 'Var' },
    { value: '84', label: 'Vaucluse' },
    { value: '85', label: 'Vendée' },
    { value: '86', label: 'Vienne' },
    { value: '87', label: 'Haute-Vienne' },
    { value: '88', label: 'Vosges' },
    { value: '89', label: 'Yonne' },
    { value: '90', label: 'Territoire de Belfort' },
    { value: '91', label: 'Essonne' },
    { value: '92', label: 'Hauts-de-Seine' },
    { value: '93', label: 'Seine-Saint-Denis' },
    { value: '94', label: 'Val-de-Marne' },
    { value: '95', label: "Val-d'Oise" },
    { value: '971', label: 'Guadeloupe' },
    { value: '972', label: 'Martinique' },
    { value: '973', label: 'Guyane' },
    { value: '974', label: 'Réunion' },
    { value: '976', label: 'Mayotte' },
    { value: '99', label: i18n.t('account.other') }
  ],
  IT: [
    { value: '', label: i18n.t('account.birthDepartmentPlaceholder') },
    { value: 'AG', label: 'AGRIGENTO' },
    { value: 'AL', label: 'ALESSANDRIA' },
    { value: 'AN', label: 'ANCONA' },
    { value: 'AO', label: 'AOSTA' },
    { value: 'AP', label: 'ASCOLI-PICENO' },
    { value: 'AQ', label: "L'AQUILA" },
    { value: 'AR', label: 'AREZZO' },
    { value: 'AT', label: 'ASTI' },
    { value: 'AV', label: 'AVELLINO' },
    { value: 'BA', label: 'BARI' },
    { value: 'BG', label: 'BERGAMO' },
    { value: 'BI', label: 'BIELLA' },
    { value: 'BL', label: 'BELLUNO' },
    { value: 'BN', label: 'BENEVENTO' },
    { value: 'BO', label: 'BOLOGNA' },
    { value: 'BR', label: 'BRINDISI' },
    { value: 'BS', label: 'BRESCIA' },
    { value: 'BT', label: 'BARLETTA-ANDRIA-TRANI' },
    { value: 'BZ', label: 'BOLZANO' },
    { value: 'CA', label: 'CAGLIARI' },
    { value: 'CB', label: 'CAMPOBASSO' },
    { value: 'CE', label: 'CASERTA' },
    { value: 'CH', label: 'CHIETI' },
    { value: 'CI', label: 'CARBONIA IGLESIAS' },
    { value: 'CL', label: 'CALTANISSETTA' },
    { value: 'CN', label: 'CUNEO' },
    { value: 'CO', label: 'COMO' },
    { value: 'CR', label: 'CREMONA' },
    { value: 'CS', label: 'COSENZA' },
    { value: 'CT', label: 'CATANIA' },
    { value: 'CZ', label: 'CATANZARO' },
    { value: 'EN', label: 'ENNA' },
    { value: 'FC', label: 'FORLI-CESENA' },
    { value: 'FE', label: 'FERRARA' },
    { value: 'FG', label: 'FOGGIA' },
    { value: 'FI', label: 'FIRENZE' },
    { value: 'FM', label: 'FERMO' },
    { value: 'FR', label: 'FROSINONE' },
    { value: 'GE', label: 'GENOVA' },
    { value: 'GO', label: 'GORIZIA' },
    { value: 'GR', label: 'GROSSETO' },
    { value: 'IM', label: 'IMPERIA' },
    { value: 'IS', label: 'ISERNIA' },
    { value: 'KR', label: 'CROTONE' },
    { value: 'LC', label: 'LECCO' },
    { value: 'LE', label: 'LECCE' },
    { value: 'LI', label: 'LIVORNO' },
    { value: 'LO', label: 'LODI' },
    { value: 'LT', label: 'LATINA' },
    { value: 'LU', label: 'LUCCA' },
    { value: 'MB', label: 'MONZA-BRIANZA' },
    { value: 'MC', label: 'MACERATA' },
    { value: 'ME', label: 'MESSINA' },
    { value: 'MI', label: 'MILANO' },
    { value: 'MN', label: 'MANTOVA' },
    { value: 'MO', label: 'MODENA' },
    { value: 'MS', label: 'MASSA-CARRARA' },
    { value: 'MT', label: 'MATERA' },
    { value: 'NA', label: 'NAPOLI' },
    { value: 'NO', label: 'NOVARA' },
    { value: 'NU', label: 'NUORO' },
    { value: 'OG', label: 'OGLIASTRA' },
    { value: 'OR', label: 'ORISTANO' },
    { value: 'OT', label: 'OLBIA TEMPIO' },
    { value: 'PA', label: 'PALERMO' },
    { value: 'PC', label: 'PIACENZA' },
    { value: 'PD', label: 'PADOVA' },
    { value: 'PE', label: 'PESCARA' },
    { value: 'PG', label: 'PERUGIA' },
    { value: 'PI', label: 'PISA' },
    { value: 'PN', label: 'PORDENONE' },
    { value: 'PO', label: 'PRATO' },
    { value: 'PR', label: 'PARMA' },
    { value: 'PT', label: 'PISTOIA' },
    { value: 'PU', label: 'PESARO-URBINO' },
    { value: 'PV', label: 'PAVIA' },
    { value: 'PZ', label: 'POTENZA' },
    { value: 'RA', label: 'RAVENNA' },
    { value: 'RC', label: 'REGGIO-CALABRIA' },
    { value: 'RE', label: 'REGGIO-EMILIA' },
    { value: 'RG', label: 'RAGUSA' },
    { value: 'RI', label: 'RIETI' },
    { value: 'RN', label: 'RIMINI' },
    { value: 'RM', label: 'ROMA' },
    { value: 'RO', label: 'ROVIGO' },
    { value: 'SP', label: 'LA-SPEZIA' },
    { value: 'SS', label: 'SASSARI' },
    { value: 'SA', label: 'SALERNO' },
    { value: 'SV', label: 'SAVONA' },
    { value: 'SI', label: 'SIENA' },
    { value: 'SR', label: 'SIRACUSA' },
    { value: 'SO', label: 'SONDRIO' },
    { value: 'SU', label: 'SUD SARDEGNA' },
    { value: 'TA', label: 'TARANTO' },
    { value: 'TE', label: 'TERAMO' },
    { value: 'TR', label: 'TERNI' },
    { value: 'TO', label: 'TORINO' },
    { value: 'TP', label: 'TRAPANI' },
    { value: 'TN', label: 'TRENTO' },
    { value: 'TV', label: 'TREVISO' },
    { value: 'TS', label: 'TRIESTE' },
    { value: 'UD', label: 'UDINE' },
    { value: 'VA', label: 'VARESE' },
    { value: 'VE', label: 'VENEZIA' },
    { value: 'VBC', label: 'VERBANO-CUSIO-OSSOLA' },
    { value: 'VC', label: 'VERCELLI' },
    { value: 'VB', label: 'VERBANIA' },
    { value: 'VR', label: 'VERONA' },
    { value: 'VI', label: 'VICENZA' },
    { value: 'VT', label: 'VITERBO' },
    { value: 'VS', label: 'MEDIO CAMPIDANO' },
    { value: 'VV', label: 'VIBO-VALENTIA' },
    { value: 'other', label: i18n.t('account.other') }
  ],
  none: [
    {
      value: '99',
      label: 'Other'
    }
  ]
};

const canadaProvinces = [
  {
    Name: i18n.t('countries.Alberta'),
    Code: 'AB'
  },
  {
    Name: i18n.t('countries.BritishColumbia'),
    Code: 'BC'
  },
  {
    Name: i18n.t('countries.Manitoba'),
    Code: 'MB'
  },
  {
    Name: i18n.t('countries.NewBrunswick'),
    Code: 'NB'
  },
  {
    Name: i18n.t('countries.NewfoundlandAndLabrador'),
    Code: 'NL'
  },
  {
    Name: i18n.t('countries.NorthwestTerritories'),
    Code: 'NT'
  },
  {
    Name: i18n.t('countries.NovaScotia'),
    Code: 'NS'
  },
  {
    Name: i18n.t('countries.Nunavut'),
    Code: 'NU'
  },
  {
    Name: i18n.t('countries.Ontario'),
    Code: 'ON'
  },
  {
    Name: i18n.t('countries.PrinceEdwardIsland'),
    Code: 'PE'
  },
  {
    Name: i18n.t('countries.Quebec'),
    Code: 'QC'
  },
  {
    Name: i18n.t('countries.Saskatchewan'),
    Code: 'SK'
  },
  {
    Name: i18n.t('countries.Yukon'),
    Code: 'YT'
  }
];

const italyProvinces = [
  {
    Code: 'AG',
    Name: i18n.t('countries.agrigento')
  },
  {
    Code: 'AL',
    Name: i18n.t('countries.alessandria')
  },
  {
    Code: 'AN',
    Name: i18n.t('countries.ancona')
  },
  {
    Code: 'AO',
    Name: i18n.t('countries.aosta')
  },
  {
    Code: 'AP',
    Name: i18n.t('countries.ascoliPiceno')
  },
  {
    Code: 'AQ',
    Name: i18n.t('countries.lAquila')
  },
  {
    Code: 'AR',
    Name: i18n.t('countries.arezzo')
  },
  {
    Code: 'AT',
    Name: i18n.t('countries.asti')
  },
  {
    Code: 'AV',
    Name: i18n.t('countries.avellino')
  },
  {
    Code: 'BA',
    Name: i18n.t('countries.bari')
  },
  {
    Code: 'BG',
    Name: i18n.t('countries.bergamo')
  },
  {
    Code: 'BI',
    Name: i18n.t('countries.biella')
  },
  {
    Code: 'BL',
    Name: i18n.t('countries.belluno')
  },
  {
    Code: 'BN',
    Name: i18n.t('countries.benevento')
  },
  {
    Code: 'BO',
    Name: i18n.t('countries.bologna')
  },
  {
    Code: 'BR',
    Name: i18n.t('countries.brindisi')
  },
  {
    Code: 'BS',
    Name: i18n.t('countries.brescia')
  },
  {
    Code: 'BT',
    Name: i18n.t('countries.barlettaAndriaTrani')
  },
  {
    Code: 'BZ',
    Name: i18n.t('countries.bolzano')
  },
  {
    Code: 'CA',
    Name: i18n.t('countries.cagliari')
  },
  {
    Code: 'CB',
    Name: i18n.t('countries.campobasso')
  },
  {
    Code: 'CE',
    Name: i18n.t('countries.caserta')
  },
  {
    Code: 'CH',
    Name: i18n.t('countries.chieti')
  },
  {
    Code: 'CI',
    Name: i18n.t('countries.carboniaIglesias')
  },
  {
    Code: 'CL',
    Name: i18n.t('countries.caltanissetta')
  },
  {
    Code: 'CN',
    Name: i18n.t('countries.cuneo')
  },
  {
    Code: 'CO',
    Name: i18n.t('countries.como')
  },
  {
    Code: 'CR',
    Name: i18n.t('countries.cremona')
  },
  {
    Code: 'CS',
    Name: i18n.t('countries.cosenza')
  },
  {
    Code: 'CT',
    Name: i18n.t('countries.catania')
  },
  {
    Code: 'CZ',
    Name: i18n.t('countries.catanzaro')
  },
  {
    Code: 'EN',
    Name: i18n.t('countries.enna')
  },
  {
    Code: 'FC',
    Name: i18n.t('countries.forliCesena')
  },
  {
    Code: 'FE',
    Name: i18n.t('countries.ferrara')
  },
  {
    Code: 'FG',
    Name: i18n.t('countries.foggia')
  },
  {
    Code: 'FI',
    Name: i18n.t('countries.firenze')
  },
  {
    Code: 'FM',
    Name: i18n.t('countries.fermo')
  },
  {
    Code: 'FR',
    Name: i18n.t('countries.frosinone')
  },
  {
    Code: 'GE',
    Name: i18n.t('countries.genova')
  },
  {
    Code: 'GO',
    Name: i18n.t('countries.gorizia')
  },
  {
    Code: 'GR',
    Name: i18n.t('countries.grosseto')
  },
  {
    Code: 'IM',
    Name: i18n.t('countries.imperia')
  },
  {
    Code: 'IS',
    Name: i18n.t('countries.isernia')
  },
  {
    Code: 'KR',
    Name: i18n.t('countries.crotone')
  },
  {
    Code: 'LC',
    Name: i18n.t('countries.lecco')
  },
  {
    Code: 'LE',
    Name: i18n.t('countries.lecce')
  },
  {
    Code: 'LI',
    Name: i18n.t('countries.livorno')
  },
  {
    Code: 'LO',
    Name: i18n.t('countries.lodi')
  },
  {
    Code: 'LT',
    Name: i18n.t('countries.latina')
  },
  {
    Code: 'LU',
    Name: i18n.t('countries.lucca')
  },
  {
    Code: 'MB',
    Name: i18n.t('countries.monzaBrianza')
  },
  {
    Code: 'MC',
    Name: i18n.t('countries.macerata')
  },
  {
    Code: 'ME',
    Name: i18n.t('countries.messina')
  },
  {
    Code: 'MI',
    Name: i18n.t('countries.milano')
  },
  {
    Code: 'MN',
    Name: i18n.t('countries.mantova')
  },
  {
    Code: 'MO',
    Name: i18n.t('countries.modena')
  },
  {
    Code: 'MS',
    Name: i18n.t('countries.massaCarrara')
  },
  {
    Code: 'MT',
    Name: i18n.t('countries.matera')
  },
  {
    Code: 'NA',
    Name: i18n.t('countries.napoli')
  },
  {
    Code: 'NO',
    Name: i18n.t('countries.novara')
  },
  {
    Code: 'NU',
    Name: i18n.t('countries.nuoro')
  },
  {
    Code: 'OG',
    Name: i18n.t('countries.ogliastra')
  },
  {
    Code: 'OR',
    Name: i18n.t('countries.oristano')
  },
  {
    Code: 'OT',
    Name: i18n.t('countries.olbiaTempio')
  },
  {
    Code: 'PA',
    Name: i18n.t('countries.palermo')
  },
  {
    Code: 'PC',
    Name: i18n.t('countries.piacenza')
  },
  {
    Code: 'PD',
    Name: i18n.t('countries.padova')
  },
  {
    Code: 'PE',
    Name: i18n.t('countries.pescara')
  },
  {
    Code: 'PG',
    Name: i18n.t('countries.perugia')
  },
  {
    Code: 'PI',
    Name: i18n.t('countries.pisa')
  },
  {
    Code: 'PN',
    Name: i18n.t('countries.pordenone')
  },
  {
    Code: 'PO',
    Name: i18n.t('countries.prato')
  },
  {
    Code: 'PR',
    Name: i18n.t('countries.parma')
  },
  {
    Code: 'PT',
    Name: i18n.t('countries.pistoia')
  },
  {
    Code: 'PU',
    Name: i18n.t('countries.pesaroUrbino')
  },
  {
    Code: 'PV',
    Name: i18n.t('countries.pavia')
  },
  {
    Code: 'PZ',
    Name: i18n.t('countries.potenza')
  },
  {
    Code: 'RA',
    Name: i18n.t('countries.ravenna')
  },
  {
    Code: 'RC',
    Name: i18n.t('countries.reggioCalabria')
  },
  {
    Code: 'RE',
    Name: i18n.t('countries.reggioEmilia')
  },
  {
    Code: 'RG',
    Name: i18n.t('countries.ragusa')
  },
  {
    Code: 'RI',
    Name: i18n.t('countries.rieti')
  },
  {
    Code: 'RN',
    Name: i18n.t('countries.rimini')
  },
  {
    Code: 'RM',
    Name: i18n.t('countries.roma')
  },
  {
    Code: 'RO',
    Name: i18n.t('countries.rovigo')
  },
  {
    Code: 'SP',
    Name: i18n.t('countries.laSpezia')
  },
  {
    Code: 'SS',
    Name: i18n.t('countries.sassari')
  },
  {
    Code: 'SA',
    Name: i18n.t('countries.salerno')
  },
  {
    Code: 'SV',
    Name: i18n.t('countries.savona')
  },
  {
    Code: 'SI',
    Name: i18n.t('countries.siena')
  },
  {
    Code: 'SR',
    Name: i18n.t('countries.siracusa')
  },
  {
    Code: 'SO',
    Name: i18n.t('countries.sondrio')
  },
  {
    Code: 'SU',
    Name: i18n.t('countries.sudSardegna')
  },
  {
    Code: 'TA',
    Name: i18n.t('countries.taranto')
  },
  {
    Code: 'TE',
    Name: i18n.t('countries.teramo')
  },
  {
    Code: 'TR',
    Name: i18n.t('countries.terni')
  },
  {
    Code: 'TO',
    Name: i18n.t('countries.torino')
  },
  {
    Code: 'TP',
    Name: i18n.t('countries.trapani')
  },
  {
    Cod: 'TN',
    Name: i18n.t('countries.trento')
  },
  {
    Cod: 'TV',
    Name: i18n.t('countries.treviso')
  },
  {
    Cod: 'TS',
    Name: i18n.t('countries.trieste')
  },
  {
    Cod: 'UD',
    Name: i18n.t('countries.udine')
  },
  {
    Cod: 'VA',
    Name: i18n.t('countries.varese')
  },
  {
    Cod: 'VE',
    Name: i18n.t('countries.venezia')
  },
  {
    Cod: 'VB',
    Name: i18n.t('countries.verbanoCusioOssola')
  },
  {
    Code: 'VC',
    Name: i18n.t('countries.vercelli')
  },
  {
    Code: 'VB',
    Name: i18n.t('countries.verbania')
  },
  {
    Code: 'VR',
    Name: i18n.t('countries.verona')
  },
  {
    Code: 'VI',
    Name: i18n.t('countries.vicenza')
  },
  {
    Code: 'VS',
    Name: i18n.t('countries.medioCampidano')
  },
  {
    Code: 'VT',
    Name: i18n.t('countries.viterbo')
  },
  {
    Code: 'VV',
    Name: i18n.t('countries.viboValentia')
  }
];

const occupations = [
  {
    value: 'Administrative/Executive',
    label: i18n.t('account.occupationRoleAdministrativeExecutive')
  },
  {
    value: 'Agricultural',
    label: i18n.t('account.occupationRoleAgricultural')
  },
  {
    value: 'Armed forces',
    label: i18n.t('account.occupationRoleArmedForces')
  },
  {
    value: 'Art worker',
    label: i18n.t('account.occupationRoleArtWorker')
  },
  {
    value: 'Banking industry',
    label: i18n.t('account.occupationRoleBankingIndustry')
  },
  {
    value: 'Barber',
    label: i18n.t('account.occupationRoleBarber')
  },
  {
    value: 'Butcher',
    label: i18n.t('account.occupationRoleButcher')
  },
  {
    value: 'Clerical',
    label: i18n.t('account.occupationRoleClerical')
  },
  {
    value: 'Coach',
    label: i18n.t('account.occupationRoleCoach')
  },
  {
    value: 'Construction',
    label: i18n.t('account.occupationRoleConstruction')
  },
  {
    value: 'Cook',
    label: i18n.t('account.occupationRoleCook')
  },
  {
    value: 'Doctor',
    label: i18n.t('account.occupationRoleDoctor')
  },
  {
    value: 'Dentist',
    label: i18n.t('account.occupationRoleDentist')
  },
  {
    value: 'Economist',
    label: i18n.t('account.occupationRoleEconomist')
  },
  {
    value: 'Teacher',
    label: i18n.t('account.occupationRoleTeacher')
  },
  {
    value: 'Engineer',
    label: i18n.t('account.occupationRoleEngineer')
  },
  {
    value: 'Financial Services',
    label: i18n.t('account.occupationRoleFinancialServices')
  },
  {
    value: 'Gambling industry',
    label: i18n.t('account.occupationRoleGamblingIndustry')
  },
  {
    value: 'IT technology',
    label: i18n.t('account.occupationRoleITTechnology')
  },
  {
    value: 'Legal Services',
    label: i18n.t('account.occupationRoleLegalServices')
  },
  {
    value: 'Mining',
    label: i18n.t('account.occupationRoleMining')
  },
  {
    value: 'Nurse',
    label: i18n.t('account.occupationRoleNurse')
  },
  {
    value: 'Police',
    label: i18n.t('account.occupationRolePolice')
  },
  {
    value: 'Politician',
    label: i18n.t('account.occupationRolePolitician')
  },
  {
    value: 'Professional/Senior administrative',
    label: i18n.t('account.occupationRoleProfessionalSeniorAdministrative')
  },
  {
    value: 'Public Services',
    label: i18n.t('account.occupationRolePublicServices')
  },
  {
    value: 'Retired',
    label: i18n.t('account.occupationRoleRetired')
  },
  {
    value: 'Self-employed',
    label: i18n.t('account.occupationRoleSelfEmployed')
  },
  {
    value: 'Self-employed professional',
    label: i18n.t('account.occupationRoleSelfEmployedProfessional')
  },
  {
    value: 'Shipping Services',
    label: i18n.t('account.occupationRoleShippingServices')
  },
  {
    value: 'Skilled Manual',
    label: i18n.t('account.occupationRoleSkilledManual')
  },
  {
    value: 'Student',
    label: i18n.t('account.occupationRoleStudent')
  },
  {
    value: 'Transport Services',
    label: i18n.t('account.occupationRoleTransportServices')
  },
  {
    value: 'Unemployed',
    label: i18n.t('account.occupationRoleUnemployed')
  },
  {
    value: 'Unskilled manual',
    label: i18n.t('account.occupationRoleUnskilledManual')
  },
  {
    value: 'Veterinarian',
    label: i18n.t('account.occupationRoleVeterinarian')
  }
];

export const incomeSourceForCanada = [
  {
    key: 12,
    value: 'Student',
    label: i18n.t('account.occupationRoleStudent')
  },
  {
    key: 13,
    value: 'Retired',
    label: i18n.t('account.occupationRoleRetired')
  },
  {
    key: 14,
    value: 'Homemaker',
    label: i18n.t('account.occupationRoleHomemaker')
  },
  {
    key: 15,
    value: 'Unemployed',
    label: i18n.t('account.occupationRoleUnemployed')
  },
  {
    key: 1,
    value: 'Employed or Self-Employed',
    label: i18n.t('account.occupationRoleEmployedSelfEmployed')
  }
];

export const industryOptions = [
  {
    label: i18n.t('account.artsCultureEntertainmentAndMedia'),
    key: 'artsCultureEntertainmentAndMedia',
    value: 'Arts, Culture, Entertainment & Media'
  },
  {
    label: i18n.t('account.travelRecreationLeisureAndSports'),
    key: 'travelRecreationLeisureAndSports',
    value: 'Travel, Recreation, Leisure, & Sports'
  },
  {
    label: i18n.t('account.foodHospitalityAndEvents'),
    key: 'foodHospitalityAndEvents',
    value: 'Food, Hospitality & Events'
  },
  {
    label: i18n.t('account.healthcareSciencesAndMedicine'),
    key: 'healthcareSciencesAndMedicine',
    value: 'Healthcare, Sciences & Medicine'
  },
  {
    label: i18n.t('account.transportLogisticsWarehousingAndDistribution'),
    key: 'transportLogisticsWarehousingAndDistribution',
    value: 'Transport, Logistics, Warehousing & Distribution'
  },
  {
    label: i18n.t('account.businessFinanceAndAdministration'),
    key: 'businessFinanceAndAdministration',
    value: 'Business, Finance & Administration'
  },
  {
    label: i18n.t('account.salesRetailAndServices'),
    key: 'salesRetailAndServices',
    value: 'Sales, Retail & Services'
  },
  {
    label: i18n.t('account.educationCommunityGovernmentAndLegalServices'),
    key: 'educationCommunityGovernmentAndLegalServices',
    value: 'Education, Community, Government & Legal Services'
  },
  {
    label: i18n.t('account.constructionTradesMaintenanceAndRepair'),
    key: 'constructionTradesMaintenanceAndRepair',
    value: 'Construction, Trades, Maintenance & Repair'
  },
  {
    label: i18n.t('account.manufacturing'),
    key: 'manufacturing',
    value: 'Manufacturing'
  },
  {
    label: i18n.t('account.informationTechnology'),
    key: 'informationTechnology',
    value: 'Information Technology'
  },
  {
    label: i18n.t('account.energyEnvironmentAgricultureAndAnimal'),
    key: 'energyEnvironmentAgricultureAndAnimal',
    value: 'Energy, Environment, Agriculture & Animal'
  }
];

export const occupationsByIndustry: {
  [k: string]: { label: string; value: string }[];
} = {
  artsCultureEntertainmentAndMedia: [
    { label: 'actorOrComedian', value: 'Actor or Comedian' },
    { label: 'animator', value: 'Animator' },
    {
      label: 'announcerOrBroadcaster',
      value: 'Announcer or broadcaster'
    },
    { label: 'technicianOrSimilar', value: 'Technician or similar' },
    { label: 'authorOrWriter', value: 'Author or writer' },
    {
      label: 'conductorComposerOrArranger',
      value: 'Conductor, composer, or arranger'
    },
    { label: 'conservatorOrCurator', value: 'Conservator or curator' },
    { label: 'creativeDesigner', value: 'Creative designer' },
    { label: 'dancer', value: 'Dancer' },
    {
      label: 'digitalContentOrSocialMedia',
      value: 'Digital content or social media'
    },
    { label: 'digitalMarketing', value: 'Digital marketing' },
    { label: 'editor', value: 'Editor' },
    {
      label: 'fashionOrCostumeDesign',
      value: 'Fashion or costume design'
    },
    {
      label: 'filmOrVideoCameraOpertator',
      value: 'Film or video camera opertator'
    },
    {
      label: 'graphicDesignOrIllustrator',
      value: 'Graphic design or illustrator'
    },
    { label: 'instructor', value: 'Instructor' },
    { label: 'journalist', value: 'Journalist' },
    { label: 'makeupArtist', value: 'Make-up artist' },
    { label: 'model', value: 'Model' },
    { label: 'musicianOrSinger', value: 'Musician or singer' },
    {
      label: 'otherPerformerOrArtsEmployee',
      value: 'Other performer or arts employee'
    },
    {
      label: 'otherCultureAndEntertainmentEmployee',
      value: 'Other culture and entertainment employee'
    },
    { label: 'otherMediaEmployee', value: 'Other media employee' },
    {
      label: 'painterSculptorOrOtherVisualArtists',
      value: 'Painter, sculptor or other visual artists'
    },
    {
      label: 'photographerOrVideographer',
      value: 'Photographer or videographer'
    },
    { label: 'presenterOrHost', value: 'Presenter or host' },
    {
      label: 'producerDirectorChoreographerOrSimilar',
      value: 'Producer, director, choreographer or similar'
    },
    { label: 'tatooArtistOrSimilar', value: 'Tatoo artist or similar' },
    {
      label: 'translatorOrInterpreter',
      value: 'Translator or interpreter'
    }
  ],
  travelRecreationLeisureAndSports: [
    { label: 'airportWorker', value: 'Airport worker' },
    {
      label: 'amusementRecreationOrSportEmployee',
      value: 'Amusement, recreation or sport employee'
    },
    { label: 'athlete', value: 'Athlete' },
    { label: 'casinoEmployee', value: 'Casino employee' },
    { label: 'sportsCoach', value: 'Sports coach' },
    { label: 'flightCrew', value: 'Flight crew' },
    { label: 'instructor', value: 'Instructor' },
    { label: 'lifeguard', value: 'Lifeguard' },
    { label: 'personalTrainer', value: 'Personal trainer' },
    { label: 'programLeader', value: 'Program leader' },
    {
      label: 'otherRecreationSportsOrFitnessEmployee',
      value: 'Other recreation, sports or fitness employee'
    },
    {
      label: 'sportsOfficialOrReferee',
      value: 'Sports official or referee'
    },
    { label: 'sportsPsychologist', value: 'Sports psychologist' },
    { label: 'ticketingAgent', value: 'Ticketing Agent' },
    { label: 'tourOrTravelGuide', value: 'Tour or travel guide' },
    {
      label: 'travelAgentOrCounsellor',
      value: 'Travel agent or counsellor'
    },
    {
      label: 'otherTravelTourismOrRelatedEmployee',
      value: 'Other travel, tourism or related employee'
    },
    { label: 'pilot', value: 'Pilot' }
  ],
  foodHospitalityAndEvents: [
    {
      label: 'accommodationServiceEmployee',
      value: 'Accommodation service employee'
    },
    { label: 'baker', value: 'Baker' },
    { label: 'bartender', value: 'Bartender' },
    {
      label: 'butcherMeatCutterOrFishmonger',
      value: 'Butcher, meat cutter or fishmonger'
    },
    { label: 'chef', value: 'Chef' },
    {
      label: 'housekeepingOrOtherDomesticServicesEmployee',
      value: 'Housekeeping or other domestic services employee'
    },
    {
      label: 'conferenceOrEventPlanner',
      value: 'Conference or event planner'
    },
    {
      label: 'otherCateringOrFoodServiceEmployee',
      value: 'Other catering or food service employee'
    },
    {
      label: 'otherHospitalityOrEventsEmployee',
      value: 'Other hospitality or events employee'
    },
    { label: 'restaurantOwner', value: 'Restaurant owner' },
    {
      label: 'securityOrRelatedServices',
      value: 'Security or related services'
    }
  ],
  healthcareSciencesAndMedicine: [
    { label: 'acupuncturist', value: 'Acupuncturist' },
    {
      label: 'alliedPrimaryHealthPractitioner',
      value: 'Allied primary health practitioner'
    },
    { label: 'archeologist', value: 'Archeologist' },
    {
      label: 'audiologistOrSpeechTherapist',
      value: 'Audiologist or speech therapist'
    },
    {
      label: 'biologistOrRelatedScientist',
      value: 'Biologist or related scientist'
    },
    { label: 'cardiologyTechnologist', value: 'Cardiology technologist' },
    { label: 'chemicalEngineer', value: 'Chemical engineer' },
    {
      label: 'chemicalTechnologistOrTechnician',
      value: 'Chemical technologist or technician'
    },
    { label: 'chemist', value: 'Chemist' },
    { label: 'chiropractor', value: 'Chiropractor' },
    { label: 'coroner', value: 'Coroner' },
    { label: 'dentalHygienist', value: 'Dental hygienist' },
    { label: 'dentist', value: 'Dentist' },
    {
      label: 'dietitianOrNutritionist',
      value: 'Dietitian or nutritionist'
    },
    {
      label: 'generalPractitionerOrFamilyPhysician',
      value: 'General practitioner or family physician'
    },
    { label: 'healthConsultant', value: 'Health consultant' },
    {
      label: 'homeSupportAssistantOrRelatedOccupation',
      value: 'Home support assistant or related occupation'
    },
    { label: 'consultant', value: 'Consultant' },
    { label: 'messageTherapist', value: 'Message therapist' },
    {
      label: 'meteorologistAndClimatologist',
      value: 'Meteorologist and climatologist'
    },
    { label: 'midwife', value: 'Midwife' },
    { label: 'mortician', value: 'Mortician' },
    {
      label: 'policyResearcherConsultantOrProgramOfficer',
      value: 'Policy researcher, consultant or program officer'
    },
    { label: 'nurse', value: 'Nurse' },
    { label: 'occupationalTherapist', value: 'Occupational therapist' },
    { label: 'optician', value: 'Optician' },
    { label: 'optometrist', value: 'Optometrist' },
    {
      label: 'otherOccupationInHealthServices',
      value: 'Other occupation in health services'
    },
    {
      label: 'otherOccupationInSciences',
      value: 'Other occupation in sciences'
    },
    { label: 'paramedic', value: 'Paramedic' },
    { label: 'pharmacist', value: 'Pharmacist' },
    { label: 'physicistOrAstronomer', value: 'Physicist or astronomer' },
    { label: 'physiotherapist', value: 'Physiotherapist' },
    { label: 'podiatrist', value: 'Podiatrist' },
    { label: 'psychologist', value: 'Psychologist' },
    { label: 'radiologist', value: 'Radiologist' },
    { label: 'surgeon', value: 'Surgeon' },
    { label: 'technicianOrSimilar', value: 'Technician or similar' }
  ],
  transportLogisticsWarehousingAndDistribution: [
    {
      label: 'airTrafficControllerOrRelatedOccupation',
      value: 'Air traffic controller or related occupation'
    },
    {
      label: 'aircraftMechanicAircraftInspector',
      value: 'Aircraft mechanic aircraft inspector'
    },
    {
      label: 'busDriverSubwayOperatorOrOtherTransportOperator',
      value: 'Bus driver, subway operator or other transport operator'
    },
    {
      label: 'customsShipOrOtherBroker',
      value: 'Customs, ship or other broker'
    },
    {
      label: 'deliveryOrCourierServiceDriver',
      value: 'Delivery or courier service driver'
    },
    {
      label: 'mineralOrMetalProcessingEmployee',
      value: 'Mineral or metal processing employee'
    },
    {
      label: 'patroleumGasOrChemicalProcessingEmployee',
      value: 'Patroleum, gas or chemical processing employee'
    },
    {
      label: 'postalOrCourierServiceEmployee',
      value: 'Postal or courier service employee'
    },
    {
      label: 'productionLogisticsCoordinator',
      value: 'Production logistics coordinator'
    },
    {
      label: 'railwayTransportEmployee',
      value: 'Railway transport employee'
    },
    {
      label: 'shippingAndReceivingEmployee',
      value: 'Shipping and receiving employee'
    },
    {
      label: 'supplyChainTrackingOrSchedulingEmployee',
      value: 'Supply chain, tracking or scheduling employee'
    },
    {
      label: 'supportOccupationInPublicTransport',
      value: 'Support occupation in public transport'
    },
    {
      label: 'taxiDriverOrChauffeurs',
      value: 'Taxi driver or chauffeurs'
    },
    { label: 'transportPlanner', value: 'Transport planner' },
    {
      label: 'transportationRouteOrCrewScheduler',
      value: 'Transportation route or crew scheduler'
    },
    { label: 'truckDriver', value: 'Truck driver' },
    { label: 'warehouseEmployee', value: 'Warehouse employee' },
    {
      label: 'waterTransportEmployee',
      value: 'Water transport employee'
    }
  ],
  businessFinanceAndAdministration: [
    { label: 'accountantOrSimilar', value: 'Accountant or similar' },
    { label: 'actuary', value: 'Actuary' },
    { label: 'administrativeEmployee', value: 'Administrative employee' },
    {
      label: 'advertisingMarketingOrPublicRelationsEmployee',
      value: 'Advertising, marketing or public relations employee'
    },
    { label: 'auditor', value: 'Auditor' },
    {
      label: 'bankingCreditOrOtherInvestmentEmployee',
      value: 'Banking, credit or other investment employee'
    },
    {
      label: 'businessAdvisorOrConsultant',
      value: 'Business advisor or consultant'
    },
    { label: 'collector', value: 'Collector' },
    { label: 'communicationsEmployee', value: 'Communications employee' },
    {
      label: 'complianceOfficerOrSimilar',
      value: 'Compliance officer or similar'
    },
    {
      label: 'correspondencePublicationOrRegulatoryClerk',
      value: 'Correspondence, publication or regulatory clerk'
    },
    { label: 'economist', value: 'Economist' },
    {
      label: 'policyResearcherConsultantOrProgramOfficer',
      value: 'Policy researcher, consultant or program officer'
    },
    { label: 'employmentCounsellor', value: 'Employment counsellor' },
    {
      label: 'financialServicesEmployee',
      value: 'Financial services employee'
    },
    { label: 'foreignExchange', value: 'Foreign exchange' },
    {
      label: 'graphicDesignerOrSimilar',
      value: 'Graphic designer or similar'
    },
    {
      label: 'healthPolicyResearcherConsultantOrProgramOfficer',
      value: 'Health policy researcher, consultant or program officer'
    },
    {
      label: 'humanResourcesOrRecruitmentEmployee',
      value: 'Human resources or recruitment employee'
    },
    {
      label: 'insuranceAgentOrBroker',
      value: 'Insurance agent or broker'
    },
    { label: 'insuranceUnderwriter', value: 'Insurance underwriter' },
    {
      label: 'insuranceRealEstateOrFinancialBrokerageEmployee',
      value: 'Insurance, real estate or financial brokerage employee'
    },
    { label: 'investor', value: 'Investor' },
    {
      label: 'mathematicianOrStatistician',
      value: 'Mathematician or statistician'
    },
    { label: 'moneyTransmitter', value: 'Money transmitter' },
    { label: 'mortgageBroker', value: 'Mortgage broker' },
    { label: 'officeWorker', value: 'Office worker' },
    { label: 'businessAnalyst', value: 'Business analyst' },
    { label: 'payrollAdministrator', value: 'Payroll administrator' },
    { label: 'personnelClerk', value: 'Personnel clerk' },
    {
      label: 'privatelyOwnedAutomatedTellerMachine',
      value: 'Privately owned automated teller machine'
    },
    { label: 'projectManager', value: 'Project manager' },
    { label: 'receptionist', value: 'Receptionist' },
    {
      label: 'securitiesAgentInvestmentDealerOrBroker',
      value: 'Securities agent, investment dealer or broker'
    },
    {
      label: 'surveyInterviewerOrStatisticalClerk',
      value: 'Survey interviewer or statistical clerk'
    },
    { label: 'underwriter', value: 'Underwriter' },
    {
      label: 'otherBusinessFinanceAndAdministrationEmployee',
      value: 'Other business, finance & administration employee'
    }
  ],
  salesRetailAndServices: [
    { label: 'antiqueDealer', value: 'Antique dealer' },
    {
      label: 'assessorValuatorOrAppraiser',
      value: 'Assessor, valuator or appraiser'
    },
    { label: 'auctioneer', value: 'Auctioneer' },
    { label: 'automotiveDealer', value: 'Automotive dealer' },
    { label: 'beautician', value: 'Beautician' },
    { label: 'makeupArtist', value: 'Make-up artist' },
    {
      label: 'butcherMeatCutterOrFishmonger',
      value: 'Butcher, meat cutter or fishmonger'
    },
    { label: 'cannabisStoreOwner', value: 'Cannabis store owner' },
    { label: 'cashier', value: 'Cashier' },
    {
      label: 'cleaningServicesEmployee',
      value: 'Cleaning services employee'
    },
    { label: 'convenienceStoreOwner', value: 'Convenience store owner' },
    {
      label: 'corporateSalesRepresentative',
      value: 'Corporate sales representative'
    },
    {
      label: 'customerOrInformationServiceEmployee',
      value: 'Customer or information service employee'
    },
    {
      label: 'dryCleaningAndLaundryServices',
      value: 'Dry cleaning and laundry services'
    },
    {
      label: 'estheticianElectrologistOrRelatedOccupation',
      value: 'Esthetician, electrologist or related occupation'
    },
    {
      label: 'financialSalesRepresentative',
      value: 'Financial sales representative'
    },
    { label: 'funeralDirector', value: 'Funeral director' },
    { label: 'hairstylistOrBarber', value: 'Hairstylist or barber' },
    { label: 'homeChildCareProvider', value: 'Home child care provider' },
    { label: 'housekeeper', value: 'Housekeeper' },
    {
      label: 'interiorDesignerOrInteriorDecorator',
      value: 'Interior designer or interior decorator'
    },
    {
      label: 'janitorCaretakerOrBuildingSuperintendent',
      value: 'Janitor, caretaker or building superintendent'
    },
    {
      label: 'otherSalesRelatedOccupation',
      value: 'Other sales related occupation'
    },
    { label: 'patternmaker', value: 'Patternmaker' },
    {
      label: 'privatelyOwnedAutomatedTellerMachine',
      value: 'Privately owned automated teller machine'
    },
    { label: 'propertyAdministrator', value: 'Property administrator' },
    {
      label: 'purchasingOrInventoryEmployee',
      value: 'Purchasing or inventory employee'
    },
    { label: 'realEstateAgent', value: 'Real estate agent' },
    { label: 'realEstateBroker', value: 'Real estate broker' },
    {
      label: 'retailAndWholesaleBuyer',
      value: 'Retail and wholesale buyer'
    },
    {
      label: 'retailSalesRepresentative',
      value: 'Retail sales representative'
    },
    { label: 'retailStoreOwner', value: 'Retail store owner' },
    { label: 'salesperson', value: 'Salesperson' },
    { label: 'storeEmployee', value: 'Store employee' },
    {
      label: 'technicalSalesSpecialist',
      value: 'Technical sales specialist'
    },
    { label: 'tobaccoDistributor', value: 'Tobacco distributor' },
    {
      label: 'translatorTerminologistOrInterpreter',
      value: 'Translator, terminologist or interpreter'
    },
    {
      label: 'vendingMachineOperator',
      value: 'Vending machine operator'
    }
  ],
  educationCommunityGovernmentAndLegalServices: [
    {
      label: 'bylawEnforcementOrOtherRegulatoryOfficer',
      value: 'By-law enforcement or other regulatory officer'
    },
    { label: 'coach', value: 'Coach' },
    { label: 'collegeInstructor', value: 'College instructor' },
    {
      label: 'commissionedOfficerOfTheCanadianArmedForces',
      value: 'Commissioned officer of the Canadian Armed Forces'
    },
    { label: 'policeOfficer', value: 'Police officer' },
    {
      label: 'correctionalServiceOfficer',
      value: 'Correctional service officer'
    },
    { label: 'courtEmployee', value: 'Court employee' },
    { label: 'counsellor', value: 'Counsellor' },
    { label: 'customsOfficer', value: 'Customs officer' },
    {
      label: 'earlyChildhoodEducator',
      value: 'Early childhood educator'
    },
    {
      label: 'socialAndCommunityServicesWorker',
      value: 'Social and community services worker'
    },
    { label: 'firefighter', value: 'Firefighter' },
    { label: 'governmentOfficial', value: 'Government official' },
    {
      label: 'healthAndSafetyInspector',
      value: 'Health and safety inspector'
    },
    { label: 'historian', value: 'Historian' },
    {
      label: 'immigrationBorderServicesOrRevenueOfficer',
      value: 'Immigration, border services or revenue officer'
    },
    { label: 'judge', value: 'Judge' },
    { label: 'lawyer', value: 'Lawyer' },
    {
      label: 'legalAdministrativeAssistant',
      value: 'Legal administrative assistant'
    },
    { label: 'legalRepresentative', value: 'Legal representative' },
    { label: 'legislator', value: 'Legislator' },
    {
      label: 'libraryArchiveMuseumOrArtGalleryEmployee',
      value: 'Library, archive, museum or art gallery employee'
    },
    { label: 'memberOfParliament', value: 'Member of parliament' },
    {
      label: 'noncommissionedRanksOfTheCanadianArmedForces',
      value: 'Non-commissioned ranks of the Canadian Armed Forces'
    },
    { label: 'notary', value: 'Notary' },
    { label: 'paralegal', value: 'Paralegal' },
    { label: 'paramedicalOccupations', value: 'Paramedical occupations' },
    {
      label: 'policyResearcherConsultantOrProgramOfficer',
      value: 'Policy researcher, consultant or program officer'
    },
    { label: 'postsecondaryTeacher', value: 'Post-secondary teacher' },
    {
      label: 'probationparoleOfficer',
      value: 'Probation/parole officer'
    },
    {
      label: 'recordsManagementTechnician',
      value: 'Records management technician'
    },
    { label: 'registrar', value: 'Registrar' },
    { label: 'religiousOccupation', value: 'Religious occupation' },
    {
      label: 'schoolPrincipalOrAdministrator',
      value: 'School principal or administrator'
    },
    {
      label: 'schoolTeacherOrAssistant',
      value: 'School teacher or assistant'
    },
    { label: 'sheriffOrBailiff', value: 'Sheriff or bailiff' },
    {
      label: 'statisticalOfficerOrRelatedResearchSupportOccupation',
      value: 'Statistical officer or related research support occupation'
    },
    {
      label: 'universityProfessorOrLecturer',
      value: 'University professor or lecturer'
    }
  ],
  constructionTradesMaintenanceAndRepair: [
    { label: 'aerospaceEngineer', value: 'Aerospace engineer' },
    {
      label: 'aircraftMechanicTechnicianOrInspector',
      value: 'Aircraft mechanic, technician or inspector'
    },
    { label: 'architect', value: 'Architect' },
    { label: 'blacksmith', value: 'Blacksmith' },
    { label: 'maintenanceTechnician', value: 'Maintenance technician' },
    { label: 'carpenter', value: 'Carpenter' },
    { label: 'constructionWorker', value: 'Construction worker' },
    {
      label: 'draftingTechnologistOrTechnician',
      value: 'Drafting technologist or technician'
    },
    { label: 'drillerOrBlaster', value: 'Driller or blaster' },
    {
      label: 'electricianOrRelatedOccupation',
      value: 'Electrician or related occupation'
    },
    { label: 'engineeringEmployee', value: 'Engineering employee' },
    {
      label: 'facilityOperationOrMaintenanceWorker',
      value: 'Facility operation or maintenance worker'
    },
    {
      label: 'floorCoveringInstaller',
      value: 'Floor covering installer'
    },
    { label: 'gasFitter', value: 'Gas fitter' },
    { label: 'glazier', value: 'Glazier' },
    {
      label: 'heavyEquipmentOperator',
      value: 'Heavy equipment operator'
    },
    { label: 'industrialDesigner', value: 'Industrial designer' },
    {
      label: 'industrialOrManufacturingEngineerOrSimilar',
      value: 'Industrial or manufacturing engineer or similar'
    },
    {
      label: 'jewelleryAndWatchRepairer',
      value: 'Jewellery and watch repairer'
    },
    { label: 'landSurveyor', value: 'Land surveyor' },
    {
      label: 'landscapingAndGroundsMaintenanceOrRelatedOccupation',
      value: 'Landscaping and grounds maintenance or related occupation'
    },
    { label: 'locksmith', value: 'Locksmith' },
    { label: 'machineFitter', value: 'Machine fitter' },
    { label: 'machinist', value: 'Machinist' },
    { label: 'mechanicalEngineer', value: 'Mechanical engineer' },
    {
      label: 'metalFormingShapingErectingTradesAndRelatedOccupations',
      value: 'Metal forming, shaping, erecting trades and related occupations'
    },
    { label: 'miningEmployee', value: 'Mining employee' },
    {
      label: 'oilAndGasDrillingServicingTesterOrRelatedWorker',
      value: 'Oil and gas drilling, servicing, tester or related worker'
    },
    {
      label: 'otherProfessionalEngineer',
      value: 'Other professional engineer'
    },
    {
      label: 'otherRepairerOrServicer',
      value: 'Other repairer or servicer'
    },
    { label: 'painterOrDecorator', value: 'Painter or decorator' },
    { label: 'plasterer', value: 'Plasterer' },
    { label: 'plumber', value: 'Plumber' },
    { label: 'projectManager', value: 'Project manager' },
    {
      label: 'publicWorksEquipmentOperatorOrRelatedWorker',
      value: 'Public works equipment operator or related worker'
    },
    { label: 'quarryWorker', value: 'Quarry worker' },
    {
      label: 'railwayYardOrTrackWorker',
      value: 'Railway yard or track worker'
    },
    {
      label: 'residentialOrCommercialInstallerOrServicer',
      value: 'Residential or commercial installer or servicer'
    },
    {
      label: 'telecommunicationsWorker',
      value: 'Telecommunications worker'
    },
    {
      label: 'urbanAndLandUserPlanner',
      value: 'Urban and land user planner'
    },
    {
      label: 'vehicleRepairMaintenanceOrServicingEmployee',
      value: 'Vehicle repair, maintenance or servicing employee'
    },
    {
      label: 'waterworksOrGasMaintenanceWorker',
      value: 'Waterworks or gas maintenance worker'
    }
  ],
  manufacturing: [
    { label: 'artisanOrCraftsperson', value: 'Artisan or craftsperson' },
    {
      label: 'assemblerFabricatorOrInspector',
      value: 'Assembler, fabricator or inspector'
    },
    {
      label: 'concreteClayOrStoneFormingOperator',
      value: 'Concrete, clay or stone forming operator'
    },
    {
      label: 'desktopPublishingOperatorOrRelatedOccupation',
      value: 'Desktop publishing operator or related occupation'
    },
    {
      label: 'fabricFurOrLeatherCutter',
      value: 'Fabric, fur or leather cutter'
    },
    {
      label: 'fishAndSeafoodPlantWorker',
      value: 'Fish and seafood plant worker'
    },
    {
      label: 'foodProcessingEmployee',
      value: 'Food processing employee'
    },
    {
      label: 'furnitureFinisherOrRefinisher',
      value: 'Furniture finisher or refinisher'
    },
    { label: 'helperOrLabourer', value: 'Helper or labourer' },
    {
      label: 'industrialButcherMeatCutterPoultryPreparerOrRelatedWorker',
      value:
        'Industrial butcher, meat cutter, poultry preparer or related worker'
    },
    {
      label: 'industrialPainterCoaterOrMetalFinishingOperator',
      value: 'Industrial painter, coater or metal finishing operator'
    },
    { label: 'industrialMachinist', value: 'Industrial machinist' },
    {
      label: 'otherManufacturingEmployee',
      value: 'Other manufacturing employee'
    },
    { label: 'materialHandler', value: 'Material handler' },
    { label: 'materialEngineer', value: 'Material engineer' },
    {
      label: 'mineralOrMetalProcessingOperator',
      value: 'Mineral or metal processing operator'
    },
    { label: 'packer', value: 'Packer' },
    {
      label: 'patroleumGasOrChemicalProcessingOperator',
      value: 'Patroleum, gas or chemical processing operator'
    },
    {
      label: 'photographicOrFilmProcessor',
      value: 'Photographic or film processor'
    },
    {
      label: 'otherProcessingEmployee',
      value: 'Other processing employee'
    },
    {
      label: 'pulpingPapermakingAndCoatingControlOperator',
      value: 'Pulping, papermaking and coating control operator'
    },
    { label: 'sheetMetalWorker', value: 'Sheet metal worker' },
    { label: 'shoemakerOrRepairer', value: 'Shoemaker or repairer' },
    {
      label: 'structuralMetalAndPlateworkFabricatorOrFitter',
      value: 'Structural metal and platework fabricator or fitter'
    },
    { label: 'tailorOrDressmaker', value: 'Tailor or dressmaker' },
    {
      label: 'testerOrGraderFoodAndBeverageProcessor',
      value: 'Tester or grader, food and beverage processor'
    },
    {
      label: 'textileProcessingWorker',
      value: 'Textile processing worker'
    },
    { label: 'toolOrDieMaker', value: 'Tool or die maker' },
    { label: 'upholsterer', value: 'Upholsterer' },
    {
      label: 'waterAndWasteManagementPlantOperator',
      value: 'Water and waste management plant operator'
    },
    {
      label: 'weaverKnitterOrOtherFabricMakingOccupation',
      value: 'Weaver, knitter or other fabric making occupation'
    },
    { label: 'welder', value: 'Welder' }
  ],
  informationTechnology: [
    {
      label: 'computerAndInformationsSystemsManager',
      value: 'Computer and informations systems manager'
    },
    { label: 'hardwareEngineer', value: 'Hardware engineer' },
    { label: 'networkTechnician', value: 'Network technician' },
    {
      label: 'dataAnalystOrDataAdministrator',
      value: 'Data analyst or data administrator'
    },
    { label: 'dataCenterManager', value: 'Data center manager' },
    { label: 'dataEntryClerk', value: 'Data entry clerk' },
    {
      label: 'informationSystemAnalystOrConsultant',
      value: 'Information system analyst or consultant'
    },
    { label: 'testingTechnician', value: 'Testing technician' },
    { label: 'productManager', value: 'Product manager' },
    { label: 'serviceDeskTechnician', value: 'Service desk technician' },
    {
      label: 'softwareEngineerOrDesigner',
      value: 'Software engineer or designer'
    },
    { label: 'userSupportAgent', value: 'User support agent' },
    {
      label: 'webDesignerOrDeveloper',
      value: 'Web designer or developer'
    },
    {
      label: 'telecommunicationsWorker',
      value: 'Telecommunications worker'
    }
  ],
  energyEnvironmentAgricultureAndAnimal: [
    {
      label: 'agriculturalAndFishProductInspector',
      value: 'Agricultural and fish product inspector'
    },
    {
      label: 'agriculturalRepresentativeConsultantOrSpecialist',
      value: 'Agricultural representative, consultant, or specialist'
    },
    {
      label: 'agriculturalServiceContractorFarmSpecialistWorker',
      value: 'Agricultural service contractor, farm specialist worker'
    },
    {
      label: 'animalHealthTechnologistOrVeterinaryTechnician',
      value: 'Animal health technologist or veterinary technician'
    },
    { label: 'animalTrainer', value: 'Animal trainer' },
    {
      label: 'aquacultureOrMarineHarvestLabourer',
      value: 'Aquaculture or marine harvest labourer'
    },
    { label: 'breeder', value: 'Breeder' },
    {
      label: 'chainSawOrSkidderOperator',
      value: 'Chain saw or skidder operator'
    },
    {
      label: 'conservationOrFisheryOfficer',
      value: 'Conservation or fishery officer'
    },
    { label: 'fisherman/woman', value: 'Fisherman/woman' },
    { label: 'florist', value: 'Florist' },
    { label: 'forestryWorker', value: 'Forestry worker' },
    { label: 'farmWorker', value: 'Farm worker' },
    {
      label: 'geologicalAndMineralTechnologistOrTechnician',
      value: 'Geological and mineral technologist or technician'
    },
    { label: 'geologicalEngineer', value: 'Geological engineer' },
    {
      label: 'geoscientistOrOceanographer',
      value: 'Geoscientist or oceanographer'
    },
    { label: 'havestingLabourer', value: 'Havesting labourer' },
    {
      label: 'landSurveyTechnologistOrTechnician',
      value: 'Land survey technologist or technician'
    },
    { label: 'landSurveyor', value: 'Land surveyor' },
    {
      label: 'landscapeAndHorticultureTechnicianOrSpecialist',
      value: 'Landscape and horticulture technician or specialist'
    },
    { label: 'landscapeArchitect', value: 'Landscape architect' },
    {
      label: 'meteorologistAndClimatologist',
      value: 'Meteorologist and climatologist'
    },
    {
      label: 'nurseryOrGreenhouseWorker',
      value: 'Nursery or greenhouse worker'
    },
    {
      label: 'pestControlOrFumigator',
      value: 'Pest control or fumigator'
    },
    {
      label: 'petGroomerOrAnimalCareWorker',
      value: 'Pet groomer or animal care worker'
    },
    { label: 'petroleumEngineer', value: 'Petroleum engineer' },
    {
      label: 'powerEngineerOrPowerSystemsOperator',
      value: 'Power engineer or power systems operator'
    },
    { label: 'silvicultureWorker', value: 'Silviculture worker' },
    {
      label: 'employeeInArgriculture',
      value: 'Employee in argriculture'
    },
    { label: 'employeeInAquaculture', value: 'Employee in aquaculture' },
    {
      label: 'employeeInHorticulture',
      value: 'Employee in horticulture'
    },
    {
      label: 'employeeInNaturalResourceProductionOrFishing',
      value: 'Employee in natural resource production or fishing'
    },
    {
      label: 'techincalOccupationInGeomaticsAndMeteorology',
      value: 'Techincal occupation in geomatics and meteorology'
    },
    { label: 'trapperOrHunter', value: 'Trapper or hunter' },
    {
      label: 'urbanOrLandUsePlanner',
      value: 'Urban or land use planner'
    },
    { label: 'utilitiesEmployee', value: 'Utilities employee' },
    { label: 'veterinarian', value: 'Veterinarian' }
  ]
};

const _incomeSource = SpringConfigs.CANADIAN_ACCOUNT_TYPE
  ? incomeSourceForCanada
  : incomeSource;

export const selectFiledData: {
  [countries: string]: any;
  docType: typeof docType;
  incomeSource: typeof _incomeSource;
  industry: typeof industryOptions;
  salaryLevels: typeof salaryLevels;
  departments: typeof departments;
  cashdeskIdData: typeof cashdeskIdData;
  occupations: typeof occupations;
  canadaProvinces: ChildRegion[];
  italyProvinces: ChildRegion[];
} = {
  countries,
  docType,
  incomeSource: _incomeSource,
  industry: industryOptions,
  salaryLevels,
  departments,
  cashdeskIdData,
  occupations,
  canadaProvinces,
  italyProvinces
};

export const normalizeNameInput = (value: string): any =>
  value.trimLeft().replace(/\s{2,}/, ' ');

export const cryptoCurrency = { TUS: 'USDT' };

export const cryptoDecimal = {
  TUS: 3,
  BTC: 8,
  LTC: 5,
  ETH: 7,
  FTN: 3
};

export const ftnCurrency = 'FTN';
export const stftnCurrency = 'stFTN';
export const usdtCurrency = 'TUS';
export const USDT_CUR = 'USDT';
export const PostGridInternational = false;
