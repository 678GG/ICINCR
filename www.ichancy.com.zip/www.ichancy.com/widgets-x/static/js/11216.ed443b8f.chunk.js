"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [11216], {
        211216: (e, t, r) => {
            var u = r(50130);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "Col", {
                enumerable: !0,
                get: function() {
                    return o.default
                }
            }), Object.defineProperty(t, "Row", {
                enumerable: !0,
                get: function() {
                    return n.default
                }
            }), t.default = void 0;
            var n = u(r(890168)),
                o = u(r(596034)),
                a = u(r(885123));
            var f = {
                useBreakpoint: function() {
                    return (0, a.default)()
                }
            };
            t.default = f
        }
    }
]);
//# sourceMappingURL=11216.ed443b8f.chunk.js.map