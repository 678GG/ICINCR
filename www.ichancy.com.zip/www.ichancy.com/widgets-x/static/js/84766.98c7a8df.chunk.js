"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [84766], {
        584766: (e, t, l) => {
            l.r(t), l.d(t, {
                default: () => C
            });
            var n, r, a = l(365043);

            function i() {
                return i = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var l = arguments[t];
                        for (var n in l) Object.prototype.hasOwnProperty.call(l, n) && (e[n] = l[n])
                    }
                    return e
                }, i.apply(this, arguments)
            }

            function o(e, t) {
                let {
                    title: l,
                    titleId: o,
                    ...s
                } = e;
                return a.createElement("svg", i({
                    width: 32,
                    height: 32,
                    viewBox: "0 0 32 33",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    ref: t,
                    "aria-labelledby": o
                }, s), l ? a.createElement("title", {
                    id: o
                }, l) : null, n || (n = a.createElement("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M28.3192 31.1089V24.3115H28.3194V2.70388C28.3194 1.21214 27.0828 0.00292969 25.5575 0.00292969H5.76379C4.23846 0.00292969 3.00187 1.21223 3.00187 2.70388V31.1089C2.98963 31.2412 3.03782 31.372 3.13342 31.4663C3.31237 31.6429 3.60383 31.6441 3.78436 31.4691L6.8225 28.6781C7.01501 28.5429 7.2744 28.5429 7.46692 28.6781L11.1034 31.8743C11.2823 32.0458 11.5688 32.0458 11.7478 31.8743L15.3383 28.6781C15.5308 28.5429 15.7902 28.5429 15.9827 28.6781L19.5732 31.8743C19.7521 32.0458 20.0386 32.0458 20.2176 31.8743L23.8541 28.6781C24.0466 28.5429 24.306 28.5429 24.4985 28.6781L27.5367 31.4691C27.6331 31.5626 27.7669 31.6097 27.9021 31.5977C28.1554 31.5754 28.3421 31.3566 28.3192 31.1089ZM9.95265 9.14121H15.8447C16.3531 9.14121 16.7654 8.73815 16.7654 8.24093C16.7654 7.74365 16.3532 7.34058 15.8447 7.34058H9.95265C9.44418 7.34058 9.03201 7.74365 9.03201 8.24093C9.03201 8.73815 9.44418 9.14121 9.95265 9.14121ZM21.3686 14.9933H9.95266C9.44419 14.9933 9.03202 14.5902 9.03202 14.0929C9.03202 13.5957 9.44419 13.1927 9.95266 13.1927H21.3685C21.877 13.1927 22.2892 13.5957 22.2892 14.0929C22.2892 14.5902 21.877 14.9933 21.3686 14.9933ZM9.95266 20.8453H21.3686C21.877 20.8453 22.2892 20.4422 22.2892 19.945C22.2892 19.4478 21.877 19.0447 21.3685 19.0447H9.95266C9.44419 19.0447 9.03202 19.4478 9.03202 19.945C9.03202 20.4422 9.44419 20.8453 9.95266 20.8453Z",
                    fill: "url(#paint0_linear_226_1765)"
                })), r || (r = a.createElement("defs", null, a.createElement("linearGradient", {
                    id: "paint0_linear_226_1765",
                    x1: 15.6606,
                    y1: .00292969,
                    x2: 15.6606,
                    y2: 32.0029,
                    gradientUnits: "userSpaceOnUse"
                }, a.createElement("stop", {
                    stopColor: "#74ACFF"
                }), a.createElement("stop", {
                    offset: 1,
                    stopColor: "#A282FF"
                })))))
            }
            const s = a.forwardRef(o),
                C = (l.p, s)
        }
    }
]);
//# sourceMappingURL=84766.98c7a8df.chunk.js.map