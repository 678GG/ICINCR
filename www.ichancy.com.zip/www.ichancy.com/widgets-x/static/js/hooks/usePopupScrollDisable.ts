import { useEffect, useRef } from 'react';

export const usePopupScrollDisable = (
  condition = true,
  preventScrollDisable?: boolean
): void => {
  const scrollPositionRef = useRef<null | number>(null);
  useEffect(() => {
    if (preventScrollDisable) {
      return;
    }

    const timer = setTimeout(() => {
      if (condition && document.body.style.overflow !== 'hidden') {
        scrollPositionRef.current = window.scrollY;
        document.body.style.overflow = 'hidden';
        document.body.style.touchAction = 'none';
        document.documentElement.style.overflow = 'hidden';
        document.body.style.position = 'fixed';
      }
    }, 200);

    return () => {
      if (preventScrollDisable) {
        return;
      }

      clearTimeout(timer);
      document.body.style.removeProperty('position');
      document.body.style.removeProperty('touch-action');

      if (condition) {
        const setOverflowInterval = setInterval(() => {
          document.body.style.overflow = '';
          document.documentElement.style.overflow = '';
          clearInterval(setOverflowInterval);
        }, 100);

        scrollPositionRef.current &&
          window.scrollTo(0, scrollPositionRef.current);
      }
    };
  }, [condition]);
};
