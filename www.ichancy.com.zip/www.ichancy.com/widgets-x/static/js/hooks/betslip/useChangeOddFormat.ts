import { useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { updateOddFormat } from 'store/actions/bet-slip';
import { getLadderLoaded, getOddFormat } from 'store/selectors/bet-slip';

import { setOddsFormat } from 'utils/betslip/odds-format';
import { loadLadder } from 'utils/betslip/odd-formats-helper';

export const useChangeOddFormat = (): ((id: number, value: string) => void) => {
  const oddFormat = useSelector(getOddFormat);
  const ladderLoaded = useSelector(getLadderLoaded);
  const dispatch = useDispatch();

  const handle = useCallback(
    (id: number, value: string) => {
      if (value && oddFormat !== id) {
        if (value === 'fractional' && !ladderLoaded) {
          void loadLadder(id);
        } else {
          dispatch(updateOddFormat(id));
        }

        setOddsFormat(value);
      }
    },
    [oddFormat, ladderLoaded]
  );

  return handle;
};
