import SpringConnector from 'services/sockets/spring-connector';

export const connectingWS = SpringConnector();
