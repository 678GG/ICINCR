"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [74268, 22102, 25040, 99866, 2825, 97694, 55329, 87076, 80127, 35594], {
        83014: (e, t, a) => {
            a.r(t), a.d(t, {
                EmptyMatches: () => v
            });
            a(314099);
            var r = a(44777),
                s = a(365043),
                i = a(870905),
                o = a(507712),
                n = a(841591),
                l = a(995392),
                d = a(80489),
                _ = a(735905),
                m = a(55418),
                c = a(899384),
                p = a(179177),
                h = a(535594),
                u = a(570579);
            const v = e => {
                let {
                    isLive: t,
                    cover: a,
                    withLink: v,
                    isEvent: y,
                    calendar: g,
                    isESport: f
                } = e;
                const {
                    t: F
                } = (0, i.B)(), k = (0, l.W6)(), P = (0, o.d4)(n.GT), x = (0, s.useRef)(), A = function() {
                    const e = (arguments.length > 1 && void 0 !== arguments[1] && arguments[1] ? !t : t) ? "live" : g ? "calendar" : "prematch";
                    switch (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "c") {
                        case "u":
                            return e.toUpperCase();
                        case "l":
                            return e.toLowerCase();
                        case "c":
                            return (0, h.Z)(e)
                    }
                };
                return (0, s.useEffect)((() => {
                    if ((0, m.F)()) return;
                    const e = x.current.closest(`[class*=${y?"EventsWrapper":"SBCol"}]`),
                        t = null === e || void 0 === e ? void 0 : e.style.position,
                        a = null === e || void 0 === e ? void 0 : e.style.overflow;
                    return e && (e.style.position = "relative", e.style.overflow = "initial"), () => {
                        e && (e.style.position = t, e.style.overflow = a)
                    }
                }), [x]), (0, u.jsx)(r.Ay, {
                    title: (0, u.jsx)(c.k, {
                        children: F("sportsbook.noGame")
                    }),
                    ...a && {
                        style: {
                            background: "var(--v3-black-2)",
                            position: (0, m.F)() ? "static" : "absolute",
                            top: 0,
                            bottom: 0,
                            width: (0, m.F)() || !v || y || f ? "100%" : "136%",
                            zIndex: 11,
                            display: "flex",
                            flexDirection: "column",
                            justifyContent: "center",
                            alignItems: "center",
                            right: 0,
                            ...(0, m.F)() && {
                                padding: 0
                            }
                        }
                    },
                    icon: (0, u.jsx)(_.GlobalIcon, {
                        lib: "generic",
                        name: "noMatches",
                        theme: "colored",
                        size: 176
                    }),
                    subTitle: (0, u.jsx)(c.y, { ...!(0, m.F)() && {
                            ref: x
                        },
                        children: F("sportsbook.noGameText")
                    }),
                    ...v && !y && {
                        extra: (0, u.jsx)(d.$, {
                            type: "primary",
                            size: "large",
                            onClick: () => {
                                var e, t;
                                return f ? k.replace(`${p.Ay.PAGE_URLS.esport}/${p.Ay.SPORTSBOOK_MOUNT_PATH}/AllESports?type=${A("l",!0)}` || `${window.location.origin+(null===(e=P.find((e=>"esport"===e.type&&"esport"===e.category)))||void 0===e?void 0:e.path)}/${p.Ay.SPORTSBOOK_MOUNT_PATH}/AllESports?type=${A("l",!0)}`) : window.location.href = p.Ay.PAGE_URLS[A("l", !0)] || window.location.origin + (null === (t = P.find((e => e.type === A("l", !0) || e.category === A("l", !0)))) || void 0 === t ? void 0 : t.path)
                            },
                            children: F(`emptyMessages.emptyMatches${A()}Action`)
                        })
                    }
                })
            }
        },
        335778: (e, t, a) => {
            a.d(t, {
                L: () => c
            });
            a(270757);
            var r = a(694227),
                s = a(365043),
                i = a(889181),
                o = a(685787),
                n = a(870875),
                l = a(55418),
                d = a(242828),
                _ = a(399866),
                m = (a(209975), a(570579));
            const c = e => {
                let {
                    sportAlias: t,
                    hideMoreWages: a,
                    detailedTeamsInfo: c
                } = e;
                const p = (0, _.$)().pageType === o.cM.live,
                    [h, u] = (0, s.useState)(n.uo.includes(t || "")),
                    [v, y] = (0, s.useState)(n.cL.includes(t || ""));
                return (0, s.useEffect)((() => {
                    u(n.uo.includes(t || "")), y(n.cL.includes(t || ""))
                }), [t]), (0, m.jsxs)(m.Fragment, {
                    children: [(0, m.jsxs)("div", {
                        className: (0, i.A)(["matchCardInline__wrapper--usa", {
                            "matchCardInline__wrapper--usa--withBorderRadius": p
                        }]),
                        children: [(0, m.jsxs)("div", {
                            className: "matchCardInline__info",
                            children: [(0, m.jsxs)("div", {
                                className: (0, i.A)(["matchCardInline__leftGameInfo", {
                                    "matchCardInline__leftGameInfo--detailedView": c
                                }]),
                                children: [c && (0, m.jsx)(r.A.Avatar, {
                                    size: "small",
                                    active: !0,
                                    shape: "circle",
                                    style: {
                                        marginRight: "4px",
                                        marginLeft: "8px"
                                    }
                                }), (0, m.jsx)(r.A, {
                                    title: {
                                        style: {
                                            height: 6,
                                            width: 80,
                                            margin: "5px auto"
                                        }
                                    },
                                    paragraph: !1,
                                    active: !0
                                })]
                            }), (0, m.jsxs)("div", {
                                className: "matchCardInline__teamNames",
                                children: [(0, m.jsxs)("div", {
                                    children: [c && (0, m.jsx)(r.A.Avatar, {
                                        size: "small",
                                        active: !0,
                                        shape: "circle",
                                        style: {
                                            marginRight: "4px",
                                            marginLeft: "8px"
                                        }
                                    }), (0, m.jsx)(r.A, {
                                        title: {
                                            style: {
                                                height: 6,
                                                width: 80,
                                                margin: "5px auto"
                                            }
                                        },
                                        paragraph: !1,
                                        active: !0
                                    })]
                                }), (0, m.jsxs)("div", {
                                    children: [c && (0, m.jsx)(r.A.Avatar, {
                                        size: "small",
                                        active: !0,
                                        shape: "circle",
                                        style: {
                                            marginRight: "4px",
                                            marginLeft: "8px"
                                        }
                                    }), (0, m.jsx)(r.A, {
                                        title: {
                                            style: {
                                                height: 6,
                                                width: 80,
                                                margin: "5px auto"
                                            }
                                        },
                                        paragraph: !1,
                                        active: !0
                                    })]
                                })]
                            })]
                        }), (0, m.jsx)("div", {
                            className: "matchCardInline__odds",
                            children: (0, m.jsx)("div", {
                                className: "matchCardInline__oddsWrapper",
                                children: (0, d.K)(v ? 2 : 3).map((e => (0, m.jsxs)("div", {
                                    className: "matchCardInline__oddGroup",
                                    children: [(0, m.jsx)("div", {
                                        className: "matchCardInline__marketName",
                                        children: (0, m.jsx)(r.A, {
                                            title: {
                                                style: {
                                                    height: 5,
                                                    width: v ? 0 : 10,
                                                    margin: "5px auto"
                                                }
                                            },
                                            paragraph: !1,
                                            active: !0
                                        })
                                    }), (0, m.jsx)(r.A, {
                                        title: {
                                            style: {
                                                height: 5,
                                                width: 30,
                                                margin: "5px auto"
                                            }
                                        },
                                        paragraph: !1,
                                        active: !0
                                    }), h && (0, m.jsx)(r.A, {
                                        title: {
                                            style: {
                                                height: 5,
                                                width: 30,
                                                margin: "5px auto"
                                            }
                                        },
                                        paragraph: !1,
                                        active: !0
                                    })]
                                }, e)))
                            })
                        })]
                    }), !a && (0, m.jsxs)("div", {
                        className: (0, i.A)(["matchCardInline__moreWages", {
                            "matchCardInline__moreWages--mobile": (0, l.F)()
                        }]),
                        children: [c && (0, m.jsx)(r.A, {
                            title: {
                                style: {
                                    height: 16,
                                    width: 60,
                                    margin: "0",
                                    marginLeft: "4px"
                                }
                            },
                            paragraph: !1,
                            active: !0
                        }), (0, m.jsx)(r.A, {
                            title: {
                                style: {
                                    height: 5,
                                    width: 80,
                                    margin: "0",
                                    marginLeft: "80%"
                                }
                            },
                            paragraph: !1,
                            active: !0
                        })]
                    })]
                })
            };
            c.defaultProps = {
                sportAlias: void 0
            }
        },
        787076: (e, t, a) => {
            a.d(t, {
                K: () => m
            });
            var r = a(365043),
                s = a(507712),
                i = a(737536),
                o = a(423400),
                n = a(704270);
            var l = a(117893),
                d = a(390648),
                _ = a(179177);
            const m = function() {
                let e = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
                const t = (0, s.wA)(),
                    a = (0, s.d4)(d.im);
                (0, r.useEffect)((() => {
                    _.Ay.IS_BOOSTED_ODDS_ENABLED && e && !a && (t((0, l.KKp)()), (e => {
                        const t = {
                            command: i.y.GET_BOOSTED_SELECTIONS,
                            params: {},
                            rid: o.A.gForCommand()
                        };
                        n.l.then((a => {
                            a.sendCommand(t, "", e)
                        }))
                    })(m))
                }), [a, e]);
                const m = e => {
                    const a = {};
                    e.details && Object.keys(e.details).forEach((t => {
                        a[t] = e.details[t].reduce(((e, t) => {
                            let {
                                Id: a,
                                BoostType: r
                            } = t;
                            return { ...e,
                                [a]: {
                                    type: r
                                }
                            }
                        }), {})
                    })), t((0, l.lGH)(a))
                }
            }
        },
        399866: (e, t, a) => {
            a.d(t, {
                $: () => m
            });
            var r = a(365043),
                s = a(697694),
                i = a(685787),
                o = a(718402),
                n = a(325040);
            const l = {
                    pageLive: 0,
                    pagePrematch: 1,
                    pageEsport: 2,
                    pagePrematchEuropean: 1,
                    pageLiveEuropean: 0
                },
                d = {
                    pagePrematchEuropean: i.bB.EUROPEAN,
                    pageLiveEuropean: i.bB.EUROPEAN,
                    pageLive: i.bB.CLASSIC,
                    pagePrematch: i.bB.CLASSIC
                },
                _ = () => (0, r.useMemo)((() => {
                    var e, t;
                    const a = null === (e = window) || void 0 === e || null === (t = e.partnerConfigs) || void 0 === t ? void 0 : t.pageParams,
                        r = null !== a && void 0 !== a && a.pageType ? l[null === a || void 0 === a ? void 0 : a.pageType] : void 0;
                    var s, i, _, m;
                    return a && void 0 !== r ? {
                        pageType: r,
                        spbLayoutType: a.pageLayout || d[a.pageType],
                        sportType: JSON.stringify(a.sportType || o.Y9),
                        type: n.h[r],
                        favoriteTeam: null !== (s = a.favoriteTeam) && void 0 !== s && s,
                        changeFavoriteTeam: null !== (i = a.changeFavoriteTeam) && void 0 !== i && i,
                        fixedScroll: null !== (_ = a.fixedScroll) && void 0 !== _ && _,
                        jackpotForSportsbook: null !== (m = a.jackpotForSportsbook) && void 0 !== m && m
                    } : {}
                }), []);

            function m() {
                const e = _();
                return void 0 !== (null === e || void 0 === e ? void 0 : e.pageType) ? e : (0, r.useContext)(s.H) || s.D
            }
        },
        133230: (e, t, a) => {
            a.d(t, {
                Mh: () => s,
                hA: () => r,
                iq: () => n,
                s0: () => i,
                s8: () => o
            });
            let r = function(e) {
                    return e[e.QUARTER_HOUR = 15] = "QUARTER_HOUR", e[e.HALF_HOUR = 30] = "HALF_HOUR", e[e.ONE_HOUR = 60] = "ONE_HOUR", e[e.THREE_HOURS = 180] = "THREE_HOURS", e[e.SEVEN_HOURS = 360] = "SEVEN_HOURS", e
                }({}),
                s = function(e) {
                    return e.CARD = "cardView", e.LIST = "listView", e
                }({}),
                i = function(e) {
                    return e.LIVE = "live", e.PREMATCH = "prematch", e.POPULAR = "popular", e.BOOSTED = "boosted", e
                }({}),
                o = function(e) {
                    return e.ALL = "all", e.LIVE = "live", e.PREMATCH = "prematch", e.POPULAR = "popular", e.BOOSTED = "boosted", e
                }({}),
                n = function(e) {
                    return e.START_TIME = "start_ts", e.FAV_ORDER = "favorite_order", e
                }({})
        },
        555329: (e, t, a) => {
            a.d(t, {
                G: () => l
            });
            a(270757);
            var r = a(694227),
                s = a(889181),
                i = a(179177),
                o = a(242828),
                n = a(570579);
            i.Ay.IS_RTL && a.e(92964).then(a.bind(a, 292964));
            const l = () => (0, n.jsx)("div", {
                className: "menu-wrapper",
                children: (0, n.jsx)("div", {
                    className: "menu-wrapper__container",
                    children: (0, o.K)(15).map((e => (0, n.jsx)("div", {
                        className: (0, s.A)(["menuItemFillSkeleton", {
                            "menuItemFillSkeleton--active": 0 === e
                        }]),
                        children: (0, n.jsx)(r.A.Avatar, {
                            size: 24,
                            active: !0
                        })
                    }, e)))
                })
            })
        },
        516058: (e, t, a) => {
            a.d(t, {
                J: () => m
            });
            var r = a(889181),
                s = (a(780510), a(326468)),
                i = (a(849416), a(147638)),
                o = (a(270757), a(694227)),
                n = a(242828),
                l = (a(739448), a(570579));
            const d = e => {
                let {
                    fromSelectedGames: t
                } = e;
                return (0, l.jsxs)("div", {
                    style: {
                        height: 164,
                        background: "var(--v3-black-0)"
                    },
                    children: [(0, l.jsxs)("div", {
                        className: "selectedGameCard__contanier",
                        style: {
                            flexDirection: "row",
                            justifyContent: "space-between"
                        },
                        children: [(0, l.jsxs)("div", {
                            className: "selectedGameCard__header",
                            children: [(0, l.jsx)(o.A, {
                                avatar: {
                                    size: t ? "default" : "small",
                                    shape: "circle",
                                    style: {
                                        width: 20,
                                        height: 20,
                                        marginTop: 2,
                                        paddingRight: 8
                                    }
                                },
                                title: {
                                    style: {
                                        marginTop: 4,
                                        marginBottom: 4
                                    }
                                },
                                paragraph: !1,
                                active: !0
                            }), (0, l.jsx)(o.A, {
                                title: {
                                    style: {
                                        width: 30,
                                        margin: 0,
                                        height: 10
                                    }
                                },
                                paragraph: !1,
                                active: !0
                            })]
                        }), (0, l.jsxs)("div", {
                            className: "selectedGameCard__header",
                            children: [(0, l.jsx)(o.A, {
                                title: {
                                    style: {
                                        width: 50,
                                        margin: 0,
                                        height: 10,
                                        marginLeft: 4
                                    }
                                },
                                paragraph: !1,
                                active: !0
                            }), (0, l.jsx)(o.A, {
                                title: {
                                    style: {
                                        width: 20,
                                        margin: 0,
                                        height: 20,
                                        marginLeft: 4
                                    }
                                },
                                paragraph: !1,
                                active: !0
                            }), (0, l.jsx)(o.A, {
                                title: {
                                    style: {
                                        width: 20,
                                        margin: 0,
                                        height: 20,
                                        marginLeft: 4
                                    }
                                },
                                paragraph: !1,
                                active: !0
                            })]
                        })]
                    }), (0, l.jsxs)("div", {
                        className: "selectedGameCard__title__titleSkeleton",
                        children: [(0, l.jsxs)("div", {
                            className: "selectedGameCard__title",
                            children: [(0, l.jsx)("div", {
                                className: "selectedGameCard__title__teamCaption__left",
                                children: (0, l.jsx)(o.A, {
                                    avatar: {
                                        shape: "circle",
                                        size: t ? "default" : "small",
                                        style: {
                                            width: 32,
                                            height: 32,
                                            marginTop: 2
                                        },
                                        ...t && {
                                            style: {
                                                marginTop: "4px"
                                            }
                                        }
                                    },
                                    title: {
                                        style: {
                                            marginTop: 4,
                                            marginBottom: 4,
                                            alignItems: "flex-start"
                                        }
                                    },
                                    paragraph: !1,
                                    active: !0
                                })
                            }), (0, l.jsx)("span", {
                                className: "selectedGameCard__title__gameInfo__vs",
                                style: {
                                    background: "none",
                                    border: "none"
                                },
                                children: (0, l.jsx)(o.A, {
                                    title: {
                                        style: {
                                            margin: 0,
                                            height: 32,
                                            width: 36
                                        }
                                    },
                                    paragraph: !1,
                                    active: !0
                                })
                            }), (0, l.jsx)("div", {
                                className: "selectedGameCard__title__teamCaption__right",
                                children: (0, l.jsx)(o.A, {
                                    avatar: {
                                        shape: "circle",
                                        size: t ? "default" : "small",
                                        style: {
                                            width: 32,
                                            height: 32,
                                            marginTop: 2
                                        },
                                        ...t && {
                                            style: {
                                                marginTop: "4px"
                                            }
                                        }
                                    },
                                    title: {
                                        style: {
                                            marginTop: 4,
                                            marginBottom: 4
                                        }
                                    },
                                    paragraph: !1,
                                    active: !0
                                })
                            })]
                        }), (0, l.jsx)(s.A, {
                            gutter: 4,
                            children: (0, n.K)(3).map((e => (0, l.jsx)(i.A, {
                                xs: 8,
                                children: (0, l.jsx)(o.A, {
                                    title: {
                                        style: {
                                            marginTop: 8,
                                            marginBottom: 0,
                                            height: 32,
                                            width: "100%"
                                        }
                                    },
                                    paragraph: !1,
                                    active: !0
                                })
                            }, e)))
                        })]
                    })]
                })
            };
            var _ = a(55418);
            a(81996);
            const m = e => {
                let {
                    gamesPerView: t,
                    className: a
                } = e;
                return (0, l.jsx)("div", {
                    className: (0, r.A)([`selectedGames__container ${a}`, {
                        "selectedGames__container-mobile selectedGames__container-mobile__width-dots": (0, _.F)()
                    }]),
                    children: [...Array((0, _.F)() ? 1 : t).keys()].map(((e, a) => (0, l.jsx)("div", {
                        className: "selectedGames__innerItem",
                        style: {
                            width: `calc(100% / ${t})`
                        },
                        children: (0, l.jsx)("div", {
                            style: {
                                backgroundColor: "var(--v3-black-0)"
                            },
                            children: (0, l.jsx)(d, {
                                fromSelectedGames: !0
                            })
                        })
                    }, a)))
                })
            }
        },
        256694: (e, t, a) => {
            a.d(t, {
                A: () => n,
                i: () => o
            });
            var r = a(365043),
                s = a(570579);
            const i = (0, r.createContext)(null),
                o = e => {
                    let {
                        configs: t,
                        children: a
                    } = e;
                    return (0, s.jsx)(i.Provider, {
                        value: t,
                        children: a
                    })
                },
                n = () => (0, r.useContext)(i)
        },
        450431: (e, t, a) => {
            a.d(t, {
                d: () => i
            });
            a(270757);
            var r = a(694227),
                s = (a(444487), a(570579));
            const i = () => (0, s.jsx)("div", {
                children: (0, s.jsx)(r.A.Button, {
                    className: "eventsTimeFilter--desktop--skeleton",
                    active: !0
                })
            })
        },
        608407: (e, t, a) => {
            a.d(t, {
                Ci: () => h,
                Kd: () => _,
                TT: () => m,
                kB: () => l,
                nZ: () => p,
                xO: () => c
            });
            var r = a(197262),
                s = a(133230),
                i = a(950694),
                o = a(179177),
                n = a(55418);
            const l = e => {
                    const t = [];
                    return Object.values(e || {}).forEach((e => {
                        let {
                            competition: a
                        } = e;
                        Object.values(a || {}).forEach((e => {
                            t.push(e)
                        }))
                    })), t
                },
                d = e => {
                    switch (e) {
                        case s.s8.LIVE:
                            return [1];
                        case s.s8.PREMATCH:
                            return [0, 2];
                        case s.s8.POPULAR || s.s8.BOOSTED:
                            return [0, 1, 2];
                        default:
                            return []
                    }
                },
                _ = e => e ? { ...i.$h,
                    game: ["sport_alias", ...i.$h.game]
                } : i.$h,
                m = e => {
                    let {
                        sport: t,
                        selectedEventsType: a,
                        activeTimeFilter: r,
                        boostedGameIds: n
                    } = e;
                    const l = {
                        game: {},
                        market: {}
                    };
                    return t && (l.sport = {
                        alias: t
                    }), a === s.s8.BOOSTED && n ? l.game.id = {
                        "@in": n
                    } : l.game.type = {
                        "@in": d(a)
                    }, a === s.s8.POPULAR && (l.game.promoted = !0), a === s.s8.PREMATCH && r && (l.game.start_ts = {
                        "@now": {
                            "@gte": 0,
                            "@lt": 60 * r
                        }
                    }), o.Ay.IS_AMERICAN_LAYOUT ? l.market = i.MP : l.market = i.L, l
                },
                c = e => e === s.s8.PREMATCH ? r.A.t("sportsbook.upcomingEvents") : r.A.t(`sportsbook.${e}Events`),
                p = e => {
                    let {
                        eventsLength: t,
                        index: a,
                        event: {
                            name: r,
                            type: s,
                            type_1: i,
                            team1_name: o,
                            team2_name: l
                        }
                    } = e;
                    return t > 2 && 1 === a ? (0, n.F)() ? "x" : r || "Draw" : 0 === a ? "P1" === s || "W1" === i ? o : l : "P2" === s || "W2" === i ? l : o
                },
                h = e => {
                    let {
                        eventsLength: t,
                        index: a
                    } = e;
                    return t > 2 && 1 === a ? 4 : (0 === a || 2 === a) && t > 2 ? 10 : 12
                }
        },
        507931: (e, t, a) => {
            a.r(t), a.d(t, {
                Events: () => Q
            });
            var r = a(133230),
                s = a(365043),
                i = a(504647),
                o = a(507712),
                n = a(218660),
                l = a(390648),
                d = a(685527),
                _ = a(889181),
                m = a(980127),
                c = a(179177),
                p = a(989618),
                h = (a(270757), a(694227)),
                u = a(570579);
            const v = () => (0, u.jsx)("div", {
                className: "events-wrapper__title",
                children: (0, u.jsx)(h.A.Button, {
                    className: "events-wrapper__title--skeleton",
                    active: !0
                })
            });
            var y = a(950694);
            const g = () => (0, u.jsx)("div", {
                className: "events-wrapper__tabs",
                children: (0, u.jsx)("div", {
                    className: "events-wrapper__tabs--skeletons",
                    children: y.uj.map((e => {
                        let {
                            key: t
                        } = e;
                        return (0, u.jsx)(h.A.Button, {
                            className: (0, _.A)(["events-wrapper__tabs--skeleton", {
                                "events-wrapper__tabs--skeleton-lg": !c.Ay.IS_BOOSTED_ODDS_ENABLED
                            }]),
                            active: !0
                        }, t)
                    }))
                })
            });
            var f = a(55418),
                F = a(256694),
                k = a(450431);
            const P = () => {
                const e = (0, F.A)(),
                    t = (0, o.d4)(n.Vt)[(null === e || void 0 === e ? void 0 : e.moduleId) || ""],
                    a = !(null === e || void 0 === e || !e.defaultEventsMinutes) && t === r.s8.PREMATCH && !(0, f.F)(),
                    s = (null === e || void 0 === e ? void 0 : e.type) === r.s8.LIVE;
                return (0, u.jsxs)("div", {
                    className: "events-wrapper__header",
                    children: [(0, u.jsxs)("div", {
                        className: "events-wrapper__header--title",
                        children: [s && (0, u.jsx)(h.A.Button, {
                            className: "events-wrapper__header--title--icon-skeleton",
                            active: !0
                        }), (0, u.jsx)(h.A.Button, {
                            className: "events-wrapper__header--title-skeleton",
                            active: !0
                        })]
                    }), (0, u.jsxs)("div", {
                        className: "events-wrapper__header--right-bar",
                        children: [a && (0, u.jsx)(k.d, {}), (0, u.jsx)(h.A.Button, {
                            className: "events-wrapper__header--right-bar--link-skeleton",
                            active: !0
                        })]
                    })]
                })
            };
            var x = a(555329);
            const A = () => (0, u.jsx)("div", {
                className: "events-wrapper__sports",
                children: (0, u.jsx)(x.G, {})
            });
            var b = a(83014),
                W = a(516058);
            a(426342);
            const j = [...Array(3).keys()],
                w = () => {
                    const e = (0, F.A)(),
                        t = (0, o.d4)(n.Vt)[(null === e || void 0 === e ? void 0 : e.moduleId) || ""],
                        a = t === r.s8.LIVE || (null === e || void 0 === e ? void 0 : e.type) === r.s8.LIVE || (null === e || void 0 === e ? void 0 : e.type) === r.s8.ALL && !t;
                    return (0, u.jsxs)("div", {
                        className: (0, _.A)(["events-game", {
                            "events-game-mobile": (0, f.F)()
                        }]),
                        children: [(0, f.F)() && (0, u.jsx)("div", {
                            className: "events-game__match-info",
                            children: (0, u.jsx)(h.A.Button, {
                                className: "events-game__match-info--text-skeleton",
                                active: !0
                            })
                        }), (0, u.jsxs)("div", {
                            className: "events-game__header",
                            children: [(0, f.F)() ? (0, u.jsxs)("div", {
                                className: "events-game__header--menu",
                                children: [(0, u.jsx)(h.A.Button, {
                                    className: "events-game__header--menu--button-skeleton-lg",
                                    active: !0
                                }), a && (0, u.jsx)(h.A.Button, {
                                    className: "events-game__header--menu--button-skeleton-md",
                                    active: !0
                                })]
                            }) : (0, u.jsx)(h.A.Button, {
                                className: "events-game__header--league-skeleton",
                                active: !0
                            }), (0, u.jsxs)("div", {
                                className: "events-game__header--menu",
                                children: [!(0, f.F)() && (0, u.jsxs)(u.Fragment, {
                                    children: [(0, u.jsx)(h.A.Button, {
                                        className: "events-game__header--menu--button-skeleton-lg",
                                        active: !0
                                    }), a && (0, u.jsx)(h.A.Button, {
                                        className: "events-game__header--menu--button-skeleton-md",
                                        active: !0
                                    })]
                                }), (0, u.jsx)(h.A.Button, {
                                    className: "events-game__header--menu--button-skeleton-md",
                                    active: !0
                                })]
                            })]
                        }), (0, u.jsx)("div", {
                            className: (0, _.A)(["events-game__markets", "events-game__markets-skeleton"]),
                            children: j.map((e => (0, u.jsx)(h.A.Button, {
                                className: "events-game__markets-skeleton--market",
                                active: !0
                            }, e)))
                        })]
                    })
                };
            var C = a(335778);
            a(792421);
            const R = () => {
                    var e;
                    const t = (0, F.A)(),
                        a = (0, o.d4)(n.Vt)[(null === t || void 0 === t ? void 0 : t.moduleId) || ""],
                        r = null === (e = (0, o.d4)(n.wR)[(null === t || void 0 === t ? void 0 : t.moduleId) || ""]) || void 0 === e ? void 0 : e[a];
                    return (0, u.jsxs)("div", {
                        children: [(0, u.jsxs)("div", {
                            className: "events-game-usa__header",
                            children: [(0, u.jsx)(h.A.Button, {
                                className: "events-game-usa__header--logo-skeleton",
                                active: !0
                            }), (0, u.jsx)(h.A.Button, {
                                className: "events-game-usa__header--title-skeleton",
                                active: !0
                            })]
                        }), (0, u.jsx)(C.L, {
                            sportAlias: null === r || void 0 === r ? void 0 : r.alias
                        })]
                    })
                },
                T = () => {
                    const e = (0, F.A)(),
                        t = [...new Array((null === e || void 0 === e ? void 0 : e.limit) || y.Kf).keys()],
                        a = (0, f.F)() ? 1 : (null === e || void 0 === e ? void 0 : e.eventsGamesPerView) || y.el;
                    return (null === e || void 0 === e ? void 0 : e.eventViewLayout) === r.Mh.CARD || (null === e || void 0 === e ? void 0 : e.showAllSportsWithSlid) ? (0, u.jsx)(W.J, {
                        gamesPerView: a
                    }) : (0, u.jsx)(u.Fragment, {
                        children: t.map((e => c.Ay.IS_AMERICAN_LAYOUT ? (0, u.jsx)(R, {}, e) : (0, u.jsx)(w, {}, e)))
                    })
                };
            var S = a(482463);
            const {
                Game: E
            } = (0, p.R)((() => Promise.all([a.e(99701), a.e(22093), a.e(45375), a.e(99989), a.e(73157), a.e(12967), a.e(77499), a.e(22491), a.e(31528), a.e(9297), a.e(36273), a.e(61579), a.e(73549), a.e(58073), a.e(24757), a.e(84716), a.e(42146), a.e(65506), a.e(10795), a.e(51172), a.e(77971), a.e(5060), a.e(55221), a.e(62956), a.e(32148), a.e(80279), a.e(2546), a.e(29634), a.e(16006), a.e(83067)]).then(a.bind(a, 577146)))), {
                GameUsa: X
            } = (0, p.R)((() => Promise.all([a.e(99701), a.e(22093), a.e(45375), a.e(99989), a.e(76481), a.e(75634), a.e(20509), a.e(73157), a.e(12967), a.e(77499), a.e(74027), a.e(22491), a.e(82363), a.e(6635), a.e(8198), a.e(31528), a.e(9297), a.e(36273), a.e(61579), a.e(70289), a.e(18574), a.e(51238), a.e(31437), a.e(57008), a.e(82675), a.e(69478), a.e(94875), a.e(80840), a.e(52106), a.e(61190), a.e(74385)]).then(a.bind(a, 704867)))), {
                CardView: M
            } = (0, p.R)((() => Promise.all([a.e(99701), a.e(22093), a.e(45375), a.e(99989), a.e(73157), a.e(12967), a.e(77499), a.e(22491), a.e(31528), a.e(9297), a.e(36273), a.e(61579), a.e(94167), a.e(73549), a.e(58073), a.e(24757), a.e(84716), a.e(42146), a.e(65506), a.e(10795), a.e(51172), a.e(77971), a.e(83573), a.e(5060), a.e(55221), a.e(62956), a.e(24131), a.e(32148), a.e(29782), a.e(25142)]).then(a.bind(a, 374134)))), L = (0, s.memo)((() => {
                var e, t, a, i;
                const l = (0, F.A)(),
                    d = (0, o.d4)(n.Vt)[(null === l || void 0 === l ? void 0 : l.moduleId) || ""],
                    _ = null === (e = (0, o.d4)(n.e)[(null === l || void 0 === l ? void 0 : l.moduleId) || ""]) || void 0 === e ? void 0 : e[d],
                    m = null === (t = (0, o.d4)(n.wR)[(null === l || void 0 === l ? void 0 : l.moduleId) || ""]) || void 0 === t ? void 0 : t[d],
                    p = null !== l && void 0 !== l && l.showAllSportsWithSlid ? y.Ig : null === m || void 0 === m ? void 0 : m.alias,
                    h = null === (a = (0, o.d4)(n.kQ)[(null === l || void 0 === l ? void 0 : l.moduleId) || ""]) || void 0 === a || null === (i = a[d]) || void 0 === i ? void 0 : i[p],
                    v = (0, f.F)() ? 1 : (null === l || void 0 === l ? void 0 : l.eventsGamesPerView) || y.el,
                    g = (null === l || void 0 === l ? void 0 : l.eventViewLayout) === r.Mh.CARD || !(null === l || void 0 === l || !l.showAllSportsWithSlid),
                    k = (0, s.useMemo)((() => {
                        if (!h) return [];
                        if (!g && !m) return [];
                        let e = [];
                        h.forEach((t => {
                            let {
                                id: a,
                                name: r,
                                game: s
                            } = t;
                            Object.values(s || {}).forEach((t => {
                                e.push({ ...t,
                                    competitionId: a,
                                    competitionName: r
                                })
                            }))
                        }));
                        if ((null === l || void 0 === l ? void 0 : l.type) === r.s8.ALL && !(null !== l && void 0 !== l && l.popularEventsOrder) || (null === l || void 0 === l ? void 0 : l.popularEventsOrder) === r.iq.START_TIME ? (e = (0, S.I)(e, (null === l || void 0 === l ? void 0 : l.popularEventsOrder) || "start_ts"), e = e.slice(0, (null === l || void 0 === l ? void 0 : l.limit) || y.Kf)) : (e = (0, S.I)(e, null === l || void 0 === l ? void 0 : l.popularEventsOrder, "desc"), e = e.slice(0, (null === l || void 0 === l ? void 0 : l.limit) || y.Kf).reverse()), g) {
                            const t = [];
                            return e.forEach(((e, a) => {
                                const r = Math.ceil((a + 1) / v) - 1;
                                t[r] = [...t[r] || [], {
                                    data: { ...e,
                                        regionAlias: e.region_alias || "",
                                        sportName: (null === m || void 0 === m ? void 0 : m.alias) || ""
                                    }
                                }]
                            })), t
                        }
                        return e
                    }), [h, m, l]),
                    P = (0, s.useMemo)((() => null !== l && void 0 !== l && l.showAllSportsWithSlid ? !!k && Boolean(h) : _ && !_.length), [_, k]);
                return null !== k && void 0 !== k && k.length ? g ? (0, u.jsx)(s.Suspense, {
                    fallback: (0, u.jsx)(T, {}),
                    children: (0, u.jsx)(M, {
                        gameData: k,
                        sliderData: k,
                        gamesPerView: v,
                        showSportIcon: null === l || void 0 === l ? void 0 : l.showAllSportsWithSlid
                    })
                }) : (0, u.jsx)(u.Fragment, {
                    children: k.map((e => c.Ay.IS_AMERICAN_LAYOUT ? (0, u.jsx)(s.Suspense, {
                        fallback: (0, u.jsx)(R, {}),
                        children: (0, u.jsx)(X, {
                            game: e
                        })
                    }, e.id) : (0, u.jsx)(s.Suspense, {
                        fallback: (0, u.jsx)(w, {}),
                        children: (0, u.jsx)(E, {
                            game: e
                        })
                    }, e.id)))
                }) : P ? (0, u.jsx)(b.EmptyMatches, {}) : (0, u.jsx)(T, {})
            }));
            var I = a(423400),
                D = a(608407),
                N = a(787076),
                O = a(490440);
            a(444487);
            const B = e => {
                let {
                    fullWidth: t
                } = e;
                return (0, u.jsx)("div", {
                    className: (0, _.A)(["eventsTimeFilter", {
                        "eventsTimeFilter--full-width": t
                    }]),
                    children: y.HC.map((e => (0, u.jsx)("div", {
                        className: "eventsTimeFilter__button",
                        children: (0, u.jsx)(h.A.Button, {
                            className: "eventsTimeFilter__button--skeleton",
                            active: !0
                        })
                    }, e)))
                })
            };
            var U = a(335232);
            "rtl" === c.Ay.DIRECTION && a.e(13052).then(a.bind(a, 413052));
            const H = () => {
                const e = (0, F.A)(),
                    t = (0, o.d4)(n.Vt)[(null === e || void 0 === e ? void 0 : e.moduleId) || ""];
                return (0, u.jsxs)(u.Fragment, {
                    children: [!(null === e || void 0 === e || !e.showTitle) && (0, u.jsx)(v, {}), (null === e || void 0 === e ? void 0 : e.type) === r.s8.ALL && (0, u.jsx)(g, {}), !(null === e || void 0 === e || !e.showCategoryName) && (0, u.jsx)(P, {}), !(null !== e && void 0 !== e && e.showAllSportsWithSlid) && (0, u.jsx)(A, {}), (t === r.s8.PREMATCH || (null === e || void 0 === e ? void 0 : e.type) === r.s8.PREMATCH) && (!(null !== e && void 0 !== e && e.showCategoryName) || (0, f.F)()) && !(null === e || void 0 === e || !e.defaultEventsMinutes) && (0, u.jsx)(B, {
                        fullWidth: !0
                    }), (0, u.jsx)("div", {
                        className: "events-wrapper__games",
                        children: (0, u.jsx)(T, {})
                    })]
                })
            };
            var G = a(200815);
            const {
                Title: V
            } = (0, p.R)((() => a.e(91105).then(a.bind(a, 158614)))), {
                Tabs: K
            } = (0, p.R)((() => Promise.all([a.e(78395), a.e(63354), a.e(37305)]).then(a.bind(a, 160868)))), {
                Header: z
            } = (0, p.R)((() => Promise.all([a.e(24757), a.e(2546), a.e(26158)]).then(a.bind(a, 615911)))), {
                Sports: $
            } = (0, p.R)((() => Promise.all([a.e(24131), a.e(27012), a.e(50245), a.e(89136)]).then(a.bind(a, 84541)))), {
                EventsTimeFilterMobile: q
            } = (0, p.R)((() => a.e(80568).then(a.bind(a, 20385))));
            "rtl" === c.Ay.DIRECTION && a.e(13052).then(a.bind(a, 413052));
            const J = {},
                Q = (0, s.memo)((e => {
                    var t;
                    let {
                        configs: a
                    } = e;
                    const p = (0, o.d4)(m.c),
                        h = (0, o.d4)(n.KI)[a.moduleId],
                        k = (0, o.d4)(n.Vt)[a.moduleId],
                        x = (0, s.useRef)(`event-element-${I.A.gCustom()}`),
                        b = null === (t = (0, o.d4)(n.wR)[a.moduleId]) || void 0 === t ? void 0 : t[k],
                        W = (0, o.d4)(l.$P),
                        j = (0, o.wA)(),
                        {
                            mounted: w
                        } = (0, O.q)(),
                        C = a.eventViewLayout === r.Mh.CARD || a.showAllSportsWithSlid;
                    (0, N.K)(k === r.s8.BOOSTED), (0, s.useEffect)((() => {
                        a.type === r.s8.ALL ? j((0, d.zg)({
                            [a.moduleId]: r.s8.LIVE
                        })) : j((0, d.zg)({
                            [a.moduleId]: a.type
                        }))
                    }), [a.type]), (0, s.useEffect)((() => {
                        p || (0, G.Or)()
                    }), []), (0, s.useEffect)((() => {
                        if (c.Ay.MOCKED_DATA) return void j((0, d.oU)({
                            [a.moduleId]: {
                                type: k,
                                sport: (null === b || void 0 === b ? void 0 : b.alias) || y.Ig,
                                data: U.C
                            }
                        }));
                        if (!b && !C || !k) return;
                        if (k === r.s8.BOOSTED && !W) return;
                        if (J[a.moduleId]) return;
                        const e = I.A.gForSubscribe("events"),
                            t = (e, t) => {
                                w.current && (j((0, d.oU)({
                                    [a.moduleId]: {
                                        type: k,
                                        sport: (null === b || void 0 === b ? void 0 : b.alias) || y.Ig,
                                        data: (0, D.kB)(e.region)
                                    }
                                })), t && (J[a.moduleId] = !0, Object.values(e.region).length || j((0, d.ZA)({
                                    moduleId: a.moduleId,
                                    type: k,
                                    sport: null === b || void 0 === b ? void 0 : b.alias
                                }))))
                            };
                        return (0, i.RS)(e, (0, D.Kd)(!!a.showAllSportsWithSlid), (0, D.TT)({
                            sport: (null === b || void 0 === b ? void 0 : b.alias) || null,
                            selectedEventsType: k,
                            activeTimeFilter: h,
                            boostedGameIds: W
                        }), (e => t(e, !0)), !0, (e => t(e, !1))), () => {
                            (0, i.lx)(e)
                        }
                    }), [a.showAllSportsWithSlid, a.eventViewLayout, b, k, h, W]), (0, s.useEffect)((() => {
                        if ((b || C) && k) return () => {
                            J[a.moduleId] = !1
                        }
                    }), [b, k, h]);
                    const R = (0, s.useMemo)((() => ({ ...a,
                        componentId: x.current
                    })), [a]);
                    return (0, u.jsx)(F.i, {
                        configs: R,
                        children: (0, u.jsx)("div", {
                            "data-testid": "event-element",
                            id: x.current,
                            className: (0, _.A)(["events-wrapper", {
                                "events-wrapper-mobile": (0, f.F)()
                            }]),
                            children: k ? (0, u.jsxs)(u.Fragment, {
                                children: [!!a.showTitle && (0, u.jsx)(s.Suspense, {
                                    fallback: (0, u.jsx)(v, {}),
                                    children: (0, u.jsx)(V, {})
                                }), a.type === r.s8.ALL && (0, u.jsx)(s.Suspense, {
                                    fallback: (0, u.jsx)(g, {}),
                                    children: (0, u.jsx)(K, {})
                                }), !!a.showCategoryName && (0, u.jsx)(s.Suspense, {
                                    fallback: (0, u.jsx)(P, {}),
                                    children: (0, u.jsx)(z, {})
                                }), !a.showAllSportsWithSlid && (0, u.jsx)(s.Suspense, {
                                    fallback: (0, u.jsx)(A, {}),
                                    children: (0, u.jsx)($, {})
                                }), (k === r.s8.PREMATCH || a.type === r.s8.PREMATCH) && (!a.showCategoryName || (0, f.F)()) && !!a.defaultEventsMinutes && (0, u.jsx)(s.Suspense, {
                                    fallback: (0, u.jsx)(B, {
                                        fullWidth: !0
                                    }),
                                    children: (0, u.jsx)(q, {
                                        fullWidth: !0
                                    })
                                }), (0, u.jsx)("div", {
                                    className: "events-wrapper__games",
                                    children: (0, u.jsx)(L, {})
                                })]
                            }) : (0, u.jsx)(H, {})
                        })
                    })
                }))
        },
        335232: (e, t, a) => {
            a.d(t, {
                C: () => s,
                e: () => r
            });
            const r = {
                    1: {
                        name: "Football",
                        alias: "Soccer",
                        id: 1,
                        type: 2,
                        order: 2
                    },
                    2: {
                        name: "Ice Hockey",
                        alias: "IceHockey",
                        id: 2,
                        type: 2,
                        order: 5
                    },
                    3: {
                        name: "Basketball",
                        alias: "Basketball",
                        id: 3,
                        type: 2,
                        order: 3
                    },
                    4: {
                        name: "Tennis",
                        alias: "Tennis",
                        id: 4,
                        type: 2,
                        order: 4
                    },
                    5: {
                        name: "Volleyball",
                        alias: "Volleyball",
                        id: 5,
                        type: 2,
                        order: 7
                    },
                    11: {
                        name: "Baseball",
                        alias: "Baseball",
                        id: 11,
                        type: 2,
                        order: 9
                    },
                    22: {
                        name: "Darts",
                        alias: "Darts",
                        id: 22,
                        type: 2,
                        order: 74
                    },
                    29: {
                        name: "Handball",
                        alias: "Handball",
                        id: 29,
                        type: 2,
                        order: 12
                    },
                    39: {
                        name: "Snooker",
                        alias: "Snooker",
                        id: 39,
                        type: 2,
                        order: 182
                    },
                    41: {
                        name: "Table Tennis",
                        alias: "TableTennis",
                        id: 41,
                        type: 2,
                        order: 6
                    },
                    75: {
                        name: "Counter-Strike: GO",
                        alias: "CounterStrike",
                        id: 75,
                        type: 0,
                        order: 311
                    }
                },
                s = [{
                    id: 16759,
                    name: "Copa de Campeones Juvenil",
                    order: 4009,
                    game: {
                        22264269: {
                            id: 22264269,
                            region_alias: "Spain",
                            team1_name: "Real Madrid (Youth)",
                            team2_name: "UD Las Palmas (Youth)",
                            markets_count: 68,
                            info: {
                                current_game_state: "notstarted",
                                current_game_time: "0",
                                score1: "0",
                                score2: "0",
                                pass_team: "none",
                                shirt1_color: "FFFFFF",
                                shirt2_color: "FFFF00",
                                short1_color: "000000",
                                short2_color: "000000",
                                field: 0
                            },
                            start_ts: 1684333800,
                            is_live: 1,
                            type: 1,
                            team1_id: 252093,
                            team2_id: 262646,
                            is_stat_available: !1,
                            is_blocked: 0,
                            market: {
                                1220436099: {
                                    name: "Match Result",
                                    type: "P1XP2",
                                    express_id: 1,
                                    id: 1220436099,
                                    event: {
                                        3717122793: {
                                            price: 4.2,
                                            type: "P2",
                                            id: 3717122793,
                                            name: "W2",
                                            order: 2,
                                            type_1: "W2"
                                        },
                                        3717122794: {
                                            price: 4.33,
                                            type: "X",
                                            id: 3717122794,
                                            name: "Draw",
                                            order: 1,
                                            type_1: "X"
                                        },
                                        3717122795: {
                                            price: 1.72,
                                            type: "P1",
                                            id: 3717122795,
                                            name: "W1",
                                            order: 0,
                                            type_1: "W1"
                                        }
                                    }
                                }
                            }
                        }
                    }
                }, {
                    id: 9244,
                    name: "Serie D",
                    order: 3018,
                    game: {
                        22262720: {
                            id: 22262720,
                            region_alias: "Italy",
                            team1_name: "SSD Citta di Brindisi",
                            team2_name: "Catania",
                            markets_count: 88,
                            info: {
                                current_game_state: "set1",
                                current_game_time: "31",
                                add_minutes: "0",
                                stoppage_firsthalf: "02:00",
                                stoppage_secondhalf: "03:00",
                                score1: "0",
                                score2: "0",
                                pass_team: "none",
                                shirt1_color: "74A6E2",
                                shirt2_color: "FF0000",
                                short1_color: "FFFFFF",
                                short2_color: "3F3F3F",
                                field: 0
                            },
                            start_ts: 1684332e3,
                            is_live: 1,
                            type: 1,
                            team1_id: 96985,
                            team2_id: 976,
                            is_stat_available: !1,
                            favorite_order: null,
                            is_blocked: 0,
                            market: {
                                1220232747: {
                                    name: "Match Result",
                                    type: "P1XP2",
                                    express_id: 1,
                                    id: 1220232747,
                                    event: {
                                        3716519131: {
                                            price: 2.7,
                                            type: "P2",
                                            id: 3716519131,
                                            name: "W2",
                                            order: 2,
                                            type_1: "W2"
                                        },
                                        3716519132: {
                                            price: 3,
                                            type: "X",
                                            id: 3716519132,
                                            name: "Draw",
                                            order: 1,
                                            type_1: "X"
                                        },
                                        3716519133: {
                                            price: 2.8,
                                            type: "P1",
                                            id: 3716519133,
                                            name: "W1",
                                            order: 0,
                                            type_1: "W1"
                                        }
                                    }
                                }
                            }
                        },
                        22267549: {
                            id: 22267549,
                            region_alias: "Italy",
                            team1_name: "FC Legnago Salus",
                            team2_name: "AC Lumezzane",
                            markets_count: 91,
                            info: {
                                current_game_state: "set1",
                                current_game_time: "26",
                                add_minutes: "0",
                                stoppage_firsthalf: "02:00",
                                stoppage_secondhalf: "03:00",
                                score1: "0",
                                score2: "1",
                                pass_team: "none",
                                shirt1_color: "000000",
                                shirt2_color: "000000",
                                short1_color: "000000",
                                short2_color: "000000",
                                field: 0
                            },
                            start_ts: 1684332e3,
                            is_live: 1,
                            type: 1,
                            team1_id: 100337,
                            team2_id: 3882,
                            is_stat_available: !1,
                            is_blocked: 0,
                            market: {
                                1220695257: {
                                    name: "Match Result",
                                    type: "P1XP2",
                                    express_id: 1,
                                    id: 1220695257,
                                    event: {
                                        3717861808: {
                                            price: 1.8,
                                            type: "P2",
                                            id: 3717861808,
                                            name: "W2",
                                            order: 2,
                                            type_1: "W2"
                                        },
                                        3717861809: {
                                            price: 3.65,
                                            type: "X",
                                            id: 3717861809,
                                            name: "Draw",
                                            order: 1,
                                            type_1: "X"
                                        },
                                        3717861810: {
                                            price: 4.3,
                                            type: "P1",
                                            id: 3717861810,
                                            name: "W1",
                                            order: 0,
                                            type_1: "W1"
                                        }
                                    }
                                }
                            }
                        },
                        22267550: {
                            id: 22267550,
                            region_alias: "Italy",
                            team1_name: "AS Giana Erminio",
                            team2_name: "ASD Pineto Calcio",
                            markets_count: 38,
                            info: {
                                current_game_state: "set2",
                                current_game_time: "68",
                                add_minutes: "0",
                                stoppage_firsthalf: "02:00",
                                stoppage_secondhalf: "03:00",
                                score1: "2",
                                score2: "1",
                                pass_team: "none",
                                shirt1_color: "000000",
                                shirt2_color: "000000",
                                short1_color: "000000",
                                short2_color: "000000",
                                field: 0
                            },
                            start_ts: 1684328400,
                            is_live: 1,
                            type: 1,
                            team1_id: 100110,
                            team2_id: 276549,
                            is_stat_available: !1,
                            is_blocked: 0,
                            market: {
                                1220698561: {
                                    name: "Match Result",
                                    type: "P1XP2",
                                    express_id: 1,
                                    id: 1220698561,
                                    event: {
                                        3717871356: {
                                            price: 11,
                                            type: "P2",
                                            id: 3717871356,
                                            name: "W2",
                                            order: 2,
                                            type_1: "W2"
                                        },
                                        3717871357: {
                                            price: 4.55,
                                            type: "X",
                                            id: 3717871357,
                                            name: "Draw",
                                            order: 1,
                                            type_1: "X"
                                        },
                                        3717871358: {
                                            price: 1.33,
                                            type: "P1",
                                            id: 3717871358,
                                            name: "W1",
                                            order: 0,
                                            type_1: "W1"
                                        }
                                    }
                                }
                            }
                        }
                    }
                }, {
                    id: 27932,
                    name: "Campionato Primavera 1",
                    order: 3025,
                    game: {
                        22225651: {
                            id: 22225651,
                            region_alias: "Italy",
                            team1_name: "Hellas Verona U19",
                            team2_name: "AC Milan U19",
                            markets_count: 94,
                            info: {
                                current_game_state: "set1",
                                current_game_time: "30",
                                add_minutes: "0",
                                stoppage_firsthalf: "02:00",
                                stoppage_secondhalf: "03:00",
                                score1: "0",
                                score2: "0",
                                pass_team: "none",
                                shirt1_color: "000000",
                                shirt2_color: "000000",
                                short1_color: "000000",
                                short2_color: "000000",
                                field: 0
                            },
                            start_ts: 1684332e3,
                            is_live: 1,
                            type: 1,
                            team1_id: 15870,
                            team2_id: 16835,
                            is_stat_available: !0,
                            favorite_order: null,
                            is_blocked: 0,
                            market: {
                                1219538572: {
                                    name: "Match Result",
                                    type: "P1XP2",
                                    express_id: 1,
                                    id: 1219538572,
                                    event: {
                                        3714509031: {
                                            price: 2.42,
                                            type: "P2",
                                            id: 3714509031,
                                            name: "W2",
                                            order: 2,
                                            type_1: "W2"
                                        },
                                        3714509032: {
                                            price: 3.1,
                                            type: "X",
                                            id: 3714509032,
                                            name: "Draw",
                                            order: 1,
                                            type_1: "X"
                                        },
                                        3714509033: {
                                            price: 3.05,
                                            type: "P1",
                                            id: 3714509033,
                                            name: "W1",
                                            order: 0,
                                            type_1: "W1"
                                        }
                                    }
                                }
                            }
                        },
                        22225654: {
                            id: 22225654,
                            region_alias: "Italy",
                            team1_name: "SSC Napoli U19",
                            team2_name: "Fiorentina U19",
                            markets_count: 84,
                            info: {
                                current_game_state: "set1",
                                current_game_time: "30",
                                add_minutes: "0",
                                stoppage_firsthalf: "02:00",
                                stoppage_secondhalf: "03:00",
                                score1: "0",
                                score2: "0",
                                pass_team: "none",
                                shirt1_color: "000000",
                                shirt2_color: "000000",
                                short1_color: "000000",
                                short2_color: "000000",
                                field: 0
                            },
                            start_ts: 1684332e3,
                            is_live: 1,
                            type: 1,
                            team1_id: 15877,
                            team2_id: 19539,
                            is_stat_available: !0,
                            favorite_order: null,
                            is_blocked: 0,
                            market: {
                                1219538552: {
                                    name: "Match Result",
                                    type: "P1XP2",
                                    express_id: 1,
                                    id: 1219538552,
                                    event: {
                                        3714508989: {
                                            price: 1.95,
                                            type: "P2",
                                            id: 3714508989,
                                            name: "W2",
                                            order: 2,
                                            type_1: "W2"
                                        },
                                        3714508990: {
                                            price: 3.05,
                                            type: "X",
                                            id: 3714508990,
                                            name: "Draw",
                                            order: 1,
                                            type_1: "X"
                                        },
                                        3714508991: {
                                            price: 4.45,
                                            type: "P1",
                                            id: 3714508991,
                                            name: "W1",
                                            order: 0,
                                            type_1: "W1"
                                        }
                                    }
                                }
                            }
                        }
                    }
                }, {
                    id: 1874,
                    name: "U19 Bundesliga",
                    order: 4021,
                    game: {
                        22258242: {
                            id: 22258242,
                            region_alias: "Germany",
                            team1_name: "Bayern Munich U19",
                            team2_name: "Bayer 04 Leverkusen U19",
                            markets_count: 68,
                            info: {
                                current_game_state: "set1",
                                current_game_time: "28",
                                add_minutes: "0",
                                stoppage_firsthalf: "02:00",
                                stoppage_secondhalf: "03:00",
                                score1: "1",
                                score2: "0",
                                pass_team: "none",
                                shirt1_color: "000000",
                                shirt2_color: "000000",
                                short1_color: "000000",
                                short2_color: "000000",
                                field: 0
                            },
                            start_ts: 1684332e3,
                            is_live: 1,
                            type: 1,
                            team1_id: 16860,
                            team2_id: 16858,
                            is_stat_available: !0,
                            is_blocked: 0,
                            market: {
                                1220538495: {
                                    name: "Match Result",
                                    type: "P1XP2",
                                    express_id: 1,
                                    id: 1220538495,
                                    event: {
                                        3717413197: {
                                            price: 9,
                                            type: "P2",
                                            id: 3717413197,
                                            name: "W2",
                                            order: 2,
                                            type_1: "W2"
                                        },
                                        3717413198: {
                                            price: 6.4,
                                            type: "X",
                                            id: 3717413198,
                                            name: "Draw",
                                            order: 1,
                                            type_1: "X"
                                        },
                                        3717413199: {
                                            price: 1.25,
                                            type: "P1",
                                            id: 3717413199,
                                            name: "W1",
                                            order: 0,
                                            type_1: "W1"
                                        }
                                    }
                                }
                            }
                        }
                    }
                }, {
                    id: 18262644,
                    name: "U21 League Cup",
                    order: 68026,
                    game: {
                        22263673: {
                            id: 22263673,
                            region_alias: "Belgium",
                            team1_name: "KV Oostende U21",
                            team2_name: "Oud-Heverlee Leuven U21",
                            markets_count: 34,
                            info: {
                                current_game_state: "Half Time",
                                add_minutes: "0",
                                stoppage_firsthalf: "02:00",
                                stoppage_secondhalf: "03:00",
                                score1: "1",
                                score2: "0",
                                pass_team: "none",
                                shirt1_color: "FF0000",
                                shirt2_color: "FFFFFF",
                                short1_color: "FF0000",
                                short2_color: "FFFFFF",
                                field: 0
                            },
                            start_ts: 1684330200,
                            is_live: 1,
                            type: 1,
                            team1_id: 171617,
                            team2_id: 177611,
                            is_stat_available: !1,
                            is_blocked: 0,
                            market: {
                                1220205207: {
                                    name: "Match Result",
                                    type: "P1XP2",
                                    express_id: 1,
                                    id: 1220205207,
                                    event: {
                                        3716439949: {
                                            price: 6.8,
                                            type: "P2",
                                            id: 3716439949,
                                            name: "W2",
                                            order: 2,
                                            type_1: "W2"
                                        },
                                        3716439950: {
                                            price: 4.2,
                                            type: "X",
                                            id: 3716439950,
                                            name: "Draw",
                                            order: 1,
                                            type_1: "X"
                                        },
                                        3716439951: {
                                            price: 1.47,
                                            type: "P1",
                                            id: 3716439951,
                                            name: "W1",
                                            order: 0,
                                            type_1: "W1"
                                        }
                                    }
                                }
                            }
                        }
                    }
                }, {
                    id: 1675,
                    name: "Superliga",
                    order: 39004,
                    game: {
                        22225524: {
                            id: 22225524,
                            region_alias: "Albania",
                            team1_name: "KF Erzeni",
                            team2_name: "KF Bylis Ballsh",
                            markets_count: 32,
                            info: {
                                current_game_state: "set2",
                                current_game_time: "71",
                                add_minutes: "0",
                                stoppage_firsthalf: "01:00",
                                stoppage_secondhalf: "03:00",
                                score1: "0",
                                score2: "1",
                                pass_team: "none",
                                shirt1_color: "FF0000",
                                shirt2_color: "4F81BD",
                                short1_color: "FF0000",
                                short2_color: "4F81BD",
                                field: 0
                            },
                            start_ts: 1684328400,
                            is_live: 1,
                            type: 1,
                            team1_id: 222571,
                            team2_id: 8301,
                            is_stat_available: !0,
                            favorite_order: null,
                            is_blocked: 0,
                            market: {
                                1219717698: {
                                    name: "Match Result",
                                    type: "P1XP2",
                                    express_id: 1,
                                    id: 1219717698,
                                    event: {
                                        3715029005: {
                                            price: 1.3,
                                            type: "P2",
                                            id: 3715029005,
                                            name: "W2",
                                            order: 2,
                                            type_1: "W2"
                                        },
                                        3715029006: {
                                            price: 4.05,
                                            type: "X",
                                            id: 3715029006,
                                            name: "Draw",
                                            order: 1,
                                            type_1: "X"
                                        },
                                        3715029007: {
                                            price: 17,
                                            type: "P1",
                                            id: 3715029007,
                                            name: "W1",
                                            order: 0,
                                            type_1: "W1"
                                        }
                                    }
                                }
                            }
                        },
                        22225526: {
                            id: 22225526,
                            region_alias: "Albania",
                            team1_name: "FK Kukesi",
                            team2_name: "KF Laci",
                            markets_count: 38,
                            info: {
                                current_game_state: "set2",
                                current_game_time: "69",
                                add_minutes: "0",
                                stoppage_firsthalf: "02:00",
                                stoppage_secondhalf: "03:00",
                                score1: "1",
                                score2: "0",
                                pass_team: "none",
                                shirt1_color: "000000",
                                shirt2_color: "000000",
                                short1_color: "000000",
                                short2_color: "000000",
                                field: 0
                            },
                            start_ts: 1684328400,
                            is_live: 1,
                            type: 1,
                            team1_id: 8307,
                            team2_id: 8306,
                            is_stat_available: !0,
                            favorite_order: null,
                            is_blocked: 0,
                            market: {
                                1219719126: {
                                    name: "Match Result",
                                    type: "P1XP2",
                                    express_id: 1,
                                    id: 1219719126,
                                    event: {
                                        3715032926: {
                                            price: 11,
                                            type: "P2",
                                            id: 3715032926,
                                            name: "W2",
                                            order: 2,
                                            type_1: "W2"
                                        },
                                        3715032927: {
                                            price: 4.25,
                                            type: "X",
                                            id: 3715032927,
                                            name: "Draw",
                                            order: 1,
                                            type_1: "X"
                                        },
                                        3715032928: {
                                            price: 1.35,
                                            type: "P1",
                                            id: 3715032928,
                                            name: "W1",
                                            order: 0,
                                            type_1: "W1"
                                        }
                                    }
                                }
                            }
                        }
                    }
                }, {
                    id: 18281810,
                    name: "Reserve League",
                    order: 46039,
                    game: {
                        22225650: {
                            id: 22225650,
                            region_alias: "Argentina",
                            team1_name: "Gimnasia y Esgrima La Plata (Reserves)",
                            team2_name: "Godoy Cruz AT (Reserves)",
                            markets_count: 53,
                            info: {
                                current_game_state: "set1",
                                current_game_time: "28",
                                add_minutes: "0",
                                stoppage_firsthalf: "02:00",
                                stoppage_secondhalf: "03:00",
                                score1: "1",
                                score2: "0",
                                pass_team: "none",
                                shirt1_color: "FFFFFF",
                                shirt2_color: "1F497D",
                                short1_color: "FFFFFF",
                                short2_color: "1F497D",
                                field: 0
                            },
                            start_ts: 1684332e3,
                            is_live: 1,
                            type: 1,
                            team1_id: 192370,
                            team2_id: 176558,
                            is_stat_available: !0,
                            is_blocked: 0,
                            market: {
                                1219538521: {
                                    name: "Match Result",
                                    type: "P1XP2",
                                    express_id: 1,
                                    id: 1219538521,
                                    event: {
                                        3714508916: {
                                            price: 14,
                                            type: "P2",
                                            id: 3714508916,
                                            name: "W2",
                                            order: 2,
                                            type_1: "W2"
                                        },
                                        3714508919: {
                                            price: 6.6,
                                            type: "X",
                                            id: 3714508919,
                                            name: "Draw",
                                            order: 1,
                                            type_1: "X"
                                        },
                                        3714508921: {
                                            price: 1.2,
                                            type: "P1",
                                            id: 3714508921,
                                            name: "W1",
                                            order: 0,
                                            type_1: "W1"
                                        }
                                    }
                                }
                            }
                        },
                        22225652: {
                            id: 22225652,
                            region_alias: "Argentina",
                            team1_name: "CA Banfield (Reserves)",
                            team2_name: "Estudiantes La Plata (Reserves)",
                            markets_count: 48,
                            info: {
                                current_game_state: "set1",
                                current_game_time: "30",
                                add_minutes: "0",
                                stoppage_firsthalf: "02:00",
                                stoppage_secondhalf: "03:00",
                                score1: "0",
                                score2: "1",
                                pass_team: "none",
                                shirt1_color: "008000",
                                shirt2_color: "FF0000",
                                short1_color: "008000",
                                short2_color: "000000",
                                field: 0
                            },
                            start_ts: 1684332e3,
                            is_live: 1,
                            type: 1,
                            team1_id: 179778,
                            team2_id: 193452,
                            is_stat_available: !0,
                            is_blocked: 0,
                            market: {
                                1219538589: {
                                    name: "Match Result",
                                    type: "P1XP2",
                                    express_id: 1,
                                    id: 1219538589,
                                    event: {
                                        3714509101: {
                                            price: 1.7,
                                            type: "P2",
                                            id: 3714509101,
                                            name: "W2",
                                            order: 2,
                                            type_1: "W2"
                                        },
                                        3714509102: {
                                            price: 3.55,
                                            type: "X",
                                            id: 3714509102,
                                            name: "Draw",
                                            order: 1,
                                            type_1: "X"
                                        },
                                        3714509103: {
                                            price: 5.1,
                                            type: "P1",
                                            id: 3714509103,
                                            name: "W1",
                                            order: 0,
                                            type_1: "W1"
                                        }
                                    }
                                }
                            }
                        },
                        22225653: {
                            id: 22225653,
                            region_alias: "Argentina",
                            team1_name: "Newells Old Boys (Reserves)",
                            team2_name: "CA Lanus (Reserves)",
                            markets_count: 46,
                            info: {
                                current_game_state: "set1",
                                current_game_time: "27",
                                add_minutes: "0",
                                stoppage_firsthalf: "02:00",
                                stoppage_secondhalf: "03:00",
                                score1: "0",
                                score2: "0",
                                pass_team: "none",
                                shirt1_color: "8B0000",
                                shirt2_color: "FFFFFF",
                                short1_color: "000000",
                                short2_color: "FFFFFF",
                                field: 0
                            },
                            start_ts: 1684332e3,
                            is_live: 1,
                            type: 1,
                            team1_id: 192569,
                            team2_id: 175921,
                            is_stat_available: !0,
                            is_blocked: 0,
                            market: {
                                1219538522: {
                                    name: "Match Result",
                                    type: "P1XP2",
                                    express_id: 1,
                                    id: 1219538522,
                                    event: {
                                        3714508922: {
                                            price: 3,
                                            type: "P2",
                                            id: 3714508922,
                                            name: "W2",
                                            order: 2,
                                            type_1: "W2"
                                        },
                                        3714508923: {
                                            price: 2.95,
                                            type: "X",
                                            id: 3714508923,
                                            name: "Draw",
                                            order: 1,
                                            type_1: "X"
                                        },
                                        3714508924: {
                                            price: 2.55,
                                            type: "P1",
                                            id: 3714508924,
                                            name: "W1",
                                            order: 0,
                                            type_1: "W1"
                                        }
                                    }
                                }
                            }
                        },
                        22245286: {
                            id: 22245286,
                            region_alias: "Argentina",
                            team1_name: "Deportivo Riestra (Reserves)",
                            team2_name: "CA Defensores Unidos (Reserves)",
                            markets_count: 53,
                            info: {
                                current_game_state: "set1",
                                current_game_time: "26",
                                add_minutes: "0",
                                stoppage_firsthalf: "02:00",
                                stoppage_secondhalf: "03:00",
                                score1: "1",
                                score2: "0",
                                pass_team: "none",
                                shirt1_color: "0C0C0C",
                                shirt2_color: "CBAFED",
                                short1_color: "0C0C0C",
                                short2_color: "CBAFED",
                                field: 0
                            },
                            start_ts: 1684332e3,
                            is_live: 1,
                            type: 1,
                            team1_id: 211225,
                            team2_id: 442339,
                            is_stat_available: !1,
                            is_blocked: 0,
                            market: {
                                1220077438: {
                                    name: "Match Result",
                                    type: "P1XP2",
                                    express_id: 1,
                                    id: 1220077438,
                                    event: {
                                        3716078222: {
                                            price: 13,
                                            type: "P2",
                                            id: 3716078222,
                                            name: "W2",
                                            order: 2,
                                            type_1: "W2"
                                        },
                                        3716078223: {
                                            price: 5.8,
                                            type: "X",
                                            id: 3716078223,
                                            name: "Draw",
                                            order: 1,
                                            type_1: "X"
                                        },
                                        3716078224: {
                                            price: 1.23,
                                            type: "P1",
                                            id: 3716078224,
                                            name: "W1",
                                            order: 0,
                                            type_1: "W1"
                                        }
                                    }
                                }
                            }
                        }
                    }
                }, {
                    id: 10895,
                    name: "U20 Campeonato Carioca",
                    order: 40010,
                    game: {
                        22226139: {
                            id: 22226139,
                            region_alias: "Brazil",
                            team1_name: "Volta Redonda FC U20",
                            team2_name: "Regatas Flamengo RJ U20",
                            markets_count: 27,
                            info: {
                                current_game_state: "Half Time",
                                add_minutes: "0",
                                stoppage_firsthalf: "01:00",
                                stoppage_secondhalf: "03:00",
                                score1: "1",
                                score2: "1",
                                pass_team: "none",
                                shirt1_color: "000000",
                                shirt2_color: "000000",
                                short1_color: "000000",
                                short2_color: "000000",
                                field: 0
                            },
                            start_ts: 1684330200,
                            is_live: 1,
                            type: 1,
                            team1_id: 211914,
                            team2_id: 175494,
                            is_stat_available: !1,
                            is_blocked: 0,
                            market: {
                                1220720116: {
                                    name: "Match Result",
                                    type: "P1XP2",
                                    express_id: 1,
                                    id: 1220720116,
                                    event: {
                                        3717932570: {
                                            price: 2.2,
                                            type: "P2",
                                            id: 3717932570,
                                            name: "W2",
                                            order: 2,
                                            type_1: "W2"
                                        },
                                        3717932572: {
                                            price: 3.85,
                                            type: "P1",
                                            id: 3717932572,
                                            name: "W1",
                                            order: 0,
                                            type_1: "W1"
                                        },
                                        3717932573: {
                                            price: 2.85,
                                            type: "X",
                                            id: 3717932573,
                                            name: "Draw",
                                            order: 1,
                                            type_1: "X"
                                        }
                                    }
                                }
                            }
                        }
                    }
                }, {
                    id: 4717,
                    name: "U19 League",
                    order: 138015,
                    game: {
                        22266053: {
                            id: 22266053,
                            region_alias: "Czech Republic",
                            team1_name: "FK Admira Praha U19",
                            team2_name: "AC Sparta Praha B U19",
                            markets_count: 33,
                            info: {
                                current_game_state: "set1",
                                current_game_time: "41",
                                add_minutes: "0",
                                stoppage_firsthalf: "02:00",
                                stoppage_secondhalf: "03:00",
                                score1: "0",
                                score2: "0",
                                pass_team: "none",
                                shirt1_color: "000000",
                                shirt2_color: "000000",
                                short1_color: "000000",
                                short2_color: "000000",
                                field: 0
                            },
                            start_ts: 1684331100,
                            is_live: 1,
                            type: 1,
                            team1_id: 372743,
                            team2_id: 373936,
                            is_stat_available: !1,
                            is_blocked: 0,
                            market: {
                                1220751744: {
                                    name: "Match Result",
                                    type: "P1XP2",
                                    express_id: 1,
                                    id: 1220751744,
                                    event: {
                                        3718023955: {
                                            price: 2.45,
                                            type: "P2",
                                            id: 3718023955,
                                            name: "W2",
                                            order: 2,
                                            type_1: "W2"
                                        },
                                        3718023957: {
                                            price: 2.85,
                                            type: "P1",
                                            id: 3718023957,
                                            name: "W1",
                                            order: 0,
                                            type_1: "W1"
                                        },
                                        3718023958: {
                                            price: 3.3,
                                            type: "X",
                                            id: 3718023958,
                                            name: "Draw",
                                            order: 1,
                                            type_1: "X"
                                        }
                                    }
                                }
                            }
                        }
                    }
                }, {
                    id: 9308,
                    name: "Division 2",
                    order: 145003,
                    game: {
                        22255050: {
                            id: 22255050,
                            region_alias: "Egypt",
                            team1_name: "Helal Aldaba",
                            team2_name: "Abu Qir Semad FC",
                            markets_count: 78,
                            info: {
                                current_game_state: "set1",
                                current_game_time: "26",
                                add_minutes: "0",
                                stoppage_firsthalf: "03:00",
                                stoppage_secondhalf: "03:00",
                                score1: "1",
                                score2: "1",
                                pass_team: "none",
                                shirt1_color: "4F81BD",
                                shirt2_color: "000000",
                                short1_color: "4F81BD",
                                short2_color: "000000",
                                field: 0
                            },
                            start_ts: 1684332e3,
                            is_live: 1,
                            type: 1,
                            team1_id: 783420,
                            team2_id: 198645,
                            is_stat_available: !1,
                            is_blocked: 0,
                            market: {
                                1219301106: {
                                    name: "Match Result",
                                    type: "P1XP2",
                                    express_id: 1,
                                    id: 1219301106,
                                    event: {
                                        3713823705: {
                                            price: 2.4,
                                            type: "P2",
                                            id: 3713823705,
                                            name: "W2",
                                            order: 2,
                                            type_1: "W2"
                                        },
                                        3713823706: {
                                            price: 2.75,
                                            type: "X",
                                            id: 3713823706,
                                            name: "Draw",
                                            order: 1,
                                            type_1: "X"
                                        },
                                        3713823707: {
                                            price: 3.5,
                                            type: "P1",
                                            id: 3713823707,
                                            name: "W1",
                                            order: 0,
                                            type_1: "W1"
                                        }
                                    }
                                }
                            }
                        },
                        22263666: {
                            id: 22263666,
                            region_alias: "Egypt",
                            team1_name: "Gomhoreyet Shebeen",
                            team2_name: "Baladiyet El Mahalla SC",
                            markets_count: 77,
                            info: {
                                current_game_state: "set1",
                                current_game_time: "26",
                                add_minutes: "0",
                                stoppage_firsthalf: "02:00",
                                stoppage_secondhalf: "03:00",
                                score1: "0",
                                score2: "0",
                                pass_team: "none",
                                shirt1_color: "000000",
                                shirt2_color: "000000",
                                short1_color: "000000",
                                short2_color: "000000",
                                field: 0
                            },
                            start_ts: 1684332e3,
                            is_live: 1,
                            type: 1,
                            team1_id: 193802,
                            team2_id: 193800,
                            is_stat_available: !1,
                            is_blocked: 0,
                            market: {
                                1220207944: {
                                    name: "Match Result",
                                    type: "P1XP2",
                                    express_id: 1,
                                    id: 1220207944,
                                    event: {
                                        3716447701: {
                                            price: 2.75,
                                            type: "P2",
                                            id: 3716447701,
                                            name: "W2",
                                            order: 2,
                                            type_1: "W2"
                                        },
                                        3716447702: {
                                            price: 2.45,
                                            type: "X",
                                            id: 3716447702,
                                            name: "Draw",
                                            order: 1,
                                            type_1: "X"
                                        },
                                        3716447703: {
                                            price: 3.4,
                                            type: "P1",
                                            id: 3716447703,
                                            name: "W1",
                                            order: 0,
                                            type_1: "W1"
                                        }
                                    }
                                }
                            }
                        },
                        22263672: {
                            id: 22263672,
                            region_alias: "Egypt",
                            team1_name: "Tanta FC",
                            team2_name: "El Olympi",
                            markets_count: 80,
                            info: {
                                current_game_state: "set1",
                                current_game_time: "27",
                                add_minutes: "0",
                                stoppage_firsthalf: "02:00",
                                stoppage_secondhalf: "03:00",
                                score1: "0",
                                score2: "1",
                                pass_team: "none",
                                shirt1_color: "FFFF00",
                                shirt2_color: "FF0000",
                                short1_color: "FFFF00",
                                short2_color: "FF0000",
                                field: 0
                            },
                            start_ts: 1684332e3,
                            is_live: 1,
                            type: 1,
                            team1_id: 231750,
                            team2_id: 236356,
                            is_stat_available: !1,
                            is_blocked: 1,
                            market: {
                                1220207945: {
                                    name: "Match Result",
                                    type: "P1XP2",
                                    express_id: 1,
                                    id: 1220207945,
                                    event: {
                                        3716447704: {
                                            price: 2.6,
                                            type: "P2",
                                            id: 3716447704,
                                            name: "W2",
                                            order: 2,
                                            type_1: "W2"
                                        },
                                        3716447705: {
                                            price: 3.05,
                                            type: "X",
                                            id: 3716447705,
                                            name: "Draw",
                                            order: 1,
                                            type_1: "X"
                                        },
                                        3716447706: {
                                            price: 2.9,
                                            type: "P1",
                                            id: 3716447706,
                                            name: "W1",
                                            order: 0,
                                            type_1: "W1"
                                        }
                                    }
                                }
                            }
                        },
                        22263689: {
                            id: 22263689,
                            region_alias: "Egypt",
                            team1_name: "Dekernes SC",
                            team2_name: "Pioneers Club",
                            markets_count: 85,
                            info: {
                                current_game_state: "set1",
                                current_game_time: "15",
                                add_minutes: "0",
                                stoppage_firsthalf: "02:00",
                                stoppage_secondhalf: "03:00",
                                score1: "0",
                                score2: "0",
                                pass_team: "none",
                                shirt1_color: "FF0000",
                                shirt2_color: "FFFFFF",
                                short1_color: "FF0000",
                                short2_color: "FFFFFF",
                                field: 0
                            },
                            start_ts: 1684332e3,
                            is_live: 1,
                            type: 1,
                            team1_id: 193803,
                            team2_id: 693777,
                            is_stat_available: !1,
                            is_blocked: 1,
                            market: {
                                1220195219: {
                                    name: "Match Result",
                                    type: "P1XP2",
                                    express_id: 1,
                                    id: 1220195219,
                                    event: {
                                        3716412138: {
                                            price: 3.8,
                                            type: "P2",
                                            id: 3716412138,
                                            name: "W2",
                                            order: 2,
                                            type_1: "W2"
                                        },
                                        3716412139: {
                                            price: 2.7,
                                            type: "X",
                                            id: 3716412139,
                                            name: "Draw",
                                            order: 1,
                                            type_1: "X"
                                        },
                                        3716412140: {
                                            price: 2.3,
                                            type: "P1",
                                            id: 3716412140,
                                            name: "W1",
                                            order: 0,
                                            type_1: "W1"
                                        }
                                    }
                                }
                            }
                        },
                        22263690: {
                            id: 22263690,
                            region_alias: "Egypt",
                            team1_name: "Al Magd",
                            team2_name: "Al Hammam",
                            markets_count: 85,
                            info: {
                                current_game_state: "set1",
                                current_game_time: "23",
                                add_minutes: "0",
                                stoppage_firsthalf: "02:00",
                                stoppage_secondhalf: "03:00",
                                score1: "0",
                                score2: "0",
                                pass_team: "none",
                                shirt1_color: "0000FF",
                                shirt2_color: "FF0000",
                                short1_color: "0000FF",
                                short2_color: "FF0000",
                                field: 0
                            },
                            start_ts: 1684332e3,
                            is_live: 1,
                            type: 1,
                            team1_id: 688641,
                            team2_id: 198646,
                            is_stat_available: !1,
                            is_blocked: 0,
                            market: {
                                1220195220: {
                                    name: "Match Result",
                                    type: "P1XP2",
                                    express_id: 1,
                                    id: 1220195220,
                                    event: {
                                        3716412141: {
                                            price: 4.35,
                                            type: "P2",
                                            id: 3716412141,
                                            name: "W2",
                                            order: 2,
                                            type_1: "W2"
                                        },
                                        3716412142: {
                                            price: 3,
                                            type: "X",
                                            id: 3716412142,
                                            name: "Draw",
                                            order: 1,
                                            type_1: "X"
                                        },
                                        3716412143: {
                                            price: 2,
                                            type: "P1",
                                            id: 3716412143,
                                            name: "W1",
                                            order: 0,
                                            type_1: "W1"
                                        }
                                    }
                                }
                            }
                        },
                        22264261: {
                            id: 22264261,
                            region_alias: "Egypt",
                            team1_name: "Nabrouh",
                            team2_name: "Al Mansoura",
                            markets_count: 78,
                            info: {
                                current_game_state: "set1",
                                current_game_time: "21",
                                add_minutes: "0",
                                stoppage_firsthalf: "02:00",
                                stoppage_secondhalf: "03:00",
                                score1: "0",
                                score2: "0",
                                pass_team: "none",
                                shirt1_color: "000000",
                                shirt2_color: "000000",
                                short1_color: "000000",
                                short2_color: "000000",
                                field: 0
                            },
                            start_ts: 1684332300,
                            is_live: 1,
                            type: 1,
                            team1_id: 193804,
                            team2_id: 193805,
                            is_stat_available: !1,
                            is_blocked: 0,
                            market: {
                                1220761372: {
                                    name: "Match Result",
                                    type: "P1XP2",
                                    express_id: 1,
                                    id: 1220761372,
                                    event: {
                                        3718055574: {
                                            price: 2.3,
                                            type: "X",
                                            id: 3718055574,
                                            name: "Draw",
                                            order: 1,
                                            type_1: "X"
                                        },
                                        3718055575: {
                                            price: 3.1,
                                            type: "P1",
                                            id: 3718055575,
                                            name: "W1",
                                            order: 0,
                                            type_1: "W1"
                                        },
                                        3718055577: {
                                            price: 3.25,
                                            type: "P2",
                                            id: 3718055577,
                                            name: "W2",
                                            order: 2,
                                            type_1: "W2"
                                        }
                                    }
                                }
                            }
                        }
                    }
                }, {
                    id: 11136,
                    name: "Kolmonen",
                    order: 154008,
                    game: {
                        22205427: {
                            id: 22205427,
                            region_alias: "Finland",
                            team1_name: "Tervarit Juniorit",
                            team2_name: "HauPa",
                            markets_count: 15,
                            info: {
                                current_game_state: "notstarted",
                                current_game_time: "0",
                                add_minutes: "0",
                                stoppage_firsthalf: "02:00",
                                stoppage_secondhalf: "03:00",
                                score1: "0",
                                score2: "0",
                                pass_team: "none",
                                shirt1_color: "000000",
                                shirt2_color: "000000",
                                short1_color: "000000",
                                short2_color: "000000",
                                field: 0
                            },
                            start_ts: 1684333800,
                            is_live: 1,
                            type: 1,
                            team1_id: 12987,
                            team2_id: 100223,
                            is_stat_available: !1,
                            is_blocked: 0,
                            market: {
                                1220500611: {
                                    name: "Match Result",
                                    type: "P1XP2",
                                    express_id: 1,
                                    id: 1220500611,
                                    event: {
                                        3717307630: {
                                            price: 1.3,
                                            type: "P2",
                                            id: 3717307630,
                                            name: "W2",
                                            order: 2,
                                            type_1: "W2"
                                        },
                                        3717307631: {
                                            price: 6.9,
                                            type: "X",
                                            id: 3717307631,
                                            name: "Draw",
                                            order: 1,
                                            type_1: "X"
                                        },
                                        3717307632: {
                                            price: 7.4,
                                            type: "P1",
                                            id: 3717307632,
                                            name: "W1",
                                            order: 0,
                                            type_1: "W1"
                                        }
                                    }
                                }
                            }
                        }
                    }
                }, {
                    id: 9237,
                    name: "Gamma Ethniki",
                    order: 161003,
                    game: {
                        22264271: {
                            id: 22264271,
                            region_alias: "Greece",
                            team1_name: "Iraklis Ammoudias",
                            team2_name: "Doxa Neo Sidirochori FC",
                            markets_count: 99,
                            info: {
                                current_game_state: "set1",
                                current_game_time: "28",
                                add_minutes: "0",
                                stoppage_firsthalf: "02:00",
                                stoppage_secondhalf: "03:00",
                                score1: "0",
                                score2: "0",
                                pass_team: "none",
                                shirt1_color: "000000",
                                shirt2_color: "000000",
                                short1_color: "000000",
                                short2_color: "000000",
                                field: 0
                            },
                            start_ts: 1684332e3,
                            is_live: 1,
                            type: 1,
                            team1_id: 736523,
                            team2_id: 383397,
                            is_stat_available: !1,
                            is_blocked: 0,
                            market: {
                                1220698286: {
                                    name: "Match Result",
                                    type: "P1XP2",
                                    express_id: 1,
                                    id: 1220698286,
                                    event: {
                                        3717870619: {
                                            price: 3.45,
                                            type: "X",
                                            id: 3717870619,
                                            name: "Draw",
                                            order: 1,
                                            type_1: "X"
                                        },
                                        3717870620: {
                                            price: 2.25,
                                            type: "P1",
                                            id: 3717870620,
                                            name: "W1",
                                            order: 0,
                                            type_1: "W1"
                                        },
                                        3717870622: {
                                            price: 3.05,
                                            type: "P2",
                                            id: 3717870622,
                                            name: "W2",
                                            order: 2,
                                            type_1: "W2"
                                        }
                                    }
                                }
                            }
                        },
                        22264273: {
                            id: 22264273,
                            region_alias: "Greece",
                            team1_name: "Thriamvos Lourou",
                            team2_name: "PAS Thyella Katsikas",
                            markets_count: 92,
                            info: {
                                current_game_state: "set1",
                                current_game_time: "29",
                                add_minutes: "0",
                                stoppage_firsthalf: "02:00",
                                stoppage_secondhalf: "03:00",
                                score1: "0",
                                score2: "0",
                                pass_team: "none",
                                shirt1_color: "000000",
                                shirt2_color: "000000",
                                short1_color: "000000",
                                short2_color: "000000",
                                field: 0
                            },
                            start_ts: 1684332e3,
                            is_live: 1,
                            type: 1,
                            team1_id: 831828,
                            team2_id: 612685,
                            is_stat_available: !1,
                            is_blocked: 1,
                            market: {
                                1220762424: {
                                    name: "Match Result",
                                    type: "P1XP2",
                                    express_id: 1,
                                    id: 1220762424,
                                    event: {
                                        3718058613: {
                                            price: 3.4,
                                            type: "X",
                                            id: 3718058613,
                                            name: "Draw",
                                            order: 1,
                                            type_1: "X"
                                        },
                                        3718058614: {
                                            price: 3.6,
                                            type: "P1",
                                            id: 3718058614,
                                            name: "W1",
                                            order: 0,
                                            type_1: "W1"
                                        },
                                        3718058616: {
                                            price: 2.03,
                                            type: "P2",
                                            id: 3718058616,
                                            name: "W2",
                                            order: 2,
                                            type_1: "W2"
                                        }
                                    }
                                }
                            }
                        }
                    }
                }, {
                    id: 11116,
                    name: "Azadegan League",
                    order: 175002,
                    game: {
                        22257391: {
                            id: 22257391,
                            region_alias: "Iran",
                            team1_name: "Arman Gohar Sirjan",
                            team2_name: "Shams Azar",
                            markets_count: 64,
                            info: {
                                current_game_state: "notstarted",
                                current_game_time: "0",
                                add_minutes: "0",
                                stoppage_firsthalf: "02:00",
                                stoppage_secondhalf: "03:00",
                                score1: "0",
                                score2: "0",
                                pass_team: "none",
                                shirt1_color: "000000",
                                shirt2_color: "000000",
                                short1_color: "000000",
                                short2_color: "000000",
                                field: 0
                            },
                            start_ts: 1684333800,
                            is_live: 1,
                            type: 1,
                            team1_id: 455328,
                            team2_id: 638771,
                            is_stat_available: !0,
                            favorite_order: null,
                            is_blocked: 0,
                            market: {
                                1220481555: {
                                    name: "Match Result",
                                    type: "P1XP2",
                                    express_id: 1,
                                    id: 1220481555,
                                    event: {
                                        3717254364: {
                                            price: 1.65,
                                            type: "P2",
                                            id: 3717254364,
                                            name: "W2",
                                            order: 2,
                                            type_1: "W2"
                                        },
                                        3717254365: {
                                            price: 3.82,
                                            type: "X",
                                            id: 3717254365,
                                            name: "Draw",
                                            order: 1,
                                            type_1: "X"
                                        },
                                        3717254366: {
                                            price: 5.4,
                                            type: "P1",
                                            id: 3717254366,
                                            name: "W1",
                                            order: 0,
                                            type_1: "W1"
                                        }
                                    }
                                }
                            }
                        },
                        22257394: {
                            id: 22257394,
                            region_alias: "Iran",
                            team1_name: "Khalij Fars Mahshahr",
                            team2_name: "FC Chokay Talesh",
                            markets_count: 59,
                            info: {
                                current_game_state: "notstarted",
                                current_game_time: "0",
                                add_minutes: "0",
                                stoppage_firsthalf: "02:00",
                                stoppage_secondhalf: "03:00",
                                score1: "0",
                                score2: "0",
                                pass_team: "none",
                                shirt1_color: "FF0000",
                                shirt2_color: "90EE90",
                                short1_color: "FF0000",
                                short2_color: "90EE90",
                                field: 0
                            },
                            start_ts: 1684333800,
                            is_live: 1,
                            type: 1,
                            team1_id: 697676,
                            team2_id: 437058,
                            is_stat_available: !0,
                            favorite_order: null,
                            is_blocked: 0,
                            market: {
                                1220481562: {
                                    name: "Match Result",
                                    type: "P1XP2",
                                    express_id: 1,
                                    id: 1220481562,
                                    event: {
                                        3717254399: {
                                            price: 3.16,
                                            type: "P2",
                                            id: 3717254399,
                                            name: "W2",
                                            order: 2,
                                            type_1: "W2"
                                        },
                                        3717254400: {
                                            price: 2.8,
                                            type: "X",
                                            id: 3717254400,
                                            name: "Draw",
                                            order: 1,
                                            type_1: "X"
                                        },
                                        3717254401: {
                                            price: 2.66,
                                            type: "P1",
                                            id: 3717254401,
                                            name: "W1",
                                            order: 0,
                                            type_1: "W1"
                                        }
                                    }
                                }
                            }
                        }
                    }
                }, {
                    id: 1907,
                    name: "Iraqi Premier League",
                    order: 176001,
                    game: {
                        22263679: {
                            id: 22263679,
                            region_alias: "Iraq",
                            team1_name: "Al Qasim SC",
                            team2_name: "Karbala FC",
                            markets_count: 40,
                            info: {
                                current_game_state: "Half Time",
                                add_minutes: "0",
                                stoppage_firsthalf: "02:00",
                                stoppage_secondhalf: "03:00",
                                score1: "1",
                                score2: "0",
                                pass_team: "none",
                                shirt1_color: "0C0C0C",
                                shirt2_color: "FFFFFF",
                                short1_color: "0C0C0C",
                                short2_color: "FFFFFF",
                                field: 0
                            },
                            start_ts: 1684330200,
                            is_live: 1,
                            type: 1,
                            team1_id: 519049,
                            team2_id: 14401,
                            is_stat_available: !1,
                            is_blocked: 0,
                            market: {
                                1220613291: {
                                    name: "Match Result",
                                    type: "P1XP2",
                                    express_id: 1,
                                    id: 1220613291,
                                    event: {
                                        3717628050: {
                                            price: 13,
                                            type: "P2",
                                            id: 3717628050,
                                            name: "W2",
                                            order: 2,
                                            type_1: "W2"
                                        },
                                        3717628051: {
                                            price: 5.6,
                                            type: "X",
                                            id: 3717628051,
                                            name: "Draw",
                                            order: 1,
                                            type_1: "X"
                                        },
                                        3717628052: {
                                            price: 1.23,
                                            type: "P1",
                                            id: 3717628052,
                                            name: "W1",
                                            order: 0,
                                            type_1: "W1"
                                        }
                                    }
                                }
                            }
                        }
                    }
                }, {
                    id: 4857,
                    name: "Kazakhstan Cup",
                    order: 186003,
                    game: {
                        22180046: {
                            id: 22180046,
                            region_alias: "Kazakhstan",
                            team1_name: "FC Kairat Almaty",
                            team2_name: "FC Atyrau",
                            markets_count: 39,
                            info: {
                                current_game_state: "set2",
                                current_game_time: "66",
                                add_minutes: "0",
                                stoppage_firsthalf: "02:00",
                                stoppage_secondhalf: "03:00",
                                score1: "1",
                                score2: "0",
                                pass_team: "none",
                                shirt1_color: "FFFF00",
                                shirt2_color: "008000",
                                short1_color: "FFFF00",
                                short2_color: "000000",
                                field: 0
                            },
                            start_ts: 1684328400,
                            is_live: 1,
                            type: 1,
                            team1_id: 5798,
                            team2_id: 5807,
                            is_stat_available: !0,
                            is_blocked: 0,
                            market: {
                                1219786126: {
                                    name: "Match Result",
                                    type: "P1XP2",
                                    express_id: 1,
                                    id: 1219786126,
                                    event: {
                                        3715224284: {
                                            price: 15,
                                            type: "P2",
                                            id: 3715224284,
                                            name: "W2",
                                            order: 2,
                                            type_1: "W2"
                                        },
                                        3715224285: {
                                            price: 5.4,
                                            type: "X",
                                            id: 3715224285,
                                            name: "Draw",
                                            order: 1,
                                            type_1: "X"
                                        },
                                        3715224286: {
                                            price: 1.23,
                                            type: "P1",
                                            id: 3715224286,
                                            name: "W1",
                                            order: 0,
                                            type_1: "W1"
                                        }
                                    }
                                }
                            }
                        }
                    }
                }, {
                    id: 1939,
                    name: "Virsliga",
                    order: 193001,
                    game: {
                        22162327: {
                            id: 22162327,
                            region_alias: "Latvia",
                            team1_name: "FK Tukums 2000/Telms",
                            team2_name: "Valmiera FC",
                            markets_count: 94,
                            info: {
                                current_game_state: "set1",
                                current_game_time: "30",
                                add_minutes: "0",
                                stoppage_firsthalf: "02:00",
                                stoppage_secondhalf: "03:00",
                                score1: "0",
                                score2: "0",
                                pass_team: "none",
                                shirt1_color: "587816",
                                shirt2_color: "FFFF00",
                                short1_color: "587816",
                                short2_color: "FFFF00",
                                field: 0
                            },
                            start_ts: 1684332e3,
                            is_live: 1,
                            type: 1,
                            team1_id: 13135,
                            team2_id: 12975,
                            is_stat_available: !0,
                            favorite_order: null,
                            is_blocked: 0,
                            market: {
                                1219099796: {
                                    name: "Match Result",
                                    type: "P1XP2",
                                    express_id: 1,
                                    id: 1219099796,
                                    event: {
                                        3713221998: {
                                            price: 1.5,
                                            type: "P2",
                                            id: 3713221998,
                                            name: "W2",
                                            order: 2,
                                            type_1: "W2"
                                        },
                                        3713221999: {
                                            price: 4.1,
                                            type: "X",
                                            id: 3713221999,
                                            name: "Draw",
                                            order: 1,
                                            type_1: "X"
                                        },
                                        3713222e3: {
                                            price: 6.4,
                                            type: "P1",
                                            id: 3713222e3,
                                            name: "W1",
                                            order: 0,
                                            type_1: "W1"
                                        }
                                    }
                                }
                            }
                        }
                    }
                }, {
                    id: 9255,
                    name: "Division Intermedia",
                    order: 235002,
                    game: {
                        22240548: {
                            id: 22240548,
                            region_alias: "Paraguay",
                            team1_name: "Atletico Colegiales",
                            team2_name: "12 de Octubre",
                            markets_count: 50,
                            info: {
                                current_game_state: "set1",
                                current_game_time: "30",
                                add_minutes: "0",
                                stoppage_firsthalf: "02:00",
                                stoppage_secondhalf: "03:00",
                                score1: "0",
                                score2: "0",
                                pass_team: "none",
                                shirt1_color: "000000",
                                shirt2_color: "000000",
                                short1_color: "000000",
                                short2_color: "000000",
                                field: 0
                            },
                            start_ts: 1684332e3,
                            is_live: 1,
                            type: 1,
                            team1_id: 493175,
                            team2_id: 22119,
                            is_stat_available: !0,
                            is_blocked: 0,
                            market: {
                                1220742569: {
                                    name: "Match Result",
                                    type: "P1XP2",
                                    express_id: 1,
                                    id: 1220742569,
                                    event: {
                                        3717996441: {
                                            price: 3.25,
                                            type: "P2",
                                            id: 3717996441,
                                            name: "W2",
                                            order: 2,
                                            type_1: "W2"
                                        },
                                        3717996442: {
                                            price: 2.4,
                                            type: "P1",
                                            id: 3717996442,
                                            name: "W1",
                                            order: 0,
                                            type_1: "W1"
                                        },
                                        3717996443: {
                                            price: 2.9,
                                            type: "X",
                                            id: 3717996443,
                                            name: "Draw",
                                            order: 1,
                                            type_1: "X"
                                        }
                                    }
                                }
                            }
                        }
                    }
                }, {
                    id: 11371,
                    name: "Cup of Amateurs",
                    order: 244021,
                    game: {
                        22268101: {
                            id: 22268101,
                            region_alias: "Russia",
                            team1_name: "SSHOR Volga Tver",
                            team2_name: "SK Tver",
                            markets_count: 49,
                            info: {
                                current_game_state: "set1",
                                current_game_time: "25",
                                add_minutes: "0",
                                stoppage_firsthalf: "02:00",
                                stoppage_secondhalf: "03:00",
                                score1: "0",
                                score2: "0",
                                pass_team: "none",
                                shirt1_color: "D8D6CB",
                                shirt2_color: "FFFF00",
                                short1_color: "D8D6CB",
                                short2_color: "FFFF00",
                                field: 0
                            },
                            start_ts: 1684332e3,
                            is_live: 1,
                            type: 1,
                            team1_id: 355637,
                            team2_id: 834127,
                            is_stat_available: !1,
                            is_blocked: 0,
                            market: {
                                1220762603: {
                                    name: "Match Result",
                                    type: "P1XP2",
                                    express_id: 1,
                                    id: 1220762603,
                                    event: {
                                        3718059458: {
                                            price: 2.55,
                                            type: "P2",
                                            id: 3718059458,
                                            name: "W2",
                                            order: 2,
                                            type_1: "W2"
                                        },
                                        3718059460: {
                                            price: 2.55,
                                            type: "P1",
                                            id: 3718059460,
                                            name: "W1",
                                            order: 0,
                                            type_1: "W1"
                                        },
                                        3718059461: {
                                            price: 3.55,
                                            type: "X",
                                            id: 3718059461,
                                            name: "Draw",
                                            order: 1,
                                            type_1: "X"
                                        }
                                    }
                                }
                            }
                        }
                    }
                }, {
                    id: 18276104,
                    name: "U19 League - Women",
                    order: 9999,
                    game: {
                        22268065: {
                            id: 22268065,
                            region_alias: "Slovakia",
                            team1_name: "FC Tatran Presov U19 (Wom)",
                            team2_name: "FC Kosice U19 (Wom)",
                            markets_count: 45,
                            info: {
                                current_game_state: "set1",
                                current_game_time: "30",
                                add_minutes: "0",
                                stoppage_firsthalf: "02:00",
                                stoppage_secondhalf: "03:00",
                                score1: "1",
                                score2: "0",
                                pass_team: "none",
                                shirt1_color: "000000",
                                shirt2_color: "000000",
                                short1_color: "000000",
                                short2_color: "000000",
                                field: 0
                            },
                            start_ts: 1684332e3,
                            is_live: 1,
                            type: 1,
                            team1_id: 774655,
                            team2_id: 613723,
                            is_stat_available: !1,
                            is_blocked: 0,
                            market: {
                                1220758953: {
                                    name: "Match Result",
                                    type: "P1XP2",
                                    express_id: 1,
                                    id: 1220758953,
                                    event: {
                                        3718048857: {
                                            price: 4.8,
                                            type: "P2",
                                            id: 3718048857,
                                            name: "W2",
                                            order: 2,
                                            type_1: "W2"
                                        },
                                        3718048859: {
                                            price: 1.55,
                                            type: "P1",
                                            id: 3718048859,
                                            name: "W1",
                                            order: 0,
                                            type_1: "W1"
                                        },
                                        3718048860: {
                                            price: 4.65,
                                            type: "X",
                                            id: 3718048860,
                                            name: "Draw",
                                            order: 1,
                                            type_1: "X"
                                        }
                                    }
                                }
                            }
                        }
                    }
                }, {
                    id: 18275325,
                    name: "1st Division",
                    order: 9999,
                    game: {
                        22267626: {
                            id: 22267626,
                            region_alias: "Syria",
                            team1_name: "Al Tall",
                            team2_name: "Al-Mohafza",
                            markets_count: 17,
                            info: {
                                current_game_state: "set2",
                                current_game_time: "71",
                                add_minutes: "0",
                                stoppage_firsthalf: "02:00",
                                stoppage_secondhalf: "03:00",
                                score1: "0",
                                score2: "1",
                                pass_team: "none",
                                shirt1_color: "FFFFFF",
                                shirt2_color: "7F7F7F",
                                short1_color: "FFFFFF",
                                short2_color: "7F7F7F",
                                field: 0
                            },
                            start_ts: 1684328400,
                            is_live: 1,
                            type: 1,
                            team1_id: 781215,
                            team2_id: 202390,
                            is_stat_available: !1,
                            is_blocked: 0,
                            market: {
                                1220706400: {
                                    name: "Match Result",
                                    type: "P1XP2",
                                    express_id: 1,
                                    id: 1220706400,
                                    event: {
                                        3717894023: {
                                            price: 1.2,
                                            type: "P2",
                                            id: 3717894023,
                                            name: "W2",
                                            order: 2,
                                            type_1: "W2"
                                        },
                                        3717894025: {
                                            price: 17,
                                            type: "P1",
                                            id: 3717894025,
                                            name: "W1",
                                            order: 0,
                                            type_1: "W1"
                                        },
                                        3717894026: {
                                            price: 6,
                                            type: "X",
                                            id: 3717894026,
                                            name: "Draw",
                                            order: 1,
                                            type_1: "X"
                                        }
                                    }
                                }
                            }
                        }
                    }
                }, {
                    id: 3013,
                    name: "Super Lig",
                    order: 289001,
                    game: {
                        22122153: {
                            id: 22122153,
                            region_alias: "Turkey",
                            team1_name: "Istanbul Basaksehir",
                            team2_name: "Umraniyespor",
                            markets_count: 112,
                            info: {
                                current_game_state: "set1",
                                current_game_time: "30",
                                add_minutes: "0",
                                stoppage_firsthalf: "02:00",
                                stoppage_secondhalf: "03:00",
                                score1: "1",
                                score2: "0",
                                pass_team: "none",
                                shirt1_color: "FF0000",
                                shirt2_color: "FFFFFF",
                                short1_color: "000000",
                                short2_color: "000000",
                                field: 0
                            },
                            start_ts: 1684332e3,
                            is_live: 1,
                            type: 1,
                            team1_id: 1524,
                            team2_id: 16435,
                            is_stat_available: !0,
                            favorite_order: null,
                            is_blocked: 0,
                            market: {
                                1214232184: {
                                    name: "Match Result",
                                    type: "P1XP2",
                                    express_id: 1,
                                    id: 1214232184,
                                    event: {
                                        3698824005: {
                                            price: 3.25,
                                            type: "P2",
                                            id: 3698824005,
                                            name: "W2",
                                            order: 2,
                                            type_1: "W2"
                                        },
                                        3698824006: {
                                            price: 3.55,
                                            type: "X",
                                            id: 3698824006,
                                            name: "Draw",
                                            order: 1,
                                            type_1: "X"
                                        },
                                        3698824007: {
                                            price: 2.1,
                                            type: "P1",
                                            id: 3698824007,
                                            name: "W1",
                                            order: 0,
                                            type_1: "W1"
                                        }
                                    }
                                }
                            }
                        }
                    }
                }, {
                    id: 11059,
                    name: "Premier Reserve League",
                    order: 296004,
                    game: {
                        22248685: {
                            id: 22248685,
                            region_alias: "Uruguay",
                            team1_name: "CA Fenix Montevideo (Reserves)",
                            team2_name: "La Luz FC (Reserves)",
                            markets_count: 34,
                            info: {
                                current_game_state: "set2",
                                current_game_time: "72",
                                add_minutes: "0",
                                stoppage_firsthalf: "02:00",
                                stoppage_secondhalf: "03:00",
                                score1: "1",
                                score2: "0",
                                pass_team: "none",
                                shirt1_color: "000000",
                                shirt2_color: "000000",
                                short1_color: "000000",
                                short2_color: "000000",
                                field: 0
                            },
                            start_ts: 1684328400,
                            is_live: 1,
                            type: 1,
                            team1_id: 177751,
                            team2_id: 442367,
                            is_stat_available: !1,
                            favorite_order: null,
                            is_blocked: 0,
                            market: {
                                1218967186: {
                                    name: "Match Result",
                                    type: "P1XP2",
                                    express_id: 1,
                                    id: 1218967186,
                                    event: {
                                        3712820228: {
                                            price: 15,
                                            type: "P2",
                                            id: 3712820228,
                                            name: "W2",
                                            order: 2,
                                            type_1: "W2"
                                        },
                                        3712820229: {
                                            price: 5,
                                            type: "X",
                                            id: 3712820229,
                                            name: "Draw",
                                            order: 1,
                                            type_1: "X"
                                        },
                                        3712820230: {
                                            price: 1.25,
                                            type: "P1",
                                            id: 3712820230,
                                            name: "W1",
                                            order: 0,
                                            type_1: "W1"
                                        }
                                    }
                                }
                            }
                        }
                    }
                }, {
                    id: 18273920,
                    name: "UEFA Champions League SRL",
                    order: 314039,
                    game: {
                        22265463: {
                            id: 22265463,
                            region_alias: "SRL Matches",
                            team1_name: "Manchester City SRL",
                            team2_name: "Real Madrid SRL",
                            markets_count: 32,
                            info: {
                                current_game_state: "set2",
                                current_game_time: "74",
                                add_minutes: "0",
                                stoppage_firsthalf: "02:00",
                                stoppage_secondhalf: "03:00",
                                score1: "1",
                                score2: "1",
                                pass_team: "none",
                                shirt1_color: "000000",
                                shirt2_color: "000000",
                                short1_color: "000000",
                                short2_color: "000000",
                                field: 0
                            },
                            start_ts: 1684328400,
                            is_live: 1,
                            type: 1,
                            team1_id: 561868,
                            team2_id: 561861,
                            is_stat_available: !1,
                            is_blocked: 0,
                            market: {
                                1220704084: {
                                    name: "Match Result",
                                    type: "P1XP2",
                                    express_id: 1,
                                    id: 1220704084,
                                    event: {
                                        3717887262: {
                                            price: 1.8,
                                            type: "X",
                                            id: 3717887262,
                                            name: "Draw",
                                            order: 1,
                                            type_1: "X"
                                        },
                                        3717887264: {
                                            price: 2.9,
                                            type: "P1",
                                            id: 3717887264,
                                            name: "W1",
                                            order: 0,
                                            type_1: "W1"
                                        },
                                        3717887268: {
                                            price: 6.2,
                                            type: "P2",
                                            id: 3717887268,
                                            name: "W2",
                                            order: 2,
                                            type_1: "W2"
                                        }
                                    }
                                }
                            }
                        }
                    }
                }]
        },
        697694: (e, t, a) => {
            a.d(t, {
                D: () => s,
                H: () => i
            });
            var r = a(365043);
            const s = {
                    pageType: 0,
                    fit: "cover",
                    type: "prematch",
                    category: "esport",
                    spbLayoutType: a(685787).bB.CLASSIC,
                    favoriteTeam: !0
                },
                i = (0, r.createContext)(s)
        },
        218660: (e, t, a) => {
            a.d(t, {
                KI: () => l,
                Vt: () => n,
                e: () => i,
                kQ: () => s,
                wR: () => o
            });
            const r = (0, a(534977).g)("events"),
                s = r("events"),
                i = r("sports"),
                o = r("selectedSport"),
                n = r("selectedEventsType"),
                l = r("timeFilter")
        },
        980127: (e, t, a) => {
            a.d(t, {
                c: () => r
            });
            const r = (0, a(534977).g)("specElems")("betslip")
        },
        950694: (e, t, a) => {
            a.d(t, {
                $h: () => h,
                HC: () => m,
                Ig: () => c,
                Kf: () => d,
                L: () => u,
                MP: () => v,
                Xv: () => p,
                el: () => _,
                uj: () => y
            });
            var r = a(133230),
                s = a(197262),
                i = a(502825),
                o = a(179177),
                n = a(735905),
                l = a(570579);
            const d = 6,
                _ = 3,
                m = [15, 30, 60, 180, 720, 1440, 2880, 4320],
                c = "all",
                p = {
                    Basketball: "P1XP2",
                    IceHockey: "P1XP2"
                },
                h = {
                    region: ["id", "order"],
                    competition: ["id", "name", "order"],
                    game: ["market", "id", "region_alias", "team1_name", "team2_name", "markets_count", "info", "start_ts", "is_live", "type", "team1_id", "team2_id", "is_stat_available", "favorite_order", "is_blocked"],
                    market: ["event", "name", "type", "marketType", "express_id", "id", "main_order", "col_count"],
                    event: ["price", "type", "id", "name", "base", "order", "type_1"]
                },
                u = {
                    type: {
                        "@in": i.yM
                    }
                },
                v = {
                    type: {
                        "@in": [...i.AS, ...i.Zp, ...i.yM]
                    }
                },
                y = [{
                    key: r.s0.LIVE,
                    value: s.A.t("sportsbook.liveEvents"),
                    icon: (0, l.jsx)(n.GlobalIcon, {
                        lib: "generic",
                        size: 8,
                        name: "dot",
                        theme: "default",
                        className: "events-wrapper__tabs--icon"
                    })
                }, {
                    key: r.s0.PREMATCH,
                    value: s.A.t("sportsbook.upcomingEvents")
                }, {
                    key: r.s0.POPULAR,
                    value: s.A.t("sportsbook.popularEvents")
                }, ...o.Ay.IS_BOOSTED_ODDS_ENABLED ? [{
                    key: r.s0.BOOSTED,
                    value: s.A.t("sportsbook.boostedEvents")
                }] : []]
        },
        325040: (e, t, a) => {
            var r;
            a.d(t, {
                f: () => i,
                h: () => s
            });
            const s = {
                    0: "live",
                    1: "prematch",
                    2: "esport"
                },
                i = !(null === (r = window.partnerConfigs) || void 0 === r || !r.pageParams)
        },
        502825: (e, t, a) => {
            a.d(t, {
                AS: () => r,
                Zp: () => s,
                yM: () => i
            });
            const r = ["Handicap", "AsianHandicap", "AsianHandicapAsian", "MatchHandicap", "TriesHandicap", "Handicap(NoDraw)", "GamesHandicap", "MapsHandicap", "MatchHandicap2", "MatchHandicap2Asian", "HandicapLegs", "RunLine"],
                s = ["OverUnder", "OverUnderAsian", "TotalGamesOver/Under", "MatchTotal", "TotalofSets", "TotalGoalsOver/Under", "TotalRounds", "Over/Under", "TotalPointsOver/Under", "GamesTotal", "MapsTotal", "MatchTotal2", "MatchTotal2Asian", "MatchPointCommonTotalOverUnder2Way", "TotalRunsOver/Under", "MatchTotalPointsOverUnder", "MatchPointsTotal2Way", "TotalLegs"],
                i = ["P1P2", "W1W2", "P1XP2", "W1XW2", "MatchWinner", "MatchResult", "MatchWinner3Way", "MoneyLine"]
        },
        870875: (e, t, a) => {
            a.d(t, {
                $R: () => i,
                cL: () => s,
                uo: () => r
            });
            const r = ["Basketball", "IceHockey", "Baseball", "AustralianFootball", "RugbyLeague", "Darts", "Lacross", "AmericanFootball"],
                s = ["Tennis", "Volleyball", "Cricket", "TableTennis", "Mma", "CounterStrike", "3x3Basketball", "Badminton", "Boxing", "Dota2", "BeachVolleyball", "LeagueOfLegends", "RainbowSix", "Squash", "StarCraft2", "Valorant", "Teqball", "Snooker", "Golf", "KingOfGlory", "HeroesOfTheStorm"],
                i = [...s, "IceHockey", "Basketball", "AmericanFootball", "Cricket", "Darts", "RugbyLeague", "RugbyUnion"]
        },
        535594: (e, t, a) => {
            a.d(t, {
                Z: () => r
            });
            const r = e => e.charAt(0).toUpperCase() + e.slice(1)
        },
        209975: () => {},
        739448: () => {},
        81996: () => {},
        426342: () => {},
        792421: () => {},
        444487: () => {}
    }
]);
//# sourceMappingURL=events.4facaa19.chunk.js.map