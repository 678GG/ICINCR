"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [29782], {
        829782: (s, e, t) => {
            t.d(e, {
                L: () => d
            });
            t(270757);
            var o, i = t(694227),
                a = t(365043);
            const n = (null === (o = window.partnerConfigs) || void 0 === o ? void 0 : o.statisticsLinkLogoV3) || "https://statistics.betconstruct.com",
                r = `${n}/images/e/`,
                c = `${n}/images/c/`;
            var l = t(490440),
                u = t(179177),
                m = t(570579);
            const d = s => {
                let {
                    teamId: e,
                    children: t,
                    size: o,
                    setHasImage: n,
                    competition: d,
                    imageLoadingType: g = "lazy",
                    sizeByPixels: v
                } = s;
                const [p, b] = (0, a.useState)(), [f, k] = (0, a.useState)(!!e), L = "sm" === o ? "s" : "md" === o ? "m" : "b", {
                    mounted: $
                } = (0, l.q)();
                return (0, a.useEffect)((() => {
                    if (!e) return;
                    if (!u.Ay.TEAM_LOGOS) return k(!1), void(null === n || void 0 === n || n(!1));
                    const s = new Image;
                    s.src = `${d?c:r}${L}/${Math.floor(e/2e3)}/${e}.webp`, s.onload = () => {
                        $ && (b(s.src), k(!1), null === n || void 0 === n || n(!0))
                    }, s.onerror = () => {
                        $ && (b(""), null === n || void 0 === n || n(!1), k(!1))
                    }
                }), [e]), f ? (0, m.jsx)(i.A.Avatar, {
                    size: v || ("b" === L ? 60 : 24),
                    active: !0
                }) : p && u.Ay.TEAM_LOGOS ? (0, m.jsx)("img", {
                    className: "teamLogoImage",
                    src: p,
                    alt: `${e}`,
                    loading: g
                }) : t || null
            }
        }
    }
]);
//# sourceMappingURL=29782.9366bd6f.chunk.js.map