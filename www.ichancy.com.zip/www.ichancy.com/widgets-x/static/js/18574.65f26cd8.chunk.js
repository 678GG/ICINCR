"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [18574], {
        918574: (r, s, e) => {
            e.d(s, {
                A: () => t
            });
            var o = e(489889);

            function t(r, s) {
                var e = (0, o.A)({}, r);
                return Array.isArray(s) && s.forEach((function(r) {
                    delete e[r]
                })), e
            }
        }
    }
]);
//# sourceMappingURL=18574.65f26cd8.chunk.js.map