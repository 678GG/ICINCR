"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [18056], {
        318056: (_, E, S) => {
            S.d(E, {
                Dn: () => e,
                EF: () => R,
                FU: () => A,
                MK: () => y,
                VF: () => I,
                fm: () => o,
                iW: () => a,
                it: () => t,
                sr: () => O,
                xq: () => N,
                zA: () => p,
                zc: () => C
            });
            var T = S(122757);
            const I = _ => ({
                    type: T.b.SET_CASINO_ORIGINAL_CATEGORIES,
                    payload: _
                }),
                p = _ => ({
                    type: T.b.SET_CASINO_CUSTOM_CATEGORIES,
                    payload: _
                }),
                A = _ => ({
                    type: T.b.SET_CASINO_ORIGINAL_CATEGORIES_SET,
                    payload: _
                }),
                a = _ => ({
                    type: T.b.SET_CASINO_ORIGINAL_CATEGORIES_SET_LEFT_SIDEBAR,
                    payload: _
                }),
                y = (_, E) => ({
                    type: T.b.SET_CASINO_PROVIDERS,
                    payload: {
                        category: E,
                        providers: _
                    }
                }),
                O = _ => ({
                    type: T.b.SET_CASINO_PROVIDERS_IN_INTERSECTION,
                    payload: _
                }),
                C = _ => ({
                    type: T.b.SET_CASINO_CURRENT_GAME,
                    payload: _
                }),
                R = _ => ({
                    type: T.b.SET_CASINO_CATEGORY_PROVIDER_IDS,
                    payload: _
                }),
                o = _ => ({
                    type: T.b.SET_CAN_REQUEST_CATEGORIES_NESTED_DATA,
                    payload: _
                }),
                N = _ => ({
                    type: T.b.SET_CAN_REQUEST_PROVIDERS_NESTED_DATA,
                    payload: _
                }),
                e = _ => ({
                    type: T.b.SET_LAST_PLAYED_CAT_SETTINGS,
                    payload: _
                }),
                t = _ => ({
                    type: T.b.SET_CATEGORIES_CUSTOM_IDS,
                    payload: _
                })
        }
    }
]);
//# sourceMappingURL=18056.9ced4993.chunk.js.map