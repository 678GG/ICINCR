"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [31437], {
        154423: (e, t) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            t.default = {
                icon: {
                    tag: "svg",
                    attrs: {
                        viewBox: "64 64 896 896",
                        focusable: "false"
                    },
                    children: [{
                        tag: "path",
                        attrs: {
                            d: "M909.6 854.5L649.9 594.8C690.2 542.7 712 479 712 412c0-80.2-31.3-155.4-87.9-212.1-56.6-56.7-132-87.9-212.1-87.9s-155.5 31.3-212.1 87.9C143.2 256.5 112 331.8 112 412c0 80.1 31.3 155.5 87.9 212.1C256.5 680.8 331.8 712 412 712c67 0 130.6-21.8 182.7-62l259.7 259.6a8.2 8.2 0 0011.6 0l43.6-43.5a8.2 8.2 0 000-11.6zM570.4 570.4C528 612.7 471.8 636 412 636s-116-23.3-158.4-65.6C211.3 528 188 471.8 188 412s23.3-116.1 65.6-158.4C296 211.3 352.2 188 412 188s116.1 23.2 158.4 65.6S636 352.2 636 412s-23.3 116.1-65.6 158.4z"
                        }
                    }]
                },
                name: "search",
                theme: "outlined"
            }
        },
        31437: (e, t, r) => {
            var a;
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var u = (a = r(500234)) && a.__esModule ? a : {
                default: a
            };
            t.default = u, e.exports = u
        },
        500234: (e, t, r) => {
            var a = r(245288),
                u = r(310684);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = a(r(601459)),
                n = function(e, t) {
                    if (!t && e && e.__esModule) return e;
                    if (null === e || "object" != u(e) && "function" != typeof e) return {
                        default: e
                    };
                    var r = s(t);
                    if (r && r.has(e)) return r.get(e);
                    var a = {
                            __proto__: null
                        },
                        o = Object.defineProperty && Object.getOwnPropertyDescriptor;
                    for (var n in e)
                        if ("default" !== n && Object.prototype.hasOwnProperty.call(e, n)) {
                            var l = o ? Object.getOwnPropertyDescriptor(e, n) : null;
                            l && (l.get || l.set) ? Object.defineProperty(a, n, l) : a[n] = e[n]
                        }
                    return a.default = e, r && r.set(e, a), a
                }(r(365043)),
                l = a(r(154423)),
                f = a(r(942740));

            function s(e) {
                if ("function" != typeof WeakMap) return null;
                var t = new WeakMap,
                    r = new WeakMap;
                return (s = function(e) {
                    return e ? r : t
                })(e)
            }
            var c = function(e, t) {
                    return n.createElement(f.default, (0, o.default)((0, o.default)({}, e), {}, {
                        ref: t,
                        icon: l.default
                    }))
                },
                d = n.forwardRef(c);
            t.default = d
        }
    }
]);
//# sourceMappingURL=31437.2a519dad.chunk.js.map