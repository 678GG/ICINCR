"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [42828], {
        242828: (s, o, r) => {
            function e(s) {
                return Array.from({
                    length: s
                }, ((s, o) => o))
            }
            r.d(o, {
                K: () => e
            })
        }
    }
]);
//# sourceMappingURL=42828.601de179.chunk.js.map