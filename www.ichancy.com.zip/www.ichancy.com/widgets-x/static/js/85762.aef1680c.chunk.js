"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [85762], {
        185762: (o, e, s) => {
            s.d(e, {
                L: () => i
            });
            var r = s(365043),
                n = s(55418),
                p = s(570579);
            const t = {
                    mobile: !0,
                    desktop: !0
                },
                i = function(o) {
                    const e = o.mobile,
                        s = o.desktop,
                        {
                            mobile: i = !0,
                            desktop: l = !0
                        } = o.conditions || t,
                        c = o.forceViewport ? o[o.forceViewport] : null,
                        k = {
                            mobile: "desktop" !== o.forceViewport,
                            desktop: "mobile" !== o.forceViewport
                        },
                        b = !o.forceViewport || k[o.forceViewport];
                    return (0, p.jsxs)(r.Suspense, {
                        fallback: o.fallback || null,
                        children: [c && b && (0, p.jsx)(c, { ...o.innerProps
                        }), c ? null : (0, n.F)() ? i && (0, p.jsx)(e, { ...o.innerProps
                        }) : l && (0, p.jsx)(s, { ...o.innerProps
                        })]
                    })
                }
        }
    }
]);
//# sourceMappingURL=85762.aef1680c.chunk.js.map