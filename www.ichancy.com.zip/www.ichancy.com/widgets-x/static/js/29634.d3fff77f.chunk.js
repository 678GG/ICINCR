"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [29634], {
        429634: (t, e, n) => {
            n.d(e, {
                h: () => k
            });
            n(737053);
            var o = n(918811),
                s = n(822631),
                l = n(179177);
            const k = function(t) {
                let e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
                    n = arguments.length > 2 ? arguments[2] : void 0;
                (0, s.G)(e, l.Ay.ERROR_MSG_DURATION, n || t), o.default.warn({
                    content: t,
                    key: n || t
                })
            }
        }
    }
]);
//# sourceMappingURL=29634.d3fff77f.chunk.js.map