"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [22093], {
        722093: (t, o, e) => {
            var f = e(50130);
            Object.defineProperty(o, "__esModule", {
                value: !0
            }), o.default = function(t) {
                var o = t.arrowWidth,
                    e = void 0 === o ? 4 : o,
                    f = t.horizontalArrowShift,
                    i = void 0 === f ? 16 : f,
                    l = t.verticalArrowShift,
                    c = void 0 === l ? 8 : l,
                    p = t.autoAdjustOverflow,
                    u = t.arrowPointAtCenter,
                    b = {
                        left: {
                            points: ["cr", "cl"],
                            offset: [-4, 0]
                        },
                        right: {
                            points: ["cl", "cr"],
                            offset: [4, 0]
                        },
                        top: {
                            points: ["bc", "tc"],
                            offset: [0, -4]
                        },
                        bottom: {
                            points: ["tc", "bc"],
                            offset: [0, 4]
                        },
                        topLeft: {
                            points: ["bl", "tc"],
                            offset: [-(i + e), -4]
                        },
                        leftTop: {
                            points: ["tr", "cl"],
                            offset: [-4, -(c + e)]
                        },
                        topRight: {
                            points: ["br", "tc"],
                            offset: [i + e, -4]
                        },
                        rightTop: {
                            points: ["tl", "cr"],
                            offset: [4, -(c + e)]
                        },
                        bottomRight: {
                            points: ["tr", "bc"],
                            offset: [i + e, 4]
                        },
                        rightBottom: {
                            points: ["bl", "cr"],
                            offset: [4, c + e]
                        },
                        bottomLeft: {
                            points: ["tl", "bc"],
                            offset: [-(i + e), 4]
                        },
                        leftBottom: {
                            points: ["br", "cl"],
                            offset: [-4, c + e]
                        }
                    };
                return Object.keys(b).forEach((function(t) {
                    b[t] = u ? (0, s.default)((0, s.default)({}, b[t]), {
                        overflow: a(p),
                        targetOffset: n
                    }) : (0, s.default)((0, s.default)({}, r.placements[t]), {
                        overflow: a(p)
                    }), b[t].ignoreShake = !0
                })), b
            }, o.getOverflowOptions = a;
            var s = f(e(319290)),
                r = e(236273),
                i = {
                    adjustX: 1,
                    adjustY: 1
                },
                l = {
                    adjustX: 0,
                    adjustY: 0
                },
                n = [0, 0];

            function a(t) {
                return "boolean" === typeof t ? t ? i : l : (0, s.default)((0, s.default)({}, l), t)
            }
        }
    }
]);
//# sourceMappingURL=22093.b07d33bc.chunk.js.map