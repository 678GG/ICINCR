"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [29925], {
        629925: (s, o, e) => {
            e(628035), e(715320), e(176481)
        },
        715320: (s, o, e) => {
            e.r(o), e.d(o, {
                default: () => k
            });
            const k = {}
        }
    }
]);
//# sourceMappingURL=29925.d9ba57ce.chunk.js.map