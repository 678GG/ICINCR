"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [9297], {
        170288: (e, t, u) => {
            var n = u(410180).default;
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                var t = f.useRef();
                return t.current = e, f.useCallback((function() {
                    for (var e, u = arguments.length, n = new Array(u), f = 0; f < u; f++) n[f] = arguments[f];
                    return null === (e = t.current) || void 0 === e ? void 0 : e.call.apply(e, [t].concat(n))
                }), [])
            };
            var f = n(u(365043))
        },
        737377: (e, t, u) => {
            var n = u(924297).default,
                f = u(410180).default;
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.useLayoutUpdateEffect = t.default = void 0;
            var a = f(u(365043)),
                r = (0, n(u(300338)).default)() ? a.useLayoutEffect : a.useEffect,
                o = function(e, t) {
                    var u = a.useRef(!0);
                    r((function() {
                        return e(u.current)
                    }), t), r((function() {
                        return u.current = !1,
                            function() {
                                u.current = !0
                            }
                    }), [])
                };
            t.useLayoutUpdateEffect = function(e, t) {
                o((function(t) {
                    if (!t) return e()
                }), t)
            }, t.default = o
        },
        809297: (e, t, u) => {
            var n = u(924297).default;
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e, t) {
                var u = t || {},
                    n = u.defaultValue,
                    l = u.value,
                    d = u.onChange,
                    i = u.postState,
                    v = (0, o.default)((function() {
                        return c(l) ? l : c(n) ? "function" === typeof n ? n() : n : "function" === typeof e ? e() : e
                    })),
                    s = (0, f.default)(v, 2),
                    p = s[0],
                    y = s[1],
                    _ = void 0 !== l ? l : p,
                    b = i ? i(_) : _,
                    k = (0, a.default)(d),
                    E = (0, o.default)([_]),
                    h = (0, f.default)(E, 2),
                    L = h[0],
                    C = h[1];
                (0, r.useLayoutUpdateEffect)((function() {
                    var e = L[0];
                    p !== e && k(p, e)
                }), [L]), (0, r.useLayoutUpdateEffect)((function() {
                    c(l) || y(l)
                }), [l]);
                var U = (0, a.default)((function(e, t) {
                    y(e, t), C([_], t)
                }));
                return [b, U]
            };
            var f = n(u(884308)),
                a = n(u(170288)),
                r = u(737377),
                o = n(u(991909));

            function c(e) {
                return void 0 !== e
            }
        }
    }
]);
//# sourceMappingURL=9297.34eaab38.chunk.js.map