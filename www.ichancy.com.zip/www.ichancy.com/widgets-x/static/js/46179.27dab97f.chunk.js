"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [46179], {
        227197: (e, t) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            t.default = {
                icon: {
                    tag: "svg",
                    attrs: {
                        viewBox: "64 64 896 896",
                        focusable: "false"
                    },
                    children: [{
                        tag: "path",
                        attrs: {
                            d: "M955.7 856l-416-720c-6.2-10.7-16.9-16-27.7-16s-21.6 5.3-27.7 16l-416 720C56 877.4 71.4 904 96 904h832c24.6 0 40-26.6 27.7-48zM480 416c0-4.4 3.6-8 8-8h48c4.4 0 8 3.6 8 8v184c0 4.4-3.6 8-8 8h-48c-4.4 0-8-3.6-8-8V416zm32 352a48.01 48.01 0 010-96 48.01 48.01 0 010 96z"
                        }
                    }]
                },
                name: "warning",
                theme: "filled"
            }
        },
        246179: (e, t, r) => {
            var a;
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = (a = r(937586)) && a.__esModule ? a : {
                default: a
            };
            t.default = n, e.exports = n
        },
        937586: (e, t, r) => {
            var a = r(245288),
                n = r(310684);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var u = a(r(601459)),
                o = function(e, t) {
                    if (!t && e && e.__esModule) return e;
                    if (null === e || "object" != n(e) && "function" != typeof e) return {
                        default: e
                    };
                    var r = c(t);
                    if (r && r.has(e)) return r.get(e);
                    var a = {
                            __proto__: null
                        },
                        u = Object.defineProperty && Object.getOwnPropertyDescriptor;
                    for (var o in e)
                        if ("default" !== o && Object.prototype.hasOwnProperty.call(e, o)) {
                            var l = u ? Object.getOwnPropertyDescriptor(e, o) : null;
                            l && (l.get || l.set) ? Object.defineProperty(a, o, l) : a[o] = e[o]
                        }
                    return a.default = e, r && r.set(e, a), a
                }(r(365043)),
                l = a(r(227197)),
                f = a(r(942740));

            function c(e) {
                if ("function" != typeof WeakMap) return null;
                var t = new WeakMap,
                    r = new WeakMap;
                return (c = function(e) {
                    return e ? r : t
                })(e)
            }
            var d = function(e, t) {
                    return o.createElement(f.default, (0, u.default)((0, u.default)({}, e), {}, {
                        ref: t,
                        icon: l.default
                    }))
                },
                i = o.forwardRef(d);
            t.default = i
        }
    }
]);
//# sourceMappingURL=46179.27dab97f.chunk.js.map