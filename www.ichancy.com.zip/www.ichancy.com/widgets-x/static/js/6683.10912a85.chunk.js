"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [6683], {
        706683: (e, l, t) => {
            t.d(l, {
                AM: () => c,
                EZ: () => u,
                Es: () => a,
                Q8: () => s,
                zH: () => n
            });
            var r = t(179177);
            const n = (e, l) => {
                    var t;
                    if (!e) return;
                    e.includes(",") && !l && (e = e.replace(",", ".")), e = e.replace(/[^\d.]/g, "");
                    let r = String(null === (t = e) || void 0 === t ? void 0 : t.replace(",", "."));
                    if (r.includes(".")) {
                        const e = r.indexOf("."),
                            l = r.indexOf(".", e + 1); - 1 !== l && (r = r.substring(0, l))
                    }
                    let n = null;
                    return 2 === r.length && 0 === +r[0] && "." !== r[1] && (n = `0.${r[1]}`), (e => /^[+]?((?!00\d*$)[0-9]+(?:[.][0-9]*)?|\.[0-9]+)$/.test(e))(r) || !e || n ? n || r : void 0
                },
                a = e => {
                    const l = e.target,
                        t = /[^0-9.]/g;
                    "." === `${l.value||""}`.charAt(0) ? l.value = `0${l.value}` : l.value.split(".").length > 2 ? l.value = l.value.slice(0, l.value.lastIndexOf(".")) : l.value = l.value.replace(t, "")
                },
                s = e => {
                    const l = (null === e || void 0 === e ? void 0 : e.toString()) || "";
                    return "," === r.Ay.PRICE_SEPARATOR && e ? l.indexOf(".") <= l.indexOf(",") ? l.replace(/\B(?=(\d{3})+(?!\d))/g, ",") : l.split(".")[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",").concat(".", l.split(".")[1].replace(",", "")) : e
                },
                u = e => e ? e.replace(",", "") : e,
                c = (e, l) => {
                    let t = !1;
                    return Object.entries(e).forEach((e => {
                        let [r, n] = e;
                        const a = l[r];
                        Number(a) !== Number(n) && (t = !0)
                    })), t
                }
        }
    }
]);
//# sourceMappingURL=6683.10912a85.chunk.js.map