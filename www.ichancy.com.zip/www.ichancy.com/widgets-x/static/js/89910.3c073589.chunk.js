"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [89910], {
        589910: (e, n, p) => {
            p.d(n, {
                F: () => a
            });
            const a = () => {
                var e, n;
                const p = null === (e = window) || void 0 === e || null === (n = e.partnerConfigs) || void 0 === n ? void 0 : n.domain;
                let a = "springbuilder.site";
                if (p) {
                    const {
                        pureDomain: e
                    } = (e => {
                        const n = e = (e = (e = (e = (e = e.replace(new RegExp(/^\s+/), "")).replace(new RegExp(/\s+$/), "")).replace(new RegExp(/\\/g), "/")).replace(new RegExp(/^http:\/\/|^https:\/\/|^ftp:\/\//i), "")).replace(new RegExp(/^www\./i), "");
                        return e.match(new RegExp(/\.[a-z]{2,3}\.[a-z]{2}$/i)) ? e = e.replace(new RegExp(/\.[a-z]{2,3}\.[a-z]{2}$/i), "") : e.match(new RegExp(/\.[a-z]{2,7}$/i)) ? e = e.replace(new RegExp(/\.[a-z]{2,7}$/i), "") : e.match(new RegExp(/\.[a-z]{2,6}$/i)) && (e = e.replace(new RegExp(/\.[a-z]{2,6}$/i), "")), {
                            isSubDomain: !!e.match(new RegExp(/\./g)),
                            pureDomain: e.match(new RegExp(/\./g)) ? n.substring(n.indexOf(".") + 1) : n
                        }
                    })(p);
                    e && (a = e)
                }
                return a
            }
        }
    }
]);
//# sourceMappingURL=89910.3c073589.chunk.js.map