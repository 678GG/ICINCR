"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [60707], {
        160707: (s, o, e) => {
            e.r(o), e.d(o, {
                default: () => k
            });
            const k = {}
        }
    }
]);
//# sourceMappingURL=60707.613e522a.chunk.js.map