"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [90440], {
        490440: (e, r, s) => {
            s.d(r, {
                q: () => u
            });
            var t = s(365043);
            const u = () => {
                const e = (0, t.useRef)(!1);
                return (0, t.useEffect)((() => (e.current = !0, () => {
                    e.current = !1
                })), []), {
                    mounted: e,
                    mountCheckWrapper: r => {
                        e.current && r()
                    }
                }
            }
        }
    }
]);
//# sourceMappingURL=90440.7c79aae5.chunk.js.map