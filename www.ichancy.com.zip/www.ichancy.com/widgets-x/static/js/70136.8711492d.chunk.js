"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [70136], {
        370136: (e, t, r) => {
            r.r(t), r.d(t, {
                default: () => s
            });
            var l, n = r(365043);

            function o() {
                return o = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = arguments[t];
                        for (var l in r) Object.prototype.hasOwnProperty.call(r, l) && (e[l] = r[l])
                    }
                    return e
                }, o.apply(this, arguments)
            }

            function a(e, t) {
                let {
                    title: r,
                    titleId: a,
                    ...i
                } = e;
                return n.createElement("svg", o({
                    width: 32,
                    height: 32,
                    viewBox: "0 0 32 32",
                    fill: "currentColor",
                    xmlns: "http://www.w3.org/2000/svg",
                    ref: t,
                    "aria-labelledby": a
                }, i), r ? n.createElement("title", {
                    id: a
                }, r) : null, l || (l = n.createElement("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M15.7394 0.0532139C15.9059 -0.017738 16.0941 -0.017738 16.2606 0.0532139L31.596 6.58964C31.841 6.69406 32 6.93465 32 7.20096V25.3018C32 25.5749 31.8329 25.8202 31.5788 25.9202L16.2433 31.9539C16.0869 32.0154 15.9131 32.0154 15.7567 31.9539L0.421234 25.9202C0.167091 25.8202 0 25.5749 0 25.3018V7.20096C0 6.93465 0.158987 6.69406 0.403973 6.58964L15.7394 0.0532139ZM1.32907 8.17654V24.8492L15.3355 30.3599V13.6873L1.32907 8.17654ZM16.6645 13.6873V30.3599L30.6709 24.8492V8.17654L16.6645 13.6873ZM29.5829 7.17636L16 12.5205L2.41707 7.17636L16 1.38692L29.5829 7.17636Z"
                })))
            }
            const i = n.forwardRef(a),
                s = (r.p, i)
        }
    }
]);
//# sourceMappingURL=70136.8711492d.chunk.js.map