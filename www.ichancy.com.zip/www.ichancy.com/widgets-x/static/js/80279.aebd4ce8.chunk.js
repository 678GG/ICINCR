"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [80279], {
        880279: (e, o, a) => {
            a.d(o, {
                GW: () => w,
                J2: () => D,
                P_: () => B,
                Zl: () => h,
                bT: () => A,
                bv: () => g,
                p7: () => O,
                pb: () => I,
                rK: () => S
            });
            var d = a(291372),
                t = a(197262),
                i = a(322908),
                n = a.n(i),
                l = a(737536),
                r = a(423400),
                s = a(144891),
                m = a(704270),
                u = a(588860),
                _ = a(828088),
                v = a(855221),
                c = a(320308),
                p = a(759851),
                b = a(179177);
            const y = e => {
                    var o;
                    const a = null === (o = d.A.getState().betSlip) || void 0 === o ? void 0 : o.betslipOpen,
                        t = b.Ay.IS_BETSLIP_FLOATING_ENABLED;
                    return !t || t && a ? e : null
                },
                A = async (e, o, a, d, t) => {
                    m.l.then((i => {
                        i.sendCommand(e, o, a, d, t)
                    }))
                },
                E = (e, o, a, d, i) => {
                    null === o || void 0 === o || o(e);
                    const {
                        result: n,
                        result_text: l,
                        details: r,
                        StatusCode: m,
                        Data: u
                    } = e, _ = m === s.bN[0];
                    if (1800 === n || _) {
                        var p, b;
                        const e = _ ? null !== u && void 0 !== u && u.ErrorData ? {
                            old_price: null === u || void 0 === u || null === (p = u.ErrorData) || void 0 === p ? void 0 : p.OldPrice,
                            new_price: null === u || void 0 === u || null === (b = u.ErrorData) || void 0 === b ? void 0 : b.ActualPrice
                        } : null : Array.isArray(r) ? {
                            old_price: r[0].old_price,
                            new_price: r[0].new_price
                        } : null;
                        if (d && d(!0), !e) return;
                        const o = t.A.t("swarm.OddsIsChanged").replace("{oldPrice}", (0, v.C)(e.old_price, a)).replace("{newPrice}", (0, v.C)(e.new_price, a));
                        (0, c.$)(o, y(i), l)
                    }
                },
                S = (e, o, a, t, i) => {
                    var n;
                    const l = null === (n = d.A.getState().betSlip) || void 0 === n ? void 0 : n.editBet;
                    null !== l && void 0 !== l && l.active ? T(e, o, a, t, i) : C(e, o, a, t, i)
                },
                C = (e, o, a, i, n) => {
                    const m = d.A.getState().betSlip.oddFormat,
                        v = d.A.getState().betSlip.editBet,
                        c = d.A.getState().betSlip.useBonusBalance,
                        S = d.A.getState().userData.user,
                        {
                            bets: C,
                            type: T,
                            mode: g,
                            sys_bet: O,
                            bonus_id: B,
                            predefined_multiple_id: h,
                            source: D,
                            each_way: I,
                            booking_id: w
                        } = e,
                        P = null !== v && void 0 !== v && v.active ? v.amount : e.amount,
                        N = e.amount,
                        k = (null === v || void 0 === v ? void 0 : v.betId) || null,
                        F = {
                            command: l.y.DO_BET,
                            params: {
                                source: D,
                                each_way: I,
                                bonus_id: B,
                                amount: P,
                                bets: C,
                                mode: g || s.wH.ODD_NOT_CHANGE,
                                odd_type: m,
                                type: T,
                                booking_id: w,
                                ...!c || b.Ay.BET_WITH_ONLY_BONUS_OR_DEPOSIT && null !== S && void 0 !== S && S.bonus_balance ? {
                                    is_bonus_money: c
                                } : {}
                            },
                            rid: r.A.gForCommand()
                        };
                    O && (F.params.sys_bet = O), h && (F.params.predefined_multiple_id = h), null !== v && void 0 !== v && v.active && (F.params.additional_amount = N, F.params.old_bet_id = k), A(F, "", (e => {
                        var a, d, i;
                        (o(e), e && "OK" === e.result) && (null !== (a = e.details) && void 0 !== a && a.is_superbet ? (0, _.y)(t.A.t("betslip.superBetSuccess"), y(n)) : (0, _.y)(t.A.t(`betslip.${u.M.DO_BET}`), y(n)));
                        b.Ay.APPEND_CUSTOM_CODE_BETSLIP && (0, p.T)(b.Ay.CUSTOM_CODE_BETSLIP, {
                            amount: P,
                            currency: null === S || void 0 === S ? void 0 : S.currency,
                            bet_id: null === e || void 0 === e || null === (d = e.details) || void 0 === d ? void 0 : d.bet_id,
                            k: null === e || void 0 === e || null === (i = e.details) || void 0 === i ? void 0 : i.k,
                            is_superbet: -1 === g,
                            bet_type: T,
                            name: null === S || void 0 === S ? void 0 : S.name,
                            first_name: null === S || void 0 === S ? void 0 : S.first_name,
                            last_name: null === S || void 0 === S ? void 0 : S.last_name,
                            email: null === S || void 0 === S ? void 0 : S.email,
                            username: null === S || void 0 === S ? void 0 : S.username,
                            btag: null === S || void 0 === S ? void 0 : S.btag,
                            userId: null === S || void 0 === S ? void 0 : S.id,
                            phone: null === S || void 0 === S ? void 0 : S.phone
                        })
                    }), (() => {}), (e => {
                        let {
                            data: o
                        } = e;
                        E(o, a, m, i, n)
                    }))
                },
                T = (e, o, a, i, n) => {
                    const s = d.A.getState().betSlip.oddFormat,
                        m = d.A.getState().betSlip.editBet,
                        v = d.A.getState().userData.user,
                        {
                            bets: c,
                            type: S,
                            mode: C,
                            source: T,
                            each_way: g
                        } = e,
                        O = null !== m && void 0 !== m && m.active ? m.amount : e.amount,
                        B = e.amount,
                        h = (null === m || void 0 === m ? void 0 : m.betId) || null,
                        D = {
                            command: l.y.CREATE_BETS,
                            params: {
                                bets: [{
                                    Source: T,
                                    EachWay: g,
                                    Amount: O,
                                    Events: c.map((e => ({
                                        SelectionId: e.event_id,
                                        Coeficient: e.price
                                    }))),
                                    OddType: s,
                                    Type: S,
                                    AdditionalAmount: void 0
                                }]
                            },
                            rid: r.A.gForCommand()
                        };
                    null !== m && void 0 !== m && m.active && (D.params.bets[0].AdditionalAmount = B, D.params.bets[0].OldBetId = h), A(D, "", (e => {
                        var a, d, i, l;
                        "0" === e.StatusCode && (e.result = "OK", null !== (a = e.Data) && void 0 !== a && null !== (d = a[0]) && void 0 !== d && d.is_superbet ? (0, _.y)(t.A.t("betslip.superBetSuccess"), y(n)) : (0, _.y)(t.A.t(`betslip.${u.M.DO_BET}`), y(n)));
                        (o(e), b.Ay.APPEND_CUSTOM_CODE_BETSLIP) && (0, p.T)(b.Ay.CUSTOM_CODE_BETSLIP, {
                            amount: O,
                            currency: null === v || void 0 === v ? void 0 : v.currency,
                            bet_id: null === e || void 0 === e || null === (i = e.Data[0]) || void 0 === i ? void 0 : i.bet_id,
                            k: null === e || void 0 === e || null === (l = e.Data[0]) || void 0 === l ? void 0 : l.k,
                            is_superbet: -1 === C,
                            bet_type: S,
                            name: null === v || void 0 === v ? void 0 : v.name,
                            first_name: null === v || void 0 === v ? void 0 : v.first_name,
                            last_name: null === v || void 0 === v ? void 0 : v.last_name,
                            email: null === v || void 0 === v ? void 0 : v.email,
                            username: null === v || void 0 === v ? void 0 : v.username,
                            btag: null === v || void 0 === v ? void 0 : v.btag,
                            userId: null === v || void 0 === v ? void 0 : v.id,
                            phone: null === v || void 0 === v ? void 0 : v.phone
                        })
                    }), (() => {}), (e => {
                        let {
                            data: o
                        } = e;
                        E(o, a, s, i, n)
                    }))
                },
                g = (e, o, a) => {
                    const d = {
                        command: l.y.GET_FREEBETS_FOR_BETSLIP_V3,
                        params: e,
                        rid: r.A.gForCommand()
                    };
                    A(d, "", o, (() => {}), a)
                },
                O = async (e, o, a) => {
                    const d = {
                        command: l.y.GET,
                        rid: r.A.gForCommand(),
                        params: {
                            source: l.p.CURRENCY_CONFIG,
                            what: {
                                currency: []
                            },
                            where: {
                                currency: {
                                    name: e
                                }
                            },
                            subscribe: !1
                        }
                    };
                    m.l.then((e => e.sendCommand(d, "", o, void 0, a)))
                },
                B = async (e, o, a) => {
                    const d = {
                            command: l.y.BOOK_BET,
                            rid: r.A.gForCommand(),
                            params: {
                                bets: e
                            }
                        },
                        t = Number(n().parse(window.location.search, {
                            ignoreQueryPrefix: !0
                        }).tid);
                    t && (d.params.cashdesk_id = t), m.l.then((e => e.sendCommand(d, "", o, void 0, a)))
                },
                h = (e, o, a) => {
                    const d = {
                        command: l.y.GET_EVENTS_BY_BOOKING_ID,
                        rid: r.A.gForCommand(),
                        params: {
                            booking_id: +e
                        }
                    };
                    m.l.then((e => e.sendCommand(d, "", o, void 0, a)))
                },
                D = (e, o, a, d, t, i) => {
                    const n = t || (e ? e.map((e => e.gameId)) : []),
                        s = t && i ? i : e ? e.map((e => e.eventId)) : [],
                        u = {
                            command: l.y.GET,
                            rid: r.A.gForCommand(),
                            params: {
                                source: l.p.BETTING,
                                what: { ...!d && {
                                        sport: ["alias", "type"],
                                        region: ["name", "alias"],
                                        competition: ["name", "id"],
                                        game: ["id", "type", "team1_name", "team2_name", "start_ts", "info"],
                                        market: ["name", "type", "extra_info"]
                                    },
                                    event: d ? ["id"] : ["id", "base", "name", "price", "ew_allowed"]
                                },
                                where: {
                                    game: {
                                        id: {
                                            "@in": n
                                        }
                                    },
                                    event: {
                                        id: {
                                            "@in": s
                                        }
                                    }
                                }
                            }
                        };
                    m.l.then((e => {
                        e.sendCommand(u, "", o, void 0, a)
                    }))
                },
                I = (e, o, a, d) => {
                    const t = {
                        command: l.y.SUPER_BET_ANSWER,
                        rid: r.A.gForCommand(),
                        params: {
                            accept: e,
                            bet_id: o
                        }
                    };
                    m.l.then((e => e.sendCommand(t, "", a, void 0, d)))
                },
                w = (e, o, a) => {
                    const d = {
                        command: l.y.CHECK_BET_STATUS,
                        rid: r.A.gForCommand(),
                        params: {
                            bet_id: e
                        }
                    };
                    m.l.then((e => e.sendCommand(d, "", o, void 0, a)))
                }
        }
    }
]);
//# sourceMappingURL=80279.aebd4ce8.chunk.js.map