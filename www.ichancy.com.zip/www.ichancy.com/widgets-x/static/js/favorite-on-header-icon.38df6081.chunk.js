"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [53575], {
        930823: (e, s, o) => {
            o.r(s), o.d(s, {
                FavoriteOnHeaderIcon: () => I
            });
            var t = o(889181),
                d = o(701616),
                c = o(507712),
                i = o(373522),
                n = o(283573),
                r = o(365043),
                u = o(841591),
                l = o(68724),
                a = o(457250);
            var b = o(735905),
                v = o(55418),
                f = o(570579);
            const I = e => {
                let {
                    favoriteTabs: s
                } = e;
                (0, l.z)();
                const o = (0, c.wA)(),
                    I = (0, c.d4)(n.Gx),
                    h = (0, c.d4)(n.v6),
                    k = ((e, s, o) => {
                        const t = !o || (null === o || void 0 === o ? void 0 : o.includes(i.b.ALL)),
                            d = t || (null === o || void 0 === o ? void 0 : o.includes(i.b.SPORTSBOOK)),
                            c = t || (null === o || void 0 === o ? void 0 : o.includes(i.b.CASINO));
                        let n = 0;
                        return !a.nK && d && (n += s || 0), !a.C4 && c && (n += e), n
                    })(h.casino, h.sportsWithCompetitions, s),
                    p = (0, c.d4)(u.XD),
                    H = (0, r.useCallback)(((e, s) => {
                        !e && s && 1 === Number(p) ? o((0, d.zl)(i.b.CASINO)) : !s && e && 2 === Number(p) && o((0, d.zl)(i.b.SPORTSBOOK))
                    }), [p]);
                (0, r.useLayoutEffect)((() => {
                    if (k) {
                        const e = !s || (null === s || void 0 === s ? void 0 : s.includes(i.b.ALL)) || (null === s || void 0 === s ? void 0 : s.includes(i.b.SPORTSBOOK)),
                            o = !s || (null === s || void 0 === s ? void 0 : s.includes(i.b.ALL)) || (null === s || void 0 === s ? void 0 : s.includes(i.b.CASINO));
                        e && o && H(h.sportsWithCompetitions, h.casino)
                    }
                }), [k, h.casino, h.sportsWithCompetitions]);
                return (0, f.jsxs)("div", {
                    className: (0, t.A)(["favoriteIconOnHeaderWrapper", {
                        "favoriteIconOnHeaderWrapper--mobile": (0, v.F)()
                    }]),
                    onClick: e => {
                        e.stopPropagation(), o((0, d.h3)(!0))
                    },
                    children: [(0, f.jsx)(b.GlobalIcon, {
                        color: "var(--v3-primary-color)",
                        theme: "default",
                        name: "favorite",
                        lib: "generic",
                        size: 20,
                        keepInCache: !0,
                        skeleton: !0
                    }), (0, f.jsx)("span", {
                        className: (0, t.A)(["totalFavoritesCount", {
                            "totalFavoritesCount--mobile": (0, v.F)()
                        }]),
                        children: I ? "-" : k
                    })]
                })
            }
        },
        68724: (e, s, o) => {
            o.d(s, {
                z: () => v
            });
            var t = o(283573),
                d = o(231436),
                c = o(507712),
                i = o(504647),
                n = o(500223),
                r = o(365043),
                u = o(117893),
                l = o(827198),
                a = o(423400);
            const b = {
                    sport: ["id", "type"],
                    game: ["id", "type"],
                    competition: ["id"],
                    region: ["id"]
                },
                v = () => {
                    const e = (0, c.wA)(),
                        s = (0, r.useRef)(a.A.gCustom("FAVORITE_MATCH_IDS_")),
                        [o, v] = (0, r.useState)(!1),
                        f = (0, c.d4)(t.QJ).all,
                        I = (0, c.d4)(t.Kh).all,
                        h = (0, c.d4)(t.fn);
                    (0, r.useLayoutEffect)((() => (d.v.mountedHookIds.fetchIds.push(s.current), () => {
                        d.v.mountedHookIds.fetchIds.splice(d.v.mountedHookIds.fetchIds.indexOf(s.current), 1)
                    })), []), (0, r.useLayoutEffect)((() => {
                        !d.v.subscribedHookIds.fetchIds || 1 !== d.v.mountedHookIds.fetchIds.length && s.current !== d.v.subscribedHookIds.fetchIds || ((0, n.lx)(d.v.subscribedHookIds.fetchIds), d.v.subscribedHookIds.fetchIds = null)
                    }), [I.length]), (0, r.useLayoutEffect)((() => {
                        let e = !0;
                        (d.v.subscribedHookIds.fetchIds || d.v.subscribedHookIds.fetchData || h) && (e = !1), v(e)
                    }), [h]), (0, r.useEffect)((() => {
                        if (o && (d.v.subscribedHookIds.fetchIds || d.v.subscribedHookIds.fetchData)) return v(!1);
                        if (I.length && o) {
                            d.v.subscribedHookIds.fetchIds = s.current;
                            const o = s => {
                                let {
                                    sport: o
                                } = s;
                                null === d.v.subscribedHookIds.fetchData && I && e((0, u.K2R)((0, l.Ly)(o || {}, !0))), e((0, u.DX2)(!1))
                            };
                            (0, i.RS)(s.current, b, (0, d.c)(I), o, !0, o)
                        }
                    }), [I.length, o]), (0, r.useLayoutEffect)((() => {
                        d.v.subscribedHookIds.fetchData ? d.v.subscribedHookIds.fetchIds && ((0, n.lx)(d.v.subscribedHookIds.fetchIds), d.v.subscribedHookIds.fetchIds = null) : d.v.subscribedHookIds.fetchIds || v(!0)
                    }), [h, f])
                }
        }
    }
]);
//# sourceMappingURL=favorite-on-header-icon.38df6081.chunk.js.map