"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [45375], {
        945375: (e, t, n) => {
            var o = n(50130),
                r = n(487066);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = o(n(329085)),
                l = o(n(579459)),
                i = o(n(319290)),
                f = function(e, t) {
                    if (!t && e && e.__esModule) return e;
                    if (null === e || "object" !== r(e) && "function" !== typeof e) return {
                        default: e
                    };
                    var n = m(t);
                    if (n && n.has(e)) return n.get(e);
                    var o = {},
                        a = Object.defineProperty && Object.getOwnPropertyDescriptor;
                    for (var l in e)
                        if ("default" !== l && Object.prototype.hasOwnProperty.call(e, l)) {
                            var i = a ? Object.getOwnPropertyDescriptor(e, l) : null;
                            i && (i.get || i.set) ? Object.defineProperty(o, l, i) : o[l] = e[l]
                        }
                    o.default = e, n && n.set(e, o);
                    return o
                }(n(365043)),
                s = o(n(161579)),
                u = o(n(809297)),
                p = o(n(498139)),
                c = o(n(722093)),
                d = n(853590),
                v = n(445600),
                y = n(199701),
                b = n(272391);

            function m(e) {
                if ("function" !== typeof WeakMap) return null;
                var t = new WeakMap,
                    n = new WeakMap;
                return (m = function(e) {
                    return e ? n : t
                })(e)
            }
            var O = function(e, t) {
                    var n = {};
                    for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && t.indexOf(o) < 0 && (n[o] = e[o]);
                    if (null != e && "function" === typeof Object.getOwnPropertySymbols) {
                        var r = 0;
                        for (o = Object.getOwnPropertySymbols(e); r < o.length; r++) t.indexOf(o[r]) < 0 && Object.prototype.propertyIsEnumerable.call(e, o[r]) && (n[o[r]] = e[o[r]])
                    }
                    return n
                },
                g = new RegExp("^(".concat(y.PresetColorTypes.join("|"), ")(-inverse)?$"));

            function w(e, t) {
                var n = e.type;
                if ((!0 === n.__ANT_BUTTON || "button" === e.type) && e.props.disabled || !0 === n.__ANT_SWITCH && (e.props.disabled || e.props.loading)) {
                    var o = function(e, t) {
                            var n = {},
                                o = (0, i.default)({}, e);
                            return t.forEach((function(t) {
                                e && t in e && (n[t] = e[t], delete o[t])
                            })), {
                                picked: n,
                                omitted: o
                            }
                        }(e.props.style, ["position", "left", "right", "top", "bottom", "float", "display", "zIndex"]),
                        r = o.picked,
                        a = o.omitted,
                        l = (0, i.default)((0, i.default)({
                            display: "inline-block"
                        }, r), {
                            cursor: "not-allowed",
                            width: e.props.block ? "100%" : null
                        }),
                        s = (0, i.default)((0, i.default)({}, a), {
                            pointerEvents: "none"
                        }),
                        u = (0, d.cloneElement)(e, {
                            style: s,
                            className: null
                        });
                    return f.createElement("span", {
                        style: l,
                        className: (0, p.default)(e.props.className, "".concat(t, "-disabled-compatible-wrapper"))
                    }, u)
                }
                return e
            }
            var C = f.forwardRef((function(e, t) {
                var n, o = f.useContext(v.ConfigContext),
                    r = o.getPopupContainer,
                    y = o.getPrefixCls,
                    m = o.direction,
                    C = (0, u.default)(!1, {
                        value: e.visible,
                        defaultValue: e.defaultVisible
                    }),
                    x = (0, l.default)(C, 2),
                    P = x[0],
                    h = x[1],
                    j = function() {
                        var t = e.title,
                            n = e.overlay;
                        return !t && !n && 0 !== t
                    },
                    k = function() {
                        var t = e.builtinPlacements,
                            n = e.arrowPointAtCenter,
                            o = e.autoAdjustOverflow;
                        return t || (0, c.default)({
                            arrowPointAtCenter: n,
                            autoAdjustOverflow: o
                        })
                    },
                    N = e.getPopupContainer,
                    _ = O(e, ["getPopupContainer"]),
                    E = e.prefixCls,
                    T = e.openClassName,
                    A = e.getTooltipContainer,
                    D = e.overlayClassName,
                    I = e.color,
                    M = e.overlayInnerStyle,
                    S = e.children,
                    V = y("tooltip", E),
                    R = y(),
                    W = P;
                !("visible" in e) && j() && (W = !1);
                var B, z = w((0, d.isValidElement)(S) ? S : f.createElement("span", null, S), V),
                    L = z.props,
                    H = (0, p.default)(L.className, (0, a.default)({}, T || "".concat(V, "-open"), !0)),
                    U = (0, p.default)(D, (n = {}, (0, a.default)(n, "".concat(V, "-rtl"), "rtl" === m), (0, a.default)(n, "".concat(V, "-").concat(I), I && g.test(I)), n)),
                    $ = M;
                return I && !g.test(I) && ($ = (0, i.default)((0, i.default)({}, M), {
                    background: I
                }), B = {
                    "--antd-arrow-background-color": I
                }), f.createElement(s.default, (0, i.default)({}, _, {
                    prefixCls: V,
                    overlayClassName: U,
                    getTooltipContainer: N || A || r,
                    ref: t,
                    builtinPlacements: k(),
                    overlay: function() {
                        var t = e.title,
                            n = e.overlay;
                        return 0 === t ? t : n || t || ""
                    }(),
                    visible: W,
                    onVisibleChange: function(t) {
                        var n;
                        h(!j() && t), j() || null === (n = e.onVisibleChange) || void 0 === n || n.call(e, t)
                    },
                    onPopupAlign: function(e, t) {
                        var n = k(),
                            o = Object.keys(n).find((function(e) {
                                return n[e].points[0] === t.points[0] && n[e].points[1] === t.points[1]
                            }));
                        if (o) {
                            var r = e.getBoundingClientRect(),
                                a = {
                                    top: "50%",
                                    left: "50%"
                                };
                            o.indexOf("top") >= 0 || o.indexOf("Bottom") >= 0 ? a.top = "".concat(r.height - t.offset[1], "px") : (o.indexOf("Top") >= 0 || o.indexOf("bottom") >= 0) && (a.top = "".concat(-t.offset[1], "px")), o.indexOf("left") >= 0 || o.indexOf("Right") >= 0 ? a.left = "".concat(r.width - t.offset[0], "px") : (o.indexOf("right") >= 0 || o.indexOf("Left") >= 0) && (a.left = "".concat(-t.offset[0], "px")), e.style.transformOrigin = "".concat(a.left, " ").concat(a.top)
                        }
                    },
                    overlayInnerStyle: $,
                    arrowContent: f.createElement("span", {
                        className: "".concat(V, "-arrow-content"),
                        style: B
                    }),
                    motion: {
                        motionName: (0, b.getTransitionName)(R, "zoom-big-fast", e.transitionName),
                        motionDeadline: 1e3
                    }
                }), W ? (0, d.cloneElement)(z, {
                    className: H
                }) : z)
            }));
            C.displayName = "Tooltip", C.defaultProps = {
                placement: "top",
                mouseEnterDelay: .1,
                mouseLeaveDelay: .1,
                arrowPointAtCenter: !1,
                autoAdjustOverflow: !0
            };
            var x = C;
            t.default = x
        }
    }
]);
//# sourceMappingURL=45375.e6fc3086.chunk.js.map