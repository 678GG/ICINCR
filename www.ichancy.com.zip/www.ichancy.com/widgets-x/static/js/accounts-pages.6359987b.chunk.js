"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [19256], {
        334170: (e, n, o) => {
            o.r(n), o.d(n, {
                ProfileInfo: () => q
            });
            o(718591);
            var l = o(273941),
                s = (o(270757), o(694227)),
                i = (o(50999), o(69661)),
                a = (o(629925), o(406995)),
                t = (o(678257), o(144719)),
                c = (o(712261), o(640371)),
                r = o(365043),
                d = o(307022),
                u = o(995392),
                p = o(870905),
                f = o(550736),
                m = o(507712),
                h = o(841591),
                _ = o(889181),
                b = o(679559),
                x = o(285275),
                v = o(462956),
                w = o(930823),
                g = o(174199),
                I = o(735905),
                y = o(179177),
                j = o(55418),
                A = o(570579);
            y.Ay.IS_RTL && o.e(94195).then(o.bind(o, 494195));
            const B = () => {
                const {
                    t: e
                } = (0, p.B)();
                return (0, A.jsxs)(A.Fragment, {
                    children: [(0, A.jsx)("div", {
                        className: "notificationPopup__icon",
                        children: (0, A.jsx)(I.GlobalIcon, {
                            lib: "generic",
                            name: "notification",
                            theme: "colored",
                            size: 44
                        })
                    }), (0, A.jsxs)("div", {
                        className: "notificationPopup__content",
                        children: [(0, A.jsx)("div", {
                            className: "notificationPopup__content--title",
                            children: e("account.newMessage")
                        }), (0, A.jsx)("div", {
                            className: "notificationPopup__content--text globalEllipsis",
                            children: e("account.clickToCheckTheMessage")
                        })]
                    }), (0, A.jsx)("div", {
                        className: (0, _.A)(["notificationPopup__closeBtn", {
                            "notificationPopup__closeBtn--desktop": !(0, j.F)()
                        }]),
                        onClick: e => {
                            e.stopPropagation(), c.default.destroy()
                        },
                        children: (0, A.jsx)(I.GlobalIcon, {
                            lib: "generic",
                            name: "close",
                            theme: "default",
                            size: 10,
                            color: "#fff"
                        })
                    })]
                })
            };
            var N = o(123213),
                S = o(626038),
                k = o(424541),
                F = o(816343),
                C = o(457250),
                T = o(556785),
                M = o(384716),
                z = o(683753),
                E = o(743544),
                O = o(189265),
                P = o(785463),
                R = o(849944),
                L = o(989618);
            const U = [{
                label: "My Profile",
                sectionType: "myProfile",
                formType: "myProfile",
                hasSettings: !1,
                showHide: !0,
                hidden: !1,
                type: "section"
            }, {
                label: "Deposit",
                sectionType: "Deposit",
                formType: "Deposit",
                hasSettings: !1,
                showHide: !0,
                hidden: !1,
                type: "section"
            }, {
                label: "Withdraw",
                sectionType: "Withdraw",
                formType: "Withdraw",
                hasSettings: !1,
                showHide: !0,
                hidden: !1,
                type: "section"
            }, {
                label: "Bonuses",
                sectionType: "Bonuses",
                formType: "Bonuses",
                hasSettings: !1,
                showHide: !0,
                hidden: !1,
                type: "section"
            }, {
                label: "Messages",
                sectionType: "Messages",
                formType: "Messages",
                hasSettings: !1,
                showHide: !0,
                hidden: !1,
                type: "section"
            }];
            var G = o(253220);
            y.Ay.IS_RTL && o.e(60707).then(o.bind(o, 160707));
            const {
                ChangeTheme: H
            } = (0, L.R)((() => Promise.all([o.e(90286), o.e(71139), o.e(17893), o.e(38761)]).then(o.bind(o, 70573)))), {
                MultiWallet: W
            } = (0, L.R)((() => Promise.all([o.e(99989), o.e(73157), o.e(12967), o.e(77499), o.e(51238), o.e(73549), o.e(87154), o.e(40999), o.e(14971), o.e(51172), o.e(88123), o.e(94137), o.e(20559)]).then(o.bind(o, 703517)))), {
                ConnectWallet: V
            } = (0, L.R)((() => Promise.all([o.e(51238), o.e(68671), o.e(73549), o.e(87154), o.e(40999), o.e(14971), o.e(41943), o.e(74635)]).then(o.bind(o, 11502)))), q = (0, r.memo)((e => {
                var n, o, L;
                let {
                    user: q,
                    favoriteEnabled: D,
                    favoriteTabs: $
                } = e;
                const K = (0, u.W6)(),
                    J = (0, m.wA)(),
                    Z = (0, r.useRef)(null),
                    Y = (0, S.N)(),
                    {
                        t: X
                    } = (0, p.B)(),
                    Q = (0, m.d4)(b.eP),
                    [ee, ne] = (0, r.useState)(),
                    oe = (0, m.d4)(b.Zd),
                    le = (0, m.d4)(v.gU),
                    se = (0, m.d4)(b.M0),
                    ie = (0, m.d4)(h.gh),
                    ae = (0, m.d4)(h.JL),
                    te = (0, m.d4)(h.d1),
                    {
                        isVisible: ce
                    } = (0, m.d4)(h.tH),
                    [re, de] = (0, r.useState)(!0),
                    [ue, pe] = (0, r.useState)(!1),
                    [fe, me] = (0, r.useState)("bottomRight"),
                    {
                        bonuses: he,
                        accounts: _e
                    } = (0, M.o)(),
                    {
                        formatAmount: be,
                        currency: xe,
                        placement: ve
                    } = (0, k.H)(),
                    we = (0, P.V)(),
                    ge = (0, r.useMemo)((() => JSON.parse(N.A.getItem((0, T.U)("account", "BALANCE_VISIBILITY")))), []),
                    Ie = (0, r.useMemo)((() => {
                        var e;
                        const n = null === ae || void 0 === ae || null === (e = ae.sections) || void 0 === e ? void 0 : e.find((e => "accountBonusIframe" === e.sectionType));
                        return !(!n || n.hidden)
                    }), [ae]),
                    ye = (0, r.useMemo)((() => ie && (0, j.F)() && 1 !== +ie.mobileCompactView), [ie]),
                    je = (0, r.useMemo)((() => ie && !(0, j.F)() && 1 !== +ie.desktopCompactView), [ie]),
                    Ae = (0, r.useMemo)((() => {
                        var e;
                        const n = null === ae || void 0 === ae || null === (e = ae.myProfile) || void 0 === e ? void 0 : e.find((e => "tabAccumulatedLosses" === e.sectionType));
                        return !(!n || n.hidden)
                    }), [ae]);
                (0, r.useEffect)((() => {
                    if (Z.current) {
                        const e = Z.current.getBoundingClientRect();
                        e.left < window.innerWidth - e.left - e.width && me("bottomLeft")
                    }
                }), []), (0, r.useEffect)((() => {
                    de(null === ge || ge)
                }), [ge]), (0, r.useEffect)((() => {
                    0 === +(null === ie || void 0 === ie ? void 0 : ie.showBalanceVisibilitySwitcher) && de(!0)
                }), [null === ie || void 0 === ie ? void 0 : ie.showBalanceVisibilitySwitcher]), (0, r.useEffect)((() => {
                    N.A.setItem((0, T.U)("account", "BALANCE_VISIBILITY"), JSON.stringify(re))
                }), [re]), (0, r.useEffect)((() => {
                    Q && ((0, f.zw)((e => {
                        if (e) {
                            const o = Object.keys((null === e || void 0 === e ? void 0 : e.messages) || {}).length;
                            if (o) {
                                var n;
                                c.default.destroy();
                                const e = new Audio(`https://static.springbuilder.site/widgets-x/audio/${"new_message.wav"}?v=${y.Ay.VERSION}`),
                                    l = e.play();
                                null === l || void 0 === l || l.catch((e => {
                                    console.warn(e)
                                }));
                                const s = document.getElementById("betslipTotalOdds"),
                                    i = null !== (n = null === s || void 0 === s ? void 0 : s.clientHeight) && void 0 !== n ? n : 0,
                                    a = G.s6 + i;
                                c.default.open({
                                    key: "newMessageNotification",
                                    placement: (0, j.F)() ? "bottom" : y.Ay.IS_RTL ? "topLeft" : "topRight",
                                    bottom: (0, j.F)() ? a ? a + 16 : 32 : void 0,
                                    top: (0, j.F)() ? void 0 : 24,
                                    duration: 3,
                                    message: null,
                                    description: (0, A.jsx)(B, {}),
                                    closeIcon: !0,
                                    className: (0, _.A)(["notificationPopup__container", {
                                        "notificationPopup__container--mobile": (0, j.F)()
                                    }]),
                                    onClick: () => {
                                        c.default.destroy(), (0, F.qx)(), K.push((0, F.U7)({
                                            accounts: "*",
                                            messages: "*"
                                        }))
                                    },
                                    onClose: () => {
                                        e.remove()
                                    }
                                }), J((0, d.DM)(o))
                            }
                        }
                    })), (0, f.c8)({
                        type: 0
                    }, (e => {
                        const n = e.messages.filter((e => 0 === e.checked));
                        J((0, d.DM)(n.length))
                    })), null !== se && void 0 !== se && se.freeBonuses || he || C.nK || J((0, d.Bt)(!0)), null !== se && void 0 !== se && se.casinoBonuses || he || C.C4 || J((0, d.Bt)(!1)), null !== se && void 0 !== se && se.freeSpinBonuses || he || C.C4 || J((0, d.Bt)(!0, (() => {}), !0, 0)))
                }), [Q, q]), (0, r.useEffect)((() => {
                    var e, n, o;
                    ne(((null === se || void 0 === se || null === (e = se.casinoBonuses) || void 0 === e ? void 0 : e.length) || 0) + ((null === se || void 0 === se || null === (n = se.freeBonuses) || void 0 === n ? void 0 : n.length) || 0) + ((null === se || void 0 === se || null === (o = se.freeSpinBonuses) || void 0 === o ? void 0 : o.length) || 0))
                }), [se]);
                const Be = (0, r.useMemo)((() => E.$6 ? (0, A.jsxs)("div", {
                        className: (0, _.A)(["profileInfo__wallet-info", "profileWallet__wallet-info" + ((0, j.F)() ? "--mobile" : "")]),
                        children: [(0, A.jsxs)("span", {
                            className: "profileInfo__wallet-info-item",
                            children: [(0, A.jsx)("span", {
                                className: "profileWallet__title",
                                children: X("account.totalBalance")
                            }), (0, A.jsx)("span", {
                                className: "profileWallet__balance",
                                children: be((0, z.Bk)({
                                    balance: q.balance,
                                    casinoBalance: q.casino_balance
                                }))
                            })]
                        }), (0, A.jsxs)("span", {
                            className: "profileInfo__wallet-info-item",
                            children: [(0, A.jsx)("span", {
                                children: X("account.sportsbookBalance")
                            }), (0, A.jsx)("span", {
                                children: be((0, z.Bk)({
                                    balance: q.balance
                                }))
                            })]
                        }), (0, A.jsxs)("span", {
                            className: "profileInfo__wallet-info-item",
                            children: [(0, A.jsx)("span", {
                                children: X("account.casinoBalance")
                            }), (0, A.jsx)("span", {
                                children: be((0, z.Mp)(q.casino_balance - q.frozen_balance))
                            })]
                        })]
                    }) : null), [re, null === ie || void 0 === ie ? void 0 : ie.showBalanceVisibilitySwitcher, ee, q.balance, q.casino_balance]),
                    Ne = (0, r.useMemo)((() => !y.Ay.CASINO_SPORTSBOOK_SWITCHER && ie && 0 !== +ie.frozenBalance && y.Ay.SHOULD_IGNORE_USER_FROZEN_BALANCE), [ie]),
                    Se = (0, r.useMemo)((() => {
                        var e;
                        return Ne ? (0, A.jsxs)("div", {
                            className: (0, _.A)(["profileInfo__wallet-info", "profileWallet__wallet-info" + ((0, j.F)() ? "--mobile" : "")]),
                            children: [(0, A.jsx)("span", {
                                className: "profileInfo__wallet-info-item",
                                children: (0, A.jsx)("span", {
                                    className: "profileWallet__title",
                                    children: X("account.bonusBalances")
                                })
                            }), (0, A.jsxs)("span", {
                                className: "profileInfo__wallet-info-item",
                                children: [(0, A.jsx)("span", {
                                    children: X("account.bonusBalance")
                                }), (0, A.jsx)("span", {
                                    children: be(null !== (e = q.bonus_balance) && void 0 !== e ? e : 0)
                                })]
                            }), (0, A.jsxs)("span", {
                                className: "profileInfo__wallet-info-item",
                                children: [(0, A.jsx)("span", {
                                    children: X("account.frozenBalance")
                                }), (0, A.jsx)("span", {
                                    children: be(q.frozen_balance)
                                })]
                            })]
                        }) : null
                    }), [q.balance, q.frozen_balance, Ne, xe, ve]),
                    ke = je || ye || !q.id || !1;
                return (0, A.jsxs)("div", {
                    className: "profileInfo__wrapper",
                    children: [(0, j.F)() || !q.currency || q.external_id || q.owner_id || 0 === +(null === ie || void 0 === ie ? void 0 : ie.multiWalletSwitcher) || !y.Ay.METAMASK_LOGIN ? null : (0, A.jsx)(r.Suspense, {
                        fallback: null,
                        children: (0, A.jsx)(V, {})
                    }), null !== le && void 0 !== le && null !== (n = le.mult_wallet_currencies) && void 0 !== n && n.length ? q.currency ? (0, A.jsx)(r.Suspense, {
                        fallback: (0, A.jsx)(g.M, {}),
                        children: (0, A.jsx)(W, {
                            user: q
                        })
                    }) : (0, A.jsx)(g.M, {}) : null, (0, A.jsxs)("div", {
                        className: (0, _.A)(["profileInfo__wallet", {
                            "profileInfo__wallet-mobile": (0, j.F)(),
                            "dropdown-exist": E.$6 || Ne
                        }]),
                        children: [(0, A.jsx)(I.GlobalIcon, {
                            lib: "generic",
                            name: "add",
                            theme: "default",
                            size: (0, j.F)() ? 24 : 28,
                            skeleton: !0,
                            className: "profileInfo__add",
                            onClick: () => {
                                y.Ay.IFRAME_SPORTSBOOK ? (0, R.W1)("deposit") : ((0, F.qx)(), K.push((0, F.U7)({
                                    accounts: "*",
                                    wallet: "*",
                                    ...(0, j.F)() ? {
                                        "deposit-methods": "*"
                                    } : {
                                        deposit: "*"
                                    }
                                })))
                            }
                        }), (0, A.jsx)(O.e, {
                            condition: null !== (o = E.$6 || Ne) && void 0 !== o && o,
                            wrapper: e => (0, A.jsx)(i.default, {
                                trigger: "click",
                                placement: "bottom",
                                overlayClassName: (0, _.A)(["wallet__info-popup", {
                                    "wallet__info-popup-mobile": (0, j.F)()
                                }]),
                                content: (0, A.jsxs)(A.Fragment, {
                                    children: [E.$6 ? Be : null, Ne ? Se : null]
                                }) || (0, A.jsx)(A.Fragment, {
                                    children: " "
                                }),
                                onVisibleChange: e => pe(e),
                                overlayStyle: (0, j.F)() ? {
                                    paddingRight: 12,
                                    paddingLeft: 12
                                } : {},
                                children: e
                            }),
                            children: (0, A.jsxs)("div", {
                                className: (0, _.A)(["profileInfo__dropdown-info", {
                                    "profileInfo__dropdown-arrow balance-hide": !re && E.$6 || Ne
                                }]),
                                children: [re && (0, A.jsxs)("div", {
                                    className: "profileInfo__balance-wrapper " + (E.$6 || Ne ? "dropdown-exist" : ""),
                                    children: [(0, A.jsx)("div", {
                                        className: (0, _.A)(["profileInfo__balance", {
                                            "profileInfo__balance-mobile": (0, j.F)()
                                        }]),
                                        dir: "ltr",
                                        children: void 0 !== q.balance ? (0, A.jsxs)(A.Fragment, {
                                            children: [" ", "left" === ve && (0, A.jsxs)("span", {
                                                className: "profileInfo__balance-currency",
                                                children: [xe, "\xa0"]
                                            }), (0, A.jsx)("span", {
                                                children: (0, z.Bk)({
                                                    balance: q.balance,
                                                    casinoBalance: q.casino_balance
                                                }, q.frozen_balance, te || 0)
                                            }), "right" === ve && (0, A.jsxs)("span", {
                                                className: "profileInfo__balance-currency",
                                                children: ["\xa0", xe]
                                            })]
                                        }) : (0, A.jsx)(s.A, {
                                            active: !0,
                                            title: {
                                                style: {
                                                    width: 23,
                                                    height: 8,
                                                    margin: "2px 0"
                                                }
                                            },
                                            paragraph: !1
                                        })
                                    }), 0 !== +(null === ie || void 0 === ie ? void 0 : ie.showBonusBalance) && (0, A.jsx)("div", {
                                        className: (0, _.A)(["profileInfo__bonus", {
                                            "profileInfo__bonus-mobile": (0, j.F)()
                                        }]),
                                        children: void 0 !== q.bonus_balance ? (0, A.jsxs)(A.Fragment, {
                                            children: ["left" === ve && (0, A.jsxs)("span", {
                                                className: "profileInfo__bonus-currency",
                                                children: [xe, "\xa0"]
                                            }), (0, A.jsx)("span", {
                                                children: (0, z.e7)(q)
                                            }), "right" === ve && (0, A.jsxs)("span", {
                                                className: "profileInfo__bonus-currency",
                                                children: ["\xa0", xe]
                                            })]
                                        }) : (0, A.jsx)(s.A, {
                                            active: !0,
                                            title: {
                                                style: {
                                                    width: 13,
                                                    height: 8,
                                                    margin: "2px 0"
                                                }
                                            },
                                            paragraph: !1
                                        })
                                    })]
                                }), E.$6 || Ne ? (0, A.jsx)(I.GlobalIcon, {
                                    lib: "generic",
                                    name: "caretDownSmall",
                                    theme: "default",
                                    size: 24,
                                    className: (0, _.A)(["profileInfo__expand-icon", {
                                        expanded: ue
                                    }])
                                }) : null]
                            })
                        })]
                    }), (null !== le && void 0 !== le && null !== (L = le.secondary_wallet_currencies) && void 0 !== L && L.length || !ie) && (0, j.F)() ? null : !C.nK && !D && (0, A.jsx)("div", {
                        className: (0, _.A)(["profileInfo__history-wrapper", {
                            "profileInfo__history-wrapper-mobile": (0, j.F)()
                        }]),
                        onClick: () => {
                            (0, F.qx)(), K.push((0, F.U7)({
                                accounts: "*",
                                "bet-history": "*"
                            }))
                        },
                        children: (0, A.jsx)(I.GlobalIcon, {
                            lib: "account",
                            name: "timeHistorySmall",
                            theme: "default",
                            size: (0, j.F)() ? 24 : 28,
                            className: "profileInfo__balance-history"
                        })
                    }), (0, A.jsx)(l.default, {
                        disabled: ke,
                        placement: fe,
                        arrow: {
                            pointAtCenter: !0
                        },
                        trigger: (0, j.F)() || je ? ["click"] : ["click", "hover"],
                        overlayClassName: (0, _.A)([{
                            "profile-Info__dropdown": !ce,
                            "profile-Info__dropdown--mobile": !ce && (0, j.F)(),
                            "profileInfo__dropdown--mobile": ce && (0, j.F)(),
                            profileInfo__dropdown: ce && !(0, j.F)()
                        }]),
                        overlay: () => {
                            const e = [],
                                n = {
                                    myProfile: {
                                        icon: (0, A.jsx)(I.GlobalIcon, {
                                            lib: "account",
                                            name: "accountSettingsOutlined",
                                            theme: "default",
                                            size: 20
                                        }),
                                        onClick: () => {
                                            (0, F.qx)(), K.push((0, F.U7)({
                                                accounts: "*",
                                                ...!(0, j.F)() && {
                                                    settings: "*"
                                                },
                                                profile: "*"
                                            }))
                                        }
                                    },
                                    myBets: {
                                        icon: (0, A.jsx)(I.GlobalIcon, {
                                            lib: "account",
                                            name: "betHistoryOutlined",
                                            theme: "default",
                                            size: 20
                                        }),
                                        onClick: () => {
                                            (0, F.qx)(), K.push((0, F.U7)({
                                                accounts: "*",
                                                "bet-history": "*"
                                            }))
                                        }
                                    },
                                    balanceHistory: {
                                        icon: (0, A.jsx)(I.GlobalIcon, {
                                            lib: "account",
                                            name: "documentsOutlined",
                                            theme: "default",
                                            size: 20
                                        }),
                                        onClick: () => {
                                            (0, F.qx)(), K.push((0, F.U7)({
                                                accounts: "*",
                                                "balance-history": "*"
                                            }))
                                        }
                                    },
                                    Messages: {
                                        icon: (0, A.jsx)("div", {
                                            className: "profileBadge",
                                            children: (0, A.jsx)(t.A, {
                                                count: oe,
                                                offset: [y.Ay.IS_RTL ? 12 : 0, 1],
                                                size: "small",
                                                className: "profileBadge--wrapper",
                                                children: (0, A.jsx)(I.GlobalIcon, {
                                                    lib: "account",
                                                    name: "messagesOutlined",
                                                    theme: "default",
                                                    size: 20
                                                })
                                            })
                                        }),
                                        onClick: () => {
                                            (0, F.qx)(), K.push((0, F.U7)({
                                                accounts: "*",
                                                messages: "*"
                                            }))
                                        }
                                    },
                                    Withdraw: {
                                        icon: (0, A.jsx)(I.GlobalIcon, {
                                            lib: "account",
                                            name: "withdrawoutlined",
                                            theme: "default",
                                            size: 20
                                        }),
                                        onClick: () => {
                                            (0, F.qx)(), K.push((0, F.U7)({
                                                accounts: "*",
                                                wallet: "*",
                                                ...(0, j.F)() ? {
                                                    "withdraw-methods": "*"
                                                } : {
                                                    withdraw: "*"
                                                }
                                            }))
                                        }
                                    },
                                    Deposit: {
                                        icon: (0, A.jsx)(I.GlobalIcon, {
                                            lib: "account",
                                            name: "depositoutlined",
                                            theme: "default",
                                            size: 20
                                        }),
                                        onClick: () => {
                                            y.Ay.IFRAME_SPORTSBOOK ? (0, R.W1)("deposit") : ((0, F.qx)(), K.push((0, F.U7)({
                                                accounts: "*",
                                                wallet: "*",
                                                ...(0, j.F)() ? {
                                                    "deposit-methods": "*"
                                                } : {
                                                    deposit: "*"
                                                }
                                            })))
                                        }
                                    },
                                    rewards: {
                                        icon: (0, A.jsx)(I.GlobalIcon, {
                                            lib: "account",
                                            name: "rewardsoutlined",
                                            theme: "default",
                                            size: 20
                                        }),
                                        onClick: () => {
                                            (0, F.qx)(), K.push((0, F.U7)({
                                                accounts: "*",
                                                rewards: "*"
                                            }))
                                        }
                                    },
                                    Bonuses: !1 !== q.is_bonus_allowed ? {
                                        icon: (0, A.jsx)("div", {
                                            className: "profileBadge",
                                            children: (0, A.jsx)(t.A, {
                                                count: ee,
                                                offset: [y.Ay.IS_RTL ? 12 : 0, 1],
                                                size: "small",
                                                className: "profileBadge--wrapper",
                                                children: (0, A.jsx)(I.GlobalIcon, {
                                                    lib: "account",
                                                    name: "bonusesOutlined",
                                                    theme: "default",
                                                    size: 20
                                                })
                                            })
                                        }),
                                        onClick: () => {
                                            (0, F.qx)(), K.push((0, F.U7)({
                                                accounts: "*",
                                                bonuses: "*",
                                                ...(0, j.F)() && we ? {
                                                    menu: "*"
                                                } : {
                                                    bonus: "*"
                                                }
                                            }))
                                        }
                                    } : {}
                                };
                            return (((0, j.F)() ? null === ae || void 0 === ae ? void 0 : ae.accountDropdownSectionsMobile : null === ae || void 0 === ae ? void 0 : ae.accountDropdownSectionsDesktop) || U).forEach((o => {
                                const l = "myProfile" === o.sectionType && q.owner_id && !(0, j.F)();
                                o.hidden || "showHideBalance" === o.sectionType || l || e.push({
                                    label: X(`account.${o.sectionType.replace(/(?:^\w|[A-Z]|\b\w)/g,(function(e,n){return 0==n?e.toLowerCase():e.toUpperCase()})).replace(/\s+/g,"")}`),
                                    key: o.sectionType,
                                    className: "profileInfo__menu-item",
                                    "data-testid": o.sectionType,
                                    ...n[o.sectionType] || {}
                                })
                            })), "0" !== (null === ie || void 0 === ie ? void 0 : ie.showBalanceVisibilitySwitcher) && e.push({
                                label: X(re ? "account.hideBalance" : "account.showAccountBalance"),
                                className: "profileInfo__menu-item",
                                key: "showHideBalance",
                                "data-testid": "showHideBalance",
                                icon: (0, A.jsx)(I.GlobalIcon, {
                                    lib: "generic",
                                    name: "passEye" + (re ? "H" : "V"),
                                    theme: "default",
                                    size: 20
                                }),
                                onClick: () => {
                                    de((e => !e))
                                }
                            }), y.Ay.IS_ACCUMULATED_LOSSES_AVAILABLE && Ae && e.push({
                                label: X("account.accumulatedProfit"),
                                className: "profileInfo__menu-item",
                                key: "accumulatedLosses",
                                "data-testid": "accumulatedLosses",
                                icon: (0, A.jsx)(I.GlobalIcon, {
                                    lib: "account",
                                    name: "accumulatedProfitOutlined",
                                    theme: "default",
                                    size: 20
                                }),
                                onClick: () => {
                                    (0, F.qx)(), K.push((0, F.U7)({
                                        accounts: "*",
                                        settings: "*",
                                        "accumulated-profit": "*"
                                    }))
                                }
                            }), Ie && e.push({
                                label: X("account.bonus-iframe"),
                                className: "profileInfo__menu-item",
                                key: "bonusIframe",
                                "data-testid": "bonusIframe",
                                icon: (0, A.jsx)(I.GlobalIcon, {
                                    lib: "account",
                                    name: "vip",
                                    theme: "default",
                                    size: 20,
                                    color: "#A57B1B"
                                }),
                                onClick: () => {
                                    (0, F.qx)(), K.push((0, F.U7)({
                                        accounts: "*",
                                        "bonus-iframe": "*"
                                    }))
                                }
                            }), e.push({
                                label: X("account.logout"),
                                key: "logout",
                                className: "profileInfo__menuItem--logout profileInfo__menu-item",
                                "data-testid": "logout",
                                icon: (0, A.jsx)(I.GlobalIcon, {
                                    lib: "account",
                                    name: "logout",
                                    theme: "default",
                                    size: 20
                                }),
                                onClick: () => Y()
                            }), (0, A.jsx)(a.default, {
                                items: e,
                                className: (0, _.A)(["profileInfo__customMenu", {
                                    isActiveMenu: _e
                                }])
                            })
                        },
                        getPopupContainer: e => {
                            var n;
                            return (0, j.F)() && (null === (n = e.parentNode) || void 0 === n ? void 0 : n.parentNode) || document.body
                        },
                        children: (0, A.jsx)("span", {
                            ref: Z,
                            className: (0, _.A)(["profileInfo__circleButton", {
                                circleButton__mobile: (0, j.F)()
                            }]),
                            ...!(0, j.F)() && {
                                onClick: () => {
                                    (0, F.qx)(), K.push((0, F.U7)(q.owner_id ? {
                                        accounts: "*",
                                        wallet: "*",
                                        ...(0, j.F)() ? {
                                            "deposit-methods": "*"
                                        } : {
                                            deposit: "*"
                                        }
                                    } : {
                                        accounts: "*",
                                        settings: "*",
                                        profile: "*"
                                    }))
                                }
                            },
                            children: (0, A.jsx)(t.A, {
                                dot: !(!ee && !oe),
                                size: "small",
                                offset: [-2, 7],
                                children: (0, A.jsx)(I.GlobalIcon, {
                                    lib: "account",
                                    name: "userSmall",
                                    theme: "default",
                                    size: (0, j.F)() ? 24 : 28,
                                    className: "profileInfo__circleButton__icon",
                                    onClick: e => {
                                        (ye || je) && (e.stopPropagation(), e.preventDefault(), (0, F.qx)(), K.push((0, F.U7)(q.owner_id && !(0, j.F)() ? {
                                            accounts: "*",
                                            wallet: "*",
                                            ...(0, j.F)() ? {
                                                "deposit-methods": "*"
                                            } : {
                                                deposit: "*"
                                            }
                                        } : {
                                            accounts: "*",
                                            profile: "*"
                                        })))
                                    }
                                })
                            })
                        })
                    }), D && (0, A.jsx)(r.Suspense, {
                        fallback: (0, A.jsx)(s.A.Avatar, {
                            size: (0, j.F)() ? 36 : 40,
                            active: !0,
                            className: "GlobalIcon__skeleton",
                            shape: "circle"
                        }),
                        children: (0, A.jsx)(w.FavoriteOnHeaderIcon, {
                            favoriteTabs: $
                        })
                    }), y.Ay.THEME_SWITCHER && !(0, j.F)() && (0, A.jsx)("span", {
                        className: "changeThemeWrapper",
                        children: (0, A.jsx)(r.Suspense, {
                            fallback: (0, A.jsx)(x.X, {}),
                            children: (0, A.jsx)(H, {})
                        })
                    })]
                })
            }))
        },
        785463: (e, n, o) => {
            o.d(n, {
                V: () => t
            });
            var l = o(507712),
                s = o(841591),
                i = o(679559),
                a = o(462956);
            const t = () => {
                const e = (0, l.d4)(a.gU),
                    n = (0, l.d4)(s.gh),
                    o = (0, l.d4)(i.wz);
                return (() => {
                    if (n) {
                        var l;
                        const s = 1 === +n.referAFriend && (e && !e.reffrend_client_cats || !(null === e || void 0 === e || null === (l = e.reffrend_client_cats) || void 0 === l || !l.includes(o.sportsbook_profile_id))),
                            i = 1 === +n.bonusManagement,
                            a = 1 === +n.bonusManagementOnlyVerified;
                        return !1 !== o.is_bonus_allowed && (s || i && (!a || a && o.is_verified))
                    }
                    return !1
                })()
            }
        },
        174199: (e, n, o) => {
            o.d(n, {
                M: () => c
            });
            o(270757);
            var l = o(694227),
                s = o(55418),
                i = o(570579);
            const a = {
                    width: 64,
                    height: 36
                },
                t = {
                    width: 64,
                    height: 40
                },
                c = () => (0, i.jsx)(l.A, {
                    active: !0,
                    className: "crypto-multi-wallet-skeleton",
                    title: !1,
                    avatar: {
                        style: { ...(0, s.F)() ? a : t,
                            margin: "0",
                            borderRadius: 50
                        }
                    },
                    paragraph: !1
                })
        },
        712261: (e, n, o) => {
            o(628035), o(605192)
        },
        605192: (e, n, o) => {
            o.r(n), o.d(n, {
                default: () => l
            });
            const l = {}
        }
    }
]);
//# sourceMappingURL=accounts-pages.6359987b.chunk.js.map