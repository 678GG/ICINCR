"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [93352], {
        697328: (e, a, n) => {
            n.d(a, {
                o: () => u
            });
            var s = n(365043),
                o = n(889181),
                i = n(679559),
                r = n(507712),
                t = n(888332),
                c = n(123343),
                l = n(462330),
                m = n(490440),
                d = n(570579);
            const u = (0, s.memo)((e => {
                let {
                    reloadIframe: a,
                    externalGameId: n,
                    type: u,
                    iframeRef: f,
                    overlay: _,
                    setOverlay: h,
                    gameOptions: p
                } = e;
                const {
                    isLoading: x,
                    setIsLoading: I
                } = (0, t.I)(), {
                    mounted: S
                } = (0, m.q)(), g = (0, r.d4)(i.eP), v = (0, s.useMemo)((() => {
                    if (S.current && n) return (0, l.I)(n, u, p, !1, void 0, !0)
                }), [n, u, S.current, g]);
                return (0, s.useEffect)((() => () => {
                    I(!0)
                }), []), (0, d.jsxs)("div", {
                    className: "x-casinoGameSingleViewIframe",
                    children: [(0, d.jsx)("div", {
                        className: (0, o.A)(["x-casinoGameSingleViewIframe__spinWrapper", {
                            "x-casinoGameSingleViewIframe__spinWrapper--active": x
                        }]),
                        children: (0, d.jsx)(c.R, {
                            size: 48
                        })
                    }), (0, d.jsx)("iframe", {
                        className: (0, o.A)(["x-casinoGameSingleViewIframe__iframe", {
                            "x-casinoGameSingleViewIframe__iframe--active": !x
                        }]),
                        src: v,
                        ref: f,
                        onLoad: () => {
                            I(!1)
                        },
                        allowFullScreen: !0
                    }, a), (0, d.jsx)("div", {
                        className: (0, o.A)(["x-casinoGameSingleViewIframe__overlay", {
                            "x-casinoGameSingleViewIframe__iframe--active": _
                        }]),
                        onClick: () => {
                            h(!1)
                        }
                    })]
                })
            }))
        },
        853291: (e, a, n) => {
            n.d(a, {
                u: () => A,
                J: () => v
            });
            n(928974);
            var s = n(893908),
                o = n(365043),
                i = n(870905),
                r = n(507712),
                t = n(995392),
                c = n(322908),
                l = n.n(c),
                m = n(679559),
                d = n(527989),
                u = n(816343),
                f = n(596771),
                _ = n(384716),
                h = n(123213),
                p = n(556785),
                x = n(424757),
                I = n(810795),
                S = n(179177),
                g = n(570579);
            let v = function(e) {
                return e[e.SWITCH = 0] = "SWITCH", e[e.DROPDOWN = 1] = "DROPDOWN", e
            }({});
            const w = e => {
                let {
                    switcherMode: a,
                    currentGameId: n
                } = e;
                const {
                    t: c
                } = (0, i.B)(), d = (0, r.d4)(m.eP), {
                    mode: w
                } = (0, _.o)(), A = (0, I.R)(), N = (0, t.W6)(), [O] = (0, o.useState)(JSON.parse(h.A.getItem((0, p.U)("account", "AUTH_DATA")))), {
                    gameId: C
                } = (0, x.i9)(), j = (0, o.useCallback)((e => {
                    if (e && d) N.push((0, u.U7)({
                        mode: "real"
                    }));
                    else {
                        if (e && !d || !e && S.Ay.CASINO_DISABLE_FUN_MODE && !d) {
                            const a = location.pathname.indexOf(`/${S.Ay.SPORTSBOOK_MOUNT_PATH}/`) > -1 ? {
                                gameId: n
                            } : {};
                            return A(), void f.y.setAfterSignIn((() => {
                                N.push({
                                    pathname: `${N.location.pathname}`,
                                    search: l().stringify({ ...a,
                                        mode: e ? "real" : "fun",
                                        accounts: void 0,
                                        login: void 0
                                    })
                                })
                            }))
                        }
                        N.push((0, u.U7)({
                            mode: "fun"
                        }))
                    }
                }), [N.location.pathname, d]);
                (0, o.useEffect)((() => {
                    !("real" === w && d || !d && "fun" === w && S.Ay.IS_CASINO_FUN_MODE_UNAVAILABLE) || null !== O && void 0 !== O && O.auth_token || !C || j("real" === w)
                }), [d, w, C]);
                const G = () => (0, g.jsxs)(g.Fragment, {
                    children: [(0, g.jsx)("div", {
                        className: "x-casinoGameModeSwitcher__label",
                        children: c("casino.funMode")
                    }), (0, g.jsx)(s.A, {
                        className: "x-casinoGameModeSwitcher__switcher",
                        checked: "real" === w,
                        onChange: j
                    }), (0, g.jsx)("div", {
                        className: "x-casinoGameModeSwitcher__label",
                        children: c("casino.realMode")
                    })]
                });
                return a === v.DROPDOWN ? (0, g.jsx)(M, {
                    mode: w,
                    onModeChange: j
                }) : (0, g.jsx)(G, {})
            };
            w.defaultProps = {
                switcherMode: v.SWITCH
            };
            const A = (0, o.memo)(w),
                M = (0, o.memo)((e => {
                    let {
                        mode: a,
                        onModeChange: n
                    } = e;
                    const {
                        t: s
                    } = (0, i.B)(), [r, t] = (0, o.useState)(!1);
                    return (0, o.useEffect)((() => {
                        t(!1)
                    }), [a]), (0, g.jsxs)(d.l, {
                        value: a,
                        open: r,
                        placement: "topLeft",
                        wrapperClassName: "x-casinoGameModeSwitcher__select",
                        dropdownMatchSelectWidth: !1,
                        getPopupContainer: e => e.parentElement,
                        onChange: e => n("real" === e),
                        onClick: () => t((e => !e)),
                        onBlur: () => t(!1),
                        children: [(0, g.jsx)(d.c, {
                            value: "fun",
                            children: s("casino.funMode")
                        }), (0, g.jsx)(d.c, {
                            value: "real",
                            children: s("casino.realMode")
                        })]
                    })
                }))
        },
        888332: (e, a, n) => {
            n.d(a, {
                I: () => o
            });
            var s = n(365043);
            const o = () => {
                const [e, a] = (0, s.useState)(!0);
                return (0, s.useMemo)((() => ({
                    isLoading: e,
                    setIsLoading: a
                })), [e])
            }
        }
    }
]);
//# sourceMappingURL=93352.847ae783.chunk.js.map