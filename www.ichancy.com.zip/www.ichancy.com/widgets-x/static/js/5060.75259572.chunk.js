"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [5060], {
        605060: (a, l, e) => {
            e.d(l, {
                z: () => u
            });
            var o = e(144891);
            const {
                DECIMAL: i,
                FRACTIONAL: n,
                AMERICAN: b,
                HONGKONG: c,
                MALAY: d,
                INDO: s
            } = o.E$, u = [{
                id: i,
                label: "Decimal",
                value: "decimal"
            }, {
                id: n,
                label: "Fractional",
                value: "fractional"
            }, {
                id: b,
                label: "American",
                value: "american"
            }, {
                id: c,
                label: "Hong Kong",
                value: "hongkong"
            }, {
                id: d,
                label: "Malay",
                value: "malay"
            }, {
                id: s,
                label: "Indo",
                value: "indo"
            }]
        }
    }
]);
//# sourceMappingURL=5060.75259572.chunk.js.map