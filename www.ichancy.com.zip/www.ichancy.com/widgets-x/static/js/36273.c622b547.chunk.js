"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [36273], {
        236273: (t, o) => {
            Object.defineProperty(o, "__esModule", {
                value: !0
            }), o.default = o.placements = void 0;
            var e = {
                    adjustX: 1,
                    adjustY: 1
                },
                f = [0, 0],
                s = {
                    left: {
                        points: ["cr", "cl"],
                        overflow: e,
                        offset: [-4, 0],
                        targetOffset: f
                    },
                    right: {
                        points: ["cl", "cr"],
                        overflow: e,
                        offset: [4, 0],
                        targetOffset: f
                    },
                    top: {
                        points: ["bc", "tc"],
                        overflow: e,
                        offset: [0, -4],
                        targetOffset: f
                    },
                    bottom: {
                        points: ["tc", "bc"],
                        overflow: e,
                        offset: [0, 4],
                        targetOffset: f
                    },
                    topLeft: {
                        points: ["bl", "tl"],
                        overflow: e,
                        offset: [0, -4],
                        targetOffset: f
                    },
                    leftTop: {
                        points: ["tr", "tl"],
                        overflow: e,
                        offset: [-4, 0],
                        targetOffset: f
                    },
                    topRight: {
                        points: ["br", "tr"],
                        overflow: e,
                        offset: [0, -4],
                        targetOffset: f
                    },
                    rightTop: {
                        points: ["tl", "tr"],
                        overflow: e,
                        offset: [4, 0],
                        targetOffset: f
                    },
                    bottomRight: {
                        points: ["tr", "br"],
                        overflow: e,
                        offset: [0, 4],
                        targetOffset: f
                    },
                    rightBottom: {
                        points: ["bl", "br"],
                        overflow: e,
                        offset: [4, 0],
                        targetOffset: f
                    },
                    bottomLeft: {
                        points: ["tl", "bl"],
                        overflow: e,
                        offset: [0, 4],
                        targetOffset: f
                    },
                    leftBottom: {
                        points: ["br", "bl"],
                        overflow: e,
                        offset: [-4, 0],
                        targetOffset: f
                    }
                };
            o.placements = s;
            var r = s;
            o.default = r
        }
    }
]);
//# sourceMappingURL=36273.c622b547.chunk.js.map