"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [40999], {
        140999: (e, o, t) => {
            t.d(o, {
                v: () => c
            });
            var n = t(365043);
            const c = function() {
                let e = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0],
                    o = arguments.length > 1 ? arguments[1] : void 0;
                const t = (0, n.useRef)(null);
                (0, n.useEffect)((() => {
                    if (o) return;
                    const n = setTimeout((() => {
                        e && "hidden" !== document.body.style.overflow && (t.current = window.scrollY, document.body.style.overflow = "hidden", document.body.style.touchAction = "none", document.documentElement.style.overflow = "hidden", document.body.style.position = "fixed")
                    }), 200);
                    return () => {
                        if (!o && (clearTimeout(n), document.body.style.removeProperty("position"), document.body.style.removeProperty("touch-action"), e)) {
                            const e = setInterval((() => {
                                document.body.style.overflow = "", document.documentElement.style.overflow = "", clearInterval(e)
                            }), 100);
                            t.current && window.scrollTo(0, t.current)
                        }
                    }
                }), [e])
            }
        }
    }
]);
//# sourceMappingURL=40999.2ae5dab3.chunk.js.map