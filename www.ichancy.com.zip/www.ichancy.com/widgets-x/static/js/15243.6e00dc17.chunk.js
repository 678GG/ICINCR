"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [15243], {
        15243: (e, t, r) => {
            var n = r(50130),
                u = r(487066);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function() {
                var e = a.useReducer((function(e) {
                    return e + 1
                }), 0);
                return (0, o.default)(e, 2)[1]
            };
            var o = n(r(579459)),
                a = function(e, t) {
                    if (!t && e && e.__esModule) return e;
                    if (null === e || "object" !== u(e) && "function" !== typeof e) return {
                        default: e
                    };
                    var r = f(t);
                    if (r && r.has(e)) return r.get(e);
                    var n = {},
                        o = Object.defineProperty && Object.getOwnPropertyDescriptor;
                    for (var a in e)
                        if ("default" !== a && Object.prototype.hasOwnProperty.call(e, a)) {
                            var c = o ? Object.getOwnPropertyDescriptor(e, a) : null;
                            c && (c.get || c.set) ? Object.defineProperty(n, a, c) : n[a] = e[a]
                        }
                    n.default = e, r && r.set(e, n);
                    return n
                }(r(365043));

            function f(e) {
                if ("function" !== typeof WeakMap) return null;
                var t = new WeakMap,
                    r = new WeakMap;
                return (f = function(e) {
                    return e ? r : t
                })(e)
            }
        }
    }
]);
//# sourceMappingURL=15243.6e00dc17.chunk.js.map