"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [77971], {
        177971: (r, t, e) => {
            e.d(t, {
                Z: () => u
            });
            var s = e(365043);
            const u = (r, t) => {
                const e = (0, s.useRef)({
                    target: r,
                    previous: t
                });
                return JSON.stringify(e.current.target) !== JSON.stringify(r) && (e.current.previous = e.current.target, e.current.target = r), e.current.previous
            }
        }
    }
]);
//# sourceMappingURL=77971.a89c5fbc.chunk.js.map