"use strict";
(self.webpackChunksportsbook_v3_0 = self.webpackChunksportsbook_v3_0 || []).push([
    [63354], {
        23725: (e, s, t) => {
            t.r(s), t.d(s, {
                CustomMenu: () => _
            });
            t(270757);
            var n = t(694227),
                o = t(365043),
                u = t(478395),
                l = t(889181),
                c = t(989618),
                i = t(179177),
                r = t(55418),
                a = t(570579);
            const {
                Homework: m
            } = (0, c.R)((() => Promise.all([t.e(87161), t.e(34426), t.e(55608), t.e(84107), t.e(81927), t.e(35834), t.e(70136), t.e(28151), t.e(90440), t.e(35905), t.e(41591), t.e(66297)]).then(t.bind(t, 371160)))), _ = (0, o.memo)((e => {
                let {
                    items: s,
                    fullWidth: t,
                    activeItem: c,
                    setActiveItem: _,
                    inverseColors: d,
                    disabled: p,
                    count: v,
                    homework: h,
                    className: M
                } = e;
                const k = (0, o.useRef)(null);
                return (0, u.w)((() => {
                    var e;
                    null === (e = k.current) || void 0 === e || e.scrollIntoView({
                        behavior: "smooth",
                        inline: "center",
                        block: "center"
                    })
                }), [c]), (0, a.jsx)("div", {
                    className: (0, l.A)([`customMenu__wrapper ${M||""}`, {
                        "customMenu__wrapper--mobile": (0, r.F)(),
                        "customMenu__wrapper--desktop": !(0, r.F)(),
                        "customMenu__wrapper--fullWidth": t,
                        "customMenu__wrapper--inverse": d,
                        "customMenu__wrapper--disabled": p
                    }]),
                    children: (0, a.jsxs)("div", {
                        className: "customMenu",
                        children: [h && i.Ay.HOMEWORK_ENABLED ? (0, a.jsx)(o.Suspense, {
                            children: (0, a.jsx)(m, {})
                        }) : null, s.map((e => {
                            var s;
                            return (0, a.jsx)("div", {
                                ref: (0, r.F)() && c === e.key ? k : null,
                                className: (0, l.A)(["customMenu__item", {
                                    "customMenu__item--mobile": (0, r.F)(),
                                    "customMenu__item--inverse": d,
                                    "customMenu__item--active": c === e.key
                                }]),
                                onClick: () => _(e.key),
                                "data-testid": null === (s = e.value) || void 0 === s ? void 0 : s.toLowerCase(),
                                children: e.skeleton ? (0, a.jsx)(n.A, {
                                    className: "customMenu__skeleton",
                                    title: {
                                        width: "50px"
                                    },
                                    paragraph: !1
                                }) : (0, a.jsxs)(a.Fragment, {
                                    children: [e.icon && (0, a.jsx)("div", {
                                        className: (0, l.A)(["customMenu__item__icon", {
                                            "customMenu__item__icon--inverse": d
                                        }]),
                                        children: e.icon
                                    }), (0, a.jsx)("span", {
                                        className: `customMenu__item--label ${h?"customMenu__item--label--sports-bar":""} ${c===e.key&&d?"active":""}`,
                                        children: e.value
                                    }), v && null !== e && void 0 !== e && e.count ? (0, a.jsx)("span", {
                                        className: "customMenu__item-count",
                                        children: e.count
                                    }) : ""]
                                })
                            }, e.key || e.value)
                        }))]
                    })
                })
            }))
        }
    }
]);
//# sourceMappingURL=custom-menu.750e130f.chunk.js.map