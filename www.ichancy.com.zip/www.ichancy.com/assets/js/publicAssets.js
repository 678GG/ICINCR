let global_GallerySettings = {};
let isV3AuthPopup = !1;
window.UcAnchor = {
    checkAnchor: function() {
        if (location.hash) {
            let alias = decodeURIComponent(location.hash).replace('#', '');
            anchor = window.UcAnchor.getAnchorByAlias(alias);
            if (anchor) {
                if (anchor.mId) {
                    alias = `m${anchor.mId}`
                } else if (anchor.rId) {
                    alias = `r${anchor.rId}`
                } else {
                    anchor = null
                }
                return {
                    target: document.getElementById(alias),
                    anchor: anchor
                }
            }
        }
        return {
            target: null,
            anchor: null
        }
    },
    isInProgress: !1,
    checkAndScrollAnchor: function(animate, onLoad = !1) {
        let {
            target,
            anchor
        } = window.UcAnchor.checkAnchor();
        if (target && anchor && (!window.UcAnchor.isInProgress || onLoad)) {
            window.UcAnchor.scrollToAnchor(target, animate, anchor)
        }
    },
    getAnchorByAlias: function(alias) {
        let anchor;
        let anchorMapping = JSON.parse(window.anchorMapping);
        for (let key in anchorMapping) {
            if (anchorMapping[key].alias === alias) {
                anchor = anchorMapping[key]
            }
        }
        return anchor
    },
    getCorrectAlias(anchor) {
        let alias = anchor.alias;
        if (anchor.mId) {
            alias = `m${anchor.mId}`
        } else if (anchor.rId) {
            alias = `r${anchor.rId}`
        } else {
            alias = null
        }
        return alias
    },
    getAnchorById: function(anchorId) {
        let anchorMapping = JSON.parse(window.anchorMapping);
        return anchorMapping[anchorId]
    },
    scrollToAnchor: function(target, animation, anchor) {
        var documentMainNode = window.popupIframe ? $('.popup-wrapper-inner') : $('html, body');
        var headerFixedRows = document.querySelectorAll('.header-rows .header-row-fix');
        var posDifference = 0;
        headerFixedRows.forEach(function(fixRow) {
            var fixRowWrapper = fixRow.closest('.header-row-wrapper');
            posDifference += fixRowWrapper.offsetHeight
        });
        var targetCoords = getCoords(target);
        var ucAnimations = $('.uc-animation');
        ucAnimations.each(function() {
            if ($(this).offset().top <= targetCoords.top) {
                $(this).addClass('active')
            }
        });
        if (animation) {
            documentMainNode.animate({
                scrollTop: (targetCoords.top - posDifference) - +anchor.margin,
                duration: 800,
            }, {
                progress: function(animation, progress, msRemaining) {
                    if (!window.popupIframe) {
                        targetCoords = getCoords(target)
                    }
                    this.eachStepPosition = 0;
                    if (typeof this.prevPosition !== 'undefined') {
                        var eachPosition = documentMainNode.scrollTop() - this.prevPosition;
                        if (this.eachStepPosition <= eachPosition) {
                            this.eachStepPosition = documentMainNode.scrollTop() - this.prevPosition
                        }
                    }
                    if (documentMainNode.scrollTop() + this.eachStepPosition > targetCoords.top) {
                        documentMainNode.animate({
                            scrollTop: targetCoords.top - posDifference
                        }, msRemaining);
                        documentMainNode.stop()
                    }
                    this.prevPosition = $(document).scrollTop()
                }
            });
            window.UcAnchor.isInProgress = !1
        } else {
            if (window.history.scrollRestoration === "auto") {
                window.history.scrollRestoration = "manual"
            }
            setTimeout(function() {
                target.scrollIntoView();
                if (anchor.margin) {
                    window.scrollBy(0, -anchor.margin)
                }
                window.UcAnchor.isInProgress = !1
            }, 100)
        }
    }
};
if (document.querySelector('.loading-page-animation')) {
    window.addEventListener('load', () => {
        document.querySelector('.loading-page-animation').remove();
        document.body.classList.remove('body__loading-page-container')
    })
}
document.addEventListener("DOMContentLoaded", ready);

function createCopyTextTooltip(text, content) {
    let copyText = null;
    if (content) {
        copyText = document.querySelector('.copy-text-tooltip')
        if (copyText)
            copyText.innerHTML = window.typographyTranslations[`typography.${text ? text : 'copiedText'}`] || "Text copied"
    } else {
        copyText = document.createElement("div");
        copyText.classList.add('copy-text-tooltip');
        const newContent = document.createTextNode(window.typographyTranslations[`typography.${text ? text : 'copiedText'}`] || "Text copied");
        copyText.appendChild(newContent);
        document.body.appendChild(copyText)
    }
    return copyText
};

function ready() {
    document.documentElement.removeEventListener("DOMContentLoaded", ready);
    let timeout = setTimeout(() => {
        window.UcAnchor.isInProgress = !0;
        window.UcAnchor.checkAndScrollAnchor(!0, !0);
        clearTimeout(timeout)
    }, 1000);
    window.popupLoaded = !1;
    getAllPopups();
    Array.from(document.querySelectorAll('.copy-text') || []).forEach((element) => {
        element.addEventListener('mouseenter', (event) => {
            let copyText = document.querySelector('.copy-text-tooltip');
            copyText = createCopyTextTooltip('copyToClipboard', copyText);
            let rect = event.target.getBoundingClientRect();
            let copyRect = copyText.getBoundingClientRect();
            if (rect) {
                copyText.style.top = `${rect.top + rect.height + 5}px`;
                copyText.style.left = `${rect.left + rect.width - copyRect.width}px`
            }
            let timeout = setTimeout(() => {
                copyText.remove();
                clearTimeout(timeout)
            }, 3000);
            document.addEventListener('scroll', () => {
                let copyText = document.querySelector('.copy-text-tooltip');
                if (!copyText) return;
                copyText.remove();
                timeout && clearTimeout(timeout)
            })
        });
        element.addEventListener('click', (event) => {
            try {
                const toCopy = event.target.innerText;
                navigator.clipboard.writeText(toCopy)
            } catch (err) {
                console.error('Failed to copy: ', err)
            }
            let copyText = document.querySelector('.copy-text-tooltip');
            copyText = createCopyTextTooltip(null, copyText);
            let rect = event.target.getBoundingClientRect();
            let copyRect = copyText.getBoundingClientRect();
            if (rect) {
                copyText.style.top = `${rect.top + rect.height + 5}px`;
                copyText.style.left = `${rect.left + rect.width + 5 - copyRect.width}px`
            }
            let timeout = setTimeout(() => {
                copyText.remove();
                clearTimeout(timeout)
            }, 3000);
            document.addEventListener('scroll', () => {
                let copyText = document.querySelector('.copy-text-tooltip');
                if (!copyText) return;
                copyText.remove();
                timeout && clearTimeout(timeout)
            })
        })
    })
}
$(function() {
    $('a[href*="#"]:not([href="#"]), .anchor-click').click(function(e) {
        if (location.pathname.replace(/^\//, '').replace(/\/$/, '') == this.pathname.replace(/^\//, '').replace(/\/$/, '') && location.hostname == this.hostname) {
            try {
                window.UcAnchor.isInProgress = !0;
                let anchorId = this.getAttribute('data-link');
                let linkType = this.getAttribute('data-linktype');
                let anchor = window.UcAnchor.getAnchorByAlias((this.href || "#").split('#')[1]);
                let alias = window.UcAnchor.getCorrectAlias(anchor);
                if (anchor && alias) {
                    target = $('[id=' + alias + ']');
                    if (target.length) {
                        $('.layers-container .layer .off-canvas').removeClass('open');
                        $('body').removeClass('no-scroll');
                        var offCanvasButton = document.querySelector('.off-canvas-button svg');
                        if (offCanvasButton && offCanvasButton.style.display === 'none') {
                            offCanvasButton.style.display = ''
                        }
                        setTimeout(function() {
                            window.UcAnchor.scrollToAnchor(target.get(0), !0, anchor)
                        }, 300);
                        history.pushState({}, "", $(this).attr('href'));
                        return !1
                    }
                }
            } catch (e) {}
        }
    })
});

function setShowLayoutParamsAllLinks() {
    var params = window.location.search.substring(1).split('&');
    if ($.inArray('show-layout=body', params) !== -1) {
        $('a').each(function() {
            var search = {};
            var hashStr = !1;
            var link = $(this).attr('href');
            if (link && link !== '#') {
                var hashParamsArray = link.split('#');
                if (hashParamsArray[1]) {
                    hashStr = hashParamsArray[1];
                    link = link.replace('#' + hashStr, '')
                }
                var params = link.split('?');
                if (params[1]) {
                    var searchParams = params[1].split('=');
                    if (searchParams[0] && searchParams[1]) {
                        search[searchParams[0]] = searchParams[1]
                    }
                }
                var newLink = '';
                if (search['show-layout'] !== 'body') {
                    newLink += '?show-layout=body'
                }
                if (Object.keys(search).length) {
                    newLink += '&'
                }
                Object.keys(search).map(function(paramKey, index) {
                    if (index !== Object.keys(search).length - 1) {
                        newLink += '&'
                    }
                    newLink += paramKey + '=' + search[paramKey]
                });
                if (hashStr) {
                    newLink += '#' + hashStr
                }
                $(this).attr('href', params[0] + newLink)
            }
        })
    }
}

function getCoords(elem) {
    var box = elem.getBoundingClientRect();
    var popupWrapper = window.popupIframe ? document.querySelector('.popup-wrapper-inner') : null;
    var body = document.body;
    var docEl = document.documentElement;
    var scrollTop = popupWrapper ? popupWrapper.scrollTop - popupWrapper.getBoundingClientRect().top : window.pageYOffset || docEl.scrollTop || body.scrollTop;
    var scrollLeft = popupWrapper ? popupWrapper.scrollTop - popupWrapper.getBoundingClientRect().left : window.pageXOffset || docEl.scrollLeft || body.scrollLeft;
    var clientTop = docEl.clientTop || body.clientTop || 0;
    var clientLeft = docEl.clientLeft || body.clientLeft || 0;
    var top = box.top + scrollTop - clientTop;
    var left = box.left + scrollLeft - clientLeft;
    return {
        top: Math.round(top),
        left: Math.round(left)
    }
}

function fixFooter() {
    if (!window.footerFixed && document.querySelector('.footer-rows')) {
        var pushHeight = document.querySelector('.header-and-main-rows .push') && document.querySelector('.header-and-main-rows .push').getBoundingClientRect().height;
        if (document.querySelector('.header-and-main-rows').getBoundingClientRect().height > window.outerHeight) {
            if (pushHeight && +pushHeight > 0) {
                document.querySelector('.header-and-main-rows .push').style.height = "0"
            }
            document.querySelector('.header-and-main-rows').style.marginBottom = "";
            document.querySelector('.main-body>.main-layout').style.height = "auto";
            window.footerFixed = !0
        } else {
            var footerHeight = $('.footer-rows').height();
            if (footerHeight !== undefined) {
                $('.header-and-main-rows').css('margin-bottom', '-' + footerHeight + 'px');
                $('.main-body .push').css('height', footerHeight + 'px')
            }
        }
    }
}
var underHeaderModules = ['ModuleImage', 'ModuleSlider', 'ModuleVideo', 'ModuleMap'];
(function($) {
    if ($.fn.style) {
        return
    }
    var escape = function(text) {
        return text.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&")
    };
    var isStyleFuncSupported = !!CSSStyleDeclaration.prototype.getPropertyValue;
    if (!isStyleFuncSupported) {
        CSSStyleDeclaration.prototype.getPropertyValue = function(a) {
            return this.getAttribute(a)
        };
        CSSStyleDeclaration.prototype.setProperty = function(styleName, value, priority) {
            this.setAttribute(styleName, value);
            var priority = typeof priority != 'undefined' ? priority : '';
            if (priority != '') {
                var rule = new RegExp(escape(styleName) + '\\s*:\\s*' + escape(value) + '(\\s*;)?', 'gmi');
                this.cssText = this.cssText.replace(rule, styleName + ': ' + value + ' !' + priority + ';')
            }
        };
        CSSStyleDeclaration.prototype.removeProperty = function(a) {
            return this.removeAttribute(a)
        };
        CSSStyleDeclaration.prototype.getPropertyPriority = function(styleName) {
            var rule = new RegExp(escape(styleName) + '\\s*:\\s*[^\\s]*\\s*!important(\\s*;)?', 'gmi');
            return rule.test(this.cssText) ? 'important' : ''
        }
    }
    $.fn.style = function(styleName, value, priority) {
        var node = this.get(0);
        if (typeof node == 'undefined') {
            return this
        }
        var style = this.get(0).style;
        if (typeof styleName != 'undefined') {
            if (typeof value != 'undefined') {
                priority = typeof priority != 'undefined' ? priority : '';
                style.setProperty(styleName, value, priority);
                return this
            } else {
                return style.getPropertyValue(styleName)
            }
        } else {
            return style
        }
    }
})(jQuery);
$.fn.hasClassStartingWith = function(needle) {
    var found_match = !1;
    $(this).each(function(i) {
        var classlist = this.className.split(/\s+/);
        $.each(classlist, function() {
            if (this.startsWith(needle)) {
                found_match = !0
            }
        })
    });
    return found_match
}

function fixFirstRowMarginTop() {
    var header = $('.uc-row.header-row');
    if (header.length && $('.header-rows').hasClass('header-overlapped')) {
        if ($('.main-rows>.uc-row-wrapper').length) {
            var headerRows = $('.main-layout .header-and-main-rows>.header-rows');
            var headerHeight = headerRows.height();
            var firstRow = $('.main-rows>.uc-row-wrapper:first-child');
            var colLength = firstRow.find('>.uc-row>.row-container>.row>.column').length;
            firstRow.find('>.uc-row>.row-container>.row>.column').each(function(index) {
                var firstModule = $(this).find('>.column-container>.module-container.first');
                var res = !1;
                for (var i in underHeaderModules) {
                    if (firstModule.hasClass(underHeaderModules[i])) {
                        res = !0
                    }
                }
                if (!res || colLength > 1) {
                    if (!window.isMobile) {
                        $(this).style('padding-top', parseInt($(this).css('padding-bottom')) + headerHeight + 'px', 'important')
                    } else {
                        if ($(this).hasClassStartingWith('col-xs-')) {
                            $(this).style('padding-top', parseInt($(this).css('padding-bottom')) + headerHeight + 'px', 'important')
                        } else if (index === 0) {
                            firstRow.find('>.uc-row>.row-container>.row>.column').first().style('padding-top', parseInt($(this).css('padding-bottom')) + headerHeight + 'px', 'important')
                        }
                    }
                }
            })
        }
    }
}
var resizeTimeOut = null;
$(document).ready(function() {
    setShowLayoutParamsAllLinks();
    if ($('html.admin-mode').length) {
        return
    }
    fixFooter();
    fixHeaderRows();
    fixFirstRowMarginTop();
    let windowWidthResize = $(window).width();
    $(window).on('resize', function() {
        if ($(window).width() != windowWidthResize) {
            windowWidthResize = $(window).width();
            clearTimeout(resizeTimeOut);
            resizeTimeOut = setTimeout(function() {
                fixFooter();
                fixFirstRowMarginTop();
                winWidth = $(window).width()
            }, 400)
        }
    })
});
$(window).on('load', function() {
    calculateVideoBackgroundPosition()
});
var calcTimeout = null;
$(window).resize(function() {
    clearTimeout(calcTimeout);
    calcTimeout = setTimeout(function() {
        calculateVideoBackgroundPosition()
    }, 200)
});

function calculateVideoBackgroundPosition() {
    $('.uc-row').each(function() {
        if ($(this).find('>.video-container').length) {
            var rowHeight = $(this).height();
            var rowWidth = $(this).width();
            var ratio = rowHeight / rowWidth;
            var posX = $(this).find('.video-container iframe').attr('data-X');
            var posY = $(this).find('.video-container iframe').attr('data-Y');
            if (ratio > 0.5625) {
                var left = (((16 / 9) * rowHeight - rowWidth) * parseInt(posX)) / 100;
                $(this).find('.video-container iframe').css({
                    'height': rowHeight + 'px',
                    'width': (16 / 9) * rowHeight + 'px',
                    'left': -left + 'px',
                    'top': 0
                })
            } else {
                var top = (((9 / 16) * rowWidth - rowHeight) * parseInt(posY)) / 100;
                $(this).find('.video-container iframe').css({
                    'width': rowWidth + 'px',
                    'height': (9 / 16) * rowWidth + 'px',
                    'top': -top + 'px',
                    'left': 0
                })
            }
        }
    })
};
$(document).ready(function() {
    $(document).on('click', '.label-link', function() {
        var obj = $(this);
        if (obj.html() == 'http://') {
            obj.html('https://')
        } else {
            obj.html('http://')
        }
        updateFakeInput($(this))
    });
    $(document).on('change', '.link-input .fake-input', function() {
        updateFakeInput($(this))
    });

    function updateFakeInput(obj) {
        var parent = obj.closest('.link-input');
        var http = parent.find('.label-link').html();
        var linkval = parent.find('.fake-input').val();
        if (linkval.indexOf('http://') > -1) {
            linkval = linkval.replace("http://", "");
            http = "http://"
        } else if (linkval.indexOf('https://') > -1) {
            linkval = linkval.replace("https://", "");
            http = "https://"
        }
        parent.find('.fake-input').val(linkval);
        parent.find('.label-link').html(http);
        if (linkval) {
            parent.find('.fake-input').siblings('input').val(http + linkval)
        }
    }

    function updateHttpField(obj) {
        var parent = obj.closest('.link-input');
        var val = obj.val();
        var http = '';
        if (val.indexOf('http://') > -1) {
            val = val.replace("http://", "");
            http = "http://"
        } else if (val.indexOf('https://') > -1) {
            val = val.replace("https://", "");
            http = "https://"
        }
        parent.find('.label-link').html(http);
        parent.find('.fake-input').val(val)
    }
    $(document).on('keypress', '.stepper input, .stepper-vertical input', function(e) {
        var code = parseInt(e.which);
        if (!((code == 8 || code === 0) || (code >= 37 && code <= 40) || (code >= 48 && code <= 57))) {
            e.preventDefault()
        }
    });
    $(document).on('keyup', '.stepper input', function(e) {
        if ($(this).val() === '') {
            $(this).val(0)
        }
        if ($(this).val() !== (parseInt($(this).val()) + '')) {
            $(this).val(parseInt($(this).val()))
        }
        if ($(this).val() < $(this).data('min')) {
            $(this).val($(this).data('min'))
        }
    });
    $(document).on('change', '.stepper input', function(e) {
        var val = $(this).val();
        if (!parseInt(val))
            $(this).val(0)
    });
    $(document).on('click', '.stepper span, .stepper-vertical span', function() {
        var input = $(this).parent().find('input');
        var max = parseInt(input.data('max'));
        var min = parseInt(input.data('min'));
        var value = input.val();
        if (value === "") {
            $(this).val(0);
            value = 0
        }
        var number = parseInt(value);
        if ($(this).is(':first-child')) {
            if (isNaN(min) || number > min) {
                number = number - 1;
                input.val(number);
                input.trigger('change')
            }
        } else {
            if (isNaN(max) || number < max) {
                number = number + 1;
                input.val(number);
                input.trigger('change')
            }
        }
    });
    $(document).on('click', '.link-box i', function() {
        $(this).parent().toggleClass('active')
    });
    $(document).on('keyup', '.stepper-form .stepper input', function() {
        if ($(this).closest('.stepper-form').find('.link-box').hasClass('active')) {
            constraint($(this).closest('.stepper-form'), $(this).data('obj'))
        }
    });
    $(document).on('click keyup', '.stepper-form .stepper span', function() {
        if ($(this).closest('.stepper-form').find('.link-box').hasClass('active')) {
            constraint($(this).closest('.stepper-form'), $(this).closest('.stepper').find('input').data('obj'))
        }
    });

    function constraint(obj, attr) {
        var origW = obj.data('width');
        var origH = obj.data('height');
        var prop = origW / origH;
        var curW = obj.find('input[data-obj="width"]');
        var curH = obj.find('input[data-obj="height"]');
        var val;
        if (attr == 'width') {
            val = Math.round(parseInt(curW.val()) / prop);
            if (!val) val = 1;
            curH.val(val)
        } else if (attr == 'height') {
            val = Math.round(parseInt(curH.val()) * prop);
            if (!val) val = 1;
            curW.val(val)
        }
    }
    $(document).on('keydown', '.key-stepper', function(e) {
        var code = parseInt(e.which);
        if (!((code == 8 || code == 46) || (code >= 37 && code <= 40) || (code >= 48 && code <= 57) || (code >= 96 && code <= 105) || (code == 13))) {
            e.preventDefault()
        }
        var key = e.which;
        if (key == 38 || key == 40) {
            e.preventDefault();
            var input = $(this),
                value = parseFloat(input.val()) * 1000,
                min = input.data('min') * 1000,
                max = input.data('max') * 1000,
                step = input.data('step') * 1000 || 1000;
            if (key == 38) {
                value += step;
                if (value > max) {
                    value = max
                }
            } else {
                value -= step;
                if (value < min) {
                    value = min
                }
            }
            input.val(value / 1000).trigger('change')
        }
    }).on('change', '.key-stepper', function(e) {
        var input = $(this),
            value = parseFloat(input.val()),
            min = input.data('min'),
            max = input.data('max');
        if (isNaN(value)) {
            value = min - 1
        }
        if (value > max) {
            value = max;
            input.val(value);
            input.trigger('change')
        } else if (value < min) {
            value = min;
            input.val(value);
            input.trigger('change')
        } else {
            input.val(value)
        }
    });
    $(document).on('focus', 'input.error,textarea.error', function() {
        var obj = $(this).find('+.input-message.error.msg-hidden');
        if (obj.length) {
            obj.closest('form').find('.input-message.error:not(.msg-hidden)').addClass('msg-hidden');
            obj.removeClass('msg-hidden')
        }
    });
    $(document).on('mousedown', '.form-three-one.error', function() {
        var obj = $(this).find('+.input-message.error.msg-hidden');
        if (obj.length) {
            obj.closest('form').find('.input-message.error:not(.msg-hidden)').addClass('msg-hidden');
            obj.removeClass('msg-hidden')
        }
    });
    $(document).on('keyup change', '[class*="val-"].error:not(.val-noval)', function() {
        $(this).validate()
    });
    $(document).on('keyup change', '[class*="val-"].error:not(.val-noval) input,[class*="val-"].error:not(.val-noval) select,[class*="val-"].error:not(.val-noval) textarea', function() {
        $(this).closest('[class*="val-"]').validate()
    });
    $(document).on('click', '.input-message.error', function() {
        $(this).addClass('msg-hidden')
    });
    $('.system-message-container').on('click', '.system-message > i', function() {
        hideSystemMessage($(this).parent())
    });
    $('.changer').each(function() {
        var changer = $(this);
        changerChange(changer);
        changer.on('change', function() {
            changerChange(changer)
        })
    });

    function changerChange(changer) {
        if (changer.prop('type') == 'checkbox') {
            value = changer.prop('checked')
        } else {
            value = changer.val()
        }
        var group = changer.data('group'),
            inputs = $('[data-changeGroup="' + group + '"]'),
            neededInput = inputs.filter('[data-changeValue="' + value + '"]'),
            otherInputs = inputs.not('[data-changeValue="' + value + '"]');
        neededInput.css({
            display: 'block'
        });
        neededInput.removeClass('val-noval');
        neededInput.find('.val-noval').removeClass('val-noval');
        otherInputs.css({
            display: 'none'
        }).each(function() {
            var hidingInput = $(this);
            if (hidingInput.is('[class*="val-"]')) {
                hidingInput.addClass('val-noval')
            } else {
                hidingInput.find('[class*="val-"]').addClass('val-noval')
            }
        })
    }
    $(document).on('click', '.background-type a', function() {
        var obj = $(this);
        var objType = $(this).attr('data-background-type');
        if (obj.parent().hasClass('active')) {} else {
            obj.closest('.background-type').find('.active').removeClass('active');
            obj.parent().addClass('active');
            obj = $(this).closest('.background-type').siblings('.background-container');
            obj.children('div[data-background-type="' + objType + '"]').fadeIn(function() {
                $(this).addClass('active')
            });
            obj.children('.active').css({
                'position': 'absolute',
                'top': '0'
            }).fadeOut(function() {
                $(this).removeClass('active');
                $(this).css('position', 'relative')
            })
        }
    });
    $(document).on('keyup', '.content.current.active input[name=title]', function(e) {
        e.preventDefault();
        e.stopPropagation();
        var titleVal = $(this).val();
        var titlePrev = $(this).attr('data-prev-value');
        if (typeof titlePrev === 'undefined') {
            titlePrev = $(this).prop('defaultValue')
        }
        var alias = $(this).parents('.content.current.active').find('input[name=alias]');
        if (convertToAlias(titlePrev) == alias.val() || alias.val() == '') {
            alias.val(convertToAlias(titleVal))
        }
        $(this).attr('data-prev-value', titleVal)
    });
    $(document).on('click touchstart', '.preview-message .close-message', function() {
        $('.preview-message').addClass('hide-message')
    })
});
(function($) {
    $.fn.resizeBoxInit = function(width) {
        var parent = $(this);
        var marginBox = !1;
        if (parent.hasClass('margin-box')) {
            marginBox = !0
        }
        var tempInputs = {};
        tempInputs.top = parent.find('.resize-box-inputs input[data-resize="top"]');
        tempInputs.left = parent.find('.resize-box-inputs input[data-resize="left"]');
        tempInputs.right = parent.find('.resize-box-inputs input[data-resize="right"]');
        tempInputs.bottom = parent.find('.resize-box-inputs input[data-resize="bottom"]');
        var inputs = {
            top: {
                object: tempInputs.top,
                value: parseInt(tempInputs.top.val()),
                min: tempInputs.top.data('min'),
                max: tempInputs.top.data('max')
            },
            right: {
                object: tempInputs.right,
                value: parseInt(tempInputs.right.val()),
                min: tempInputs.right.data('min'),
                max: tempInputs.right.data('max')
            },
            bottom: {
                object: tempInputs.bottom,
                value: parseInt(tempInputs.bottom.val()),
                min: tempInputs.bottom.data('min'),
                max: tempInputs.bottom.data('max')
            },
            left: {
                object: tempInputs.left,
                value: parseInt(tempInputs.left.val()),
                min: tempInputs.left.data('min'),
                max: tempInputs.left.data('max')
            }
        };
        var boxSize = width || 146;
        if (marginBox) {
            boxSize = 36 + 2 * inputs.top.max
        }
        parent.find('.resize-box').css({
            width: boxSize,
            height: boxSize
        });
        applyPaddings();
        var mouseDown = 0;
        var startX = -1;
        var startY = -1;
        var object = null;
        parent.find('.resize-box .resize-box-preview > div').on('mousedown', function(e) {
            mouseDown = 1;
            $("body").addClass('disableHighlight');
            startX = e.pageX;
            startY = e.pageY;
            object = $(this);
            var resize = object.data('resize');
            if (resize == 'top') {
                if (marginBox) {
                    oldStart = startY - inputs.top.max + inputs.top.value
                } else {
                    oldStart = startY - inputs.top.value
                }
            } else if (resize == 'bottom') {
                if (marginBox) {
                    oldStart = startY + inputs.bottom.max - inputs.bottom.value
                } else {
                    oldStart = startY + inputs.bottom.value
                }
            } else if (resize == 'left') {
                oldStart = startX - inputs.left.value
            } else if (resize == 'right') {
                oldStart = startX + inputs.right.value
            }
        });
        $(document).on('mousemove', function(e) {
            if (!mouseDown) return;
            var resize = object.data('resize');
            var min = parseInt(inputs[resize].min);
            var max = parseInt(inputs[resize].max);
            if (resize == 'top') {
                if (marginBox) {
                    inputs[resize].value -= e.pageY - startY
                } else {
                    inputs[resize].value += e.pageY - startY
                }
                startY = e.pageY;
                if (marginBox) {
                    if (startY - oldStart < min) {
                        inputs[resize].value = max
                    }
                    if (startY - oldStart > max) {
                        inputs[resize].value = min
                    }
                } else {
                    if (startY - oldStart > max) {
                        inputs[resize].value = max
                    }
                    if (startY - oldStart < min) {
                        inputs[resize].value = min
                    }
                }
            } else if (resize == 'bottom') {
                if (marginBox) {
                    inputs[resize].value -= startY - e.pageY
                } else {
                    inputs[resize].value += startY - e.pageY
                }
                startY = e.pageY;
                if (marginBox) {
                    if (oldStart - startY < min) {
                        inputs[resize].value = max
                    }
                    if (oldStart - startY > max) {
                        inputs[resize].value = min
                    }
                } else {
                    if (oldStart - startY > max) {
                        inputs[resize].value = max
                    }
                    if (oldStart - startY < min) {
                        inputs[resize].value = min
                    }
                }
            } else if (resize == 'left') {
                inputs[resize].value += e.pageX - startX;
                startX = e.pageX;
                if (startX - oldStart > max) {
                    inputs[resize].value = max
                }
                if (startX - oldStart < min) {
                    inputs[resize].value = min
                }
            } else if (resize == 'right') {
                inputs[resize].value += startX - e.pageX;
                startX = e.pageX;
                if (oldStart - startX > max) {
                    inputs[resize].value = max
                }
                if (oldStart - startX < min) {
                    inputs[resize].value = min
                }
            }
            if (inputs[resize].value > max) {
                inputs[resize].value = max
            }
            if (inputs[resize].value < min) {
                inputs[resize].value = min
            }
            if (parent.find('.link-box.active').length) {
                inputs.top.value = inputs.right.value = inputs.bottom.value = inputs.left.value = inputs[resize].value
            }
            applyPaddings(resize, 0)
        });
        $(document).on('mouseup', function(e) {
            mouseDown = 0;
            startX = -1;
            startY = -1;
            oldStartY = -1;
            $("body").removeClass('disableHighlight')
        });
        parent.find('input').on('keyup mouseup change scroll mousewheel', function() {
            if ($(this).closest('.resize-box-container').find('.link-box').hasClass('active')) {
                changeEqual($(this).closest('.resize-box-inputs'), $(this).val())
            }
        });
        parent.find('input').on('keyup mouseup change scroll mousewheel', function(e) {
            var input = $(this);
            var resize = input.data('resize');
            inputs[resize].value = parseInt(input.val());
            applyPaddings(resize, 1)
        });

        function changeEqual(container, val) {
            container.find('input').val(val);
            for (var resize in inputs) {
                inputs[resize].value = val
            }
        }

        function applyPaddings(param, mouse) {
            var linked = !1;
            if (parent.find('.link-box.active').length) {
                linked = !0
            }
            if (inputs.top.value < inputs.top.min) inputs.top.value = inputs.top.min;
            if (inputs.left.value < inputs.left.min) inputs.left.value = inputs.left.min;
            if (inputs.bottom.value < inputs.bottom.min) inputs.bottom.value = inputs.bottom.min;
            if (inputs.right.value < inputs.right.min) inputs.right.value = inputs.right.min;
            if (parent.hasClass('margin-box')) {
                if (!mouse) {
                    inputs.top.object.val(parseInt(inputs.top.value));
                    inputs.bottom.object.val(parseInt(inputs.bottom.value))
                }
                if (inputs.top.value > parseInt(inputs.top.max))
                    inputs.top.value = inputs.top.max;
                if (inputs.top.value < parseInt(inputs.top.min))
                    inputs.top.value = inputs.top.min;
                if (inputs.bottom.value > parseInt(inputs.bottom.max))
                    inputs.bottom.value = inputs.bottom.max;
                if (inputs.bottom.value < parseInt(inputs.bottom.min))
                    inputs.bottom.value = inputs.bottom.min;
                if (isNaN(inputs.top.value)) {
                    inputs.top.value = 90
                }
                if (isNaN(inputs.bottom.value)) {
                    inputs.bottom.value = 90
                }
                parent.find('.resize-box .content').css({
                    'padding-top': inputs.top.max - inputs.top.value + 'px',
                    'padding-bottom': inputs.bottom.max - inputs.bottom.value + 'px'
                })
            } else {
                if (!mouse) {
                    inputs.top.object.val(parseInt(inputs.top.value));
                    inputs.left.object.val(parseInt(inputs.left.value));
                    inputs.bottom.object.val(parseInt(inputs.bottom.value));
                    inputs.right.object.val(parseInt(inputs.right.value))
                }
                if (inputs.top.value > parseInt(inputs.top.max))
                    inputs.top.value = parseInt(inputs.top.max);
                if (inputs.top.value < parseInt(inputs.top.min))
                    inputs.top.value = parseInt(inputs.top.min);
                if (inputs.bottom.value > parseInt(inputs.bottom.max))
                    inputs.bottom.value = parseInt(inputs.bottom.max);
                if (inputs.bottom.value < parseInt(inputs.bottom.min))
                    inputs.bottom.value = parseInt(inputs.bottom.min);
                if (inputs.left.value > parseInt(inputs.left.max))
                    inputs.left.value = parseInt(inputs.left.max);
                if (inputs.left.value < parseInt(inputs.left.min))
                    inputs.left.value = parseInt(inputs.left.min);
                if (inputs.right.value > parseInt(inputs.right.max))
                    inputs.right.value = parseInt(inputs.right.max);
                if (inputs.right.value < parseInt(inputs.right.min))
                    inputs.right.value = parseInt(inputs.right.min);
                parent.find('.resize-box .content').css({
                    'padding-top': parseInt(inputs.top.value) + 'px',
                    'padding-left': parseInt(inputs.left.value) + 'px',
                    'padding-right': parseInt(inputs.right.value) + 'px',
                    'padding-bottom': parseInt(inputs.bottom.value) + 'px'
                })
            }
        }
    };
    $.fn.resizeBox = function(width) {
        this.each(function() {
            $(this).resizeBoxInit(width)
        })
    }
})($);

function convertToAlias(string) {
    var ret = string.replace(/[^-a-zA-Z0-9\s]/g, "");
    ret = ret.trim();
    ret = ret.toLowerCase();
    ret = ret.replace(/\s/g, '-');
    ret = ret.replace(/-+/g, '-');
    return ret
}(function($) {
    function showError(obj, msg) {
        obj.siblings('.msg-error').remove();
        obj.addClass('error');
        var objTagName = obj.prop("tagName").toLowerCase();
        if (objTagName == 'select' || (objTagName == 'input' && obj.attr('type') == 'checkbox')) {
            $('<span class="input-message error">' + msg + '</span>').insertAfter(obj.next())
        } else {
            $('<span class="input-message error">' + msg + '</span>').insertAfter(obj)
        }
    }

    function hideErrors(form) {
        form.find('.input-message').remove()
    }
    $.fn.validate = function(method, msg) {
        if ((this.offset().left + parseInt(this.css('padding-left')) + this.width() + 266) > $(window).width()) {
            this.addClass('errors-left')
        } else {
            this.removeClass('errors-left')
        }
        if (method == 'showError') {
            showError(this, msg);
            return !0
        } else if (method == 'hideErrors') {
            hideErrors(this);
            return !0
        }

        function isValidUrl(url) {
            url = url.replace('http://', '');
            url = url.replace('https://', '');
            return url.match(/^[a-zA-Z0-9-\.]+\.[a-z]{2,4}\/?([^\s<>\#%"\,\{\}\\|\\\^\[\]`]+)?$/)
        }

        function isValidEmailAddress(emailAddress) {
            var pattern = new RegExp(/^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?$/i);
            return pattern.test(emailAddress)
        }

        function isValidMask(value, maxLength) {
            return value.length === parseInt(maxLength)
        }

        function validateField(obj, parent) {
            var requiredMessage = window.translations['validation.requiredField'];
            var invalidEmail = window.translations['validation.invalidEmail'];
            var invalidDate = window.translations['validation.invalidDate'];
            var invalidDateFormat = window.translations['validation.invalidDateFormat'];
            var characterRequired = window.translations['validation.characterRequired'];
            var characterAllowed = window.translations['validation.characterAllowed'];
            var wordsRequired = window.translations['validation.wordsRequired'];
            var wordsAllowed = window.translations['validation.wordsAllowed'];
            var invalidUrl = window.translations['validation.invalidUrl'];
            var passwordCompare = window.translations['validation.passwordCompare'];
            var promoCodeCompare = window.translations['validation.promoCodeCompare'];
            var invalidNumber = window.translations['validation.invalidNumber'];
            var greaterThanNumber = window.translations['validation.greaterThanNumber'];
            var lowerThanNumber = window.translations['validation.lowerThanNumber'];
            var alias = window.translations['validation.alias'];
            var invalidMasking = window.translations['validation.invalidMasking'];
            var valClass = obj.attr('class') || "";
            if (valClass.indexOf('val-') == '-1')
                return 1;
            var errorObj = {};
            var errC = 0;
            if (obj.hasClass('val-noval'))
                return 1;
            if (obj.hasClass('val-date')) {
                var inputs = obj.find('input');
                var day = inputs.first();
                var month = day.next();
                var year = month.next();
                var dayVal = day.val() || '';
                var monthVal = month.val() || '';
                var yearVal = year.val() || '';
                if ((dayVal || monthVal || yearVal) && !(dayVal && monthVal && yearVal)) {
                    errorObj[errC++] = invalidDate
                } else if (dayVal && monthVal && yearVal) {
                    var date = Date.parse(month.val() + '/' + day.val() + '/' + year.val());
                    if (isNaN(date) || year.val() == '0000') {
                        errorObj[errC++] = invalidDate
                    } else {
                        var dateString = dayVal + '/' + monthVal + '/' + yearVal;
                        var format = /^(3[01]|[12][0-9]|0[1-9])\/(1[0-2]|0[1-9])\/[0-9]{4}$/;
                        if (!format.test(dateString)) {
                            errorObj[errC++] = invalidDateFormat
                        }
                    }
                }
                if (parseInt(monthVal) == 2 && dayVal > 29) {
                    errorObj[errC++] = invalidDate
                }
            }
            if (obj.hasClass('val-exp-date')) {
                var inputs = obj.find('input');
                var month = inputs.first();
                var year = month.next();
                var monthVal = month.val() || '';
                var yearVal = year.val() || '';
                if ((monthVal || yearVal) && !(monthVal && yearVal)) {
                    errorObj[errC++] = invalidDate
                } else if (monthVal && yearVal) {
                    var date = Date.parse(month.val() + '/01/' + year.val());
                    if (isNaN(date)) {
                        errorObj[errC++] = invalidDate
                    }
                }
            }
            if (obj.hasClass('val-chars')) {
                if (obj.prop("tagName").toLowerCase() == 'input' || obj.prop("tagName").toLowerCase() == 'textarea') {
                    var min = obj.data('chars-min');
                    var max = obj.data('chars-max');
                    var val = obj.val();
                    if (min != '' && val.length < parseInt(min)) {
                        errorObj[errC++] = characterRequired + min
                    }
                    if (max != '' && val.length > parseInt(max)) {
                        errorObj[errC++] = characterAllowed + max
                    }
                }
            }
            if (obj.hasClass('val-words')) {
                if (obj.prop("tagName").toLowerCase() == 'input' || obj.prop("tagName").toLowerCase() == 'textarea') {
                    var min = obj.data('words-min');
                    var max = obj.data('words-max');
                    var val = obj.val();
                    var wordC = val.split(' ').length;
                    if (val == '') {
                        wordC = 0
                    }
                    if (min != '' && wordC < parseInt(min)) {
                        errorObj[errC++] = wordsRequired + min
                    }
                    if (max != '' && wordC > parseInt(max)) {
                        errorObj[errC++] = wordsAllowed + max
                    }
                }
            }
            if (obj.hasClass('val-url')) {
                if (obj.prop("tagName").toLowerCase() == 'input' && obj.val() != '' && !isValidUrl(obj.val())) {
                    errorObj[errC++] = invalidUrl
                }
            }
            if (obj.hasClass('val-email')) {
                if (obj.prop("tagName").toLowerCase() == 'input' && obj.val() != '' && !isValidEmailAddress(obj.val())) {
                    errorObj[errC++] = invalidEmail
                }
            }
            if (obj.hasClass('val-mask')) {
                if (obj.prop("tagName").toLowerCase() == 'input' && obj.val() != '' && !isValidMask(obj.val(), obj.prop("maxlength"))) {
                    errorObj[errC++] = invalidMasking
                }
            }
            if (obj.hasClass('val-password')) {
                if (obj.prop("tagName").toLowerCase() == 'input' && obj.val() != '') {
                    if (obj.val() != parent.find('.val-confirm-password').val()) {
                        errorObj[errC++] = passwordCompare
                    } else {
                        parent.find('.val-confirm-password').removeClass('error')
                    }
                }
            }
            if (obj.hasClass('val-confirm-password')) {
                if (obj.prop("tagName").toLowerCase() == 'input' && obj.val() != '') {
                    if (obj.val() != parent.find('.val-password').val()) {
                        errorObj[errC++] = passwordCompare
                    } else {
                        parent.find('.val-password').removeClass('error')
                    }
                }
            }
            if (obj.hasClass('val-promo')) {
                if (obj.prop("tagName").toLowerCase() == 'input' && obj.val() != '') {
                    if (obj.val() != parent.find("[name='promoCodeValue']").val()) {
                        errorObj[errC++] = promoCodeCompare
                    } else {
                        parent.find('.val-promo').removeClass('error')
                    }
                }
            }
            if (obj.hasClass('val-number')) {
                var val = obj.val();
                if (obj.prop("tagName").toLowerCase() == 'input' && val != '' && (isNaN(val) || val == '')) {
                    errorObj[errC++] = invalidNumber
                } else if (val != '') {
                    var min = obj.data('min');
                    var max = obj.data('max');
                    if (min != '' && parseFloat(val) < min) {
                        errorObj[errC++] = greaterThanNumber + " " + min
                    }
                    if (max != '' && parseFloat(val) > max) {
                        errorObj[errC++] = lowerThanNumber + max
                    }
                }
            }
            if (obj.hasClass('val-alias')) {
                var val = obj.val();
                var reg = /^[a-z0-9-]+$/;
                if (!(val.search(reg) != -1 && val[0] != '-' && val[val.length - 1] != '-')) {
                    errorObj[errC++] = alias
                }
            }
            if (obj.hasClass('val-custom')) {
                var validationResult = customValidations[obj.data('cutom-val-func')](obj);
                if (validationResult.type == -1) {
                    errorObj[errC++] = validationResult.message
                }
            }
            if (obj.hasClass('val-required')) {
                if (((obj.prop("tagName").toLowerCase() == 'input' || obj.prop("tagName").toLowerCase() == 'textarea') && obj.val().trim() == '') || (obj.attr('type') == 'checkbox' && obj.prop('checked') === !1)) {
                    errorObj[errC++] = requiredMessage
                } else if (obj.prop("tagName").toLowerCase() == 'select' && (obj.val() == '' || obj.val() == null)) {
                    errorObj[errC++] = requiredMessage
                } else if (obj.hasClass('form-three-one')) {
                    var threeOneEmpty = 0;
                    obj.find('input').each(function() {
                        if ($(this).val() === '' || obj.val() === null) {
                            threeOneEmpty = 1
                        }
                    });
                    if (threeOneEmpty) {
                        errorObj[errC++] = requiredMessage
                    }
                } else if (obj.attr('type') == 'radio') {
                    if (!obj.closest('.checkbox-group').find('input[name=' + obj.attr('name') + ']:checked').length) {
                        errorObj[errC++] = requiredMessage
                    }
                } else if (obj.hasClass('checkbox-group')) {
                    var checkedCount = 0;
                    obj.find('input').each(function() {
                        if ($(this).prop('checked')) {
                            checkedCount++
                        }
                    });
                    if (!checkedCount) {
                        errorObj[errC++] = requiredMessage
                    }
                }
            }
            if (errC) {
                if (obj.find('+.input-message.error').length) {
                    obj.find('+.input-message.error').remove()
                } else {
                    obj.addClass('error');
                    obj.attr('aria-invalid', !0)
                }
                var hClass = '';
                if (parent.find('.input-message.error:not(.msg-hidden)').length && !obj.is(':focus'))
                    hClass = ' msg-hidden';
                var errorClass = $('body').hasClass('preview') ? 'input-message msg-bct error' + hClass : 'input-message error' + hClass;
                if (obj.prop("tagName").toLowerCase() == 'select') {
                    $('<span class="' + errorClass + '">' + errorObj[0] + '</span>').insertAfter(obj)
                } else if (obj.prop("tagName").toLowerCase() == 'input' && (obj.attr('type') == 'checkbox' || obj.attr('type') == 'radio')) {} else if (obj.hasClass('checkbox-group')) {
                    $('<span class="' + errorClass + '">' + errorObj[0] + '</span>').insertAfter(obj)
                } else {
                    $('<span class="' + errorClass + '">' + errorObj[0] + '</span>').insertAfter(obj)
                }
                return 0
            }
            obj.find('+.input-message.error').remove();
            obj.next().find('+.input-message.error').remove();
            obj.removeClass('error');
            obj.attr('aria-invalid', !1)
            return 1
        }
        var parent = $(this);
        var error = 0;
        if ($(this).attr('class') !== undefined && $(this).attr('class') != '') {
            if ($(this).attr('class').indexOf('val-') != '-1') {
                parent = $(this).closest('form');
                return validateField($(this), parent)
            }
        }
        $(this).find('.input-message.error').addClass('second-time');
        $(this).find('[class*="val-"]').each(function() {
            if (!validateField($(this), parent)) {
                error = 1
            }
        });
        if (error) {
            return !1
        } else {
            return !0
        }
    }
}($));

function showSystemMessage(type, msg) {
    var obj = $('body > .system-message-container');
    var msgText = '';
    $('<div class="hidden system-message ' + type + '"><span>' + msgText + msg + '</span><i>a</i></div>').prependTo(obj)
}

function hideSystemMessage(obj) {
    anime({
        target: obj.get(0),
        opacity: 0,
        duration: 300,
        complete: function() {
            $(this).remove()
        }
    })
}(function($) {
    $.fn.paddingBoxInit = function() {
        var parent = $(this);
        var hiddenInput = parent.children('.values');
        var tempInputs = {};
        tempInputs.top = parent.find('.control.top input');
        tempInputs.right = parent.find('.control.right input');
        tempInputs.bottom = parent.find('.control.bottom input');
        tempInputs.left = parent.find('.control.left input');
        var inputs = {
            top: {
                object: tempInputs.top,
                value: parseInt(tempInputs.top.val()),
                min: tempInputs.top.data('min'),
                max: tempInputs.top.data('max'),
                unit: tempInputs.top.data('unit'),
                disabled: tempInputs.top.is(':disabled')
            },
            right: {
                object: tempInputs.right,
                value: parseInt(tempInputs.right.val()),
                min: tempInputs.right.data('min'),
                max: tempInputs.right.data('max'),
                unit: tempInputs.right.data('unit'),
                disabled: tempInputs.right.is(':disabled')
            },
            bottom: {
                object: tempInputs.bottom,
                value: parseInt(tempInputs.bottom.val()),
                min: tempInputs.bottom.data('min'),
                max: tempInputs.bottom.data('max'),
                unit: tempInputs.bottom.data('unit'),
                disabled: tempInputs.bottom.is(':disabled')
            },
            left: {
                object: tempInputs.left,
                value: parseInt(tempInputs.left.val()),
                min: tempInputs.left.data('min'),
                max: tempInputs.left.data('max'),
                unit: tempInputs.left.data('unit'),
                disabled: tempInputs.left.is(':disabled')
            }
        };
        var mouseDown, startX, startY, side, startValue, min, max, linked, cursor;
        parent.find('.control .line').mousedown(function(e) {
            startX = Math.floor(e.pageX / 4);
            startY = Math.floor(e.pageY / 4);
            side = $(this).closest('.control').data('side');
            startValue = inputs[side].value;
            min = inputs[side].min;
            max = inputs[side].max;
            linked = parent.find('.padding-box-link input').prop('checked');
            cursor = 'corsor-ns-resize';
            if (side == 'left' || side == 'right') {
                cursor = 'corsor-ew-resize'
            }
            $('body').addClass('disableHighlight ' + cursor);
            $(document).on('mousemove', paddingBoxMousemove);
            $(document).on('mouseup', paddingBoxMouseup)
        });
        parent.find('.control input').change(changeFromInput);

        function applyPaddings() {
            inputs.top.object.val(inputs.top.value);
            inputs.right.object.val(inputs.right.value);
            inputs.bottom.object.val(inputs.bottom.value);
            inputs.left.object.val(inputs.left.value);
            hiddenInput.val('' + inputs.top.value + inputs.top.unit + ' ' + inputs.right.value + inputs.right.unit + ' ' + inputs.bottom.value + inputs.bottom.unit + ' ' + inputs.left.value + inputs.left.unit).trigger('change')
        }

        function paddingBoxMousemove(e) {
            if (!inputs[side].disabled) {
                var curX = Math.floor(e.pageX / 4),
                    curY = Math.floor(e.pageY / 4);
                if (side == 'top') {
                    inputs[side].value = startValue - curY + startY
                } else if (side == 'right') {
                    inputs[side].value = startValue + curX - startX
                } else if (side == 'bottom') {
                    inputs[side].value = startValue + curY - startY
                } else if (side == 'left') {
                    inputs[side].value = startValue - curX + startX
                }
                if (inputs[side].value > max) {
                    inputs[side].value = max
                } else if (inputs[side].value < min) {
                    inputs[side].value = min
                }
                if (linked) {
                    if (!inputs.top.disabled) {
                        inputs.top.value = inputs[side].value
                    }
                    if (!inputs.right.disabled) {
                        inputs.right.value = inputs[side].value
                    }
                    if (!inputs.bottom.disabled) {
                        inputs.bottom.value = inputs[side].value
                    }
                    if (!inputs.left.disabled) {
                        inputs.left.value = inputs[side].value
                    }
                }
                applyPaddings()
            }
        }

        function paddingBoxMouseup(e) {
            $("body").removeClass('disableHighlight ' + cursor);
            $(document).unbind('mousemove', paddingBoxMousemove);
            $(document).unbind('mouseup', paddingBoxMouseup)
        }

        function changeFromInput(e) {
            var curInput = $(e.target),
                side = curInput.closest('.control').data('side');
            inputs[side].value = parseInt(curInput.val());
            if (parent.find('.padding-box-link input').prop('checked')) {
                if (!inputs.top.disabled) {
                    inputs.top.value = inputs[side].value
                }
                if (!inputs.right.disabled) {
                    inputs.right.value = inputs[side].value
                }
                if (!inputs.bottom.disabled) {
                    inputs.bottom.value = inputs[side].value
                }
                if (!inputs.left.disabled) {
                    inputs.left.value = inputs[side].value
                }
            }
            applyPaddings()
        }
    };
    $.fn.paddingBox = function() {
        this.each(function() {
            $(this).paddingBoxInit()
        })
    }
})(jQuery);
(function($) {
    $.fn.rangeSliderInit = function() {
        var container = $(this);
        var input = $(this).find('input');
        var max = parseFloat(input.data('max'));
        var min = parseFloat(input.data('min'));
        var val = parseFloat(input.val());
        var step = input.data('step') || 1;
        var button = container.find('.toggle');
        var parent = container.find('.range-slider-container div');
        var offset;
        var left = Math.round((val - min) * 100 / (max - min));
        $(this).find('.toggle').css('left', left + '%');
        parent.find('.trace').css('width', left + '%');
        input.change(function() {
            val = parseFloat($(this).val());
            if (isNaN(val)) {
                val = min;
                $(this).val(val)
            }
            if (val > max) {
                val = max
            } else if (val < min) {
                val = min
            }
            left = Math.round((val - min) * 100 / (max - min));
            button.css('left', left + '%');
            parent.find('.trace').css('width', left + '%')
        });
        parent.mousedown(function(e) {
            $('body').addClass('disableHighlight');
            offset = parent.offset();
            var percent = Math.round(((e.pageX - document.body.scrollLeft - offset.left) / parent.width()) * 100);
            var valuePer = (max - min) * percent / 100 + min;
            valuePer *= 1000;
            step *= 1000;
            valuePer = Math.round(valuePer / step) * step;
            valuePer /= 1000;
            step /= 1000;
            percent = Math.round((valuePer - min) * 100 / (max - min));
            if (valuePer <= min) {
                valuePer = min
            } else if (valuePer >= max) {
                valuePer = max
            }
            if (!$(e.target).hasClass('toggle')) {
                input.val(valuePer);
                input.trigger('change');
                button.css('left', percent + '%')
            }
            $(document).on('mousemove', rangeSliderMousemove);
            $(document).on('mouseup', rangeSliderMouseup)
        });

        function rangeSliderMousemove(e) {
            var percent = Math.round(((e.pageX - offset.left) / parent.width()) * 100);
            var valuePer = (max - min) * percent / 100 + min;
            valuePer *= 1000;
            step *= 1000;
            valuePer = Math.round(valuePer / step) * step;
            valuePer /= 1000;
            step /= 1000;
            if (valuePer <= min) {
                valuePer = min
            } else if (valuePer >= max) {
                valuePer = max
            }
            if (percent > 100) {
                percent = 100;
                input.val(max)
            } else if (percent < 0) {
                percent = 0;
                input.val(min)
            }
            if ((valuePer * 1000 - min * 1000) % (step * 1000) === 0) {
                input.val(valuePer);
                button.css('left', percent + '%');
                input.trigger('change')
            }
        }

        function rangeSliderMouseup() {
            $('body').removeClass('disableHighlight');
            $(document).unbind('mousemove', rangeSliderMousemove);
            $(document).unbind('mouseup', rangeSliderMouseup)
        }
    };
    $.fn.rangeSlider = function() {
        this.each(function() {
            $(this).rangeSliderInit()
        })
    }
})(jQuery);

function initUploader(options) {
    var invalidFileType = window.translations['validation.invalidFileType'];
    var FileIsBig = window.translations['validation.fileIsBig'];
    var fileExtensions = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
    var maxFileSize = 5242880;
    if (typeof(options.selector) === 'undefined') {
        alert('Wrong uploader initiation. Contact ucraft support.')
    }
    if (typeof(options.fileExtensions) !== 'undefined') {
        fileExtensions = options.fileExtensions
    }
    if (typeof(options.maxFileSize) !== 'undefined') {
        maxFileSize = options.maxFileSize
    }
    $(options.selector).ajaxForm({
        data: {
            _token: window._token
        },
        clearForm: !0,
        beforeSubmit: function(arr) {
            if (typeof(options.beforeSubmit) !== 'undefined') {
                return options.beforeSubmit(arr)
            }
            var errorMsg = "";
            for (var index in arr) {
                if (arr.hasOwnProperty(index) === !1 || arr[index].type !== 'file') {
                    continue
                }
                var file = arr[index].value;
                file.type = file.type.toLowerCase();
                if (fileExtensions.indexOf('*') === -1 && fileExtensions.indexOf(file.type) === -1) {
                    arr[index].value.error = invalidFileType;
                    errorMsg = arr[index].value.error
                } else if (file.size > maxFileSize) {
                    arr[index].value.error = FileIsBig;
                    errorMsg = arr[index].value.error
                }
            }
            if (errorMsg.length > 0) {
                options.errorValidation(arr, errorMsg);
                confirmData.message = errorMsg;
                delete confirmData.buttons.discard;
                confirmData.buttons.confirm.label = 'Ok';
                confirmData.buttons.confirm['function'] = function() {
                    $('.confirm-layer-container').removeClass('active');
                    anime({
                        target: '.confirm-layer-container',
                        opacity: 0,
                        duration: 300,
                        complete: function() {
                            jQuery('.confirm-layer-container').remove()
                        }
                    })
                };
                confirmPopup(confirmData);
                return !1
            }
            if (typeof(options.successValidation) !== 'undefined') {
                options.successValidation(arr);
                return !0
            }
            return !0
        },
        uploadProgress: function(event, position, total, percentComplete) {
            if (typeof(options.uploadProgress) !== 'undefined') {
                return options.uploadProgress(event, position, total, percentComplete)
            }
        },
        success: function(responseJson) {
            var response = responseJson;
            if (response.type === -1) {
                confirmData.message = '';
                delete confirmData.buttons.discard;
                confirmData.buttons.confirm.label = 'Ok';
                for (var i in response.msg) {
                    if (i != 'global') {
                        confirmData.message += capitalizeFirstLetter(i) + ': ' + response.msg[i] + '<br/>'
                    } else {
                        confirmData.message += response.msg[i] + '<br/>'
                    }
                }
                confirmData.buttons.confirm['function'] = function() {
                    $('.confirm-layer-container').removeClass('active');
                    anime({
                        target: '.confirm-layer-container',
                        opacity: 0,
                        duration: 300,
                        complete: function() {
                            jQuery('.confirm-layer-container').remove()
                        }
                    })
                };
                confirmPopup(confirmData);
                if (typeof(options.error) !== 'undefined') {
                    return options.error(response)
                }
            } else {
                if (typeof(options.success) !== 'undefined') {
                    return options.success(response)
                }
            }
        },
        complete: function(xhr) {
            if (typeof(options.complete) !== 'undefined') {
                return options.complete(xhr)
            }
        },
        error: function(errorMsg) {
            if (typeof(options.error) !== 'undefined') {
                return options.error()
            }
        }
    })
}
$(document).ready(function() {
    var uploadContainer = $('.public-file-upload-attach');
    var progressContainer = $('.public-file-uploader-process');
    var selectedFileContainer = $('.selected-file');
    progressContainer.addClass('hidden');
    selectedFileContainer.addClass('hidden');
    var selectedFileContainerRmv = selectedFileContainer.find('.uci-close-small');
    selectedFileContainerRmv.click(function(e) {
        e.preventDefault();
        var parent = $(this).parents('.public-file-uploader-container');
        var request = {
            name: parent.find('.attached-file').val()
        };
        api.publicCall('default', 'MediaFile', 'remove', JSON.stringify(request));
        parent.find('.selected-file').addClass('hidden');
        parent.find('.attached-file').val('');
        parent.find('.public-file-upload-attach').removeClass('hidden')
    });
    $('.public-file-upload-attach').click(function() {
        var connectionId = $(this).closest('.public-file-uploader-container').attr('id');
        $('form[data-connection-id="' + connectionId + '"]').find('.public-file-uploader-button').click()
    });
    $('.public-file-uploader-button').change(function() {
        var form = $(this).closest('form');
        var connectionId = form.attr('data-connection-id');
        var uploader = $('#' + connectionId);
        var errorContainer = uploader.find('.public-file-uploader-error');
        var uploadContainer = uploader.find('.public-file-upload-attach');
        var progressContainer = uploader.find('.public-file-uploader-process');
        var selectedFileContainer = uploader.find('.selected-file');
        var input = $(this);
        if ($(this).val()) {
            var uploaderOptions = {
                selector: '#' + form.attr('id'),
                fileExtensions: ['image/jpeg', 'image/png', 'image/gif', 'application/pdf', 'text/plain', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/excel', 'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/octet-stream'],
                errorValidation: function(arr, errorMsg) {
                    input.val('');
                    errorContainer.find('.file-uploader-error-msg').html(errorMsg);
                    errorContainer.addClass('occurred');
                    return !1
                },
                uploadProgress: function(event, position, total, percentComplete) {
                    progressContainer.removeClass('hidden');
                    uploadContainer.addClass('hidden')
                },
                success: function(resp) {
                    progressContainer.addClass('hidden');
                    selectedFileContainer.removeClass('hidden');
                    uploadContainer.addClass('hidden');
                    uploader.find('input').val(resp.data)
                },
                error: function() {
                    progressContainer.addClass('hidden');
                    selectedFileContainer.addClass('hidden');
                    uploadContainer.removeClass('hidden')
                }
            };
            initUploader(uploaderOptions);
            form.submit()
        }
    })
})
$(window).on('load', function() {
    initVideos()
});

function onYouTubeIframeAPIReady(youtubeVideos = []) {
    let popup = window.initVideosPopup || !1;
    if (!youtubeVideos || !youtubeVideos.length) {
        if (popup) {
            if (typeof popup === 'string') {
                popup = new DOMParser().parseFromString(popup, "text/xml")
            }
            youtubeVideos = popup.querySelectorAll('.vidoeYoutubeContent')
        } else {
            youtubeVideos = document.querySelectorAll('.vidoeYoutubeContent')
        }
    }
    youtubeVideos.forEach(video => {
        if (popup || (!popup && !video.closest('.popup-layer'))) {
            let elId = video.getAttribute('data-id');
            let urlYoutube = video.getAttribute('data-url');
            let youtubeId = videoId(urlYoutube);
            let start = startPoint(urlYoutube);
            if (youtubeId) {
                if (!tv[`iframe${elId}`]) {
                    youtubeBackground(youtubeId, elId, start)
                } else {
                    tv[`iframe${elId}`].playVideo()
                }
            }
        }
    })
}

function initVideos(popup = !1) {
    if (!window.tv) {
        window.tv = []
    }
    let youtubeVideos = '',
        vimeoVideos = '';
    if (popup) {
        if (typeof popup === 'string') {
            popup = new DOMParser().parseFromString(popup, "text/xml")
        }
        youtubeVideos = popup.querySelectorAll('.vidoeYoutubeContent');
        vimeoVideos = popup.querySelectorAll('.vidoeVimeoContent')
    } else {
        youtubeVideos = document.querySelectorAll('.vidoeYoutubeContent');
        vimeoVideos = document.querySelectorAll('.vidoeVimeoContent')
    }
    window.initVideosPopup = popup;
    if (youtubeVideos && youtubeVideos.length) {
        if (window.isMobile || (window.parent.isMobile && window.popupIframe)) {
            var tag = document.createElement('script');
            tag.src = "https://www.youtube.com/iframe_api";
            var firstScriptTag = document.getElementsByTagName('script')[0];
            firstScriptTag.parentNode.insertBefore(tag, firstScriptTag)
        } else {
            onYouTubeIframeAPIReady(youtubeVideos)
        }
    }
    vimeoVideos.forEach(function(video) {
        if (popup || (!popup && !video.closest('.popup-layer'))) {
            let elId = video.getAttribute('data-id');
            let urlVimeo = video.getAttribute('data-url');
            if (urlVimeo) {
                if (!tv[`vimeo${elId}`]) {
                    vimeoBackground(urlVimeo, elId)
                } else {
                    tv[`vimeo${elId}`].play();
                    if (popup) {
                        hideBackgroundImage(popup)
                    }
                }
            }
        }
    })
}

function vimeoBackground(urlVimeo, elId) {
    var playerDefaults = {
        url: urlVimeo,
        autoplay: !0,
        autopause: !1,
        background: !0,
        loop: !0,
        muted: !0,
        responsive: !0,
        byline: !1,
        title: !1
    };
    tv["vimeo" + elId] = new Vimeo.Player("vimeo" + elId, playerDefaults);
    tv["vimeo" + elId].disableTextTrack();
    tv["vimeo" + elId].on('loaded', function() {
        onPlayerStateChange();
        vidRescale()
    });

    function onPlayerStateChange(e) {
        var iframeElement = document.querySelector("#vimeo" + elId);
        if (iframeElement) {
            iframeElement.classList.add('active');
            var ucRow = iframeElement.closest('.uc-row');
            var header = iframeElement.closest('.header-rows');
            var footer = iframeElement.closest('.footer-rows');
            hideBackgroundImage(ucRow);
            hideBackgroundImage(header);
            hideBackgroundImage(footer)
        }
    }

    function vidRescale() {
        var parentHeight = document.querySelector(".vimeo" + elId).offsetHeight;
        var parentWidth = document.querySelector(".vimeo" + elId).offsetWidth;
        var proportionX = 16;
        var proportionY = 9;
        var maxWidth = parentHeight * proportionX / proportionY;
        var maxHeight = parentWidth * proportionY / proportionX;
        var videoWidth = Math.max(parentWidth, maxWidth);
        var videoHeight = Math.max(parentHeight, maxHeight);
        var vimeoWrapperDiv = document.querySelector("#vimeo" + elId + " > div");
        var vimeoIframe = document.querySelector("#vimeo" + elId + " > div");
        var vimeoScreen = document.querySelector(".vimeo" + elId + " .screen");
        if (vimeoWrapperDiv) {
            vimeoWrapperDiv.style.height = videoHeight + "px";
            vimeoWrapperDiv.style.width = videoWidth + "px";
            vimeoWrapperDiv.style.padding = 0
        }
        if (vimeoIframe) {
            vimeoIframe.style.height = videoHeight + "px";
            vimeoIframe.style.width = videoWidth + "px"
        }
        if (vimeoScreen) {
            if (parentWidth > videoWidth) {
                vimeoScreen.style.left = ((vimeoScreen.offsetWidth - videoWidth) / 2) + "px"
            } else {
                vimeoScreen.style.left = -(videoWidth - parentWidth) / 2 + "px"
            }
        }
    }
    window.removeEventListener("load", this._vimeoBackgroundLoad, !1);
    window.addEventListener('load', this._vimeoBackgroundLoad = function() {
        vidRescale()
    });
    window.removeEventListener("resize", this._vimeoBackgroundScroll, !1);
    window.addEventListener('resize', this._vimeoBackgroundScroll = function() {
        vidRescale()
    });
    return tv
}

function youtubeBackground(videoId, elId, start) {
    let iframeElement = document.querySelector("#iframe" + elId);
    if (iframeElement) {
        iframeElement.classList.add('active');
        var ucRow = iframeElement.closest('.uc-row');
        var header = iframeElement.closest('.header-rows');
        var footer = iframeElement.closest('.footer-rows');
        hideBackgroundImage(ucRow);
        hideBackgroundImage(header);
        hideBackgroundImage(footer)
    }

    function vidRescale() {
        var parentHeight = $(".youtube" + elId).height();
        var parentWidth = $(".youtube" + elId).width();
        var proportionX = 16,
            proportionY = 9;
        var maxWidth = parentHeight * proportionX / proportionY;
        var maxHeight = parentWidth * proportionY / proportionX;
        var videoWidth = Math.max(parentWidth, maxWidth);
        var videoHeight = Math.max(parentHeight, maxHeight);
        if (parentWidth > videoWidth) {
            $(".youtube" + elId + " .screen").css({
                'left': -($(".youtube" + elId + " .screen").outerWidth() - videoWidth) / 4
            })
        } else {
            $(".youtube" + elId + " .screen").css({
                'left': -(videoWidth - parentWidth) / 4
            })
        }
        document.querySelector(".youtube" + elId + " .screen").height = videoHeight;
        document.querySelector(".youtube" + elId + " .screen").width = videoWidth;
        if (window.isMobile || (window.parent.isMobile && window.popupIframe)) {
            document.querySelector(".youtube" + elId + " .screen").src += '&enablejsapi=1';
            new YT.Player("iframe" + elId, {
                events: {
                    onReady: function(event) {
                        event.target.playVideo()
                    }
                }
            })
        }
    }
    $(window).on('load resize', function() {
        vidRescale()
    });
    vidRescale()
};

function videoId(url) {
    if (url !== undefined && url !== '') {
        var regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=|\?v=)([^#\&\?]*).*/;
        var match = url.match(regExp);
        if (match && match[2].length == 11) {
            return match[2]
        } else {
            return !1
        }
    } else {
        return !1
    }
};

function startPoint(url) {
    if (url !== undefined && url !== '' && url.indexOf('start=') !== -1) {
        return url.split('start=')[1]
    }
    return !1
}

function setLoadingEffects(element) {
    let activeTag = element && global_GallerySettings[element.getAttribute('id')] ? global_GallerySettings[element.getAttribute('id')].activeTag : 'all';
    if (element) {
        if (!$(element).find('.has-effect').length && (!window[$(element).data('animated-id') + 'animated'] || activeTag && !window[$(element).data('animated-id') + activeTag + 'animated'])) {
            var el = element;
            var loadMore = $('[data-module-id="' + $(el).data('animated-id') + '"]');
            var imagesContainer;
            if (loadMore.length && loadMore.css('display') != "none") {
                if (activeTag && activeTag != 'all') {
                    imagesContainer = [].slice.call($(el).find('.animated-item').filter(function(e) {
                        return $(this).data('tags').indexOf(activeTag.toString()) > -1
                    }), 0, loadMore.data('per-row'))
                } else {
                    imagesContainer = [].slice.call($(el).find('.animated-item'), 0, loadMore.data('per-row'))
                }
            } else {
                imagesContainer = [].slice.call($(el).find('.animated-item'), 0, $(el).find('.animated-item').length)
            }
            window[$(el).data('animated-id') + 'animated'] = !0;
            if (activeTag) {
                window[$(el).data('animated-id') + activeTag + 'animated'] = !0
            }
            window.imagesLoaded($(el), () => {
                (new UcraftLoader(el, null, imagesContainer))._render($(el).data('loading-animation'))
            })
        }
    } else {
        var animatedElements = $('.animated.loading-animation');
        if (animatedElements.length) {
            animatedElements.map(function(element) {
                if (!$(this).find('.has-effect').length) {
                    if (window.imagesLoaded) {
                        var el = this;
                        var loadMore = $('[data-module-id="' + $(this).data('animated-id') + '"]');
                        var imagesContainer = loadMore.length ? [].slice.call($(this).find('.animated-item'), 0, loadMore.data('per-row')) : [].slice.call($(this).find('.animated-item'), 0, $(this).find('.animated-item').length);
                        window.imagesLoaded($(this), () => {
                            (new UcraftLoader(el, null, imagesContainer))._render($(this).data('loading-animation'))
                        })
                    }
                }
            })
        }
    }
}

function startLoadingEffects(direction, element) {
    var animatedElements = $('.animated.loading-animation');
    var scrollTop = $(document).scrollTop();
    var scrollTopWithWindowHeight = scrollTop + $(window).height();
    if (element) {
        var elementOffsetTop = $(element).offset().top;
        var elementOffsetTopWithHeight = $(element).offset().top + $(element).height();
        if ((scrollTop >= elementOffsetTop || scrollTopWithWindowHeight >= elementOffsetTop) && (scrollTop <= elementOffsetTopWithHeight || scrollTopWithWindowHeight <= elementOffsetTopWithHeight)) {
            setLoadingEffects(element)
        }
    } else {
        if (animatedElements.length) {
            animatedElements.map(function() {
                var elementOffsetTop = $(this).offset().top;
                var elementOffsetTopWithHeight = $(this).offset().top + $(this).height();
                if ((scrollTop >= elementOffsetTop || scrollTopWithWindowHeight >= elementOffsetTop) && (scrollTop <= elementOffsetTopWithHeight || scrollTopWithWindowHeight <= elementOffsetTopWithHeight)) {
                    if (!$(this).hasClass('masonry')) {
                        setLoadingEffects(this)
                    }
                }
            })
        }
    }
}
$(document).ready(function() {
    $('.module.ModuleGallery').each(function() {
        var slider = $(this).find('.slider-wrapper').first();
        var id = slider.attr('id');
        var options = window[id + 'options'];
        if (options) {
            slider.jqueryUcSlider(options, !0)
        }
    });
    $(document).on('click', '.ModuleGallery .image-items-loadmore .load-more', function(e) {
        e.preventDefault();
        let loadmoreButton = this,
            moduleId = loadmoreButton.getAttribute('data-module-id'),
            index = 0,
            pageLimit = 0,
            perPage = pageLimit = global_GallerySettings[moduleId].imgPerPage,
            activeTag = global_GallerySettings[moduleId].activeTag;
        loadmoreButton.classList.add('btn-loading');
        global_GallerySettings[moduleId].loadMoreCount++;
        let el = $('.module.ModuleGallery div[data-animated-id=' + moduleId + ']'),
            selector = '.animated-item';
        if ($(el).data('loading-animation')) {
            selector = '.animated-loading-item'
        }
        el.find(selector).each(function() {
            $(this).addClass('hidden');
            if (activeTag === 'all' || $(this).data('tags').includes(activeTag.toString())) {
                if (index < global_GallerySettings[moduleId].imgPerPage * (global_GallerySettings[moduleId].loadMoreCount + 1)) {
                    $(this).removeClass('hidden')
                }
                index++
            }
        });
        if ((global_GallerySettings[moduleId].loadMoreCount + 1) * global_GallerySettings[moduleId].imgPerPage >= index) {
            this.classList.add('hidden')
        }
        let start = global_GallerySettings[moduleId].loadMoreCount * global_GallerySettings[moduleId].imgPerPage,
            end = (global_GallerySettings[moduleId].loadMoreCount + 1) * global_GallerySettings[moduleId].imgPerPage;
        if ($(el).data('loading-animation')) {
            let imagesContainer;
            if (activeTag && activeTag != 'all') {
                imagesContainer = [].slice.call($(el).find('.animated-item').filter(function(e) {
                    return $(this).data('tags').indexOf(activeTag.toString()) > -1
                }), pageLimit, global_GallerySettings[moduleId].imgPerPage)
            } else {
                imagesContainer = [].slice.call($(el).find('.animated-item'), pageLimit, global_GallerySettings[moduleId].imgPerPage)
            }
            window.imagesLoaded(el[0], () => {
                (new UcraftLoader(el[0], null, imagesContainer, start, end))._render($(el).data('loading-animation'))
            })
        }
        setTimeout(function() {
            loadmoreButton.classList.remove('btn-loading')
        }, 300);
        setGallerySettings(loadmoreButton.getAttribute('data-module-id'), null, activeTag)
    })
});

function setGallerySettings(elId, isMasonry, tag = null, allTagButton = null) {
    let el = document.querySelector(`[uc-masonry-id="${elId}"]`);
    if (!global_GallerySettings[elId]) {
        global_GallerySettings[elId] = {
            activeTag: 'all',
            allTagButton: allTagButton,
            isMasonry: isMasonry,
            loadMoreCount: 0,
            tagItems: [{
                tag: 'All',
                imagesInfo: [],
                itemsIndexes: []
            }],
            imgPerPage: parseInt(el.getAttribute('data-per-page')),
            imgPerRow: parseInt(el.getAttribute('data-per-row')),
            verticalDistance: parseInt(el.getAttribute('data-vertical-distance')),
        }
    }
    if (global_GallerySettings[elId].isMasonry) {
        let childs = el.children,
            curItemTags = null,
            curItemImage = null,
            curTagInfo = null,
            tagName = tag ? capitalizeFirstLetter(tag) : 'All';
        for (let i = 0; i < el.childElementCount; i++) {
            curItemTags = childs[i].getAttribute('data-tags') && JSON.parse(childs[i].getAttribute('data-tags')).length ? JSON.parse(childs[i].getAttribute('data-tags')) : [];
            curItemImage = childs[i].querySelector(`img`);
            if (!global_GallerySettings[elId].tagItems[0].itemsIndexes.includes(i)) {
                if (curItemImage) {
                    global_GallerySettings[elId].tagItems[0].imagesInfo.push({
                        index: i,
                        image: curItemImage
                    })
                }
                global_GallerySettings[elId].tagItems[0].itemsIndexes.push(i)
            }
            curItemTags.forEach(curTag => {
                curTagInfo = global_GallerySettings[elId].tagItems.find(item => item.tag === capitalizeFirstLetter(curTag));
                if (curTagInfo) {
                    if (!curTagInfo.itemsIndexes.includes(i)) {
                        if (curItemImage) {
                            curTagInfo.imagesInfo.push({
                                index: i,
                                image: curItemImage
                            })
                        }
                        curTagInfo.itemsIndexes.push(i)
                    }
                } else {
                    global_GallerySettings[elId].tagItems.push({
                        tag: capitalizeFirstLetter(curTag),
                        imagesInfo: [{
                            index: curItemImage ? i : [],
                            image: curItemImage ? curItemImage : [],
                        }],
                        itemsIndexes: [i]
                    })
                }
            })
        }
        setMasonryImagesPos(elId, tagName)
    }
}

function setMasonryImagesPos(elId, tag) {
    let el = document.querySelector(`[uc-masonry-id="${elId}"]`),
        elSettings = global_GallerySettings[elId],
        perRow = elSettings.imgPerRow,
        perPage = elSettings.imgPerPage,
        verticalDistance = elSettings.verticalDistance,
        tagItems = elSettings.tagItems.find(item => item.tag === tag),
        imagesInfo = tagItems.imagesInfo,
        itemsIndexes = tagItems.itemsIndexes,
        loadableImages = [],
        start = elSettings.loadMoreCount * perPage,
        end = itemsIndexes.length && start + perPage > itemsIndexes.length ? itemsIndexes.length : start + perPage;
    let len = 0,
        counter = 0;
    if (imagesInfo.length) {
        for (let i = start; i < end; i++) {
            imagesInfo.find(item => item.index === itemsIndexes[i]) && loadableImages.push(imagesInfo.find(item => item.index === itemsIndexes[i]).image)
        }
        len = loadableImages.length
    } else {
        incrementCounter(!0)
    }[].forEach.call(loadableImages, img => {
        if (img.complete)
            incrementCounter();
        else img.addEventListener('load', incrementCounter, !1)
    });

    function incrementCounter(startCalculation = !1) {
        counter++;
        if (counter === len || startCalculation) {
            let curItem = '',
                curItemChild = '',
                comparativeItem = '';
            for (let i = start; i < end; i++) {
                curItem = el.children[itemsIndexes[i]];
                if (curItem) {
                    curItemChild = curItem.querySelector('.uc-masonry-item');
                    if (curItemChild.style.marginTop) {
                        curItemChild.style.marginTop = 0
                    }
                    if (i >= perRow) {
                        comparativeItem = el.children[itemsIndexes[i - perRow]].querySelector('.uc-masonry-item');
                        if (comparativeItem.offsetTop + comparativeItem.offsetHeight < curItemChild.offsetTop + verticalDistance) {
                            curItemChild.style.marginTop = comparativeItem.offsetTop + verticalDistance + comparativeItem.offsetHeight - curItemChild.offsetTop + "px"
                        }
                    }
                    curItem.classList.remove('uc-masonry-item-not-loaded')
                }
            }
        }
    }
}(function() {
    var openInNewTab = function(url, target) {
        let linkTarget = '_blank';
        if (!target) {
            linkTarget = '_self'
        }
        var win = window.open(url, linkTarget);
        win.focus()
    };
    var popupHtml = "<div class='image-popup-layer'>" + `<span class='sb-close'>
            <svg fill="currentColor" xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24">
                <defs>
                    <clipPath>
                        <rect width="1em" height="1em" transform="translate(971 2389)">
                        </rect>
                    </clipPath>
                </defs>
                <g transform="translate(-971 -2389)">
                    <path
                        d="M20.5,23.124l-8.834,8.834a1.852,1.852,0,1,1-2.618-2.619L17.887,20.5,9.053,11.671a1.851,1.851,0,1,1,2.618-2.618L20.5,17.887l8.834-8.834a1.852,1.852,0,1,1,2.619,2.618L23.124,20.5l8.834,8.834a1.852,1.852,0,1,1-2.619,2.619Z"
                        transform="translate(962.495 2380.495)">
                    </path>
                </g>
            </svg>
        </span>` + `<span class='gallery-left sb-slider-arrow-1-left'>
            <svg width="32" height="32" viewBox="0 0 32 32"  xmlns="http://www.w3.org/2000/svg">
            <g clip-path="url(#clip0_153_455)">
                <path d="M22.8533 32.5734L9.79999 16.0001L22.8533 -0.573242L23.3733 -0.159909L10.64 16.0001L23.3733 32.1601L22.8533 32.5734Z" />
            </g>
            <defs>
                <clipPath id="clip0_153_455">
                    <rect width="32" height="32" fill="white"/>
                </clipPath>
            </defs>
        </svg>
        </span>` + `<span class='gallery-right sb-slider-arrow-1-right'>
            <svg width="32" height="32" viewBox="0 0 32 32"  xmlns="http://www.w3.org/2000/svg">
                <g clip-path="url(#clip0_153_480)">
                    <path d="M9.14668 32.5734L8.62668 32.1601L21.36 16.0001L8.62668 -0.159909L9.14668 -0.573242L22.2 16.0001L9.14668 32.5734Z" />
                </g>
                <defs>
                    <clipPath id="clip0_153_480">
                        <rect width="32" height="32" fill="white"/>
                    </clipPath>
                </defs>
            </svg>
        </span>` + "<div class='image-box'>" + "<img src=''>" + "</div>" + "</div>";
    var imgPopup = $('<div/>', {
        id: 'galleryPopup',
        class: 'image-popup image-layer-container',
        html: popupHtml,
        click: function(event) {
            var eventTarget = $(event.target);
            if (eventTarget.closest('.gallery-right').hasClass('gallery-right')) {
                activeImageIndex++;
                if (activeImageIndex >= galleryImagesArr.length) {
                    activeImageIndex = 0
                }
                if ($(galleryElement.children()[activeImageIndex]).hasClass('hidden')) {
                    $(this).trigger(event);
                    return !1
                }
                var nextSrc = galleryImagesArr[activeImageIndex].src;
                imgPopupImg.attr('src', nextSrc)
            } else if (eventTarget.closest('.gallery-left').hasClass('gallery-left')) {
                activeImageIndex--;
                if (activeImageIndex < 0) {
                    activeImageIndex = galleryImagesArr.length - 1
                }
                if ($(galleryElement.children()[activeImageIndex]).hasClass('hidden')) {
                    $(this).trigger(event);
                    return !1
                }
                var prevSrc = galleryImagesArr[activeImageIndex].src;
                imgPopupImg.attr('src', prevSrc)
            } else if (eventTarget.hasClass('image-popup-layer') || eventTarget.closest('.sb-close').hasClass('sb-close')) {
                $(this).removeClass('active');
                galleryItem = null;
                galleryImagesArr = null;
                activeImageIndex = 0;
                galleryElement = null
            }
        }
    });
    var galleryItem = null;
    var galleryImagesArr = null;
    var imgPopupImg = imgPopup.find('img').first();
    var activeImageIndex = 0;
    var galleryElement = null;
    var filterByTag = function(tagElement) {
        let el = tagElement.closest('.ModuleGallery'),
            moduleId = el.querySelector('.gallery').getAttribute('id'),
            activeTag;
        if (tagElement.classList.contains('active')) {
            if (global_GallerySettings[moduleId].allTagButton) {
                return
            } else {
                tagElement.classList.remove('active');
                activeTag = 'all';
                global_GallerySettings[moduleId].activeTag = 'all'
            }
        } else {
            activeTag = tagElement.getAttribute('data-tag');
            global_GallerySettings[moduleId].activeTag = activeTag;
            tagElement.parentNode.querySelector('.active') && tagElement.parentNode.querySelector('.active').classList.remove('active')
            tagElement.classList.add('active')
        }
        let loadmoreButton = el.querySelector('.load-more'),
            gallery = tagElement.closest('.ModuleGallery').querySelector('.gallery'),
            pageLimit = global_GallerySettings[moduleId].imgPerPage,
            count = 1,
            tagImgsCount = 0;
        for (let index = 0; index < gallery.children.length; index++) {
            let item = gallery.children[index];
            let itemTags = item.getAttribute('data-tags');
            item.classList.add('hidden');
            item.querySelector('.animated-item') && item.querySelector('.animated-item').classList.add('hidden');
            if (activeTag === 'all' || typeof itemTags !== 'undefined' && JSON.parse(itemTags).includes(activeTag)) {
                tagImgsCount++;
                if (count <= pageLimit) {
                    count++;
                    item.classList.remove('hidden');
                    item.querySelector('.animated-item') && item.querySelector('.animated-item').classList.remove('hidden')
                }
            }
        }
        if (loadmoreButton) {
            if (tagImgsCount <= pageLimit) {
                loadmoreButton.classList.add('hidden')
            } else {
                loadmoreButton.classList.remove('hidden')
            }
        }
        let hasLoadingEffect = gallery.classList.contains('loading-animation');
        if (hasLoadingEffect) {
            startLoadingEffects(null, document.querySelector("[data-animated-id='" + gallery.getAttribute('data-animated-id') + "']"))
        }
        global_GallerySettings[moduleId].loadMoreCount = 0;
        setGallerySettings(moduleId, null, activeTag)
    };
    $(document).on('click', '.slider-item.active-slide .slide-background', function() {
        var sliderItem = $(this);
        var link = sliderItem.attr('data-link');
        var target = sliderItem.attr('data-target');
        if (link !== undefined) {
            openInNewTab(link, parseInt(target))
        }
    });

    function galleryPopupRun() {
        if ($('html').hasClass('admin-mode')) {
            return !1
        }
        $(document).on('keydown', function(e) {
            if ($('#galleryPopup.image-popup.image-layer-container.active').length) {
                if (e.which == 37) {
                    $('.gallery-left').click()
                } else if (e.which == 39) {
                    $('.gallery-right').click()
                } else if (e.which == 27) {
                    document.querySelector('#galleryPopup.image-popup.image-layer-container .uci-close').click()
                }
            }
        });
        if ($('input[type="hidden"].gallery-images-data').length) {
            imgPopup.appendTo('body')
        }
        $(document).on('click', '.gallery-image .single-item, .figcaption', function(event) {
            galleryItem = $(this);
            var link = galleryItem.attr('data-link');
            var target = galleryItem.attr('data-target');
            var src = galleryItem.attr('src');
            let imageLink = event.target.closest('a');
            let previewAvailable = event.target.closest('.gallery-image') ? event.target.closest('.gallery-image').getAttribute('data-preview') : 0;
            let itemIndex = parseInt(galleryItem.attr('data-index')) - 1;
            if (link !== undefined) {
                openInNewTab(link, parseInt(target))
            } else if (src !== undefined) {
                if ($(this).attr('class').includes("not-clickable")) {
                    return
                }
                if (!imageLink && parseInt(previewAvailable) !== 0) {
                    imgPopupImg.attr('src', src);
                    if (galleryItem.attr('data-module-id')) {
                        imgPopup.attr('data-module', galleryItem.attr('data-module-id'))
                    }
                    imgPopup.addClass('active')
                }
                if (galleryImagesArr === null) {
                    galleryImagesArr = JSON.parse(galleryItem.closest('.ModuleGallery').find('input.gallery-images-data').first().val());
                    galleryElement = galleryItem.closest('.gallery').first();
                    var galleryModule = this.closest('.gallery');
                    var galleryImagePopup = document.getElementById('galleryPopup');
                    if (galleryModule && galleryImagePopup) {
                        var galleryElementChildren = galleryModule.children.length;
                        var hiddenItemCount = 0;
                        if (galleryElementChildren) {
                            for (var index = 0; index < galleryElementChildren; index++) {
                                if (galleryModule.children[index].classList.contains('hidden')) {
                                    hiddenItemCount++
                                }
                            }
                        }
                        if (galleryElementChildren - hiddenItemCount <= 1) {
                            galleryImagePopup.classList.add('hide-arrows')
                        } else {
                            galleryImagePopup.classList.remove('hide-arrows')
                        }
                    }
                    activeImageIndex = itemIndex
                }
            }
        });
        $(document).on('click', '.tags-group [data-tag]', function(event) {
            tagElement = $(this);
            filterByTag(this)
        })
    }
    var isEffectsDone = setInterval(function() {
        if (window.animateEffects && window.animateEffects.effectsDone) {
            galleryPopupRun();
            clearInterval(isEffectsDone)
        }
    }, 500)
}());
var lastScrollTop = $(document).scrollTop();
$(window).on('load', function() {
    startLoadingEffects();
    $(window).on('wheel mousewheel scroll', function(e) {
        var scrollTop = $(document).scrollTop();
        var direction = '';
        if (scrollTop >= lastScrollTop) {
            direction = 'bottom'
        } else {
            direction = 'top'
        }
        lastScrollTop = scrollTop;
        startLoadingEffects(direction)
    })
    window.addEventListener('message', function(e) {
        if (checkOrigin(e)) {
            if (e.data && e.data.logomaker && e.data.imageSrc) {
                var logoElements = document.querySelectorAll('[data-logo-element]');
                logoElements.forEach((item) => {
                    item.src = e.data.imageSrc;
                    if (item.dataset.src) {
                        item.dataset.src = e.data.imageSrc
                    }
                    if (item.classList.contains('fixed-ratio-content')) {
                        item.classList.remove('fixed-ratio-content');
                        let parentBlock = item.closest('.fixed-ratio');
                        if (parentBlock) {
                            parentBlock.style.paddingBottom = 0
                        }
                    }
                })
            }
        }
    })
});
let lazyLoadVideos = function(lazyVideos) {
    if (!lazyVideos || !lazyVideos.length) return;
    if ("IntersectionObserver" in window) {
        var lazyVideoObserver = new IntersectionObserver(function(entries, ) {
            entries.forEach(function(video) {
                if (video.isIntersecting) {
                    for (var source in video.target.children) {
                        var videoSource = video.target.children[source];
                        if (typeof videoSource.tagName === "string" && videoSource.tagName === "SOURCE" && !videoSource.src) {
                            videoSource.src = videoSource.dataset.src
                        }
                    }
                    video.target.load();
                    video.target.classList.remove("lazy");
                    lazyVideoObserver.unobserve(video.target)
                }
            })
        });
        lazyVideos.forEach(function(lazyVideo) {
            lazyVideoObserver.observe(lazyVideo)
        })
    }
}
window.addEventListener('load', () => {
    let timeout = setTimeout(() => {
        let lazyVideos = [].slice.call(document.querySelectorAll("video.data-lazy")),
            allLazyVideos = Object.assign(lazyVideos, [].slice.call(document.querySelectorAll("video.lazy")));
        if (lazyVideos && lazyVideos.length) {
            lazyVideos.forEach(elelemnt => {
                elelemnt.classList.add('lazy');
                elelemnt.classList.remove('data-lazy')
            })
        }
        lazyLoadVideos(allLazyVideos);
        clearTimeout(timeout)
    })
});

function hideBackgroundImage(element) {
    if (element) {
        element.querySelectorAll('.backgroundVideoImage').forEach(el => {
            el.classList.add('hide-background-image')
        })
    }
}

function outerHeightDimension(elm) {
    let elmHeight = elm.offsetHeight;
    let elmMargin;
    if (document.all) {
        elmMargin = parseInt(elm.currentStyle.marginTop, 10) + parseInt(elm.currentStyle.marginBottom, 10)
    } else {
        let getComputedStyle = document.defaultView.getComputedStyle(elm, '');
        if (getComputedStyle) {
            elmMargin = parseInt(getComputedStyle.getPropertyValue('margin-top')) + parseInt(getComputedStyle.getPropertyValue('margin-bottom'))
        }
    }
    return (elmHeight + elmMargin)
}

function fixHeaderRows() {
    var overlapedHeader = document.querySelector('.header-and-main-rows .header-rows.header-overlapped');
    var headerFixedRows = document.querySelectorAll('.header-and-main-rows .header-rows .header-row.header-row-fix');
    if (!headerFixedRows.length) {
        return !1
    }
    if (!overlapedHeader) {
        var headerRows = document.querySelectorAll('.header-and-main-rows .header-rows .header-row');
        if (headerRows.length === headerFixedRows.length) {
            headerRows[0].closest('.header-rows').classList.add('header-sticky');
            return !1
        }
    }
    var top = 0;
    headerFixedRows.forEach(function(item) {
        var itemHeight = outerHeightDimension(item);
        var offsetTop = item.closest('.header-row-wrapper').offsetTop;
        item.setAttribute('data-top', top);
        item.setAttribute('data-start-fix', offsetTop);
        item.closest('.header-row-wrapper').style.height = itemHeight + "px";
        if (window.pageYOffset > offsetTop || offsetTop === 0) {
            item.classList.add('fixed');
            item.style.top = top + "px"
        }
        top += itemHeight
    });
    document.removeEventListener("scroll", this._fixRowOnHeader, !1);
    document.addEventListener('scroll', this._fixRowOnHeader = function() {
        headerFixedRows.forEach(function(item) {
            var startFix = parseInt(item.getAttribute('data-start-fix'));
            var top = parseInt(item.getAttribute('data-top'));
            if ((window.pageYOffset > startFix - top) || startFix === 0) {
                item.classList.add('fixed');
                item.style.top = top + "px";
                if (document.querySelector('.crypto-side-bar__container')) {
                    item.style.left = '90px'
                }
            } else {
                item.classList.remove('fixed');
                item.style.top = 'auto';
                if (document.querySelector('.crypto-side-bar__container')) {
                    item.style.left = 'unset'
                }
            }
        })
    })
}

function getAllPopups() {
    if (!window.popupsExist) return;
    let pageId = window.page.id,
        currentUrl = window.location.pathname;
    api.publicCall('default', 'Popup', 'getPopups', JSON.stringify({
        pageId,
        currentUrl
    }), function(response) {
        window.popupLoaded = !0;
        window.popups = JSON.parse(response.msg);
        initPopups()
    }, 'get')
}
window.addEventListener('hashchange', hashHandler, !1);
window.activePopupAlias = null;
window.removeNoScroll = !1;
window.referrerPopupAliases = [];
var popupAnimationDuration = 250;

function initPopups() {
    var popupAlias = window.location.hash.split('?')[1];
    if (popupAlias) {
        var alias = decodeURIComponent(popupAlias);
        if (window.popupLoaded && window.popups[alias]) {
            openPopup(alias)
        } else if (!window.popupLoaded) {
            openPopupsWithInterval(alias)
        } else {
            popupTriggering()
        }
    } else {
        popupTriggering()
    }
};

function hashHandler() {
    var popupAlias = window.location.hash.split('?')[1];
    if (window.removeNoScroll) {
        document.body.classList.remove('no-scroll')
    } else {
        window.removeNoScroll = !0
    }
    if (!popupAlias) {
        document.body.classList.remove('no-scroll', 'open-popup')
    }
    if (!window.activePopupAlias || window.activePopupAlias !== popupAlias) {
        openPopup(popupAlias)
    }
}

function getItem(name) {
    if (!window.localStorage) {
        return !1
    } else {
        return window.localStorage.getItem(name)
    }
}

function setItem(name, data) {
    if (!window.localStorage) {
        return !1
    } else {
        window.localStorage.setItem(name, data);
        return !0
    }
}

function addPopupId(popupId, popupsList, currentLanguageId, saveCounter) {
    if (popupsList[currentLanguageId]) {
        let popup = popupsList[currentLanguageId].find(item => item.popupId === popupId);
        if (popup) {
            popup.showsCount++
        } else {
            popupsList[currentLanguageId].push({
                popupId,
                showsCount: 1,
                saveCounter: saveCounter || 1
            })
        }
    } else {
        popupsList[currentLanguageId] = [{
            popupId,
            showsCount: 1,
            saveCounter: saveCounter || 1
        }]
    }
    setItem('openedPopupsListByLanguage', JSON.stringify(popupsList))
}

function correctStructure(curPopups, saveCounter) {
    let curPopupsArr = [];
    curPopups.forEach(popup => {
        curPopupsArr.push({
            popupId: popup,
            showsCount: 1,
            saveCounter: saveCounter
        })
    });
    return curPopupsArr
}

function updateStructure(curPopups, popupId, saveCounter) {
    let curPopup = curPopups.find(item => item.popupId === popupId);
    curPopup.showsCount = 0;
    curPopup.saveCounter = saveCounter;
    return curPopups
}

function popupTriggering(disableOpenedPopupList = !1) {
    if (window.popupTriggeringRules) {
        if (window.page.status === 404) {
            return !1
        }
        let rules = popupTriggeringRules.filter(function(item) {
            return item.enableTriggeringRule == 1
        });
        let BreakException = {};
        try {
            rules.forEach((rule) => {
                let openedPopupsList = null;
                let currentLanguageId = null;
                if (!disableOpenedPopupList) {
                    openedPopupsList = getItem('openedPopupsListByLanguage');
                    currentLanguageId = this.window.currentLanguageObject.id;
                    if (openedPopupsList) {
                        openedPopupsList = JSON.parse(openedPopupsList)
                    } else {
                        openedPopupsList = {}
                    }
                    if (openedPopupsList && currentLanguageId && openedPopupsList[currentLanguageId]) {
                        if (typeof openedPopupsList[currentLanguageId][0] === 'number') {
                            openedPopupsList[currentLanguageId] = correctStructure(openedPopupsList[currentLanguageId], rule.saveCounter);
                            setItem('openedPopupsListByLanguage', JSON.stringify(openedPopupsList))
                        }
                        let curPopup = openedPopupsList[currentLanguageId] && openedPopupsList[currentLanguageId].length && openedPopupsList[currentLanguageId].find(item => item.popupId === rule.id);
                        if (curPopup) {
                            if (curPopup.saveCounter !== (parseInt(rule.saveCounter) || 1)) {
                                openedPopupsList[currentLanguageId] = updateStructure(openedPopupsList[currentLanguageId], rule.id, parseInt(rule.saveCounter));
                                setItem('openedPopupsListByLanguage', JSON.stringify(openedPopupsList))
                            } else if (rule.impressionsMaxNumber === undefined || parseInt(rule.impressionsMaxNumber) !== 0 && parseInt(rule.impressionsMaxNumber) <= curPopup.showsCount) {
                                return
                            }
                        }
                    }
                }
                let triggeringUrlValue = rule.triggeringUrlValue.toLowerCase();
                let pathname = window.location.pathname.toLowerCase();
                pathname = decodeURI(pathname);
                if (pathname === '/') {
                    pathname = pathname + window.page.alias
                }
                if (pathname === `/${window.currentLanguagePrefix}`) {
                    pathname = pathname + '/' + window.page.alias
                }
                let segments = pathname.split('/');
                let lastSegment = segments[segments.length - 1]
                switch (rule.triggeringUrlRule) {
                    case 'is':
                        if (lastSegment === triggeringUrlValue || pathname === triggeringUrlValue || pathname === `/${triggeringUrlValue}` || window.page.alias === triggeringUrlValue) {
                            window.triggeringRuleIsWorked = !0;
                            setTimeout(function() {
                                openPopup(rule.alias);
                                markNotificationAsRead(rule)
                                if (!disableOpenedPopupList) addPopupId(rule.id, openedPopupsList, currentLanguageId, rule.saveCounter)
                            }, Number(rule.triggeringTime) * 1000);
                            throw BreakException
                        }
                        break;
                    case 'isNot':
                        if (!pathname.includes(triggeringUrlValue) && window.popups[rule.alias]) {
                            window.triggeringRuleIsWorked = !0;
                            setTimeout(function() {
                                openPopup(rule.alias);
                                markNotificationAsRead(rule)
                                if (!disableOpenedPopupList) addPopupId(rule.id, openedPopupsList, currentLanguageId, rule.saveCounter)
                            }, Number(rule.triggeringTime) * 1000);
                            throw BreakException
                        }
                        break;
                    case 'startsWith':
                        if (pathname.startsWith(triggeringUrlValue) && window.popups[rule.alias]) {
                            window.triggeringRuleIsWorked = !0;
                            setTimeout(function() {
                                openPopup(rule.alias);
                                markNotificationAsRead(rule)
                                if (!disableOpenedPopupList) addPopupId(rule.id, openedPopupsList, currentLanguageId, rule.saveCounter)
                            }, Number(rule.triggeringTime) * 1000);
                            throw BreakException
                        }
                        break;
                    case 'endsWith':
                        if (pathname.endsWith(triggeringUrlValue) && window.popups[rule.alias]) {
                            window.triggeringRuleIsWorked = !0;
                            setTimeout(function() {
                                openPopup(rule.alias);
                                markNotificationAsRead(rule)
                                if (!disableOpenedPopupList) addPopupId(rule.id, openedPopupsList, currentLanguageId, rule.saveCounter)
                            }, Number(rule.triggeringTime) * 1000);
                            throw BreakException
                        }
                        break;
                    case 'contains':
                        if (pathname.includes(triggeringUrlValue) && window.popups[rule.alias]) {
                            window.triggeringRuleIsWorked = !0;
                            setTimeout(function() {
                                openPopup(rule.alias);
                                markNotificationAsRead(rule)
                                if (!disableOpenedPopupList) addPopupId(rule.id, openedPopupsList, currentLanguageId, rule.saveCounter)
                            }, Number(rule.triggeringTime) * 1000);
                            throw BreakException
                        }
                        break;
                    case 'doesNotContains':
                        if (!pathname.includes(triggeringUrlValue) && window.popups[rule.alias]) {
                            window.triggeringRuleIsWorked = !0;
                            setTimeout(function() {
                                openPopup(rule.alias);
                                markNotificationAsRead(rule)
                                if (!disableOpenedPopupList) addPopupId(rule.id, openedPopupsList, currentLanguageId, rule.saveCounter)
                            }, Number(rule.triggeringTime) * 1000);
                            throw BreakException
                        }
                        break;
                    default:
                }
            })
        } catch (e) {
            if (e !== BreakException) throw e
        }
    }
}

function markNotificationAsRead(rule) {
    if (rule.key && window.SB && window.SB.markAsReadNotification) {
        window.SB.markAsReadNotification(+rule.key)
    }
}

function openPopupsWithInterval(alias) {
    var popupOpenInterval = setInterval(function() {
        if (window.popupLoaded) {
            clearInterval(popupOpenInterval);
            if (window.popups[alias]) {
                openPopup(alias)
            } else {
                popupTriggering()
            }
        }
    }, 300)
}
window.addEventListener("message", receiveMessageForPopup.bind(this), !1);

function checkOrigin(event) {
    return event.origin === window.location.origin
}

function receiveMessageForPopup(event) {
    if (checkOrigin(event)) {
        if (event.data.action) {
            if (event.data.action === "openPopup") {
                openPopup(event.data.alias)
            }
            if (event.data.action === "changeLanguage" && event.data.prefix && event.data.url) {
                changeLanguage(null, event.data.prefix, event.data.url)
            }
        }
    }
}
if (window.popupIframe) {
    window.onclick = function(e) {
        var target;
        if (e.target.href) {
            target = e.target
        } else if (e.target.closest("a") && e.target.closest("a").href) {
            target = e.target.closest("a")
        }
        if (target && target.href && !target.classList.contains('moduleForm-submit')) {
            e.preventDefault();
            e.stopPropagation();
            window.parent.postMessage({
                action: 'popupBeforeRedirection',
                href: target.href,
                target: target.target
            }, '*')
        }
        if (e.target.type == 'checkbox') {
            return
        }
        let popupWrapper = document.querySelector('.popup-body'),
            ecwidPopup = document.querySelector('#ecwid_body'),
            isClickInsideElement = popupWrapper.contains(e.target) || !e.target.closest('.uc-popup-close') || (ecwidPopup && ecwidPopup.contains(popupWrapper) && (ecwidPopup.contains(e.target) || e.target.classList.item(0).toLowerCase() === 'ecwid-popup-closebutton'));
        if (e.target.getAttribute('button-role') !== "auth-next-step" && (!isClickInsideElement || e.target.closest('.uc-popup-close'))) {
            let alias = !isClickInsideElement ? popupWrapper.getAttribute('data-wrapper-alias') : e.target.getAttribute('data-alias');
            window.parent.postMessage({
                action: 'closePopup',
                alias: alias || e.target.closest('.uc-popup-close').getAttribute('data-alias')
            }, '*')
        }
    }
} else {
    window.addEventListener("message", event => {
        if (checkOrigin(event)) {
            if (event.data.action === "popupBeforeRedirection") {
                if (event.data.target === '_blank') {
                    window.open(event.data.href)
                } else {
                    window.location.href = event.data.href
                }
            }
            if (event.data.action === 'closePopup') {
                closePopup(event.data.alias)
            }
        }
    }, !1)
}

function openPopup(alias, isAccountPopup = !1) {
    if ((window.V3_ENABLED && isAccountPopup)) {
        isV3AuthPopup = !0
    }
    if (window.popupIframe) {
        window.parent.postMessage({
            action: 'openPopup',
            alias: alias
        }, '*');
        return !1
    }
    if (!window.popupLoaded) {
        openPopupsWithInterval(alias)
        return !1
    }
    alias = decodeURIComponent(alias);
    var popup = window.popups[alias];
    if (popup) {
        var existingPopup = document.querySelector('[data-alias="' + alias + '"]');
        if (!existingPopup) {
            var htmlObject = document.createElement('div');
            htmlObject.innerHTML = popup;
            existingPopup = htmlObject.querySelector('[data-alias="' + alias + '"]');
            document.body.appendChild(htmlObject);
            var iframe = document.createElement('iframe');
            iframe.style = "width:100%;height:100%;border:0;position:relative;z-index:1";
            document.querySelector(`[data-wrapper-alias='${alias}'] .popup-wrapper-overlay`).after(iframe);
            iframe.contentWindow.document.open();
            iframe.contentWindow.document.write('<div class="popup-wrapper-container">' + document.querySelector('.popup-wrapper-container').innerHTML + '</div>');
            iframe.contentWindow.document.querySelector('body').style.background = 'transparent';
            iframe.contentWindow.document.querySelector('html').lang = document.querySelector('html').lang;
            iframe.contentWindow.document.querySelector('html').setAttribute('data-theme', document.querySelector('html').getAttribute('data-theme'));
            iframe.contentWindow.document.querySelector('html').setAttribute('class', document.querySelector('html').getAttribute('class'));
            iframe.contentWindow.document.querySelector('body').classList.add('popup-body');
            iframe.contentWindow.document.close();
            document.querySelector(`[data-wrapper-alias='${alias}'] .popup-wrapper-container`).remove()
        }
        setTimeout(function() {
            if (window.activePopupAlias === alias) {
                return
            }
            if (window.activePopupAlias) {
                var activePopup = document.querySelector('.popup-tool-container.active');
                activePopup.classList.remove('active');
                activePopup.classList.add('out');
                activePopup.classList.add('delay');
                existingPopup.classList.add("active");
                existingPopup.classList.add("delay");
                setTimeout(function() {
                    activePopup.classList.remove('out');
                    activePopup.classList.remove('delay');
                    existingPopup.classList.remove('delay')
                }, popupAnimationDuration);
                window.activePopupAlias = alias
            } else {
                window.activePopupAlias = alias;
                existingPopup.classList.add("active")
            }
            var locationHash = window.location.hash ? window.location.hash : '#';
            var hashAlias = locationHash.split('?')[1];
            if (window.referrerPopupAliases[window.referrerPopupAliases.length - 1] !== alias) {
                window.referrerPopupAliases.push(alias)
            }
            if (!hashAlias) {
                if (!V3_ENABLED || (V3_ENABLED && !isAccountPopup)) {
                    history.pushState(null, null, locationHash + '?' + alias)
                }
                window.removeNoScroll = !1
            } else if (hashAlias !== alias && !isAccountPopup && !hashAlias.includes('sign-in') && !hashAlias.includes('sign-up')) {
                var replacedHash = window.location.hash.replace(hashAlias, alias);
                history.pushState(null, null, replacedHash)
            }
            setTimeout(() => {
                initVideos(popup)
            }, 500)
        }, 100);
        document.body.classList.add('no-scroll');
        document.body.classList.add('open-popup')
    } else {
        closeOpenedPopups()
    }
}

function closePopup(alias, onClickAction = !1) {
    window.activePopupAlias = null;
    var currentPopup = document.querySelector('[data-alias="' + alias + '"]');
    if (currentPopup !== null) {
        let moduleYoutubeVideos = currentPopup.querySelectorAll('.moduleYoutubeVideo'),
            moduleVimeoVideos = currentPopup.querySelectorAll('.moduleVimeoVideo'),
            moduleCustomVideos = currentPopup.querySelectorAll('.moduleCustomVideo');
        moduleYoutubeVideos.forEach(video => {
            let elId = video.getAttribute('data-id');
            document.querySelector(`#iframe${elId}`).contentWindow.postMessage('{"event":"command","func":"pauseVideo","args":""}', '*')
        });
        moduleVimeoVideos.forEach(video => {
            let elId = video.getAttribute('data-id');
            document.querySelector(`#iframe${elId}`).contentWindow.postMessage('{"method":"pause"}', '*')
        });
        moduleCustomVideos.forEach(video => {
            video.pause()
        });
        window.referrerPopupAliases.pop();
        currentPopup.classList.remove("active");
        currentPopup.classList.add('out');
        setTimeout(() => {
            currentPopup.classList.remove('out');
            currentPopup.closest('div').remove()
        }, popupAnimationDuration);
        history.pushState(null, null, window.location.hash.split('?')[0]);
        document.body.classList.remove('no-scroll');
        document.body.classList.remove('open-popup');
        if (window.referrerPopupAliases.length) {
            openPopup(window.referrerPopupAliases[window.referrerPopupAliases.length - 1])
        }
        let youtubeVideos = currentPopup.querySelectorAll('.vidoeYoutubeContent'),
            vimeoVideos = currentPopup.querySelectorAll('.vidoeVimeoContent'),
            hiddenBackgroundImages = currentPopup.querySelectorAll('.hide-background-image');
        youtubeVideos.forEach(video => {
            let elId = video.getAttribute('data-id');
            tv[`iframe${elId}`].stopVideo()
        });
        vimeoVideos.forEach(video => {
            let elId = video.getAttribute('data-id');
            tv[`vimeo${elId}`].unload()
        });
        hiddenBackgroundImages.forEach(bg => {
            bg.classList.remove('hide-background-image')
        });
        console.log(isV3AuthPopup);
        if (onClickAction || isV3AuthPopup) {
            isV3AuthPopup = !1;
            window.parent.postMessage({
                action: 'closePopup',
                alias: alias
            }, '*')
        }
    }
}

function closeOpenedPopups() {
    var activePopup = document.querySelector('.popup-tool-container.active');
    if (activePopup) {
        activePopup.classList.remove('active');
        window.activePopupAlias = null
    }
}
document.addEventListener('keydown', function() {
    document.documentElement.classList.add('keyboard');
    document.documentElement.classList.remove('mouse')
});
document.addEventListener('mousedown', function() {
    document.documentElement.classList.add('mouse');
    document.documentElement.classList.remove('keyboard')
});

function setOpenedClassToHeaderRow(target, type) {
    if (type !== 'leave') {
        let headerRow = target.closest('.uc-row.header-row');
        headerRow && headerRow.classList.add('has-opened-sub-pages')
    } else {
        let headerRow = target.closest('.uc-row.header-row');
        headerRow && headerRow.classList.remove('has-opened-sub-pages')
    }
}
document.addEventListener('click', function() {
    if (openedSubMenu) {
        closeUcSubMenu(document.querySelectorAll('.subMenu__show'));
        openedSubMenu = null
    }
})
var ucExternalUrl = {};
ucExternalUrl.getUrlQueryParams = function(url) {
    var queries = {};
    if (url.indexOf('?') === -1) {
        return queries
    }
    url = url.split('?')[1];
    var queryStrings = url;
    if (url.indexOf('#') !== -1) {
        queryStrings = url.split('#')[0]
    }
    queryStrings = queryStrings.split('&');
    queryStrings.forEach(function(queryString) {
        if (queryString.length > 0) {
            queryString = queryString.split('=');
            if (queryString[1] !== undefined) {
                queries[queryString[0]] = queryString[1]
            } else {
                queries[queryString[0]] = ''
            }
        }
    });
    return queries
};
ucExternalUrl.getUpdatedurl = function(currentUrlQueries, url, langSwitcher = !1) {
    if (url.indexOf(window.location.hostname) !== -1 && !langSwitcher) {
        return url
    }
    var regex = /^https?:\/\/|^\/\//i;
    if (regex.test(url) === !1) {
        return url
    }
    let urlParts = url.split('#'),
        hashquery = "",
        urlQueries = Object.assign({}, currentUrlQueries);
    if (urlQueries.btag && urlQueries.hasOwnProperty('AFFAGG') && urlParts[1]) {
        urlQueryParamsAffiliate = {
            btag: urlQueries.btag,
            AFFAGG: urlQueries.AFFAGG
        }
        delete urlQueries.btag;
        delete urlQueries.AFFAGG;
        hashquery = ucExternalUrl.buildQuery(urlParts[1], urlQueryParamsAffiliate)
    }
    query = ucExternalUrl.buildQuery(urlParts[0], urlQueries);
    url = urlParts[0] += query;
    if (urlParts[1] !== undefined) {
        url += '#' + urlParts[1] + hashquery
    }
    return url
};
ucExternalUrl.buildQuery = function(url, queries) {
    var query = '';
    if (url.indexOf('?') === -1) {
        var counter = 1;
        for (var index in queries) {
            if (queries.hasOwnProperty(index)) {
                if (counter === 1) {
                    query += '?' + index + '=' + queries[index]
                } else {
                    query += '&' + index + '=' + queries[index]
                }
                counter++
            }
        }
    } else {
        var hrefQueries = ucExternalUrl.getUrlQueryParams(url);
        for (var index in queries) {
            if (queries.hasOwnProperty(index)) {
                if (hrefQueries[index] === undefined) {
                    query += '&' + index + '=' + queries[index]
                }
            }
        }
    }
    return query
}
ucExternalUrl.createCookie = function(name, value, days) {
    if (days) {
        var date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        var expires = "; expires=" + date.toUTCString()
    } else var expires = "";
    document.cookie = name + "=" + value + expires + "; path=/"
};
ucExternalUrl.readCookie = function(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') c = c.substring(1, c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length)
    }
    return null
};
ucExternalUrl.eraseCookie = function(name) {
    ucExternalUrl.createCookie(name, "", -1)
};
var cookieUrlQueries = [];
$(function() {
    var cookieExcludeList = ['device', 'previewMode', 'firstRun', 'firstRunForAnalytics', 'gws_rd'];
    var externalUrlQueryParams = ucExternalUrl.getUrlQueryParams(location.search);
    var urlQueryParamsForMergeCookie = {};
    var externalUrlQueryKeys = Object.keys(externalUrlQueryParams).filter(function(key) {
        if (cookieExcludeList.indexOf(key) > -1) {
            urlQueryParamsForMergeCookie[key] = externalUrlQueryParams[key];
            return !1
        }
        return !0
    });
    var urlStringForSaveCookie = '';
    if (externalUrlQueryKeys.length) {
        let stringParts = externalUrlQueryKeys.map(function(key) {
            if (key === 'tap_cid' || key === 'ref' || key === 'tap_s') {
                ucExternalUrl.createCookie(key, externalUrlQueryParams[key], 30)
            }
            return key + '=' + externalUrlQueryParams[key]
        });
        urlStringForSaveCookie += '?' + stringParts.join('&')
    } else {
        document.cookie = 'ucraftExternalUrlQueryParams=; Max-Age=0'
    }
    if (urlStringForSaveCookie.length > 0 && window.languageSwitcherQueryParams) {
        ucExternalUrl.createCookie('ucraftExternalUrlQueryParams', urlStringForSaveCookie, 30)
    }
    var ucraftExternalUrlQueryParams = window.languageSwitcherQueryParams ? ucExternalUrl.readCookie('ucraftExternalUrlQueryParams') : '';
    if (!ucraftExternalUrlQueryParams) {
        if (!urlQueryParamsForMergeCookie) {
            return !0
        } else {
            cookieUrlQueries = urlQueryParamsForMergeCookie
        }
    } else {
        cookieUrlQueries = ucExternalUrl.getUrlQueryParams(ucraftExternalUrlQueryParams);
        cookieUrlQueries = Object.assign(cookieUrlQueries, urlQueryParamsForMergeCookie)
    }
    var currentHostname = window.location.hostname;
    $('a[href]').each(function() {
        try {
            let href = $(this).attr('href');
            let {
                hostname
            } = new URL(href);
            if (hostname != currentHostname) {
                $(this).attr('href', ucExternalUrl.getUpdatedurl(cookieUrlQueries, href))
            }
        } catch (err) {}
    });
    $('.ModuleLanguageSwitcher ul a').each(function() {
        var href = $(this).attr('data-href');
        $(this).attr('href', ucExternalUrl.getUpdatedurl(cookieUrlQueries, href, !0))
    })
});
if (!window.websiteElementsDisabled) {
    var returnUrl = encodeURIComponent(window.location.href.replace(location.hash, ""));
    window.addEventListener("message", receiveMessage, !1);
    window.accountSystemLanguage = null;

    function receiveMessage(event) {
        switch (event.data.action) {
            case 'accounts_status':
                window.location.href = window.accountsURLWithoutLocale + '#/login?return=' + returnUrl;
                break;
            case 'login':
                setCookie("justLoggedIn", '1', 1);
                window.location.href = event.data.url;
                break;
            case 'close':
                iframe_popup_close();
                $('#accounts-iframe').attr('src', '');
                if (window.accountSystemLanguage !== null) {
                    tryToRedirectToRightLanguage(window.accountSystemLanguage)
                }
                break;
            case 'reload':
                window.location.reload();
                break;
            case 'loaded':
                handleIframeLoaded();
                $(".accounts-popup .loading-container").removeClass("show");
                break;
            case 'accept':
                iframe_popup_close();
                $('#accounts-iframe').attr('src', '');
                break;
            case 'redirect':
                window.open(event.data.url, '_blank');
                iframe_popup_close();
                $('#accounts-iframe').attr('src', '');
                break;
            case 'updateAvatar':
                $('.user-image img').attr('src', event.data.avatar);
                break;
            case "changeLanguage":
                window.accountSystemLanguage = event.data.currentLocale;
                break;
            case 'logout':
                document.querySelectorAll('.user-profile-menu').forEach(function(node) {
                    node.classList.remove('logged-in')
                });
            case "changeLayout":
                changeLayout(event.data.layout);
                break
        }
    }
    $(document).ready(function() {
        window.language = window.currentLanguageObject ? window.currentLanguageObject.prefix : "";
        let url = `/${window.language}/papi/default/ModuleUserProfile/getCurrentUser`;
        if (document.documentElement.classList.contains('preview-mode')) {
            url += '?previewMode=true'
        }
        window.currentUsergetCall = fetch(url);
        window.currentUsergetCall.then((response) => response.json()).then((data) => {
            window.currentUser = data.msg.currentUser;
            if (window.currentUser && window.currentUser.id) {
                document.querySelectorAll('[data-session-visibility="2"]').forEach(function(node) {
                    node.removeAttribute('data-session-visibility')
                });
                window.language = data.msg.currentUser.language;
                if (document.querySelector('.user-profile')) {
                    document.querySelectorAll('.user-profile-menu').forEach(function(node) {
                        node.classList.add('logged-in')
                    })
                    document.querySelectorAll('.user-profile .name').forEach(function(node) {
                        node.innerHTML = window.currentUser.firstName + " " + window.currentUser.lastName
                    });
                    document.querySelectorAll('.user-profile .email').forEach(function(node) {
                        node.innerHTML = window.currentUser.email
                    });
                    userAccountFrame();
                    if (window.currentUser.avatarUrl !== "") {
                        document.querySelectorAll('.user-profile .user-image').forEach(function(node) {
                            node.firstElementChild.setAttribute('src', window.currentUser.avatarUrl)
                        })
                    }
                    if (getCookie("justLoggedIn")) {
                        deleteCookie("justLoggedIn");
                        if (window.currentUser.hasSites) {
                            window.location.hash = "#my-sites";
                            hash_change()
                        } else {
                            window.location.hash = "#get-started";
                            hash_change()
                        }
                    }
                }
            } else {
                document.querySelectorAll('[data-session-visibility="3"]').forEach(function(node) {
                    node.removeAttribute('data-session-visibility')
                });
                if (document.querySelector('.user-profile')) {
                    userAccountFrame();
                    document.querySelectorAll('.user-profile-menu').forEach(function(node) {
                        node.classList.remove('logged-in')
                    })
                }
                if ($('.user-profile-menu').find(".user-profile")) {
                    $('.user-profile-menu').find(".user-profile").remove()
                }
            }
        });
        var externalUrlQueryParams = ucExternalUrl.getUrlQueryParams(location.search);
        var tapCid = ucExternalUrl.readCookie('tap_cid');
        var ref = ucExternalUrl.readCookie('ref');
        if (externalUrlQueryParams.ref) {
            ucExternalUrl.createCookie('tap_s', externalUrlQueryParams.tap_s ? externalUrlQueryParams.tap_s : '', 30)
        }
        var source = ucExternalUrl.readCookie('tap_s');
        if (externalUrlQueryParams.ref || (ref && !tapCid)) {
            api.publicCall('default', 'Helper', 'getAffilaitionClickId', JSON.stringify({
                referralId: externalUrlQueryParams.ref ? externalUrlQueryParams.ref : ref,
                sourceId: source
            }), function(response) {
                if (response && response.data && response.data.click && response.data.click.id) {
                    ucExternalUrl.createCookie('tap_cid', response.data.click.id, 30);
                    userAccountFrame()
                }
            }, 'get')
        }
    });

    function userAccountFrame() {
        window.accountsURL = window.accountsIframeUrl + '?locale=' + window.language;
        window.accountsURLWithoutLocale = window.accountsUrl;
        var ucraftExternalUrlQueryParams = ucExternalUrl.readCookie('ucraftExternalUrlQueryParams');
        if (ucraftExternalUrlQueryParams !== null && ucraftExternalUrlQueryParams.length) {
            var cookieUrlQueries = ucExternalUrl.getUrlQueryParams(ucraftExternalUrlQueryParams);
            var tapCid = ucExternalUrl.readCookie('tap_cid');
            var affiliateId = tapCid ? tapCid : (cookieUrlQueries.tap_cid ? cookieUrlQueries.tap_cid : null);
            if (affiliateId) {
                window.accountsURL += '&affiliateId=' + affiliateId;
                window.accountsURL += '&affiliateType=tapfiliate'
            }
            if (cookieUrlQueries.tap_id !== undefined && cookieUrlQueries.tap_id && cookieUrlQueries.tap_program !== undefined && cookieUrlQueries.tap_program) {
                window.accountsURL += '&affiliateId=' + cookieUrlQueries.tap_id;
                window.accountsURL += '&affiliateType=tapfiliate';
                window.accountsURL += '&affiliateProgramId=' + cookieUrlQueries.tap_program
            }
        }
        window.popupViews = {
            "#sign-in": {
                "url": window.accountsURL + "#/login?animate=false&response=url&redirectTo=" + returnUrl,
                "loginStatus": !1
            },
            "#sign-up": {
                "url": window.accountsURL + "#/registration?animate=false&response=url&redirectTo=" + returnUrl,
                "loginStatus": !1
            },
            "#add-site-with-package": {
                "url": "DYNAMIC_BUILDABLE",
                "loginStatus": !0
            },
            "#add-site-with-template": {
                "url": "DYNAMIC_BUILDABLE",
                "loginStatus": !0
            },
            "#generate-a-new-wl-project": {
                "url": "DYNAMIC_BUILDABLE",
                "loginStatus": !0
            },
            "#forgot-password": {
                "url": window.accountsURL + "#/forgot-password?animate=false",
                "loginStatus": !1
            },
            "#my-sites": {
                "url": window.accountsURL + "#/my-sites?animate=false"
            },
            "#get-started": {
                "url": window.accountsURL + "#/wizard?animate=false",
                "loginStatus": !0
            },
            "#profile": {
                "url": window.accountsURL + "#/my/profile?animate=false",
                "loginStatus": !0
            },
            "#billing": {
                "url": window.accountsURL + "#/my/billing/billing-details?animate=false",
                "loginStatus": !0
            },
            "#subscriptions": {
                "url": window.accountsURL + "#/my/subscriptions?animate=false",
                "loginStatus": !0
            }
        };
        if (window.location.hash.trim().length) {
            hash_change()
        }
    }
    $(document).on('click', '.accounts-logout', function(e) {
        e.preventDefault();
        logout()
    });

    function logout() {
        if (window.logoutFromAllDevices && document.querySelector('.sign-out-public-container')) {
            document.querySelector('.sign-out-public-container').classList.add('active')
        } else {
            signOut(0)
        }
    }

    function logOutFromAllDevices() {
        let signOurFromAll = 0,
            input = document.getElementById('sign-out-all-devices')
        if (input && input.checked) {
            signOurFromAll = 1
        }
        signOut(signOurFromAll);
        cancelSignOutConfPopUp()
    }

    function cancelSignOutConfPopUp() {
        document.querySelector('.sign-out-public-container').classList.remove('active')
    }

    function signOut(signOurFromAll) {
        $.ajax({
            type: "GET",
            url: `/${window.currentLanguageObject.prefix}/papi/default/ModuleUserProfile/logout?sign_out_from_all=${signOurFromAll}`,
            success: function(response) {
                $('.user-profile-menu').removeClass('logged-in');
                if ($('.user-profile-menu').find(".user-profile")) {
                    $('.user-profile-menu').find(".user-profile").remove()
                }
            },
            error: function(error) {
                error = JSON.parse(error)
            }
        })
    }

    function handleIframeLoaded() {
        if (localStorage.getItem('iframeUrl')) {
            iframe_popup_show();
            document.querySelector(".accounts-popup .loading-container").classList.add("show");
            document.querySelector('#accounts-iframe').setAttribute('src', localStorage.getItem('iframeUrl'));
            localStorage.removeItem('iframeUrl')
        }
    }

    function handleIubendaClick() {
        let frame = document.querySelector('#accounts-iframe');
        if (frame) {
            localStorage.setItem('iframeUrl', frame.getAttribute('src'))
        }
    }

    function changeIntercomeStyle(display) {
        let intercom = document.querySelector('#intercom-container');
        if (!intercom)
            intercom = document.querySelector('.intercom-lightweight-app');
        if (intercom)
            intercom.style.display = display;
        return !!(intercom)
    }

    function changeLayout(layout) {
        switch (layout.component) {
            case 'sign-up':
                if (layout.mobile) {
                    if (layout.init) {
                        let timeout = setInterval(() => {
                            if (changeIntercomeStyle('none'))
                                clearInterval(timeout)
                        }, 100)
                    } else changeIntercomeStyle('unset')
                }
                break
        }
    }

    function hash_change() {
        let iubenda = document.querySelector('.iubenda-cs-container');
        let iubendaClose = document.querySelector('.iubenda-cs-close-btn');
        if (iubenda && iubendaClose) {
            iubendaClose.removeEventListener('mousedown', handleIubendaClick, {
                once: !0
            });
            iubendaClose.addEventListener('mousedown', handleIubendaClick, {
                once: !0
            })
        }
        hash = window.location.hash.trim();
        var hashLink = hash.split('?')[0];
        if (window.popupViews && window.popupViews[hashLink]) {
            var hashParts = hash.split('?');
            var oldSrc = $('#accounts-iframe').attr('src');
            var newSrc = popupViews[hashParts[0]].url + (hashParts[1] ? "&" + hashParts[1] : "");
            if (hash.indexOf('#add-site-with-template') !== -1) {
                var templateIdAndType = hashParts[1].split('|');
                var alias = '';
                if (templateIdAndType[1] != '') {
                    alias = templateIdAndType[1]
                } else {
                    alias = 'free-website'
                }
                newSrc = window.accountsURL + "#/wizard/choose-site-name/" + templateIdAndType[0] + "/" + alias + "?animate=false"
            }
            if (hash.indexOf('#add-site-with-package') !== -1) {
                newSrc = window.accountsURL + "#/wizard/choose-template/" + hashParts[1] + "?animate=false"
            }
            if (hash.indexOf('#generate-a-new-wl-project') !== -1) {
                newSrc = `${window.accountsURL}#/purchase/plan/${hashParts[1]}?animate=false`
            }
            iframe_popup_show();
            $(".accounts-popup .loading-container").addClass("show");
            $('#accounts-iframe').attr('src', newSrc)
        }
    }

    function checkUserLogin() {
        return window.loginStatus == 1
    }

    function iframe_popup_show() {
        $(".accounts-popup").addClass("show");
        $("html, body").addClass('no-scroll')
    }

    function iframe_popup_close() {
        $(".accounts-popup").removeClass("show");
        window.location.hash = '/';
        $("html, body").removeClass('no-scroll')
    }

    function signIn() {
        window.location.hash = "#sign-in";
        hash_change()
    }
    $(window).on('hashchange', function(e) {
        hash_change(e)
    });
    $(document).keyup(function(e) {
        if (e.keyCode == 27) {
            if (jQuery(".accounts-popup").hasClass("show")) {
                iframe_popup_close()
            }
        }
    });
    $(document).on('keypress', function(e) {
        if (e.keyCode == 27) {
            iframe_popup_close()
        }
    });
    $(document).on("click", ".use-package", function(e) {
        e.preventDefault();
        var templateId = jQuery(this).attr('pricing-alias');
        var url = jQuery(this).attr('href');
        window.location.href = url + "?" + templateId
    });
    $(document).on("click", ".use-template", function(e) {
        e.preventDefault();
        var templateId = jQuery(this).attr('template-id');
        var templateType = jQuery(this).attr('template-type');
        var url = jQuery(this).attr('href');
        window.location.href = url + "?" + templateId + '|' + templateType
    });

    function getCookie(name) {
        var v = document.cookie.match('(^|;) ?' + name + '=([^;]*)(;|$)');
        return v ? v[2] : null
    }

    function setCookie(name, value, days) {
        var d = new Date;
        d.setTime(d.getTime() + 24 * 60 * 60 * 1000 * days);
        document.cookie = name + "=" + value + ";path=/;expires=" + d.toGMTString()
    }

    function deleteCookie(name) {
        setCookie(name, '', -1)
    }
}
(function($) {
    $.fn.jqueryUcSlider = function(options, publicMode, update) {
        var currentSlide, nextSlide, slideDuration, slideIndex, slideTimeOut;
        var currentSlideIndex = options.currentSlideId ? options.currentSlideId : 0;
        var autoPlay = options.autoPlay;
        var sliderType = options.slideType;
        var autoPlayDelay = options.autoPlayDelay;
        var autoPlayOnHover = options.autoPlayOnHover === "on";
        var slideItems = options.sliderItems || $(this).find("> .slider-container > .slider-container > .slider-item");
        var addTouchEvents = options.touchEvents;
        var contentHeight = options.contentHeight;
        var thatContainer = this;
        var isSliding = !1;
        var slider = $(this);
        var isInHoverState = !1;
        slideDuration = options.animationSpeed;
        slideItems.css('opacity', '1');
        if (!autoPlayOnHover) {
            var handlerIn = function() {
                isInHoverState = !0;
                if (autoPlay === "on") {
                    clearTimeout(slideTimeOut)
                }
            };
            var handlerOut = function() {
                isInHoverState = !1;
                if (autoPlay === "on") {
                    slideTimeOut = setTimeout(moveNext, autoPlayDelay)
                }
            };
            slider.hover(handlerIn, handlerOut)
        }
        if (publicMode === !0) {
            if (autoPlay === "on" && slideItems.length > 1) {
                slideTimeOut = setTimeout(moveNext, autoPlayDelay)
            }
        }
        if (update) {
            $(window).on("resize", function() {
                updateHeight(thatContainer)
            })
        }
        if (contentHeight == !0) {
            updateHeight(this)
        }

        function updateHeight(that) {
            var sliderHeight = 0;
            $(that).find(".slider-item").removeClass("display-none");
            $(that).find(".slider-container li").each(function() {
                var thisSliderHeight = $(this).find(".quote-item").height();
                if (sliderHeight < thisSliderHeight) {
                    sliderHeight = thisSliderHeight
                }
            });
            $(that).find(".slider-container").css({
                height: sliderHeight + "px"
            });
            $(that).find(".slider-item").addClass("display-none")
        }
        var pagination = options.paginationItems || $(this).find(">.slider-container > .slide-pagination").find(".slide-pointer");
        $(pagination).find("a").removeClass("active");
        $(pagination[currentSlideIndex]).find("a").addClass("active");
        $(pagination).unbind("click");
        $(this).find(".slider-left").unbind("click");
        slideItems.removeClass("active-slide next-slide");
        $(slideItems[currentSlideIndex]).addClass("active-slide");
        slideItems.css('transform', 'translate(0,0)');
        $(this).find(".slider-left").click(function(e) {
            e.preventDefault();
            if (!isSliding && slideItems.length > 1) {
                if (publicMode === !0 && autoPlay === "on") {
                    clearTimeout(slideTimeOut)
                }
                movePrev()
            }
        });
        $(this).find(".slider-right").unbind("click");
        $(this).find(".slider-right").click(function(e) {
            e.preventDefault();
            if (!isSliding && slideItems.length > 1) {
                if (publicMode === !0 && autoPlay === "on") {
                    clearTimeout(slideTimeOut)
                }
                moveNext()
            }
        });
        if (addTouchEvents === "on") {
            setupSwipeEvents()
        }
        $(pagination).click(function(e) {
            e.preventDefault();
            if (isSliding) {
                return
            }
            if ($(this).index() === currentSlideIndex) {
                return
            }
            if (publicMode === !0 && autoPlay === "on") {
                clearTimeout(slideTimeOut)
            }
            moveTo($(this).index())
        });

        function setupSwipeEvents() {
            var startX, dist, startTime, endTime;
            slider.on("touchstart", ".slider-container", function(event) {
                var touchObj = event.originalEvent.changedTouches[0];
                startX = touchObj.clientX;
                startTime = new Date().getTime();
                $(document).one("touchend", function(e) {
                    var touchObj = e.originalEvent.changedTouches[0];
                    dist = touchObj.clientX - startX;
                    endTime = new Date().getTime();
                    if (startTime - endTime < 500) {
                        touchMove(dist)
                    }
                })
            })
        }

        function touchMove(dist) {
            if (dist > 0 && dist >= 70) {
                movePrev()
            }
            if (dist < 0 && Math.abs(dist) >= 70) {
                moveNext()
            }
        }

        function updateForNextSlide() {
            if (publicMode === !0) {
                if (autoPlay === "on") {
                    clearTimeout(slideTimeOut);
                    if (!autoPlayOnHover || (autoPlayOnHover && !isInHoverState)) {
                        slideTimeOut = setTimeout(moveNext, autoPlayDelay)
                    }
                }
            }
            nextSlide.removeClass("next-slide").addClass("active-slide");
            if (currentSlide && currentSlide.find('.uc-animation').length) {
                window.animateEffects.addActiveClass()
            }
            currentSlide.removeClass("active-slide");
            isSliding = !1;
            $(pagination).find("a").removeClass("active");
            currentSlideIndex++;
            $(pagination.get(currentSlideIndex)).find("a").addClass("active")
        }

        function updateForPrevSlide() {
            if (publicMode === !0) {
                if (autoPlay === "on") {
                    clearTimeout(slideTimeOut);
                    if (!autoPlayOnHover || (autoPlayOnHover && !isInHoverState)) {
                        slideTimeOut = setTimeout(moveNext, autoPlayDelay)
                    }
                }
            }
            nextSlide.removeClass("next-slide").addClass("active-slide");
            currentSlide.removeClass("active-slide");
            isSliding = !1;
            $(pagination).find("a").removeClass("active");
            currentSlideIndex--;
            $(pagination.get(currentSlideIndex)).find("a").addClass("active")
        }

        function updateForAnimate() {
            if (publicMode === !0) {
                if (autoPlay === "on") {
                    clearTimeout(slideTimeOut);
                    slideTimeOut = setTimeout(moveNext, autoPlayDelay)
                }
            }
            slideItems.removeClass("active-slide next-slide");
            slideItems.css('transform', 'translate(0,0)');
            $(pagination).find("a").removeClass("active");
            $(pagination.get(slideIndex)).find("a").addClass("active");
            currentSlide.removeClass("active-slide");
            nextSlide.removeClass("next-slide").addClass("active-slide");
            isSliding = !1;
            currentSlideIndex = slideIndex
        }

        function animateForward(slide1, slide2) {
            if (sliderType === "horizontal") {
                anime({
                    targets: slide1.get(0),
                    translateX: '-100%',
                    duration: slideDuration * 1000,
                    easing: 'easeInOutCubic'
                });
                anime.set(slide2.get(0), {
                    translateX: '100%',
                });
                anime({
                    targets: slide2.get(0),
                    translateX: 0,
                    duration: slideDuration * 1000,
                    easing: 'easeInOutCubic',
                    complete: updateForAnimate
                })
            } else {
                if (sliderType === "vertical") {
                    anime({
                        targets: slide1.get(0),
                        translateY: '-100%',
                        duration: slideDuration * 1000,
                        easing: 'easeInOutCubic'
                    });
                    anime.set(slide2.get(0), {
                        translateY: '100%',
                    });
                    anime({
                        targets: slide2.get(0),
                        translateY: 0,
                        duration: slideDuration * 1000,
                        easing: 'easeInOutCubic',
                        complete: updateForAnimate
                    })
                } else {
                    if (sliderType === "fade") {
                        anime({
                            targets: slide1.get(0),
                            opacity: 0,
                            duration: slideDuration * 1000,
                            easing: 'linear'
                        });
                        anime.set(slide2.get(0), {
                            opacity: 0,
                        });
                        anime({
                            targets: slide2.get(0),
                            opacity: 1,
                            duration: slideDuration * 1000,
                            easing: 'easeInOutCubic',
                            complete: updateForAnimate
                        })
                    }
                }
            }
        }

        function animateBack(slide1, slide2) {
            if (sliderType === "horizontal") {
                anime({
                    targets: slide1.get(0),
                    translateX: '100%',
                    duration: slideDuration * 1000,
                    easing: 'easeInOutCubic'
                });
                anime.set(slide2.get(0), {
                    translateX: '-100%',
                });
                anime({
                    targets: slide2.get(0),
                    translateX: 0,
                    duration: slideDuration * 1000,
                    easing: 'easeInOutCubic',
                    complete: updateForAnimate
                })
            } else {
                if (sliderType === "vertical") {
                    anime({
                        targets: slide1.get(0),
                        translateY: '100%',
                        duration: slideDuration * 1000,
                        easing: 'easeInOutCubic'
                    });
                    anime.set(slide2.get(0), {
                        translateY: '-100%',
                    });
                    anime({
                        targets: slide2.get(0),
                        translateY: 0,
                        duration: slideDuration * 1000,
                        easing: 'easeInOutCubic',
                        complete: updateForAnimate
                    })
                } else {
                    if (sliderType === "fade") {
                        anime({
                            targets: slide1.get(0),
                            opacity: 0,
                            duration: slideDuration * 1000,
                            easing: 'linear'
                        });
                        anime.set(slide2.get(0), {
                            opacity: 0,
                        });
                        anime({
                            targets: slide2.get(0),
                            opacity: 1,
                            duration: slideDuration * 1000,
                            easing: 'easeInOutCubic',
                            complete: updateForAnimate
                        })
                    }
                }
            }
        }

        function moveNext() {
            if (isSliding) {
                return
            }
            currentSlide = $(slideItems.get(currentSlideIndex));
            isSliding = !0;
            if (currentSlideIndex === slideItems.length - 1) {
                nextSlide = $(slideItems.get(0));
                currentSlideIndex = -1
            } else {
                nextSlide = currentSlide.next()
            }
            nextSlide.addClass("next-slide");
            currentSlide.addClass("active-slide");
            if (sliderType === "horizontal") {
                anime({
                    targets: currentSlide.get(0),
                    translateX: '-100%',
                    duration: slideDuration * 1000,
                    easing: 'easeInOutCubic'
                });
                anime.set(nextSlide.get(0), {
                    translateX: '100%',
                });
                anime({
                    targets: nextSlide.get(0),
                    translateX: 0,
                    duration: slideDuration * 1000,
                    easing: 'easeInOutCubic',
                    complete: updateForNextSlide
                })
            } else {
                if (sliderType === "vertical") {
                    anime({
                        targets: currentSlide.get(0),
                        translateY: '-100%',
                        duration: slideDuration * 1000,
                        easing: 'easeInOutCubic'
                    });
                    anime.set(nextSlide.get(0), {
                        translateY: '100%',
                    });
                    anime({
                        targets: nextSlide.get(0),
                        translateY: 0,
                        duration: slideDuration * 1000,
                        easing: 'easeInOutCubic',
                        complete: updateForNextSlide
                    })
                } else {
                    if (sliderType === "fade") {
                        anime({
                            targets: currentSlide.get(0),
                            opacity: '0',
                            duration: slideDuration * 1000,
                            easing: 'linear'
                        });
                        anime.set(nextSlide.get(0), {
                            opacity: '0',
                        });
                        anime({
                            targets: nextSlide.get(0),
                            opacity: 1,
                            duration: slideDuration * 1000,
                            easing: 'linear',
                            complete: updateForNextSlide
                        })
                    }
                }
            }
        }

        function movePrev() {
            if (isSliding) {
                return
            }
            currentSlide = $(slideItems.get(currentSlideIndex));
            isSliding = !0;
            if (currentSlideIndex === 0) {
                var lastSlideIndex = slideItems.length - 1;
                nextSlide = $(slideItems.get(lastSlideIndex));
                currentSlideIndex = slideItems.length
            } else {
                nextSlide = $(slideItems.get(currentSlideIndex - 1))
            }
            nextSlide.addClass("next-slide");
            currentSlide.addClass("active-slide");
            if (sliderType === "horizontal") {
                anime({
                    targets: currentSlide.get(0),
                    translateX: '100%',
                    duration: slideDuration * 1000,
                    easing: 'easeInOutCubic'
                });
                anime.set(nextSlide.get(0), {
                    translateX: '-100%',
                });
                anime({
                    targets: nextSlide.get(0),
                    translateX: 0,
                    duration: slideDuration * 1000,
                    easing: 'easeInOutCubic',
                    complete: updateForPrevSlide
                })
            } else {
                if (sliderType === "vertical") {
                    anime({
                        targets: currentSlide.get(0),
                        translateY: '100%',
                        duration: slideDuration * 1000,
                        easing: 'easeInOutCubic'
                    });
                    anime.set(nextSlide.get(0), {
                        translateY: '-100%',
                    });
                    anime({
                        targets: nextSlide.get(0),
                        translateY: 0,
                        duration: slideDuration * 1000,
                        easing: 'easeInOutCubic',
                        complete: updateForPrevSlide
                    })
                } else {
                    if (sliderType === "fade") {
                        anime({
                            targets: currentSlide.get(0),
                            opacity: '0',
                            duration: slideDuration * 1000,
                            easing: 'linear'
                        });
                        anime.set(nextSlide.get(0), {
                            opacity: '0',
                        });
                        anime({
                            targets: nextSlide.get(0),
                            opacity: 1,
                            duration: slideDuration * 1000,
                            easing: 'linear',
                            complete: updateForPrevSlide
                        })
                    }
                }
            }
        }

        function moveTo(index) {
            if (isSliding) {
                return
            }
            isSliding = !0;
            slideIndex = index;
            currentSlide = $(slideItems.get(currentSlideIndex));
            nextSlide = $(slideItems.get(index));
            currentSlide.addClass("active-slide");
            nextSlide.addClass("next-slide");
            if (index < currentSlideIndex) {
                animateBack(currentSlide, nextSlide)
            } else {
                if (index > currentSlideIndex) {
                    animateForward(currentSlide, nextSlide)
                }
            }
        }
        return {
            clearDelays: function() {
                if (publicMode === !0) {
                    clearTimeout(slideTimeOut)
                }
            }
        }
    }
})(jQuery)

function Api() {}
Api.prototype.call = function(component, type, action, data, callback) {
    var url = baseUrl + '/' + apiPrefix + '/' + component + '/' + type + '/' + action;
    ucRequest(url, data, callback)
};
Api.prototype.publicCall = function(component, type, action, data, callback, method) {
    if (currentLanguageObject.default === 0 && currentLanguageObject.prefix) {
        baseUrlModified = baseUrl + '/' + currentLanguageObject.prefix
    } else {
        baseUrlModified = baseUrl
    }
    var url = baseUrlModified + '/' + publicApiPrefix + '/' + component + '/' + type + '/' + action;
    var sendMethod = 'POST';
    if (typeof method !== 'undefined') {
        sendMethod = method
    }
    ucRequest(url, data, callback, sendMethod)
};
Api.prototype.maintenanceCall = function(action, data, callback) {
    var url = baseUrl + '/' + maintenancePrefix + '/' + action;
    ucRequest(url, data, callback, 'GET')
};
Api.prototype.login = function(data, callback) {
    $('a.btn.login').addClass('loading');
    if (typeof callback === "undefined") {
        callback = function(data) {
            var message = '';
            for (var i in data.msg) {
                message += data.msg[i] + "\n"
            }
            if (data.type == 1) {
                var returnUrl = $('form.login input[name="_returnUrl"]')
                if (returnUrl.length > 0) {
                    window.location = returnUrl.val()
                } else {
                    window.location = baseUrl
                }
            } else {
                $('a.btn.login').removeClass('loading')
            }
        }
    }
    this.publicCall('default', 'admin', 'login', data, callback)
};
Api.prototype.logout = function(data, callback) {
    $('a.btn.logout').addClass('loading');
    if (typeof callback === "undefined") {
        callback = function(data) {
            var message = '';
            for (var i in data.msg) {
                message += data.msg[i] + "\n"
            }
            if (data.type == 1) {
                if ($('form.logout input[name="_returnUrl"]').length > 0 && $('form.logout input[name="_returnUrl"]').val() != '') {
                    window.location = $('form.logout input[name="_returnUrl"]').val()
                } else {
                    window.location = baseUrl
                }
            } else {
                $('a.btn.logout').removeClass('loading')
            }
        }
    }
    this.call('default', 'admin', 'logout', data, callback)
};
Api.prototype.sendForm = function(data, callback) {
    this.publicCall('default', 'ModuleForm', 'send', data, callback)
};
Api.prototype.viewPage = function(data, callback) {
    this.publicCall('default', 'ModulePasswordProtectionHidden', 'viewPage', data, callback)
};
Api.prototype.downloadPage = function(data, callback) {
    this.publicCall('default', 'ModuleSave', 'downloadPage', data, callback)
};
api = new Api();
(function($) {
    $.fn.serializeFormJSON = function() {
        var o = {};
        var a = this.serializeArray();
        $.each(a, function() {
            if (o[this.name]) {
                if (!o[this.name].push) {
                    o[this.name] = [o[this.name]]
                }
                o[this.name].push(this.value || '')
            } else {
                o[this.name] = this.value || ''
            }
        });
        return o
    }
})(jQuery);
var moduleController;
var marginController;
var confirmData = [];
confirmData.container = 'body';
confirmData.addClass = 'default';
confirmData.buttons = [];
confirmData.buttons.confirm = [];
confirmData.buttons.confirm.label = 'Yes';
confirmData.buttons.discard = [];
confirmData.buttons.discard.label = 'No';
confirmData.buttons.discard['function'] = function() {
    $('.confirm-layer-container').removeClass('active');
    anime({
        targets: '.confirm-layer-container',
        opacity: 0,
        duration: 300,
        easing: 'linear'
    })
};
var confirmObj;

function confirmPopup(data) {
    var container = '';
    var confirmHtml = '<div class="confirm-layer-container admin">' + '<div class="confirm-layer">' + '<div class="confirm-container">' + '<div class="confirm-message">' + '</div>' + '<div class="confirm-buttons">' + '<a class="btn-conf btn2 btn-discard"></a>' + '<a class="btn-conf btn1 btn-confirm"></a>' + '</div>' + '</div>' + '</div>' + '</div>';
    confirmObj = $(confirmHtml);
    if ($(data.container).length > 0) {
        var container = $(data.container)
    }
    if (data.buttons) {
        confirmObj.find('.confirm-buttons').removeClass('invisible');
        if (data.buttons.confirm) {
            confirmObj.find('.btn-confirm').unbind("click");
            confirmObj.find('.btn-confirm').removeClass('invisible');
            confirmObj.find('.btn-confirm').html(data.buttons.confirm.label);
            confirmObj.find('.btn-confirm').click(function(e) {
                e.preventDefault();
                e.stopPropagation();
                data.buttons.confirm['function'](data.buttons.confirm.params);
                closeConfirmPopup()
            })
        } else {
            confirmObj.find('.btn-confirm').addClass('invisible')
        }
        if (data.buttons.discard) {
            confirmObj.find('.btn-discard').removeClass('invisible');
            confirmObj.find('.btn-discard').unbind("click");
            confirmObj.find('.btn-discard').html(data.buttons.discard.label);
            confirmObj.find('.btn-discard').click(function(e) {
                e.preventDefault();
                e.stopPropagation();
                data.buttons.discard['function'](data.buttons.discard.params);
                closeConfirmPopup()
            })
        } else {
            confirmObj.find('.btn-discard').addClass('invisible')
        }
    } else {
        confirmObj.find('.confirm-buttons').addClass('invisible')
    }
    if (data.addClass) {
        confirmObj.attr('data-custom-class', data.addClass);
        confirmObj.addClass(data.addClass)
    } else {
        confirmObj.removeClass(confirmObj.attr('data-custom-class'));
        confirmObj.removeAttr('data-custom-class')
    }
    confirmObj.find('.confirm-message').html(data.message);
    $(container).append(confirmObj);
    confirmObj.addClass('active');
    anime({
        targets: confirmObj.get(0),
        opacity: 1,
        duration: 300,
        easing: 'linear'
    })
}

function closeConfirmPopup(data) {
    confirmObj.removeClass('active');
    anime({
        targets: confirmObj.get(0),
        opacity: 0,
        duration: 300,
        easing: 'linear',
        complete: function() {
            jQuery('.confirm-layer-container').remove()
        }
    })
}

function capitalizeFirstLetter(data) {
    return data.charAt(0).toUpperCase() + data.slice(1)
}

function ucRequest(url, data, callback, method) {
    if (window.previewMode) {
        if (url.indexOf('?') === -1) {
            url += '?previewMode=true'
        } else {
            url += '&previewMode=true'
        }
    }
    if (typeof method === 'undefined') {
        method = 'POST'
    }
    if (typeof callback === "undefined") {
        callback = function(data) {
            var message = '';
            for (var i in data.msg) {
                message += data.msg[i] + "\n"
            }
            console.log(message)
        }
    }
    var sendData = Object();
    sendData.data = data;
    if (typeof _token !== "undefined")
        sendData._token = _token;
    $.ajax({
        type: method,
        url: url,
        data: sendData,
        success: function(response) {
            if (response.type == -2) {
                window.location = 'https://www.ucraft.com'
            } else if (response.type == -1) {
                confirmData.message = '';
                delete confirmData.buttons.discard;
                confirmData.buttons.confirm.label = 'Ok';
                for (var i in response.msg) {
                    if (i != 'global') {
                        confirmData.message += capitalizeFirstLetter(i) + ': ' + response.msg[i] + '<br/>'
                    } else {
                        confirmData.message += response.msg[i] + '<br/>'
                    }
                }
                confirmData.buttons.confirm['function'] = function() {
                    $('.confirm-layer-container').removeClass('active');
                    anime({
                        targets: '.confirm-layer-container',
                        opacity: 0,
                        duration: 300,
                        easing: 'linear',
                        complete: function() {
                            jQuery('.confirm-layer-container').remove();
                            callback(response)
                        }
                    })
                };
                confirmPopup(confirmData)
            } else {
                callback(response)
            }
        },
        error: function(xhr, status, error) {
            if (!xhr.getAllResponseHeaders()) {
                return !0
            }
            var message = 'Internal Server Error.<br> Please, refresh the page to restore the syncronization with server.';
            if (xhr.status === 429) {
                message = error || 'Too Many Requests'
            }
            if (xhr.responseJSON && xhr.responseJSON.message) {
                message = xhr.responseJSON.message;
                if (xhr.responseJSON.subMessage) {
                    message += '<br>' + xhr.responseJSON.subMessage
                }
            }
            var response = {
                type: -1,
                msg: {
                    global: message
                },
                status: 500
            };
            confirmData.message = '';
            confirmData.buttons.confirm.label = 'Refresh now';
            confirmData.buttons.discard = [];
            confirmData.buttons.discard.label = 'Ok';
            for (var i in response.msg) {
                if (i != 'global') {
                    confirmData.message += capitalizeFirstLetter(i) + ': ' + response.msg[i] + '<br/>'
                } else {
                    confirmData.message += response.msg[i] + '<br/>'
                }
            }
            confirmData.buttons.discard['function'] = function() {
                $('.confirm-layer-container').removeClass('active');
                anime({
                    targets: '.confirm-layer-container',
                    opacity: 0,
                    duration: 300,
                    easing: 'linear',
                    complete: function() {
                        jQuery('.confirm-layer-container').remove();
                        callback(response)
                    }
                })
            };
            confirmData.buttons.confirm['function'] = function() {
                $('.confirm-layer-container').removeClass('active');
                anime({
                    targets: '.confirm-layer-container',
                    opacity: 0,
                    duration: 300,
                    easing: 'linear',
                    complete: function() {
                        jQuery('.confirm-layer-container').remove();
                        callback(response);
                        window.location.reload()
                    }
                })
            };
            console.error(confirmData.message)
        },
        dataType: 'json'
    })
}
window.animateEffects = {
    effectsDone: !1,
    effectStartThreshold: 50,
    elementTop: {},
    lazyTimer: 400,
    addActiveClass: function() {
        var _self = this;
        var animateBoxes = $(".uc-animation:not(.active)");
        animateBoxes.each(function() {
            var effectBoxNode = $(this).parent();
            if (!effectBoxNode.length) {
                effectBoxNode = $(this)
            }
            var effectBoxTop = effectBoxNode.offset().top;
            var effectStartPosition = effectBoxTop + _self.effectStartThreshold;
            var scrollClientPos = $(document).scrollTop() + $(window).height();
            if (scrollClientPos >= effectStartPosition) {
                var element = this,
                    rows = element.closest(".main-rows");
                if (!rows) {
                    rows = element.closest(".header-rows") ? element.closest(".header-rows") : element.closest(".footer-rows")
                }
                if (rows) {
                    rows.querySelectorAll(".uc-row.uc-animation.staticParallax.active").forEach(content => {
                        if (content && !content.querySelector('.affix'))
                            content.classList.remove("active")
                    })
                }
                element.classList.add("active");
                if (!element.classList.contains('affix')) {
                    element.parentElement.classList.add("no-scroll");
                    setTimeout(function() {
                        element.parentElement.classList.remove("no-scroll")
                    }, 300)
                }
            }
        });
        if (!animateBoxes.length) {
            window.removeEventListener('scroll', window.animateEffects.scrollFunction, !0)
        }
        window.animateEffects.effectsDone = !0
    },
    effects: function() {
        if (window.animateEffects.lazyTimer) {
            setTimeout(function() {
                if (!window.animateEffects.effectsDone) {
                    window.animateEffects.addActiveClass()
                }
            }, window.animateEffects.lazyTimer)
        } else {
            if (!window.animateEffects.effectsDone) {
                window.animateEffects.addActiveClass()
            }
        }
        window.addEventListener('scroll', window.animateEffects.scrollFunction = function() {
            window.animateEffects.addActiveClass()
        }, !0)
    },
};
$(document).ready(function() {
    window.animateEffects.effects()
});
window.addEventListener("load", function() {
    var headerFixedRows = document.querySelectorAll('.header-rows .header-row-fix');
    var fixHeaderHeight = 0;
    headerFixedRows.forEach(function(fixRow) {
        var fixRowWrapper = fixRow.closest('.header-row-wrapper');
        fixHeaderHeight += fixRowWrapper.offsetHeight
    });
    var affixColumns = document.querySelectorAll('.affix-column');
    for (var i = 0; i < affixColumns.length; i++) {
        var affixColumn = affixColumns[i];
        if (headerFixedRows.length && affixColumn) {
            var affixTopDistance = affixColumn.style.top ? parseInt(affixColumn.style.top) + fixHeaderHeight : fixHeaderHeight;
            affixColumn.style.top = `${affixTopDistance}px`
        }
    }
}) ! function(a) {
    "use strict";
    "function" == typeof define && define.amd ? define(["jquery"], a) : "undefined" != typeof exports ? module.exports = a(require("jquery")) : a(jQuery)
}(function(a) {
    "use strict";
    var b = window.Slick || {};
    b = function() {
        function c(c, d) {
            var f, e = this;
            e.defaults = {
                accessibility: !0,
                adaptiveHeight: !1,
                appendArrows: a(c),
                appendDots: a(c),
                arrows: !0,
                asNavFor: null,
                prevArrow: '<button type="button" data-role="none" class="slick-prev" aria-label="Previous" tabindex="0" role="button">Previous</button>',
                nextArrow: '<button type="button" data-role="none" class="slick-next" aria-label="Next" tabindex="0" role="button">Next</button>',
                autoplay: !1,
                autoplaySpeed: 3e3,
                centerMode: !1,
                centerPadding: "50px",
                cssEase: "ease",
                customPaging: function(b, c) {
                    return a('<button type="button" data-role="none" role="button" tabindex="0" />').text(c + 1)
                },
                dots: !1,
                dotsClass: "slick-dots",
                draggable: !0,
                easing: "linear",
                edgeFriction: .35,
                fade: !1,
                focusOnSelect: !1,
                infinite: !0,
                initialSlide: 0,
                lazyLoad: "ondemand",
                mobileFirst: !1,
                pauseOnHover: !0,
                pauseOnFocus: !0,
                pauseOnDotsHover: !1,
                respondTo: "window",
                responsive: null,
                rows: 1,
                rtl: !1,
                slide: "",
                slidesPerRow: 1,
                slidesToShow: 1,
                slidesToScroll: 1,
                speed: 500,
                swipe: !0,
                swipeToSlide: !1,
                touchMove: !0,
                touchThreshold: 5,
                useCSS: !0,
                useTransform: !0,
                variableWidth: !1,
                vertical: !1,
                verticalSwiping: !1,
                waitForAnimate: !0,
                zIndex: 1e3
            }, e.initials = {
                animating: !1,
                dragging: !1,
                autoPlayTimer: null,
                currentDirection: 0,
                currentLeft: null,
                currentSlide: 0,
                direction: 1,
                $dots: null,
                listWidth: null,
                listHeight: null,
                loadIndex: 0,
                $nextArrow: null,
                $prevArrow: null,
                slideCount: null,
                slideWidth: null,
                $slideTrack: null,
                $slides: null,
                sliding: !1,
                slideOffset: 0,
                swipeLeft: null,
                $list: null,
                touchObject: {},
                transformsEnabled: !1,
                unslicked: !1
            }, a.extend(e, e.initials), e.activeBreakpoint = null, e.animType = null, e.animProp = null, e.breakpoints = [], e.breakpointSettings = [], e.cssTransitions = !1, e.focussed = !1, e.interrupted = !1, e.hidden = "hidden", e.paused = !0, e.positionProp = null, e.respondTo = null, e.rowCount = 1, e.shouldClick = !0, e.$slider = a(c), e.$slidesCache = null, e.transformType = null, e.transitionType = null, e.visibilityChange = "visibilitychange", e.windowWidth = 0, e.windowTimer = null, f = a(c).data("slick") || {}, e.options = a.extend({}, e.defaults, d, f), e.currentSlide = e.options.initialSlide, e.originalSettings = e.options, "undefined" != typeof document.mozHidden ? (e.hidden = "mozHidden", e.visibilityChange = "mozvisibilitychange") : "undefined" != typeof document.webkitHidden && (e.hidden = "webkitHidden", e.visibilityChange = "webkitvisibilitychange"), e.autoPlay = a.proxy(e.autoPlay, e), e.autoPlayClear = a.proxy(e.autoPlayClear, e), e.autoPlayIterator = a.proxy(e.autoPlayIterator, e), e.changeSlide = a.proxy(e.changeSlide, e), e.clickHandler = a.proxy(e.clickHandler, e), e.selectHandler = a.proxy(e.selectHandler, e), e.setPosition = a.proxy(e.setPosition, e), e.swipeHandler = a.proxy(e.swipeHandler, e), e.dragHandler = a.proxy(e.dragHandler, e), e.keyHandler = a.proxy(e.keyHandler, e), e.instanceUid = b++, e.htmlExpr = /^(?:\s*(<[\w\W]+>)[^>]*)$/, e.registerBreakpoints(), e.init(!0)
        }
        var b = 0;
        return c
    }(), b.prototype.activateADA = function() {
        var a = this;
        a.$slideTrack.find(".slick-active").attr({
            "aria-hidden": "false"
        }).find("a, input, button, select").attr({
            tabindex: "0"
        })
    }, b.prototype.addSlide = b.prototype.slickAdd = function(b, c, d) {
        var e = this;
        if ("boolean" == typeof c) d = c, c = null;
        else if (0 > c || c >= e.slideCount) return !1;
        e.unload(), "number" == typeof c ? 0 === c && 0 === e.$slides.length ? a(b).appendTo(e.$slideTrack) : d ? a(b).insertBefore(e.$slides.eq(c)) : a(b).insertAfter(e.$slides.eq(c)) : d === !0 ? a(b).prependTo(e.$slideTrack) : a(b).appendTo(e.$slideTrack), e.$slides = e.$slideTrack.children(this.options.slide), e.$slideTrack.children(this.options.slide).detach(), e.$slideTrack.append(e.$slides), e.$slides.each(function(b, c) {
            a(c).attr("data-slick-index", b)
        }), e.$slidesCache = e.$slides, e.reinit()
    }, b.prototype.animateHeight = function() {
        var a = this;
        if (1 === a.options.slidesToShow && a.options.adaptiveHeight === !0 && a.options.vertical === !1) {
            var b = a.$slides.eq(a.currentSlide).outerHeight(!0);
            a.$list.animate({
                height: b
            }, a.options.speed)
        }
    }, b.prototype.animateSlide = function(b, c) {
        var d = {},
            e = this;
        e.animateHeight(), e.options.rtl === !0 && e.options.vertical === !1 && (b = -b), e.transformsEnabled === !1 ? e.options.vertical === !1 ? e.$slideTrack.animate({
            left: b
        }, e.options.speed, e.options.easing, c) : e.$slideTrack.animate({
            top: b
        }, e.options.speed, e.options.easing, c) : e.cssTransitions === !1 ? (e.options.rtl === !0 && (e.currentLeft = -e.currentLeft), a({
            animStart: e.currentLeft
        }).animate({
            animStart: b
        }, {
            duration: e.options.speed,
            easing: e.options.easing,
            step: function(a) {
                a = Math.ceil(a), e.options.vertical === !1 ? (d[e.animType] = "translate(" + a + "px, 0px)", e.$slideTrack.css(d)) : (d[e.animType] = "translate(0px," + a + "px)", e.$slideTrack.css(d))
            },
            complete: function() {
                c && c.call()
            }
        })) : (e.applyTransition(), b = Math.ceil(b), e.options.vertical === !1 ? d[e.animType] = "translate3d(" + b + "px, 0px, 0px)" : d[e.animType] = "translate3d(0px," + b + "px, 0px)", e.$slideTrack.css(d), c && setTimeout(function() {
            e.disableTransition(), c.call()
        }, e.options.speed))
    }, b.prototype.getNavTarget = function() {
        var b = this,
            c = b.options.asNavFor;
        return c && null !== c && (c = a(c).not(b.$slider)), c
    }, b.prototype.asNavFor = function(b) {
        var c = this,
            d = c.getNavTarget();
        null !== d && "object" == typeof d && d.each(function() {
            var c = a(this).slick("getSlick");
            c.unslicked || c.slideHandler(b, !0)
        })
    }, b.prototype.applyTransition = function(a) {
        var b = this,
            c = {};
        b.options.fade === !1 ? c[b.transitionType] = b.transformType + " " + b.options.speed + "ms " + b.options.cssEase : c[b.transitionType] = "opacity " + b.options.speed + "ms " + b.options.cssEase, b.options.fade === !1 ? b.$slideTrack.css(c) : b.$slides.eq(a).css(c)
    }, b.prototype.autoPlay = function() {
        var a = this;
        a.autoPlayClear(), a.slideCount > a.options.slidesToShow && (a.autoPlayTimer = setInterval(a.autoPlayIterator, a.options.autoplaySpeed))
    }, b.prototype.autoPlayClear = function() {
        var a = this;
        a.autoPlayTimer && clearInterval(a.autoPlayTimer)
    }, b.prototype.autoPlayIterator = function() {
        var a = this,
            b = a.currentSlide + a.options.slidesToScroll;
        a.paused || a.interrupted || a.focussed || (a.options.infinite === !1 && (1 === a.direction && a.currentSlide + 1 === a.slideCount - 1 ? a.direction = 0 : 0 === a.direction && (b = a.currentSlide - a.options.slidesToScroll, a.currentSlide - 1 === 0 && (a.direction = 1))), a.slideHandler(b))
    }, b.prototype.buildArrows = function() {
        var b = this;
        b.options.arrows === !0 && (b.$prevArrow = a(b.options.prevArrow).addClass("slick-arrow"), b.$nextArrow = a(b.options.nextArrow).addClass("slick-arrow"), b.slideCount > b.options.slidesToShow ? (b.$prevArrow.removeClass("slick-hidden").removeAttr("aria-hidden tabindex"), b.$nextArrow.removeClass("slick-hidden").removeAttr("aria-hidden tabindex"), b.htmlExpr.test(b.options.prevArrow) && b.$prevArrow.prependTo(b.options.appendArrows), b.htmlExpr.test(b.options.nextArrow) && b.$nextArrow.appendTo(b.options.appendArrows), b.options.infinite !== !0 && b.$prevArrow.addClass("slick-disabled").attr("aria-disabled", "true")) : b.$prevArrow.add(b.$nextArrow).addClass("slick-hidden").attr({
            "aria-disabled": "true",
            tabindex: "-1"
        }))
    }, b.prototype.buildDots = function() {
        var c, d, b = this;
        if (b.options.dots === !0 && b.slideCount > b.options.slidesToShow) {
            for (b.$slider.addClass("slick-dotted"), d = a("<ul />").addClass(b.options.dotsClass), c = 0; c <= b.getDotCount(); c += 1) d.append(a("<li />").append(b.options.customPaging.call(this, b, c)));
            b.$dots = d.appendTo(b.options.appendDots), b.$dots.find("li").first().addClass("slick-active").attr("aria-hidden", "false")
        }
    }, b.prototype.buildOut = function() {
        var b = this;
        b.$slides = b.$slider.children(b.options.slide + ":not(.slick-cloned)").addClass("slick-slide"), b.slideCount = b.$slides.length, b.$slides.each(function(b, c) {
            a(c).attr("data-slick-index", b).data("originalStyling", a(c).attr("style") || "")
        }), b.$slider.addClass("slick-slider"), b.$slideTrack = 0 === b.slideCount ? a('<div class="slick-track"/>').appendTo(b.$slider) : b.$slides.wrapAll('<div class="slick-track"/>').parent(), b.$list = b.$slideTrack.wrap('<div aria-live="polite" class="slick-list"/>').parent(), b.$slideTrack.css("opacity", 0), (b.options.centerMode === !0 || b.options.swipeToSlide === !0) && (b.options.slidesToScroll = 1), a("img[data-lazy]", b.$slider).not("[src]").addClass("slick-loading"), b.setupInfinite(), b.buildArrows(), b.buildDots(), b.updateDots(), b.setSlideClasses("number" == typeof b.currentSlide ? b.currentSlide : 0), b.options.draggable === !0 && b.$list.addClass("draggable")
    }, b.prototype.buildRows = function() {
        var b, c, d, e, f, g, h, a = this;
        if (e = document.createDocumentFragment(), g = a.$slider.children(), a.options.rows > 1) {
            for (h = a.options.slidesPerRow * a.options.rows, f = Math.ceil(g.length / h), b = 0; f > b; b++) {
                var i = document.createElement("div");
                for (c = 0; c < a.options.rows; c++) {
                    var j = document.createElement("div");
                    for (d = 0; d < a.options.slidesPerRow; d++) {
                        var k = b * h + (c * a.options.slidesPerRow + d);
                        g.get(k) && j.appendChild(g.get(k))
                    }
                    i.appendChild(j)
                }
                e.appendChild(i)
            }
            a.$slider.empty().append(e), a.$slider.children().children().children().css({
                width: 100 / a.options.slidesPerRow + "%",
                display: "inline-block"
            })
        }
    }, b.prototype.checkResponsive = function(b, c) {
        var e, f, g, d = this,
            h = !1,
            i = d.$slider.width(),
            j = window.innerWidth || a(window).width();
        if ("window" === d.respondTo ? g = j : "slider" === d.respondTo ? g = i : "min" === d.respondTo && (g = Math.min(j, i)), d.options.responsive && d.options.responsive.length && null !== d.options.responsive) {
            f = null;
            for (e in d.breakpoints) d.breakpoints.hasOwnProperty(e) && (d.originalSettings.mobileFirst === !1 ? g < d.breakpoints[e] && (f = d.breakpoints[e]) : g > d.breakpoints[e] && (f = d.breakpoints[e]));
            null !== f ? null !== d.activeBreakpoint ? (f !== d.activeBreakpoint || c) && (d.activeBreakpoint = f, "unslick" === d.breakpointSettings[f] ? d.unslick(f) : (d.options = a.extend({}, d.originalSettings, d.breakpointSettings[f]), b === !0 && (d.currentSlide = d.options.initialSlide), d.refresh(b)), h = f) : (d.activeBreakpoint = f, "unslick" === d.breakpointSettings[f] ? d.unslick(f) : (d.options = a.extend({}, d.originalSettings, d.breakpointSettings[f]), b === !0 && (d.currentSlide = d.options.initialSlide), d.refresh(b)), h = f) : null !== d.activeBreakpoint && (d.activeBreakpoint = null, d.options = d.originalSettings, b === !0 && (d.currentSlide = d.options.initialSlide), d.refresh(b), h = f), b || h === !1 || d.$slider.trigger("breakpoint", [d, h])
        }
    }, b.prototype.changeSlide = function(b, c) {
        var f, g, h, d = this,
            e = a(b.currentTarget);
        switch (e.is("a") && b.preventDefault(), e.is("li") || (e = e.closest("li")), h = d.slideCount % d.options.slidesToScroll !== 0, f = h ? 0 : (d.slideCount - d.currentSlide) % d.options.slidesToScroll, b.data.message) {
            case "previous":
                g = 0 === f ? d.options.slidesToScroll : d.options.slidesToShow - f, d.slideCount > d.options.slidesToShow && d.slideHandler(d.currentSlide - g, !1, c);
                break;
            case "next":
                g = 0 === f ? d.options.slidesToScroll : f, d.slideCount > d.options.slidesToShow && d.slideHandler(d.currentSlide + g, !1, c);
                break;
            case "index":
                var i = 0 === b.data.index ? 0 : b.data.index || e.index() * d.options.slidesToScroll;
                d.slideHandler(d.checkNavigable(i), !1, c), e.children().trigger("focus");
                break;
            default:
                return
        }
    }, b.prototype.checkNavigable = function(a) {
        var c, d, b = this;
        if (c = b.getNavigableIndexes(), d = 0, a > c[c.length - 1]) a = c[c.length - 1];
        else
            for (var e in c) {
                if (a < c[e]) {
                    a = d;
                    break
                }
                d = c[e]
            }
        return a
    }, b.prototype.cleanUpEvents = function() {
        var b = this;
        b.options.dots && null !== b.$dots && a("li", b.$dots).off("click.slick", b.changeSlide).off("mouseenter.slick", a.proxy(b.interrupt, b, !0)).off("mouseleave.slick", a.proxy(b.interrupt, b, !1)), b.$slider.off("focus.slick blur.slick"), b.options.arrows === !0 && b.slideCount > b.options.slidesToShow && (b.$prevArrow && b.$prevArrow.off("click.slick", b.changeSlide), b.$nextArrow && b.$nextArrow.off("click.slick", b.changeSlide)), b.$list.off("touchstart.slick mousedown.slick", b.swipeHandler), b.$list.off("touchmove.slick mousemove.slick", b.swipeHandler), b.$list.off("touchend.slick mouseup.slick", b.swipeHandler), b.$list.off("touchcancel.slick mouseleave.slick", b.swipeHandler), b.$list.off("click.slick", b.clickHandler), a(document).off(b.visibilityChange, b.visibility), b.cleanUpSlideEvents(), b.options.accessibility === !0 && b.$list.off("keydown.slick", b.keyHandler), b.options.focusOnSelect === !0 && a(b.$slideTrack).children().off("click.slick", b.selectHandler), a(window).off("orientationchange.slick.slick-" + b.instanceUid, b.orientationChange), a(window).off("resize.slick.slick-" + b.instanceUid, b.resize), a("[draggable!=true]", b.$slideTrack).off("dragstart", b.preventDefault), a(window).off("load.slick.slick-" + b.instanceUid, b.setPosition), a(document).off("ready.slick.slick-" + b.instanceUid, b.setPosition)
    }, b.prototype.cleanUpSlideEvents = function() {
        var b = this;
        b.$list.off("mouseenter.slick", a.proxy(b.interrupt, b, !0)), b.$list.off("mouseleave.slick", a.proxy(b.interrupt, b, !1))
    }, b.prototype.cleanUpRows = function() {
        var b, a = this;
        a.options.rows > 1 && (b = a.$slides.children().children(), b.removeAttr("style"), a.$slider.empty().append(b))
    }, b.prototype.clickHandler = function(a) {
        var b = this;
        b.shouldClick === !1 && (a.stopImmediatePropagation(), a.stopPropagation(), a.preventDefault())
    }, b.prototype.destroy = function(b) {
        var c = this;
        c.autoPlayClear(), c.touchObject = {}, c.cleanUpEvents(), a(".slick-cloned", c.$slider).detach(), c.$dots && c.$dots.remove(), c.$prevArrow && c.$prevArrow.length && (c.$prevArrow.removeClass("slick-disabled slick-arrow slick-hidden").removeAttr("aria-hidden aria-disabled tabindex").css("display", ""), c.htmlExpr.test(c.options.prevArrow) && c.$prevArrow.remove()), c.$nextArrow && c.$nextArrow.length && (c.$nextArrow.removeClass("slick-disabled slick-arrow slick-hidden").removeAttr("aria-hidden aria-disabled tabindex").css("display", ""), c.htmlExpr.test(c.options.nextArrow) && c.$nextArrow.remove()), c.$slides && (c.$slides.removeClass("slick-slide slick-active slick-center slick-visible slick-current").removeAttr("aria-hidden").removeAttr("data-slick-index").each(function() {
            a(this).attr("style", a(this).data("originalStyling"))
        }), c.$slideTrack.children(this.options.slide).detach(), c.$slideTrack.detach(), c.$list.detach(), c.$slider.append(c.$slides)), c.cleanUpRows(), c.$slider.removeClass("slick-slider"), c.$slider.removeClass("slick-initialized"), c.$slider.removeClass("slick-dotted"), c.unslicked = !0, b || c.$slider.trigger("destroy", [c])
    }, b.prototype.disableTransition = function(a) {
        var b = this,
            c = {};
        c[b.transitionType] = "", b.options.fade === !1 ? b.$slideTrack.css(c) : b.$slides.eq(a).css(c)
    }, b.prototype.fadeSlide = function(a, b) {
        var c = this;
        c.cssTransitions === !1 ? (c.$slides.eq(a).css({
            zIndex: c.options.zIndex
        }), c.$slides.eq(a).animate({
            opacity: 1
        }, c.options.speed, c.options.easing, b)) : (c.applyTransition(a), c.$slides.eq(a).css({
            opacity: 1,
            zIndex: c.options.zIndex
        }), b && setTimeout(function() {
            c.disableTransition(a), b.call()
        }, c.options.speed))
    }, b.prototype.fadeSlideOut = function(a) {
        var b = this;
        b.cssTransitions === !1 ? b.$slides.eq(a).animate({
            opacity: 0,
            zIndex: b.options.zIndex - 2
        }, b.options.speed, b.options.easing) : (b.applyTransition(a), b.$slides.eq(a).css({
            opacity: 0,
            zIndex: b.options.zIndex - 2
        }))
    }, b.prototype.filterSlides = b.prototype.slickFilter = function(a) {
        var b = this;
        null !== a && (b.$slidesCache = b.$slides, b.unload(), b.$slideTrack.children(this.options.slide).detach(), b.$slidesCache.filter(a).appendTo(b.$slideTrack), b.reinit())
    }, b.prototype.focusHandler = function() {
        var b = this;
        b.$slider.off("focus.slick blur.slick").on("focus.slick blur.slick", "*:not(.slick-arrow)", function(c) {
            c.stopImmediatePropagation();
            var d = a(this);
            setTimeout(function() {
                b.options.pauseOnFocus && (b.focussed = d.is(":focus"), b.autoPlay())
            }, 0)
        })
    }, b.prototype.getCurrent = b.prototype.slickCurrentSlide = function() {
        var a = this;
        return a.currentSlide
    }, b.prototype.getDotCount = function() {
        var a = this,
            b = 0,
            c = 0,
            d = 0;
        if (a.options.infinite === !0)
            for (; b < a.slideCount;) ++d, b = c + a.options.slidesToScroll, c += a.options.slidesToScroll <= a.options.slidesToShow ? a.options.slidesToScroll : a.options.slidesToShow;
        else if (a.options.centerMode === !0) d = a.slideCount;
        else if (a.options.asNavFor)
            for (; b < a.slideCount;) ++d, b = c + a.options.slidesToScroll, c += a.options.slidesToScroll <= a.options.slidesToShow ? a.options.slidesToScroll : a.options.slidesToShow;
        else d = 1 + Math.ceil((a.slideCount - a.options.slidesToShow) / a.options.slidesToScroll);
        return d - 1
    }, b.prototype.getLeft = function(a) {
        var c, d, f, b = this,
            e = 0;
        return b.slideOffset = 0, d = b.$slides.first().outerHeight(!0), b.options.infinite === !0 ? (b.slideCount > b.options.slidesToShow && (b.slideOffset = b.slideWidth * b.options.slidesToShow * -1, e = d * b.options.slidesToShow * -1), b.slideCount % b.options.slidesToScroll !== 0 && a + b.options.slidesToScroll > b.slideCount && b.slideCount > b.options.slidesToShow && (a > b.slideCount ? (b.slideOffset = (b.options.slidesToShow - (a - b.slideCount)) * b.slideWidth * -1, e = (b.options.slidesToShow - (a - b.slideCount)) * d * -1) : (b.slideOffset = b.slideCount % b.options.slidesToScroll * b.slideWidth * -1, e = b.slideCount % b.options.slidesToScroll * d * -1))) : a + b.options.slidesToShow > b.slideCount && (b.slideOffset = (a + b.options.slidesToShow - b.slideCount) * b.slideWidth, e = (a + b.options.slidesToShow - b.slideCount) * d), b.slideCount <= b.options.slidesToShow && (b.slideOffset = 0, e = 0), b.options.centerMode === !0 && b.options.infinite === !0 ? b.slideOffset += b.slideWidth * Math.floor(b.options.slidesToShow / 2) - b.slideWidth : b.options.centerMode === !0 && (b.slideOffset = 0, b.slideOffset += b.slideWidth * Math.floor(b.options.slidesToShow / 2)), c = b.options.vertical === !1 ? a * b.slideWidth * -1 + b.slideOffset : a * d * -1 + e, b.options.variableWidth === !0 && (f = b.slideCount <= b.options.slidesToShow || b.options.infinite === !1 ? b.$slideTrack.children(".slick-slide").eq(a) : b.$slideTrack.children(".slick-slide").eq(a + b.options.slidesToShow), c = b.options.rtl === !0 ? f[0] ? -1 * (b.$slideTrack.width() - f[0].offsetLeft - f.width()) : 0 : f[0] ? -1 * f[0].offsetLeft : 0, b.options.centerMode === !0 && (f = b.slideCount <= b.options.slidesToShow || b.options.infinite === !1 ? b.$slideTrack.children(".slick-slide").eq(a) : b.$slideTrack.children(".slick-slide").eq(a + b.options.slidesToShow + 1), c = b.options.rtl === !0 ? f[0] ? -1 * (b.$slideTrack.width() - f[0].offsetLeft - f.width()) : 0 : f[0] ? -1 * f[0].offsetLeft : 0, c += (b.$list.width() - f.outerWidth()) / 2)), c
    }, b.prototype.getOption = b.prototype.slickGetOption = function(a) {
        var b = this;
        return b.options[a]
    }, b.prototype.getNavigableIndexes = function() {
        var e, a = this,
            b = 0,
            c = 0,
            d = [];
        for (a.options.infinite === !1 ? e = a.slideCount : (b = -1 * a.options.slidesToScroll, c = -1 * a.options.slidesToScroll, e = 2 * a.slideCount); e > b;) d.push(b), b = c + a.options.slidesToScroll, c += a.options.slidesToScroll <= a.options.slidesToShow ? a.options.slidesToScroll : a.options.slidesToShow;
        return d
    }, b.prototype.getSlick = function() {
        return this
    }, b.prototype.getSlideCount = function() {
        var c, d, e, b = this;
        return e = b.options.centerMode === !0 ? b.slideWidth * Math.floor(b.options.slidesToShow / 2) : 0, b.options.swipeToSlide === !0 ? (b.$slideTrack.find(".slick-slide").each(function(c, f) {
            return f.offsetLeft - e + a(f).outerWidth() / 2 > -1 * b.swipeLeft ? (d = f, !1) : void 0
        }), c = Math.abs(a(d).attr("data-slick-index") - b.currentSlide) || 1) : b.options.slidesToScroll
    }, b.prototype.goTo = b.prototype.slickGoTo = function(a, b) {
        var c = this;
        c.changeSlide({
            data: {
                message: "index",
                index: parseInt(a)
            }
        }, b)
    }, b.prototype.init = function(b) {
        var c = this;
        a(c.$slider).hasClass("slick-initialized") || (a(c.$slider).addClass("slick-initialized"), c.buildRows(), c.buildOut(), c.setProps(), c.startLoad(), c.loadSlider(), c.initializeEvents(), c.updateArrows(), c.updateDots(), c.checkResponsive(!0), c.focusHandler()), b && c.$slider.trigger("init", [c]), c.options.accessibility === !0 && c.initADA(), c.options.autoplay && (c.paused = !1, c.autoPlay())
    }, b.prototype.initADA = function() {
        var b = this;
        b.$slides.add(b.$slideTrack.find(".slick-cloned")).attr({
            "aria-hidden": "true",
            tabindex: "-1"
        }).find("a, input, button, select").attr({
            tabindex: "-1"
        }), b.$slideTrack.attr("role", "listbox"), b.$slides.not(b.$slideTrack.find(".slick-cloned")).each(function(c) {
            a(this).attr({
                role: "option",
                "aria-describedby": "slick-slide" + b.instanceUid + c
            })
        }), null !== b.$dots && b.$dots.attr("role", "tablist").find("li").each(function(c) {
            a(this).attr({
                role: "presentation",
                "aria-selected": "false",
                "aria-controls": "navigation" + b.instanceUid + c,
                id: "slick-slide" + b.instanceUid + c
            })
        }).first().attr("aria-selected", "true").end().find("button").attr("role", "button").end().closest("div").attr("role", "toolbar"), b.activateADA()
    }, b.prototype.initArrowEvents = function() {
        var a = this;
        a.options.arrows === !0 && a.slideCount > a.options.slidesToShow && (a.$prevArrow.off("click.slick").on("click.slick", {
            message: "previous"
        }, a.changeSlide), a.$nextArrow.off("click.slick").on("click.slick", {
            message: "next"
        }, a.changeSlide))
    }, b.prototype.initDotEvents = function() {
        var b = this;
        b.options.dots === !0 && b.slideCount > b.options.slidesToShow && a("li", b.$dots).on("click.slick", {
            message: "index"
        }, b.changeSlide), b.options.dots === !0 && b.options.pauseOnDotsHover === !0 && a("li", b.$dots).on("mouseenter.slick", a.proxy(b.interrupt, b, !0)).on("mouseleave.slick", a.proxy(b.interrupt, b, !1))
    }, b.prototype.initSlideEvents = function() {
        var b = this;
        b.options.pauseOnHover && (b.$list.on("mouseenter.slick", a.proxy(b.interrupt, b, !0)), b.$list.on("mouseleave.slick", a.proxy(b.interrupt, b, !1)))
    }, b.prototype.initializeEvents = function() {
        var b = this;
        b.initArrowEvents(), b.initDotEvents(), b.initSlideEvents(), b.$list.on("touchstart.slick mousedown.slick", {
            action: "start"
        }, b.swipeHandler), b.$list.on("touchmove.slick mousemove.slick", {
            action: "move"
        }, b.swipeHandler), b.$list.on("touchend.slick mouseup.slick", {
            action: "end"
        }, b.swipeHandler), b.$list.on("touchcancel.slick mouseleave.slick", {
            action: "end"
        }, b.swipeHandler), b.$list.on("click.slick", b.clickHandler), a(document).on(b.visibilityChange, a.proxy(b.visibility, b)), b.options.accessibility === !0 && b.$list.on("keydown.slick", b.keyHandler), b.options.focusOnSelect === !0 && a(b.$slideTrack).children().on("click.slick", b.selectHandler), a(window).on("orientationchange.slick.slick-" + b.instanceUid, a.proxy(b.orientationChange, b)), a(window).on("resize.slick.slick-" + b.instanceUid, a.proxy(b.resize, b)), a("[draggable!=true]", b.$slideTrack).on("dragstart", b.preventDefault), a(window).on("load.slick.slick-" + b.instanceUid, b.setPosition), a(document).on("ready.slick.slick-" + b.instanceUid, b.setPosition)
    }, b.prototype.initUI = function() {
        var a = this;
        a.options.arrows === !0 && a.slideCount > a.options.slidesToShow && (a.$prevArrow.show(), a.$nextArrow.show()), a.options.dots === !0 && a.slideCount > a.options.slidesToShow && a.$dots.show()
    }, b.prototype.keyHandler = function(a) {
        var b = this;
        a.target.tagName.match("TEXTAREA|INPUT|SELECT") || (37 === a.keyCode && b.options.accessibility === !0 ? b.changeSlide({
            data: {
                message: b.options.rtl === !0 ? "next" : "previous"
            }
        }) : 39 === a.keyCode && b.options.accessibility === !0 && b.changeSlide({
            data: {
                message: b.options.rtl === !0 ? "previous" : "next"
            }
        }))
    }, b.prototype.lazyLoad = function() {
        function g(c) {
            a("img[data-lazy]", c).each(function() {
                var c = a(this),
                    d = a(this).attr("data-lazy"),
                    e = document.createElement("img");
                e.onload = function() {
                    c.animate({
                        opacity: 0
                    }, 100, function() {
                        c.attr("src", d).animate({
                            opacity: 1
                        }, 200, function() {
                            c.removeAttr("data-lazy").removeClass("slick-loading")
                        }), b.$slider.trigger("lazyLoaded", [b, c, d])
                    })
                }, e.onerror = function() {
                    c.removeAttr("data-lazy").removeClass("slick-loading").addClass("slick-lazyload-error"), b.$slider.trigger("lazyLoadError", [b, c, d])
                }, e.src = d
            })
        }
        var c, d, e, f, b = this;
        b.options.centerMode === !0 ? b.options.infinite === !0 ? (e = b.currentSlide + (b.options.slidesToShow / 2 + 1), f = e + b.options.slidesToShow + 2) : (e = Math.max(0, b.currentSlide - (b.options.slidesToShow / 2 + 1)), f = 2 + (b.options.slidesToShow / 2 + 1) + b.currentSlide) : (e = b.options.infinite ? b.options.slidesToShow + b.currentSlide : b.currentSlide, f = Math.ceil(e + b.options.slidesToShow), b.options.fade === !0 && (e > 0 && e--, f <= b.slideCount && f++)), c = b.$slider.find(".slick-slide").slice(e, f), g(c), b.slideCount <= b.options.slidesToShow ? (d = b.$slider.find(".slick-slide"), g(d)) : b.currentSlide >= b.slideCount - b.options.slidesToShow ? (d = b.$slider.find(".slick-cloned").slice(0, b.options.slidesToShow), g(d)) : 0 === b.currentSlide && (d = b.$slider.find(".slick-cloned").slice(-1 * b.options.slidesToShow), g(d))
    }, b.prototype.loadSlider = function() {
        var a = this;
        a.setPosition(), a.$slideTrack.css({
            opacity: 1
        }), a.$slider.removeClass("slick-loading"), a.initUI(), "progressive" === a.options.lazyLoad && a.progressiveLazyLoad()
    }, b.prototype.next = b.prototype.slickNext = function() {
        var a = this;
        a.changeSlide({
            data: {
                message: "next"
            }
        })
    }, b.prototype.orientationChange = function() {
        var a = this;
        a.checkResponsive(), a.setPosition()
    }, b.prototype.pause = b.prototype.slickPause = function() {
        var a = this;
        a.autoPlayClear(), a.paused = !0
    }, b.prototype.play = b.prototype.slickPlay = function() {
        var a = this;
        a.autoPlay(), a.options.autoplay = !0, a.paused = !1, a.focussed = !1, a.interrupted = !1
    }, b.prototype.postSlide = function(a) {
        var b = this;
        b.unslicked || (b.$slider.trigger("afterChange", [b, a]), b.animating = !1, b.setPosition(), b.swipeLeft = null, b.options.autoplay && b.autoPlay(), b.options.accessibility === !0 && b.initADA())
    }, b.prototype.prev = b.prototype.slickPrev = function() {
        var a = this;
        a.changeSlide({
            data: {
                message: "previous"
            }
        })
    }, b.prototype.preventDefault = function(a) {
        a.preventDefault()
    }, b.prototype.progressiveLazyLoad = function(b) {
        b = b || 1;
        var e, f, g, c = this,
            d = a("img[data-lazy]", c.$slider);
        d.length ? (e = d.first(), f = e.attr("data-lazy"), g = document.createElement("img"), g.onload = function() {
            e.attr("src", f).removeAttr("data-lazy").removeClass("slick-loading"), c.options.adaptiveHeight === !0 && c.setPosition(), c.$slider.trigger("lazyLoaded", [c, e, f]), c.progressiveLazyLoad()
        }, g.onerror = function() {
            3 > b ? setTimeout(function() {
                c.progressiveLazyLoad(b + 1)
            }, 500) : (e.removeAttr("data-lazy").removeClass("slick-loading").addClass("slick-lazyload-error"), c.$slider.trigger("lazyLoadError", [c, e, f]), c.progressiveLazyLoad())
        }, g.src = f) : c.$slider.trigger("allImagesLoaded", [c])
    }, b.prototype.refresh = function(b) {
        var d, e, c = this;
        e = c.slideCount - c.options.slidesToShow, !c.options.infinite && c.currentSlide > e && (c.currentSlide = e), c.slideCount <= c.options.slidesToShow && (c.currentSlide = 0), d = c.currentSlide, c.destroy(!0), a.extend(c, c.initials, {
            currentSlide: d
        }), c.init(), b || c.changeSlide({
            data: {
                message: "index",
                index: d
            }
        }, !1)
    }, b.prototype.registerBreakpoints = function() {
        var c, d, e, b = this,
            f = b.options.responsive || null;
        if ("array" === a.type(f) && f.length) {
            b.respondTo = b.options.respondTo || "window";
            for (c in f)
                if (e = b.breakpoints.length - 1, d = f[c].breakpoint, f.hasOwnProperty(c)) {
                    for (; e >= 0;) b.breakpoints[e] && b.breakpoints[e] === d && b.breakpoints.splice(e, 1), e--;
                    b.breakpoints.push(d), b.breakpointSettings[d] = f[c].settings
                }
            b.breakpoints.sort(function(a, c) {
                return b.options.mobileFirst ? a - c : c - a
            })
        }
    }, b.prototype.reinit = function() {
        var b = this;
        b.$slides = b.$slideTrack.children(b.options.slide).addClass("slick-slide"), b.slideCount = b.$slides.length, b.currentSlide >= b.slideCount && 0 !== b.currentSlide && (b.currentSlide = b.currentSlide - b.options.slidesToScroll), b.slideCount <= b.options.slidesToShow && (b.currentSlide = 0), b.registerBreakpoints(), b.setProps(), b.setupInfinite(), b.buildArrows(), b.updateArrows(), b.initArrowEvents(), b.buildDots(), b.updateDots(), b.initDotEvents(), b.cleanUpSlideEvents(), b.initSlideEvents(), b.checkResponsive(!1, !0), b.options.focusOnSelect === !0 && a(b.$slideTrack).children().on("click.slick", b.selectHandler), b.setSlideClasses("number" == typeof b.currentSlide ? b.currentSlide : 0), b.setPosition(), b.focusHandler(), b.paused = !b.options.autoplay, b.autoPlay(), b.$slider.trigger("reInit", [b])
    }, b.prototype.resize = function() {
        var b = this;
        a(window).width() !== b.windowWidth && (clearTimeout(b.windowDelay), b.windowDelay = window.setTimeout(function() {
            b.windowWidth = a(window).width(), b.checkResponsive(), b.unslicked || b.setPosition()
        }, 50))
    }, b.prototype.removeSlide = b.prototype.slickRemove = function(a, b, c) {
        var d = this;
        return "boolean" == typeof a ? (b = a, a = b === !0 ? 0 : d.slideCount - 1) : a = b === !0 ? --a : a, d.slideCount < 1 || 0 > a || a > d.slideCount - 1 ? !1 : (d.unload(), c === !0 ? d.$slideTrack.children().remove() : d.$slideTrack.children(this.options.slide).eq(a).remove(), d.$slides = d.$slideTrack.children(this.options.slide), d.$slideTrack.children(this.options.slide).detach(), d.$slideTrack.append(d.$slides), d.$slidesCache = d.$slides, void d.reinit())
    }, b.prototype.setCSS = function(a) {
        var d, e, b = this,
            c = {};
        b.options.rtl === !0 && (a = -a), d = "left" == b.positionProp ? Math.ceil(a) + "px" : "0px", e = "top" == b.positionProp ? Math.ceil(a) + "px" : "0px", c[b.positionProp] = a, b.transformsEnabled === !1 ? b.$slideTrack.css(c) : (c = {}, b.cssTransitions === !1 ? (c[b.animType] = "translate(" + d + ", " + e + ")", b.$slideTrack.css(c)) : (c[b.animType] = "translate3d(" + d + ", " + e + ", 0px)", b.$slideTrack.css(c)))
    }, b.prototype.setDimensions = function() {
        var a = this;
        a.options.vertical === !1 ? a.options.centerMode === !0 && a.$list.css({
            padding: "0px " + a.options.centerPadding
        }) : (a.$list.height(a.$slides.first().outerHeight(!0) * a.options.slidesToShow), a.options.centerMode === !0 && a.$list.css({
            padding: a.options.centerPadding + " 0px"
        })), a.listWidth = a.$list.width(), a.listHeight = a.$list.height(), a.options.vertical === !1 && a.options.variableWidth === !1 ? (a.slideWidth = Math.ceil(a.listWidth / a.options.slidesToShow), a.$slideTrack.width(Math.ceil(a.slideWidth * a.$slideTrack.children(".slick-slide").length))) : a.options.variableWidth === !0 ? a.$slideTrack.width(5e3 * a.slideCount) : (a.slideWidth = Math.ceil(a.listWidth), a.$slideTrack.height(Math.ceil(a.$slides.first().outerHeight(!0) * a.$slideTrack.children(".slick-slide").length)));
        var b = a.$slides.first().outerWidth(!0) - a.$slides.first().width();
        a.options.variableWidth === !1 && a.$slideTrack.children(".slick-slide").width(a.slideWidth - b)
    }, b.prototype.setFade = function() {
        var c, b = this;
        b.$slides.each(function(d, e) {
            c = b.slideWidth * d * -1, b.options.rtl === !0 ? a(e).css({
                position: "relative",
                right: c,
                top: 0,
                zIndex: b.options.zIndex - 2,
                opacity: 0
            }) : a(e).css({
                position: "relative",
                left: c,
                top: 0,
                zIndex: b.options.zIndex - 2,
                opacity: 0
            })
        }), b.$slides.eq(b.currentSlide).css({
            zIndex: b.options.zIndex - 1,
            opacity: 1
        })
    }, b.prototype.setHeight = function() {
        var a = this;
        if (1 === a.options.slidesToShow && a.options.adaptiveHeight === !0 && a.options.vertical === !1) {
            var b = a.$slides.eq(a.currentSlide).outerHeight(!0);
            a.$list.css("height", b)
        }
    }, b.prototype.setOption = b.prototype.slickSetOption = function() {
        var c, d, e, f, h, b = this,
            g = !1;
        if ("object" === a.type(arguments[0]) ? (e = arguments[0], g = arguments[1], h = "multiple") : "string" === a.type(arguments[0]) && (e = arguments[0], f = arguments[1], g = arguments[2], "responsive" === arguments[0] && "array" === a.type(arguments[1]) ? h = "responsive" : "undefined" != typeof arguments[1] && (h = "single")), "single" === h) b.options[e] = f;
        else if ("multiple" === h) a.each(e, function(a, c) {
            b.options[a] = c
        });
        else if ("responsive" === h)
            for (d in f)
                if ("array" !== a.type(b.options.responsive)) b.options.responsive = [f[d]];
                else {
                    for (c = b.options.responsive.length - 1; c >= 0;) b.options.responsive[c].breakpoint === f[d].breakpoint && b.options.responsive.splice(c, 1), c--;
                    b.options.responsive.push(f[d])
                }
        g && (b.unload(), b.reinit())
    }, b.prototype.setPosition = function() {
        var a = this;
        a.setDimensions(), a.setHeight(), a.options.fade === !1 ? a.setCSS(a.getLeft(a.currentSlide)) : a.setFade(), a.$slider.trigger("setPosition", [a])
    }, b.prototype.setProps = function() {
        var a = this,
            b = document.body.style;
        a.positionProp = a.options.vertical === !0 ? "top" : "left", "top" === a.positionProp ? a.$slider.addClass("slick-vertical") : a.$slider.removeClass("slick-vertical"), (void 0 !== b.WebkitTransition || void 0 !== b.MozTransition || void 0 !== b.msTransition) && a.options.useCSS === !0 && (a.cssTransitions = !0), a.options.fade && ("number" == typeof a.options.zIndex ? a.options.zIndex < 3 && (a.options.zIndex = 3) : a.options.zIndex = a.defaults.zIndex), void 0 !== b.OTransform && (a.animType = "OTransform", a.transformType = "-o-transform", a.transitionType = "OTransition", void 0 === b.perspectiveProperty && void 0 === b.webkitPerspective && (a.animType = !1)), void 0 !== b.MozTransform && (a.animType = "MozTransform", a.transformType = "-moz-transform", a.transitionType = "MozTransition", void 0 === b.perspectiveProperty && void 0 === b.MozPerspective && (a.animType = !1)), void 0 !== b.webkitTransform && (a.animType = "webkitTransform", a.transformType = "-webkit-transform", a.transitionType = "webkitTransition", void 0 === b.perspectiveProperty && void 0 === b.webkitPerspective && (a.animType = !1)), void 0 !== b.msTransform && (a.animType = "msTransform", a.transformType = "-ms-transform", a.transitionType = "msTransition", void 0 === b.msTransform && (a.animType = !1)), void 0 !== b.transform && a.animType !== !1 && (a.animType = "transform", a.transformType = "transform", a.transitionType = "transition"), a.transformsEnabled = a.options.useTransform && null !== a.animType && a.animType !== !1
    }, b.prototype.setSlideClasses = function(a) {
        var c, d, e, f, b = this;
        d = b.$slider.find(".slick-slide").removeClass("slick-active slick-center slick-current").attr("aria-hidden", "true"), b.$slides.eq(a).addClass("slick-current"), b.options.centerMode === !0 ? (c = Math.floor(b.options.slidesToShow / 2), b.options.infinite === !0 && (a >= c && a <= b.slideCount - 1 - c ? b.$slides.slice(a - c, a + c + 1).addClass("slick-active").attr("aria-hidden", "false") : (e = b.options.slidesToShow + a, d.slice(e - c + 1, e + c + 2).addClass("slick-active").attr("aria-hidden", "false")), 0 === a ? d.eq(d.length - 1 - b.options.slidesToShow).addClass("slick-center") : a === b.slideCount - 1 && d.eq(b.options.slidesToShow).addClass("slick-center")), b.$slides.eq(a).addClass("slick-center")) : a >= 0 && a <= b.slideCount - b.options.slidesToShow ? b.$slides.slice(a, a + b.options.slidesToShow).addClass("slick-active").attr("aria-hidden", "false") : d.length <= b.options.slidesToShow ? d.addClass("slick-active").attr("aria-hidden", "false") : (f = b.slideCount % b.options.slidesToShow, e = b.options.infinite === !0 ? b.options.slidesToShow + a : a, b.options.slidesToShow == b.options.slidesToScroll && b.slideCount - a < b.options.slidesToShow ? d.slice(e - (b.options.slidesToShow - f), e + f).addClass("slick-active").attr("aria-hidden", "false") : d.slice(e, e + b.options.slidesToShow).addClass("slick-active").attr("aria-hidden", "false")), "ondemand" === b.options.lazyLoad && b.lazyLoad()
    }, b.prototype.setupInfinite = function() {
        var c, d, e, b = this;
        if (b.options.fade === !0 && (b.options.centerMode = !1), b.options.infinite === !0 && b.options.fade === !1 && (d = null, b.slideCount > b.options.slidesToShow)) {
            for (e = b.options.centerMode === !0 ? b.options.slidesToShow + 1 : b.options.slidesToShow, c = b.slideCount; c > b.slideCount - e; c -= 1) d = c - 1, a(b.$slides[d]).clone(!0).attr("id", "").attr("data-slick-index", d - b.slideCount).prependTo(b.$slideTrack).addClass("slick-cloned");
            for (c = 0; e > c; c += 1) d = c, a(b.$slides[d]).clone(!0).attr("id", "").attr("data-slick-index", d + b.slideCount).appendTo(b.$slideTrack).addClass("slick-cloned");
            b.$slideTrack.find(".slick-cloned").find("[id]").each(function() {
                a(this).attr("id", "")
            })
        }
    }, b.prototype.interrupt = function(a) {
        var b = this;
        a || b.autoPlay(), b.interrupted = a
    }, b.prototype.selectHandler = function(b) {
        var c = this,
            d = a(b.target).is(".slick-slide") ? a(b.target) : a(b.target).parents(".slick-slide"),
            e = parseInt(d.attr("data-slick-index"));
        return e || (e = 0), c.slideCount <= c.options.slidesToShow ? (c.setSlideClasses(e), void c.asNavFor(e)) : void c.slideHandler(e)
    }, b.prototype.slideHandler = function(a, b, c) {
        var d, e, f, g, j, h = null,
            i = this;
        return b = b || !1, i.animating === !0 && i.options.waitForAnimate === !0 || i.options.fade === !0 && i.currentSlide === a || i.slideCount <= i.options.slidesToShow ? void 0 : (b === !1 && i.asNavFor(a), d = a, h = i.getLeft(d), g = i.getLeft(i.currentSlide), i.currentLeft = null === i.swipeLeft ? g : i.swipeLeft, i.options.infinite === !1 && i.options.centerMode === !1 && (0 > a || a > i.getDotCount() * i.options.slidesToScroll) ? void(i.options.fade === !1 && (d = i.currentSlide, c !== !0 ? i.animateSlide(g, function() {
            i.postSlide(d)
        }) : i.postSlide(d))) : i.options.infinite === !1 && i.options.centerMode === !0 && (0 > a || a > i.slideCount - i.options.slidesToScroll) ? void(i.options.fade === !1 && (d = i.currentSlide, c !== !0 ? i.animateSlide(g, function() {
            i.postSlide(d)
        }) : i.postSlide(d))) : (i.options.autoplay && clearInterval(i.autoPlayTimer), e = 0 > d ? i.slideCount % i.options.slidesToScroll !== 0 ? i.slideCount - i.slideCount % i.options.slidesToScroll : i.slideCount + d : d >= i.slideCount ? i.slideCount % i.options.slidesToScroll !== 0 ? 0 : d - i.slideCount : d, i.animating = !0, i.$slider.trigger("beforeChange", [i, i.currentSlide, e]), f = i.currentSlide, i.currentSlide = e, i.setSlideClasses(i.currentSlide), i.options.asNavFor && (j = i.getNavTarget(), j = j.slick("getSlick"), j.slideCount <= j.options.slidesToShow && j.setSlideClasses(i.currentSlide)), i.updateDots(), i.updateArrows(), i.options.fade === !0 ? (c !== !0 ? (i.fadeSlideOut(f), i.fadeSlide(e, function() {
            i.postSlide(e)
        })) : i.postSlide(e), void i.animateHeight()) : void(c !== !0 ? i.animateSlide(h, function() {
            i.postSlide(e)
        }) : i.postSlide(e))))
    }, b.prototype.startLoad = function() {
        var a = this;
        a.options.arrows === !0 && a.slideCount > a.options.slidesToShow && (a.$prevArrow.hide(), a.$nextArrow.hide()), a.options.dots === !0 && a.slideCount > a.options.slidesToShow && a.$dots.hide(), a.$slider.addClass("slick-loading")
    }, b.prototype.swipeDirection = function() {
        var a, b, c, d, e = this;
        return a = e.touchObject.startX - e.touchObject.curX, b = e.touchObject.startY - e.touchObject.curY, c = Math.atan2(b, a), d = Math.round(180 * c / Math.PI), 0 > d && (d = 360 - Math.abs(d)), 45 >= d && d >= 0 ? e.options.rtl === !1 ? "left" : "right" : 360 >= d && d >= 315 ? e.options.rtl === !1 ? "left" : "right" : d >= 135 && 225 >= d ? e.options.rtl === !1 ? "right" : "left" : e.options.verticalSwiping === !0 ? d >= 35 && 135 >= d ? "down" : "up" : "vertical"
    }, b.prototype.swipeEnd = function(a) {
        var c, d, b = this;
        if (b.dragging = !1, b.interrupted = !1, b.shouldClick = b.touchObject.swipeLength > 10 ? !1 : !0, void 0 === b.touchObject.curX) return !1;
        if (b.touchObject.edgeHit === !0 && b.$slider.trigger("edge", [b, b.swipeDirection()]), b.touchObject.swipeLength >= b.touchObject.minSwipe) {
            switch (d = b.swipeDirection()) {
                case "left":
                case "down":
                    c = b.options.swipeToSlide ? b.checkNavigable(b.currentSlide + b.getSlideCount()) : b.currentSlide + b.getSlideCount(), b.currentDirection = 0;
                    break;
                case "right":
                case "up":
                    c = b.options.swipeToSlide ? b.checkNavigable(b.currentSlide - b.getSlideCount()) : b.currentSlide - b.getSlideCount(), b.currentDirection = 1
            }
            "vertical" != d && (b.slideHandler(c), b.touchObject = {}, b.$slider.trigger("swipe", [b, d]))
        } else b.touchObject.startX !== b.touchObject.curX && (b.slideHandler(b.currentSlide), b.touchObject = {})
    }, b.prototype.swipeHandler = function(a) {
        var b = this;
        if (!(b.options.swipe === !1 || "ontouchend" in document && b.options.swipe === !1 || b.options.draggable === !1 && -1 !== a.type.indexOf("mouse"))) switch (b.touchObject.fingerCount = a.originalEvent && void 0 !== a.originalEvent.touches ? a.originalEvent.touches.length : 1, b.touchObject.minSwipe = b.listWidth / b.options.touchThreshold, b.options.verticalSwiping === !0 && (b.touchObject.minSwipe = b.listHeight / b.options.touchThreshold), a.data.action) {
            case "start":
                b.swipeStart(a);
                break;
            case "move":
                b.swipeMove(a);
                break;
            case "end":
                b.swipeEnd(a)
        }
    }, b.prototype.swipeMove = function(a) {
        var d, e, f, g, h, b = this;
        return h = void 0 !== a.originalEvent ? a.originalEvent.touches : null, !b.dragging || h && 1 !== h.length ? !1 : (d = b.getLeft(b.currentSlide), b.touchObject.curX = void 0 !== h ? h[0].pageX : a.clientX, b.touchObject.curY = void 0 !== h ? h[0].pageY : a.clientY, b.touchObject.swipeLength = Math.round(Math.sqrt(Math.pow(b.touchObject.curX - b.touchObject.startX, 2))), b.options.verticalSwiping === !0 && (b.touchObject.swipeLength = Math.round(Math.sqrt(Math.pow(b.touchObject.curY - b.touchObject.startY, 2)))), e = b.swipeDirection(), "vertical" !== e ? (void 0 !== a.originalEvent && b.touchObject.swipeLength > 4 && a.preventDefault(), g = (b.options.rtl === !1 ? 1 : -1) * (b.touchObject.curX > b.touchObject.startX ? 1 : -1), b.options.verticalSwiping === !0 && (g = b.touchObject.curY > b.touchObject.startY ? 1 : -1), f = b.touchObject.swipeLength, b.touchObject.edgeHit = !1, b.options.infinite === !1 && (0 === b.currentSlide && "right" === e || b.currentSlide >= b.getDotCount() && "left" === e) && (f = b.touchObject.swipeLength * b.options.edgeFriction, b.touchObject.edgeHit = !0), b.options.vertical === !1 ? b.swipeLeft = d + f * g : b.swipeLeft = d + f * (b.$list.height() / b.listWidth) * g, b.options.verticalSwiping === !0 && (b.swipeLeft = d + f * g), b.options.fade === !0 || b.options.touchMove === !1 ? !1 : b.animating === !0 ? (b.swipeLeft = null, !1) : void b.setCSS(b.swipeLeft)) : void 0)
    }, b.prototype.swipeStart = function(a) {
        var c, b = this;
        return b.interrupted = !0, 1 !== b.touchObject.fingerCount || b.slideCount <= b.options.slidesToShow ? (b.touchObject = {}, !1) : (void 0 !== a.originalEvent && void 0 !== a.originalEvent.touches && (c = a.originalEvent.touches[0]), b.touchObject.startX = b.touchObject.curX = void 0 !== c ? c.pageX : a.clientX, b.touchObject.startY = b.touchObject.curY = void 0 !== c ? c.pageY : a.clientY, void(b.dragging = !0))
    }, b.prototype.unfilterSlides = b.prototype.slickUnfilter = function() {
        var a = this;
        null !== a.$slidesCache && (a.unload(), a.$slideTrack.children(this.options.slide).detach(), a.$slidesCache.appendTo(a.$slideTrack), a.reinit())
    }, b.prototype.unload = function() {
        var b = this;
        a(".slick-cloned", b.$slider).remove(), b.$dots && b.$dots.remove(), b.$prevArrow && b.htmlExpr.test(b.options.prevArrow) && b.$prevArrow.remove(), b.$nextArrow && b.htmlExpr.test(b.options.nextArrow) && b.$nextArrow.remove(), b.$slides.removeClass("slick-slide slick-active slick-visible slick-current").attr("aria-hidden", "true").css("width", "")
    }, b.prototype.unslick = function(a) {
        var b = this;
        b.$slider.trigger("unslick", [b, a]), b.destroy()
    }, b.prototype.updateArrows = function() {
        var b, a = this;
        b = Math.floor(a.options.slidesToShow / 2), a.options.arrows === !0 && a.slideCount > a.options.slidesToShow && !a.options.infinite && (a.$prevArrow.removeClass("slick-disabled").attr("aria-disabled", "false"), a.$nextArrow.removeClass("slick-disabled").attr("aria-disabled", "false"), 0 === a.currentSlide ? (a.$prevArrow.addClass("slick-disabled").attr("aria-disabled", "true"), a.$nextArrow.removeClass("slick-disabled").attr("aria-disabled", "false")) : a.currentSlide >= a.slideCount - a.options.slidesToShow && a.options.centerMode === !1 ? (a.$nextArrow.addClass("slick-disabled").attr("aria-disabled", "true"), a.$prevArrow.removeClass("slick-disabled").attr("aria-disabled", "false")) : a.currentSlide >= a.slideCount - 1 && a.options.centerMode === !0 && (a.$nextArrow.addClass("slick-disabled").attr("aria-disabled", "true"), a.$prevArrow.removeClass("slick-disabled").attr("aria-disabled", "false")))
    }, b.prototype.updateDots = function() {
        var a = this;
        null !== a.$dots && (a.$dots.find("li").removeClass("slick-active").attr("aria-hidden", "true"), a.$dots.find("li").eq(Math.floor(a.currentSlide / a.options.slidesToScroll)).addClass("slick-active").attr("aria-hidden", "false"))
    }, b.prototype.visibility = function() {
        var a = this;
        a.options.autoplay && (document[a.hidden] ? a.interrupted = !0 : a.interrupted = !1)
    }, a.fn.slick = function() {
        var f, g, a = this,
            c = arguments[0],
            d = Array.prototype.slice.call(arguments, 1),
            e = a.length;
        for (f = 0; e > f; f++)
            if ("object" == typeof c || "undefined" == typeof c ? a[f].slick = new b(a[f], c) : g = a[f].slick[c].apply(a[f].slick, d), "undefined" != typeof g) return g;
        return a
    }
}) ! function(n, e) {
    "object" == typeof exports && "undefined" != typeof module ? module.exports = e() : "function" == typeof define && define.amd ? define(e) : n.anime = e()
}(this, function() {
    "use strict";
    var n = {
            update: null,
            begin: null,
            loopBegin: null,
            changeBegin: null,
            change: null,
            changeComplete: null,
            loopComplete: null,
            complete: null,
            loop: 1,
            direction: "normal",
            autoplay: !0,
            timelineOffset: 0
        },
        e = {
            duration: 1e3,
            delay: 0,
            endDelay: 0,
            easing: "easeOutElastic(1, .5)",
            round: 0
        },
        r = ["translateX", "translateY", "translateZ", "rotate", "rotateX", "rotateY", "rotateZ", "scale", "scaleX", "scaleY", "scaleZ", "skew", "skewX", "skewY", "perspective"],
        t = {
            CSS: {},
            springs: {}
        };

    function a(n, e, r) {
        return Math.min(Math.max(n, e), r)
    }

    function o(n, e) {
        return n.indexOf(e) > -1
    }

    function u(n, e) {
        return n.apply(null, e)
    }
    var i = {
        arr: function(n) {
            return Array.isArray(n)
        },
        obj: function(n) {
            return o(Object.prototype.toString.call(n), "Object")
        },
        pth: function(n) {
            return i.obj(n) && n.hasOwnProperty("totalLength")
        },
        svg: function(n) {
            return n instanceof SVGElement
        },
        inp: function(n) {
            return n instanceof HTMLInputElement
        },
        dom: function(n) {
            return n.nodeType || i.svg(n)
        },
        str: function(n) {
            return "string" == typeof n
        },
        fnc: function(n) {
            return "function" == typeof n
        },
        und: function(n) {
            return void 0 === n
        },
        hex: function(n) {
            return /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(n)
        },
        rgb: function(n) {
            return /^rgb/.test(n)
        },
        hsl: function(n) {
            return /^hsl/.test(n)
        },
        col: function(n) {
            return i.hex(n) || i.rgb(n) || i.hsl(n)
        },
        key: function(r) {
            return !n.hasOwnProperty(r) && !e.hasOwnProperty(r) && "targets" !== r && "keyframes" !== r
        }
    };

    function c(n) {
        var e = /\(([^)]+)\)/.exec(n);
        return e ? e[1].split(",").map(function(n) {
            return parseFloat(n)
        }) : []
    }

    function s(n, e) {
        var r = c(n),
            o = a(i.und(r[0]) ? 1 : r[0], .1, 100),
            u = a(i.und(r[1]) ? 100 : r[1], .1, 100),
            s = a(i.und(r[2]) ? 10 : r[2], .1, 100),
            f = a(i.und(r[3]) ? 0 : r[3], .1, 100),
            l = Math.sqrt(u / o),
            d = s / (2 * Math.sqrt(u * o)),
            p = d < 1 ? l * Math.sqrt(1 - d * d) : 0,
            h = 1,
            v = d < 1 ? (d * l - f) / p : -f + l;

        function g(n) {
            var r = e ? e * n / 1e3 : n;
            return r = d < 1 ? Math.exp(-r * d * l) * (h * Math.cos(p * r) + v * Math.sin(p * r)) : (h + v * r) * Math.exp(-r * l), 0 === n || 1 === n ? n : 1 - r
        }
        return e ? g : function() {
            var e = t.springs[n];
            if (e) return e;
            for (var r = 0, a = 0;;)
                if (1 === g(r += 1 / 6)) {
                    if (++a >= 16) break
                } else a = 0;
            var o = r * (1 / 6) * 1e3;
            return t.springs[n] = o, o
        }
    }

    function f(n) {
        return void 0 === n && (n = 10),
            function(e) {
                return Math.round(e * n) * (1 / n)
            }
    }
    var l, d, p = function() {
            var n = 11,
                e = 1 / (n - 1);

            function r(n, e) {
                return 1 - 3 * e + 3 * n
            }

            function t(n, e) {
                return 3 * e - 6 * n
            }

            function a(n) {
                return 3 * n
            }

            function o(n, e, o) {
                return ((r(e, o) * n + t(e, o)) * n + a(e)) * n
            }

            function u(n, e, o) {
                return 3 * r(e, o) * n * n + 2 * t(e, o) * n + a(e)
            }
            return function(r, t, a, i) {
                if (0 <= r && r <= 1 && 0 <= a && a <= 1) {
                    var c = new Float32Array(n);
                    if (r !== t || a !== i)
                        for (var s = 0; s < n; ++s) c[s] = o(s * e, r, a);
                    return function(n) {
                        return r === t && a === i ? n : 0 === n || 1 === n ? n : o(f(n), t, i)
                    }
                }

                function f(t) {
                    for (var i = 0, s = 1, f = n - 1; s !== f && c[s] <= t; ++s) i += e;
                    var l = i + (t - c[--s]) / (c[s + 1] - c[s]) * e,
                        d = u(l, r, a);
                    return d >= .001 ? function(n, e, r, t) {
                        for (var a = 0; a < 4; ++a) {
                            var i = u(e, r, t);
                            if (0 === i) return e;
                            e -= (o(e, r, t) - n) / i
                        }
                        return e
                    }(t, l, r, a) : 0 === d ? l : function(n, e, r, t, a) {
                        for (var u, i, c = 0;
                            (u = o(i = e + (r - e) / 2, t, a) - n) > 0 ? r = i : e = i, Math.abs(u) > 1e-7 && ++c < 10;);
                        return i
                    }(t, i, i + e, r, a)
                }
            }
        }(),
        h = (l = {
            linear: function() {
                return function(n) {
                    return n
                }
            }
        }, d = {
            Sine: function() {
                return function(n) {
                    return 1 - Math.cos(n * Math.PI / 2)
                }
            },
            Circ: function() {
                return function(n) {
                    return 1 - Math.sqrt(1 - n * n)
                }
            },
            Back: function() {
                return function(n) {
                    return n * n * (3 * n - 2)
                }
            },
            Bounce: function() {
                return function(n) {
                    for (var e, r = 4; n < ((e = Math.pow(2, --r)) - 1) / 11;);
                    return 1 / Math.pow(4, 3 - r) - 7.5625 * Math.pow((3 * e - 2) / 22 - n, 2)
                }
            },
            Elastic: function(n, e) {
                void 0 === n && (n = 1), void 0 === e && (e = .5);
                var r = a(n, 1, 10),
                    t = a(e, .1, 2);
                return function(n) {
                    return 0 === n || 1 === n ? n : -r * Math.pow(2, 10 * (n - 1)) * Math.sin((n - 1 - t / (2 * Math.PI) * Math.asin(1 / r)) * (2 * Math.PI) / t)
                }
            }
        }, ["Quad", "Cubic", "Quart", "Quint", "Expo"].forEach(function(n, e) {
            d[n] = function() {
                return function(n) {
                    return Math.pow(n, e + 2)
                }
            }
        }), Object.keys(d).forEach(function(n) {
            var e = d[n];
            l["easeIn" + n] = e, l["easeOut" + n] = function(n, r) {
                return function(t) {
                    return 1 - e(n, r)(1 - t)
                }
            }, l["easeInOut" + n] = function(n, r) {
                return function(t) {
                    return t < .5 ? e(n, r)(2 * t) / 2 : 1 - e(n, r)(-2 * t + 2) / 2
                }
            }
        }), l);

    function v(n, e) {
        if (i.fnc(n)) return n;
        var r = n.split("(")[0],
            t = h[r],
            a = c(n);
        switch (r) {
            case "spring":
                return s(n, e);
            case "cubicBezier":
                return u(p, a);
            case "steps":
                return u(f, a);
            default:
                return u(t, a)
        }
    }

    function g(n) {
        try {
            return document.querySelectorAll(n)
        } catch (n) {
            return
        }
    }

    function m(n, e) {
        for (var r = n.length, t = arguments.length >= 2 ? arguments[1] : void 0, a = [], o = 0; o < r; o++)
            if (o in n) {
                var u = n[o];
                e.call(t, u, o, n) && a.push(u)
            }
        return a
    }

    function y(n) {
        return n.reduce(function(n, e) {
            return n.concat(i.arr(e) ? y(e) : e)
        }, [])
    }

    function b(n) {
        return i.arr(n) ? n : (i.str(n) && (n = g(n) || n), n instanceof NodeList || n instanceof HTMLCollection ? [].slice.call(n) : [n])
    }

    function M(n, e) {
        return n.some(function(n) {
            return n === e
        })
    }

    function x(n) {
        var e = {};
        for (var r in n) e[r] = n[r];
        return e
    }

    function w(n, e) {
        var r = x(n);
        for (var t in n) r[t] = e.hasOwnProperty(t) ? e[t] : n[t];
        return r
    }

    function k(n, e) {
        var r = x(n);
        for (var t in e) r[t] = i.und(n[t]) ? e[t] : n[t];
        return r
    }

    function O(n) {
        return i.rgb(n) ? (r = /rgb\((\d+,\s*[\d]+,\s*[\d]+)\)/g.exec(e = n)) ? "rgba(" + r[1] + ",1)" : e : i.hex(n) ? (t = n.replace(/^#?([a-f\d])([a-f\d])([a-f\d])$/i, function(n, e, r, t) {
            return e + e + r + r + t + t
        }), a = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(t), "rgba(" + parseInt(a[1], 16) + "," + parseInt(a[2], 16) + "," + parseInt(a[3], 16) + ",1)") : i.hsl(n) ? function(n) {
            var e, r, t, a = /hsl\((\d+),\s*([\d.]+)%,\s*([\d.]+)%\)/g.exec(n) || /hsla\((\d+),\s*([\d.]+)%,\s*([\d.]+)%,\s*([\d.]+)\)/g.exec(n),
                o = parseInt(a[1], 10) / 360,
                u = parseInt(a[2], 10) / 100,
                i = parseInt(a[3], 10) / 100,
                c = a[4] || 1;

            function s(n, e, r) {
                return r < 0 && (r += 1), r > 1 && (r -= 1), r < 1 / 6 ? n + 6 * (e - n) * r : r < .5 ? e : r < 2 / 3 ? n + (e - n) * (2 / 3 - r) * 6 : n
            }
            if (0 == u) e = r = t = i;
            else {
                var f = i < .5 ? i * (1 + u) : i + u - i * u,
                    l = 2 * i - f;
                e = s(l, f, o + 1 / 3), r = s(l, f, o), t = s(l, f, o - 1 / 3)
            }
            return "rgba(" + 255 * e + "," + 255 * r + "," + 255 * t + "," + c + ")"
        }(n) : void 0;
        var e, r, t, a
    }

    function C(n) {
        var e = /[+-]?\d*\.?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?(%|px|pt|em|rem|in|cm|mm|ex|ch|pc|vw|vh|vmin|vmax|deg|rad|turn)?$/.exec(n);
        if (e) return e[1]
    }

    function B(n, e) {
        return i.fnc(n) ? n(e.target, e.id, e.total) : n
    }

    function P(n, e) {
        return n.getAttribute(e)
    }

    function I(n, e, r) {
        if (M([r, "deg", "rad", "turn"], C(e))) return e;
        var a = t.CSS[e + r];
        if (!i.und(a)) return a;
        var o = document.createElement(n.tagName),
            u = n.parentNode && n.parentNode !== document ? n.parentNode : document.body;
        u.appendChild(o), o.style.position = "absolute", o.style.width = 100 + r;
        var c = 100 / o.offsetWidth;
        u.removeChild(o);
        var s = c * parseFloat(e);
        return t.CSS[e + r] = s, s
    }

    function T(n, e, r) {
        if (e in n.style) {
            var t = e.replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase(),
                a = n.style[e] || getComputedStyle(n).getPropertyValue(t) || "0";
            return r ? I(n, a, r) : a
        }
    }

    function D(n, e) {
        return i.dom(n) && !i.inp(n) && (P(n, e) || i.svg(n) && n[e]) ? "attribute" : i.dom(n) && M(r, e) ? "transform" : i.dom(n) && "transform" !== e && T(n, e) ? "css" : null != n[e] ? "object" : void 0
    }

    function E(n) {
        if (i.dom(n)) {
            for (var e, r = n.style.transform || "", t = /(\w+)\(([^)]*)\)/g, a = new Map; e = t.exec(r);) a.set(e[1], e[2]);
            return a
        }
    }

    function F(n, e, r, t) {
        var a, u = o(e, "scale") ? 1 : 0 + (o(a = e, "translate") || "perspective" === a ? "px" : o(a, "rotate") || o(a, "skew") ? "deg" : void 0),
            i = E(n).get(e) || u;
        return r && (r.transforms.list.set(e, i), r.transforms.last = e), t ? I(n, i, t) : i
    }

    function N(n, e, r, t) {
        switch (D(n, e)) {
            case "transform":
                return F(n, e, t, r);
            case "css":
                return T(n, e, r);
            case "attribute":
                return P(n, e);
            default:
                return n[e] || 0
        }
    }

    function A(n, e) {
        var r = /^(\*=|\+=|-=)/.exec(n);
        if (!r) return n;
        var t = C(n) || 0,
            a = parseFloat(e),
            o = parseFloat(n.replace(r[0], ""));
        switch (r[0][0]) {
            case "+":
                return a + o + t;
            case "-":
                return a - o + t;
            case "*":
                return a * o + t
        }
    }

    function L(n, e) {
        if (i.col(n)) return O(n);
        if (/\s/g.test(n)) return n;
        var r = C(n),
            t = r ? n.substr(0, n.length - r.length) : n;
        return e ? t + e : t
    }

    function j(n, e) {
        return Math.sqrt(Math.pow(e.x - n.x, 2) + Math.pow(e.y - n.y, 2))
    }

    function S(n) {
        for (var e, r = n.points, t = 0, a = 0; a < r.numberOfItems; a++) {
            var o = r.getItem(a);
            a > 0 && (t += j(e, o)), e = o
        }
        return t
    }

    function q(n) {
        if (n.getTotalLength) return n.getTotalLength();
        switch (n.tagName.toLowerCase()) {
            case "circle":
                return o = n, 2 * Math.PI * P(o, "r");
            case "rect":
                return 2 * P(a = n, "width") + 2 * P(a, "height");
            case "line":
                return j({
                    x: P(t = n, "x1"),
                    y: P(t, "y1")
                }, {
                    x: P(t, "x2"),
                    y: P(t, "y2")
                });
            case "polyline":
                return S(n);
            case "polygon":
                return r = (e = n).points, S(e) + j(r.getItem(r.numberOfItems - 1), r.getItem(0))
        }
        var e, r, t, a, o
    }

    function $(n, e) {
        var r = e || {},
            t = r.el || function(n) {
                for (var e = n.parentNode; i.svg(e) && i.svg(e.parentNode);) e = e.parentNode;
                return e
            }(n),
            a = t.getBoundingClientRect(),
            o = P(t, "viewBox"),
            u = a.width,
            c = a.height,
            s = r.viewBox || (o ? o.split(" ") : [0, 0, u, c]);
        return {
            el: t,
            viewBox: s,
            x: s[0] / 1,
            y: s[1] / 1,
            w: u / s[2],
            h: c / s[3]
        }
    }

    function X(n, e) {
        function r(r) {
            void 0 === r && (r = 0);
            var t = e + r >= 1 ? e + r : 0;
            return n.el.getPointAtLength(t)
        }
        var t = $(n.el, n.svg),
            a = r(),
            o = r(-1),
            u = r(1);
        switch (n.property) {
            case "x":
                return (a.x - t.x) * t.w;
            case "y":
                return (a.y - t.y) * t.h;
            case "angle":
                return 180 * Math.atan2(u.y - o.y, u.x - o.x) / Math.PI
        }
    }

    function Y(n, e) {
        var r = /[+-]?\d*\.?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?/g,
            t = L(i.pth(n) ? n.totalLength : n, e) + "";
        return {
            original: t,
            numbers: t.match(r) ? t.match(r).map(Number) : [0],
            strings: i.str(n) || e ? t.split(r) : []
        }
    }

    function Z(n) {
        return m(n ? y(i.arr(n) ? n.map(b) : b(n)) : [], function(n, e, r) {
            return r.indexOf(n) === e
        })
    }

    function Q(n) {
        var e = Z(n);
        return e.map(function(n, r) {
            return {
                target: n,
                id: r,
                total: e.length,
                transforms: {
                    list: E(n)
                }
            }
        })
    }

    function V(n, e) {
        var r = x(e);
        if (/^spring/.test(r.easing) && (r.duration = s(r.easing)), i.arr(n)) {
            var t = n.length;
            2 === t && !i.obj(n[0]) ? n = {
                value: n
            } : i.fnc(e.duration) || (r.duration = e.duration / t)
        }
        var a = i.arr(n) ? n : [n];
        return a.map(function(n, r) {
            var t = i.obj(n) && !i.pth(n) ? n : {
                value: n
            };
            return i.und(t.delay) && (t.delay = r ? 0 : e.delay), i.und(t.endDelay) && (t.endDelay = r === a.length - 1 ? e.endDelay : 0), t
        }).map(function(n) {
            return k(n, r)
        })
    }

    function z(n, e) {
        var r = [],
            t = e.keyframes;
        for (var a in t && (e = k(function(n) {
                for (var e = m(y(n.map(function(n) {
                        return Object.keys(n)
                    })), function(n) {
                        return i.key(n)
                    }).reduce(function(n, e) {
                        return n.indexOf(e) < 0 && n.push(e), n
                    }, []), r = {}, t = function(t) {
                        var a = e[t];
                        r[a] = n.map(function(n) {
                            var e = {};
                            for (var r in n) i.key(r) ? r == a && (e.value = n[r]) : e[r] = n[r];
                            return e
                        })
                    }, a = 0; a < e.length; a++) t(a);
                return r
            }(t), e)), e) i.key(a) && r.push({
            name: a,
            tweens: V(e[a], n)
        });
        return r
    }

    function H(n, e) {
        var r;
        return n.tweens.map(function(t) {
            var a = function(n, e) {
                    var r = {};
                    for (var t in n) {
                        var a = B(n[t], e);
                        i.arr(a) && 1 === (a = a.map(function(n) {
                            return B(n, e)
                        })).length && (a = a[0]), r[t] = a
                    }
                    return r.duration = parseFloat(r.duration), r.delay = parseFloat(r.delay), r
                }(t, e),
                o = a.value,
                u = i.arr(o) ? o[1] : o,
                c = C(u),
                s = N(e.target, n.name, c, e),
                f = r ? r.to.original : s,
                l = i.arr(o) ? o[0] : f,
                d = C(l) || C(s),
                p = c || d;
            return i.und(u) && (u = f), a.from = Y(l, p), a.to = Y(A(u, l), p), a.start = r ? r.end : 0, a.end = a.start + a.delay + a.duration + a.endDelay, a.easing = v(a.easing, a.duration), a.isPath = i.pth(o), a.isColor = i.col(a.from.original), a.isColor && (a.round = 1), r = a, a
        })
    }
    var G = {
        css: function(n, e, r) {
            return n.style[e] = r
        },
        attribute: function(n, e, r) {
            return n.setAttribute(e, r)
        },
        object: function(n, e, r) {
            return n[e] = r
        },
        transform: function(n, e, r, t, a) {
            if (t.list.set(e, r), e === t.last || a) {
                var o = "";
                t.list.forEach(function(n, e) {
                    o += e + "(" + n + ") "
                }), n.style.transform = o
            }
        }
    };

    function R(n, e) {
        Q(n).forEach(function(n) {
            for (var r in e) {
                var t = B(e[r], n),
                    a = n.target,
                    o = C(t),
                    u = N(a, r, o, n),
                    i = A(L(t, o || C(u)), u),
                    c = D(a, r);
                G[c](a, r, i, n.transforms, !0)
            }
        })
    }

    function W(n, e) {
        return m(y(n.map(function(n) {
            return e.map(function(e) {
                return function(n, e) {
                    var r = D(n.target, e.name);
                    if (r) {
                        var t = H(e, n),
                            a = t[t.length - 1];
                        return {
                            type: r,
                            property: e.name,
                            animatable: n,
                            tweens: t,
                            duration: a.end,
                            delay: t[0].delay,
                            endDelay: a.endDelay
                        }
                    }
                }(n, e)
            })
        })), function(n) {
            return !i.und(n)
        })
    }

    function J(n, e) {
        var r = n.length,
            t = function(n) {
                return n.timelineOffset ? n.timelineOffset : 0
            },
            a = {};
        return a.duration = r ? Math.max.apply(Math, n.map(function(n) {
            return t(n) + n.duration
        })) : e.duration, a.delay = r ? Math.min.apply(Math, n.map(function(n) {
            return t(n) + n.delay
        })) : e.delay, a.endDelay = r ? a.duration - Math.max.apply(Math, n.map(function(n) {
            return t(n) + n.duration - n.endDelay
        })) : e.endDelay, a
    }
    var K = 0;
    var U, _ = [],
        nn = [],
        en = function() {
            function n() {
                U = requestAnimationFrame(e)
            }

            function e(e) {
                var r = _.length;
                if (r) {
                    for (var t = 0; t < r;) {
                        var a = _[t];
                        if (a.paused) {
                            var o = _.indexOf(a);
                            o > -1 && (_.splice(o, 1), r = _.length)
                        } else a.tick(e);
                        t++
                    }
                    n()
                } else U = cancelAnimationFrame(U)
            }
            return n
        }();

    function rn(r) {
        void 0 === r && (r = {});
        var t, o = 0,
            u = 0,
            i = 0,
            c = 0,
            s = null;

        function f(n) {
            var e = window.Promise && new Promise(function(n) {
                return s = n
            });
            return n.finished = e, e
        }
        var l, d, p, h, v, g, y, b, M = (d = w(n, l = r), p = w(e, l), h = z(p, l), v = Q(l.targets), g = W(v, h), y = J(g, p), b = K, K++, k(d, {
            id: b,
            children: [],
            animatables: v,
            animations: g,
            duration: y.duration,
            delay: y.delay,
            endDelay: y.endDelay
        }));
        f(M);

        function x() {
            var n = M.direction;
            "alternate" !== n && (M.direction = "normal" !== n ? "normal" : "reverse"), M.reversed = !M.reversed, t.forEach(function(n) {
                return n.reversed = M.reversed
            })
        }

        function O(n) {
            return M.reversed ? M.duration - n : n
        }

        function C() {
            o = 0, u = O(M.currentTime) * (1 / rn.speed)
        }

        function B(n, e) {
            e && e.seek(n - e.timelineOffset)
        }

        function P(n) {
            for (var e = 0, r = M.animations, t = r.length; e < t;) {
                var o = r[e],
                    u = o.animatable,
                    i = o.tweens,
                    c = i.length - 1,
                    s = i[c];
                c && (s = m(i, function(e) {
                    return n < e.end
                })[0] || s);
                for (var f = a(n - s.start - s.delay, 0, s.duration) / s.duration, l = isNaN(f) ? 1 : s.easing(f), d = s.to.strings, p = s.round, h = [], v = s.to.numbers.length, g = void 0, y = 0; y < v; y++) {
                    var b = void 0,
                        x = s.to.numbers[y],
                        w = s.from.numbers[y] || 0;
                    b = s.isPath ? X(s.value, l * x) : w + l * (x - w), p && (s.isColor && y > 2 || (b = Math.round(b * p) / p)), h.push(b)
                }
                var k = d.length;
                if (k) {
                    g = d[0];
                    for (var O = 0; O < k; O++) {
                        d[O];
                        var C = d[O + 1],
                            B = h[O];
                        isNaN(B) || (g += C ? B + C : B + " ")
                    }
                } else g = h[0];
                G[o.type](u.target, o.property, g, u.transforms), o.currentValue = g, e++
            }
        }

        function I(n) {
            M[n] && !M.passThrough && M[n](M)
        }

        function T(n) {
            var e = M.duration,
                r = M.delay,
                l = e - M.endDelay,
                d = O(n);
            M.progress = a(d / e * 100, 0, 100), M.reversePlayback = d < M.currentTime, t && function(n) {
                if (M.reversePlayback)
                    for (var e = c; e--;) B(n, t[e]);
                else
                    for (var r = 0; r < c; r++) B(n, t[r])
            }(d), !M.began && M.currentTime > 0 && (M.began = !0, I("begin")), !M.loopBegan && M.currentTime > 0 && (M.loopBegan = !0, I("loopBegin")), d <= r && 0 !== M.currentTime && P(0), (d >= l && M.currentTime !== e || !e) && P(e), d > r && d < l ? (M.changeBegan || (M.changeBegan = !0, M.changeCompleted = !1, I("changeBegin")), I("change"), P(d)) : M.changeBegan && (M.changeCompleted = !0, M.changeBegan = !1, I("changeComplete")), M.currentTime = a(d, 0, e), M.began && I("update"), n >= e && (u = 0, M.remaining && !0 !== M.remaining && M.remaining--, M.remaining ? (o = i, I("loopComplete"), M.loopBegan = !1, "alternate" === M.direction && x()) : (M.paused = !0, M.completed || (M.completed = !0, I("loopComplete"), I("complete"), !M.passThrough && "Promise" in window && (s(), f(M)))))
        }
        return M.reset = function() {
            var n = M.direction;
            M.passThrough = !1, M.currentTime = 0, M.progress = 0, M.paused = !0, M.began = !1, M.loopBegan = !1, M.changeBegan = !1, M.completed = !1, M.changeCompleted = !1, M.reversePlayback = !1, M.reversed = "reverse" === n, M.remaining = M.loop, t = M.children;
            for (var e = c = t.length; e--;) M.children[e].reset();
            (M.reversed && !0 !== M.loop || "alternate" === n && 1 === M.loop) && M.remaining++, P(M.reversed ? M.duration : 0)
        }, M.set = function(n, e) {
            return R(n, e), M
        }, M.tick = function(n) {
            i = n, o || (o = i), T((i + (u - o)) * rn.speed)
        }, M.seek = function(n) {
            T(O(n))
        }, M.pause = function() {
            M.paused = !0, C()
        }, M.play = function() {
            M.paused && (M.completed && M.reset(), M.paused = !1, _.push(M), C(), U || en())
        }, M.reverse = function() {
            x(), C()
        }, M.restart = function() {
            M.reset(), M.play()
        }, M.reset(), M.autoplay && M.play(), M
    }

    function tn(n, e) {
        for (var r = e.length; r--;) M(n, e[r].animatable.target) && e.splice(r, 1)
    }
    return "undefined" != typeof document && document.addEventListener("visibilitychange", function() {
        document.hidden ? (_.forEach(function(n) {
            return n.pause()
        }), nn = _.slice(0), rn.running = _ = []) : nn.forEach(function(n) {
            return n.play()
        })
    }), rn.version = "3.1.0", rn.speed = 1, rn.running = _, rn.remove = function(n) {
        for (var e = Z(n), r = _.length; r--;) {
            var t = _[r],
                a = t.animations,
                o = t.children;
            tn(e, a);
            for (var u = o.length; u--;) {
                var i = o[u],
                    c = i.animations;
                tn(e, c), c.length || i.children.length || o.splice(u, 1)
            }
            a.length || o.length || t.pause()
        }
    }, rn.get = N, rn.set = R, rn.convertPx = I, rn.path = function(n, e) {
        var r = i.str(n) ? g(n)[0] : n,
            t = e || 100;
        return function(n) {
            return {
                property: n,
                el: r,
                svg: $(r),
                totalLength: q(r) * (t / 100)
            }
        }
    }, rn.setDashoffset = function(n) {
        var e = q(n);
        return n.setAttribute("stroke-dasharray", e), e
    }, rn.stagger = function(n, e) {
        void 0 === e && (e = {});
        var r = e.direction || "normal",
            t = e.easing ? v(e.easing) : null,
            a = e.grid,
            o = e.axis,
            u = e.from || 0,
            c = "first" === u,
            s = "center" === u,
            f = "last" === u,
            l = i.arr(n),
            d = l ? parseFloat(n[0]) : parseFloat(n),
            p = l ? parseFloat(n[1]) : 0,
            h = C(l ? n[1] : n) || 0,
            g = e.start || 0 + (l ? d : 0),
            m = [],
            y = 0;
        return function(n, e, i) {
            if (c && (u = 0), s && (u = (i - 1) / 2), f && (u = i - 1), !m.length) {
                for (var v = 0; v < i; v++) {
                    if (a) {
                        var b = s ? (a[0] - 1) / 2 : u % a[0],
                            M = s ? (a[1] - 1) / 2 : Math.floor(u / a[0]),
                            x = b - v % a[0],
                            w = M - Math.floor(v / a[0]),
                            k = Math.sqrt(x * x + w * w);
                        "x" === o && (k = -x), "y" === o && (k = -w), m.push(k)
                    } else m.push(Math.abs(u - v));
                    y = Math.max.apply(Math, m)
                }
                t && (m = m.map(function(n) {
                    return t(n / y) * y
                })), "reverse" === r && (m = m.map(function(n) {
                    return o ? n < 0 ? -1 * n : -n : Math.abs(y - n)
                }))
            }
            return g + (l ? (p - d) / y : d) * (Math.round(100 * m[e]) / 100) + h
        }
    }, rn.timeline = function(n) {
        void 0 === n && (n = {});
        var r = rn(n);
        return r.duration = 0, r.add = function(t, a) {
            var o = _.indexOf(r),
                u = r.children;

            function c(n) {
                n.passThrough = !0
            }
            o > -1 && _.splice(o, 1);
            for (var s = 0; s < u.length; s++) c(u[s]);
            var f = k(t, w(e, n));
            f.targets = f.targets || n.targets;
            var l = r.duration;
            f.autoplay = !1, f.direction = r.direction, f.timelineOffset = i.und(a) ? l : A(a, l), c(r), r.seek(f.timelineOffset);
            var d = rn(f);
            c(d), u.push(d);
            var p = J(u, n);
            return r.delay = p.delay, r.endDelay = p.endDelay, r.duration = p.duration, r.seek(0), r.reset(), r.autoplay && r.play(), r
        }, r
    }, rn.easing = v, rn.penner = h, rn.random = function(n, e) {
        return Math.floor(Math.random() * (e - n + 1)) + n
    }, rn
});