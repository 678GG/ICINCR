$(document).ready(function() {
    $(document).on('click', '.pageArticlesContainer .article-items-loadmore .load-more', function(e) {
        e.preventDefault();
        var $loadmoreButton = $(this);
        var pageId = $loadmoreButton.attr('data-page-id');
        var pageIndex = $loadmoreButton.attr('data-page-index');
        if (!$('html').hasClass('admin-mode')) {
            data = {
                pageId: pageId,
                pageIndex: pageIndex
            };
            api.publicCall('default', 'Article', 'loadMore', JSON.stringify(data), function(response) {
                if (response.type == 1) {
                    $('.pageArticlesContainer .article-items').append(response.data.html);
                    $loadmoreButton.attr('data-article-index', response.data.nextPageIndex);
                    if (response.data.loadmore) {
                        $loadmoreButton.parent().removeClass('hide')
                    } else {
                        $loadmoreButton.parent().addClass('hide')
                    }
                }
            })
        }
    })
})

function getCookie(name) {
    var re = new RegExp(name + "=([^;]+)");
    var value = re.exec(document.cookie);
    return (value != null) ? unescape(value[1]) : null
}
/*! validatorjs - v3.11.0 -  - 2016-12-22 */
(function(f) {
    if (typeof exports === "object" && typeof module !== "undefined") {
        module.exports = f()
    } else if (typeof define === "function" && define.amd) {
        define([], f)
    } else {
        var g;
        if (typeof window !== "undefined") {
            g = window
        } else if (typeof global !== "undefined") {
            g = global
        } else if (typeof self !== "undefined") {
            g = self
        } else {
            g = this
        }
        g.Validator = f()
    }
})(function() {
    var define, module, exports;
    return (function e(t, n, r) {
        function s(o, u) {
            if (!n[o]) {
                if (!t[o]) {
                    var a = typeof require == "function" && require;
                    if (!u && a) return a(o, !0);
                    if (i) return i(o, !0);
                    var f = new Error("Cannot find module '" + o + "'");
                    throw f.code = "MODULE_NOT_FOUND", f
                }
                var l = n[o] = {
                    exports: {}
                };
                t[o][0].call(l.exports, function(e) {
                    var n = t[o][1][e];
                    return s(n ? n : e)
                }, l, l.exports, e, t, n, r)
            }
            return n[o].exports
        }
        var i = typeof require == "function" && require;
        for (var o = 0; o < r.length; o++) s(r[o]);
        return s
    })({
        1: [function(require, module, exports) {
            function AsyncResolvers(onFailedOne, onResolvedAll) {
                this.onResolvedAll = onResolvedAll;
                this.onFailedOne = onFailedOne;
                this.resolvers = {};
                this.resolversCount = 0;
                this.passed = [];
                this.failed = [];
                this.firing = !1
            }
            AsyncResolvers.prototype = {
                add: function(rule) {
                    var index = this.resolversCount;
                    this.resolvers[index] = rule;
                    this.resolversCount++;
                    return index
                },
                resolve: function(index) {
                    var rule = this.resolvers[index];
                    if (rule.passes === !0) {
                        this.passed.push(rule)
                    } else if (rule.passes === !1) {
                        this.failed.push(rule);
                        this.onFailedOne(rule)
                    }
                    this.fire()
                },
                isAllResolved: function() {
                    return (this.passed.length + this.failed.length) === this.resolversCount
                },
                fire: function() {
                    if (!this.firing) {
                        return
                    }
                    if (this.isAllResolved()) {
                        this.onResolvedAll(this.failed.length === 0)
                    }
                },
                enableFiring: function() {
                    this.firing = !0
                }
            };
            module.exports = AsyncResolvers
        }, {}],
        2: [function(require, module, exports) {
            var replacements = {
                between: function(template, rule) {
                    var parameters = rule.getParameters();
                    return this._replacePlaceholders(rule, template, {
                        min: parameters[0],
                        max: parameters[1]
                    })
                },
                required_if: function(template, rule) {
                    var parameters = rule.getParameters();
                    return this._replacePlaceholders(rule, template, {
                        other: parameters[0],
                        value: parameters[1]
                    })
                },
                required_unless: function(template, rule) {
                    var parameters = rule.getParameters();
                    return this._replacePlaceholders(rule, template, {
                        other: parameters[0],
                        value: parameters[1]
                    })
                },
                required_with: function(template, rule) {
                    var parameters = rule.getParameters();
                    return this._replacePlaceholders(rule, template, {
                        field: parameters[0]
                    })
                },
                required_with_all: function(template, rule) {
                    var parameters = rule.getParameters();
                    return this._replacePlaceholders(rule, template, {
                        fields: parameters.join(', ')
                    })
                },
                required_without: function(template, rule) {
                    var parameters = rule.getParameters();
                    return this._replacePlaceholders(rule, template, {
                        field: parameters[0]
                    })
                },
                required_without_all: function(template, rule) {
                    var parameters = rule.getParameters();
                    return this._replacePlaceholders(rule, template, {
                        fields: parameters.join(', ')
                    })
                }
            };

            function formatter(attribute) {
                return attribute.replace(/[_\[]/g, ' ').replace(/]/g, '')
            }
            module.exports = {
                replacements: replacements,
                formatter: formatter
            }
        }, {}],
        3: [function(require, module, exports) {
            var Errors = function() {
                this.errors = {}
            };
            Errors.prototype = {
                constructor: Errors,
                add: function(attribute, message) {
                    if (!this.has(attribute)) {
                        this.errors[attribute] = []
                    }
                    if (this.errors[attribute].indexOf(message) === -1) {
                        this.errors[attribute].push(message)
                    }
                },
                get: function(attribute) {
                    if (this.has(attribute)) {
                        return this.errors[attribute]
                    }
                    return []
                },
                first: function(attribute) {
                    if (this.has(attribute)) {
                        return this.errors[attribute][0]
                    }
                    return !1
                },
                all: function() {
                    return this.errors
                },
                has: function(attribute) {
                    if (this.errors.hasOwnProperty(attribute)) {
                        return !0
                    }
                    return !1
                }
            };
            module.exports = Errors
        }, {}],
        4: [function(require, module, exports) {
            var Messages = require('./messages');
            require('./lang/en');
            var container = {
                messages: {},
                _set: function(lang, rawMessages) {
                    this.messages[lang] = rawMessages
                },
                _setRuleMessage: function(lang, attribute, message) {
                    this._load(lang);
                    if (message === undefined) {
                        message = this.messages[lang].def
                    }
                    this.messages[lang][attribute] = message
                },
                _load: function(lang) {
                    if (!this.messages[lang]) {
                        var rawMessages = require('./lang/' + lang);
                        this._set(lang, rawMessages)
                    }
                },
                _get: function(lang) {
                    this._load(lang);
                    return this.messages[lang]
                },
                _make: function(lang) {
                    this._load(lang);
                    return new Messages(lang, this.messages[lang])
                }
            };
            module.exports = container
        }, {
            "./lang/en": 5,
            "./messages": 6
        }],
        5: [function(require, module, exports) {
            module.exports = {
                accepted: 'The :attribute must be accepted.',
                alpha: 'The :attribute field must contain only alphabetic characters.',
                alpha_dash: 'The :attribute field may only contain alpha-numeric characters, as well as dashes and underscores.',
                alpha_num: 'The :attribute field must be alphanumeric.',
                between: 'The :attribute field must be between :min and :max.',
                confirmed: 'The :attribute confirmation does not match.',
                email: 'The :attribute format is invalid.',
                date: 'The :attribute is not a valid date format',
                def: 'The :attribute attribute has errors.',
                digits: 'The :attribute must be :digits digits.',
                different: 'The :attribute and :different must be different.',
                'in': 'The selected :attribute is invalid.',
                integer: 'The :attribute must be an integer.',
                min: {
                    numeric: 'The :attribute must be at least :min.',
                    string: 'The :attribute must be at least :min characters.'
                },
                max: {
                    numeric: 'The :attribute may not be greater than :max.',
                    string: 'The :attribute may not be greater than :max characters.'
                },
                not_in: 'The selected :attribute is invalid.',
                numeric: 'The :attribute must be a number.',
                required: 'The :attribute field is required.',
                required_if: 'The :attribute field is required when :other is :value.',
                required_unless: 'The :attribute field is required when :other is not :value.',
                required_with: 'The :attribute field is required when :field is not empty.',
                required_with_all: 'The :attribute field is required when :fields are not empty.',
                required_without: 'The :attribute field is required when :field is empty.',
                required_without_all: 'The :attribute field is required when :fields are empty.',
                same: 'The :attribute and :same fields must match.',
                size: {
                    numeric: 'The :attribute must be :size.',
                    string: 'The :attribute must be :size characters.'
                },
                string: 'The :attribute must be a string.',
                url: 'The :attribute format is invalid.',
                regex: 'The :attribute format is invalid',
                attributes: {}
            }
        }, {}],
        6: [function(require, module, exports) {
            var Attributes = require('./attributes');
            var Messages = function(lang, messages) {
                this.lang = lang;
                this.messages = messages;
                this.customMessages = {};
                this.attributeNames = {}
            };
            Messages.prototype = {
                constructor: Messages,
                _setCustom: function(customMessages) {
                    this.customMessages = customMessages || {}
                },
                _setAttributeNames: function(attributes) {
                    this.attributeNames = attributes
                },
                _setAttributeFormatter: function(func) {
                    this.attributeFormatter = func
                },
                _getAttributeName: function(attribute) {
                    var name = attribute;
                    if (this.attributeNames.hasOwnProperty(attribute)) {
                        return this.attributeNames[attribute]
                    } else if (this.messages.attributes.hasOwnProperty(attribute)) {
                        name = this.messages.attributes[attribute]
                    }
                    if (this.attributeFormatter) {
                        name = this.attributeFormatter(name)
                    }
                    return name
                },
                all: function() {
                    return this.messages
                },
                render: function(rule) {
                    if (rule.customMessage) {
                        return rule.customMessage
                    }
                    var template = this._getTemplate(rule);
                    var message;
                    if (Attributes.replacements[rule.name]) {
                        message = Attributes.replacements[rule.name].apply(this, [template, rule])
                    } else {
                        message = this._replacePlaceholders(rule, template, {})
                    }
                    return message
                },
                _getTemplate: function(rule) {
                    var messages = this.messages;
                    var template = messages.def;
                    var customMessages = this.customMessages;
                    var formats = [rule.name + '.' + rule.attribute, rule.name];
                    for (var i = 0, format; i < formats.length; i++) {
                        format = formats[i];
                        if (customMessages.hasOwnProperty(format)) {
                            template = customMessages[format];
                            break
                        } else if (messages.hasOwnProperty(format)) {
                            template = messages[format];
                            break
                        }
                    }
                    if (typeof template === 'object') {
                        template = template[rule._getValueType()]
                    }
                    return template
                },
                _replacePlaceholders: function(rule, template, data) {
                    var message, attribute;
                    data.attribute = this._getAttributeName(rule.attribute);
                    data[rule.name] = rule.getParameters().join(',');
                    if (typeof template === 'string' && typeof data === 'object') {
                        message = template;
                        for (attribute in data) {
                            message = message.replace(new RegExp(':' + attribute, 'g'), data[attribute])
                        }
                    }
                    return message
                }
            };
            module.exports = Messages
        }, {
            "./attributes": 2
        }],
        7: [function(require, module, exports) {
            var rules = {
                required: function(val) {
                    var str;
                    if (val === undefined || val === null) {
                        return !1
                    }
                    str = String(val).replace(/\s/g, "");
                    return str.length > 0 ? !0 : !1
                },
                required_if: function(val, req, attribute) {
                    req = this.getParameters();
                    if (this.validator._objectPath(this.validator.input, req[0]) === req[1]) {
                        return this.validator.getRule('required').validate(val)
                    }
                    return !0
                },
                required_unless: function(val, req, attribute) {
                    req = this.getParameters();
                    if (this.validator._objectPath(this.validator.input, req[0]) !== req[1]) {
                        return this.validator.getRule('required').validate(val)
                    }
                    return !0
                },
                required_with: function(val, req, attribute) {
                    if (this.validator._objectPath(this.validator.input, req)) {
                        return this.validator.getRule('required').validate(val)
                    }
                    return !0
                },
                required_with_all: function(val, req, attribute) {
                    req = this.getParameters();
                    for (var i = 0; i < req.length; i++) {
                        if (!this.validator._objectPath(this.validator.input, req[i])) {
                            return !0
                        }
                    }
                    return this.validator.getRule('required').validate(val)
                },
                required_without: function(val, req, attribute) {
                    if (this.validator._objectPath(this.validator.input, req)) {
                        return !0
                    }
                    return this.validator.getRule('required').validate(val)
                },
                required_without_all: function(val, req, attribute) {
                    req = this.getParameters();
                    for (var i = 0; i < req.length; i++) {
                        if (this.validator._objectPath(this.validator.input, req[i])) {
                            return !0
                        }
                    }
                    return this.validator.getRule('required').validate(val)
                },
                'boolean': function(val) {
                    return (val === !0 || val === !1 || val === 0 || val === 1 || val === '0' || val === '1' || val === 'true' || val === 'false')
                },
                'numberWithCommon': function(val) {
                    return /^[0-9]\d*((\.|,)\d+)?$/.test(val)
                },
                size: function(val, req, attribute) {
                    if (val) {
                        req = parseFloat(req);
                        var size = this.getSize();
                        return size === req
                    }
                    return !0
                },
                string: function(val, req, attribute) {
                    return typeof val === 'string'
                },
                sometimes: function(val) {
                    return !0
                },
                min: function(val, req, attribute) {
                    var size = this.getSize();
                    return size >= req
                },
                max: function(val, req, attribute) {
                    var size = this.getSize();
                    return size <= req
                },
                between: function(val, req, attribute) {
                    req = this.getParameters();
                    var size = this.getSize();
                    var min = parseFloat(req[0], 10);
                    var max = parseFloat(req[1], 10);
                    return size >= min && size <= max
                },
                email: function(val) {
                    var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
                    return re.test(val)
                },
                numeric: function(val) {
                    var num;
                    num = Number(val);
                    if (typeof num === 'number' && !isNaN(num) && typeof val !== 'boolean') {
                        return !0
                    } else {
                        return !1
                    }
                },
                array: function(val) {
                    return val instanceof Array
                },
                url: function(url) {
                    return (/^https?:\/\/\S+/).test(url)
                },
                alpha: function(val) {
                    return (/^[a-zA-Z]+$/).test(val)
                },
                alpha_dash: function(val) {
                    return (/^[a-zA-Z0-9_\-]+$/).test(val)
                },
                alpha_num: function(val) {
                    return (/^[a-zA-Z0-9]+$/).test(val)
                },
                same: function(val, req) {
                    var val1 = this.validator.input[req];
                    var val2 = val;
                    if (val1 === val2) {
                        return !0
                    }
                    return !1
                },
                different: function(val, req) {
                    var val1 = this.validator.input[req];
                    var val2 = val;
                    if (val1 !== val2) {
                        return !0
                    }
                    return !1
                },
                "in": function(val, req) {
                    var list, i;
                    if (val) {
                        list = req.split(',')
                    }
                    if (val && !(val instanceof Array)) {
                        val = String(val);
                        for (i = 0; i < list.length; i++) {
                            if (val === list[i]) {
                                return !0
                            }
                        }
                        return !1
                    }
                    if (val && val instanceof Array) {
                        for (i = 0; i < val.length; i++) {
                            if (list.indexOf(val[i]) < 0) {
                                return !1
                            }
                        }
                    }
                    return !0
                },
                not_in: function(val, req) {
                    var list = req.split(',');
                    var len = list.length;
                    var returnVal = !0;
                    val = String(val);
                    for (var i = 0; i < len; i++) {
                        if (val === list[i]) {
                            returnVal = !1;
                            break
                        }
                    }
                    return returnVal
                },
                accepted: function(val) {
                    if (val === 'on' || val === 'yes' || val === 1 || val === '1' || val === !0) {
                        return !0
                    }
                    return !1
                },
                confirmed: function(val, req, key) {
                    var confirmedKey = key + '_confirmation';
                    if (this.validator.input[confirmedKey] === val) {
                        return !0
                    }
                    return !1
                },
                integer: function(val) {
                    return String(parseInt(val, 10)) === String(val)
                },
                digits: function(val, req) {
                    var numericRule = this.validator.getRule('numeric');
                    if (numericRule.validate(val) && String(val).length === parseInt(req)) {
                        return !0
                    }
                    return !1
                },
                regex: function(val, req) {
                    var mod = /[g|i|m]{1,3}$/;
                    var flag = req.match(mod);
                    flag = flag ? flag[0] : "";
                    req = req.replace(mod, "").slice(1, -1);
                    req = new RegExp(req, flag);
                    return !!val.match(req)
                },
                date: function(val) {
                    var valid = (new Date(val).toString()) !== 'Invalid Date';
                    if (typeof val === 'number') {
                        return val.toString().length === 12 && valid
                    }
                    return valid
                }
            };

            function Rule(name, fn, async) {
                this.name = name;
                this.fn = fn;
                this.passes = null;
                this.customMessage = undefined;
                this.async = async
            }
            Rule.prototype = {
                validate: function(inputValue, ruleValue, attribute, callback) {
                    var _this = this;
                    this._setValidatingData(attribute, inputValue, ruleValue);
                    if (typeof callback === 'function') {
                        this.callback = callback;
                        var handleResponse = function(passes, message) {
                            _this.response(passes, message)
                        };
                        if (this.async) {
                            return this.fn.apply(this, [inputValue, ruleValue, attribute, handleResponse])
                        } else {
                            return handleResponse(this.fn.apply(this, [inputValue, ruleValue, attribute]))
                        }
                    }
                    return this.fn.apply(this, [inputValue, ruleValue, attribute])
                },
                _setValidatingData: function(attribute, inputValue, ruleValue) {
                    this.attribute = attribute;
                    this.inputValue = inputValue;
                    this.ruleValue = ruleValue
                },
                getParameters: function() {
                    return this.ruleValue ? this.ruleValue.split(',') : []
                },
                getSize: function() {
                    var value = this.inputValue;
                    if (value instanceof Array) {
                        return value.length
                    }
                    if (typeof value === 'number') {
                        return value
                    }
                    if (this.validator._hasNumericRule(this.attribute)) {
                        return parseFloat(value, 10)
                    }
                    return value.length
                },
                _getValueType: function() {
                    if (typeof this.inputValue === 'number' || this.validator._hasNumericRule(this.attribute)) {
                        return 'numeric'
                    }
                    return 'string'
                },
                response: function(passes, message) {
                    this.passes = (passes === undefined || passes === !0);
                    this.customMessage = message;
                    this.callback(this.passes, message)
                },
                setValidator: function(validator) {
                    this.validator = validator
                }
            };
            var manager = {
                asyncRules: [],
                implicitRules: ['required', 'required_if', 'required_unless', 'required_with', 'required_with_all', 'required_without', 'required_without_all', 'accepted'],
                make: function(name, validator) {
                    var async = this.isAsync(name);
                    var rule = new Rule(name, rules[name], async);
                    rule.setValidator(validator);
                    return rule
                },
                isAsync: function(name) {
                    for (var i = 0, len = this.asyncRules.length; i < len; i++) {
                        if (this.asyncRules[i] === name) {
                            return !0
                        }
                    }
                    return !1
                },
                isImplicit: function(name) {
                    return this.implicitRules.indexOf(name) > -1
                },
                register: function(name, fn) {
                    rules[name] = fn
                },
                registerAsync: function(name, fn) {
                    this.register(name, fn);
                    this.asyncRules.push(name)
                }
            };
            module.exports = manager
        }, {}],
        8: [function(require, module, exports) {
            var Rules = require('./rules');
            var Lang = require('./lang');
            var Errors = require('./errors');
            var Attributes = require('./attributes');
            var AsyncResolvers = require('./async');
            var Validator = function(input, rules, customMessages) {
                var lang = Validator.getDefaultLang();
                this.input = input;
                this.messages = Lang._make(lang);
                this.messages._setCustom(customMessages);
                this.setAttributeFormatter(Validator.prototype.attributeFormatter);
                this.errors = new Errors();
                this.errorCount = 0;
                this.hasAsync = !1;
                this.rules = this._parseRules(rules)
            };
            Validator.prototype = {
                constructor: Validator,
                lang: 'en',
                numericRules: ['integer', 'numeric'],
                attributeFormatter: Attributes.formatter,
                check: function() {
                    var self = this;
                    for (var attribute in this.rules) {
                        var attributeRules = this.rules[attribute];
                        var inputValue = this._objectPath(this.input, attribute);
                        if (this._hasRule(attribute, ['sometimes']) && !this._suppliedWithData(attribute)) {
                            continue
                        }
                        for (var i = 0, len = attributeRules.length, rule, ruleOptions, rulePassed; i < len; i++) {
                            ruleOptions = attributeRules[i];
                            rule = this.getRule(ruleOptions.name);
                            if (!this._isValidatable(rule, inputValue)) {
                                continue
                            }
                            rulePassed = rule.validate(inputValue, ruleOptions.value, attribute);
                            if (!rulePassed) {
                                this._addFailure(rule)
                            }
                            if (this._shouldStopValidating(attribute, rulePassed)) {
                                break
                            }
                        }
                    }
                    return this.errorCount === 0
                },
                checkAsync: function(passes, fails) {
                    var _this = this;
                    passes = passes || function() {};
                    fails = fails || function() {};
                    var failsOne = function(rule, message) {
                        _this._addFailure(rule, message)
                    };
                    var resolvedAll = function(allPassed) {
                        if (allPassed) {
                            passes()
                        } else {
                            fails()
                        }
                    };
                    var asyncResolvers = new AsyncResolvers(failsOne, resolvedAll);
                    var validateRule = function(inputValue, ruleOptions, attribute, rule) {
                        return function() {
                            var resolverIndex = asyncResolvers.add(rule);
                            rule.validate(inputValue, ruleOptions.value, attribute, function() {
                                asyncResolvers.resolve(resolverIndex)
                            })
                        }
                    };
                    for (var attribute in this.rules) {
                        var attributeRules = this.rules[attribute];
                        var inputValue = this._objectPath(this.input, attribute);
                        if (this._hasRule(attribute, ['sometimes']) && !this._suppliedWithData(attribute)) {
                            continue
                        }
                        for (var i = 0, len = attributeRules.length, rule, ruleOptions; i < len; i++) {
                            ruleOptions = attributeRules[i];
                            rule = this.getRule(ruleOptions.name);
                            if (!this._isValidatable(rule, inputValue)) {
                                continue
                            }
                            validateRule(inputValue, ruleOptions, attribute, rule)()
                        }
                    }
                    asyncResolvers.enableFiring();
                    asyncResolvers.fire()
                },
                _addFailure: function(rule) {
                    var msg = this.messages.render(rule);
                    this.errors.add(rule.attribute, msg);
                    this.errorCount++
                },
                _flattenObject: function(obj) {
                    var flattened = {};

                    function recurse(current, property) {
                        if (!property && Object.getOwnPropertyNames(current).length === 0) {
                            return
                        }
                        if (Object(current) !== current || Array.isArray(current)) {
                            flattened[property] = current
                        } else {
                            var isEmpty = !0;
                            for (var p in current) {
                                isEmpty = !1;
                                recurse(current[p], property ? property + "." + p : p)
                            }
                            if (isEmpty) {
                                flattened[property] = {}
                            }
                        }
                    }
                    if (obj) {
                        recurse(obj)
                    }
                    return flattened
                },
                _objectPath: function(obj, path) {
                    if (Object.prototype.hasOwnProperty.call(obj, path)) {
                        return obj[path]
                    }
                    var keys = path.replace(/\[(\w+)\]/g, ".$1").replace(/^\./, "").split(".");
                    var copy = {};
                    for (var attr in obj) {
                        if (Object.prototype.hasOwnProperty.call(obj, attr)) {
                            copy[attr] = obj[attr]
                        }
                    }
                    for (var i = 0, l = keys.length; i < l; i++) {
                        if (Object.hasOwnProperty.call(copy, keys[i])) {
                            copy = copy[keys[i]]
                        } else {
                            return
                        }
                    }
                    return copy
                },
                _parseRules: function(rules) {
                    var parsedRules = {};
                    rules = this._flattenObject(rules);
                    for (var attribute in rules) {
                        var rulesArray = rules[attribute];
                        var attributeRules = [];
                        let regexRule = '';
                        if (typeof rulesArray === 'string') {
                            let regexIndex = rulesArray.indexOf('regex:');
                            let regexLastIndex = rulesArray.lastIndexOf('/');
                            if (regexIndex + 1) {
                                regexRule = rulesArray.slice(regexIndex + 6, regexLastIndex + 1);
                                if (regexRule) {
                                    rulesArray = rulesArray.replace(regexRule, '')
                                }
                            }
                            rulesArray = rulesArray.split('|')
                        }
                        for (var i = 0, len = rulesArray.length, rule; i < len; i++) {
                            if (rulesArray[i].indexOf('regex') + 1 && regexRule) {
                                rulesArray[i] = rulesArray[i].replace('regex:', '');
                                rulesArray[i] = `regex:${regexRule}${rulesArray[i]}`
                            }
                            rule = this._extractRuleAndRuleValue(rulesArray[i]);
                            if (Rules.isAsync(rule.name)) {
                                this.hasAsync = !0
                            }
                            attributeRules.push(rule)
                        }
                        parsedRules[attribute] = attributeRules
                    }
                    return parsedRules
                },
                _suppliedWithData: function(attribute) {
                    return this.input.hasOwnProperty(attribute)
                },
                _extractRuleAndRuleValue: function(ruleString) {
                    var rule = {},
                        ruleArray;
                    rule.name = ruleString;
                    if (ruleString.indexOf(':') >= 0) {
                        ruleArray = ruleString.split(':');
                        rule.name = ruleArray[0];
                        rule.value = ruleArray.slice(1).join(":")
                    }
                    return rule
                },
                _hasRule: function(attribute, findRules) {
                    var rules = this.rules[attribute] || [];
                    for (var i = 0, len = rules.length; i < len; i++) {
                        if (findRules.indexOf(rules[i].name) > -1) {
                            return !0
                        }
                    }
                    return !1
                },
                _hasNumericRule: function(attribute) {
                    return this._hasRule(attribute, this.numericRules)
                },
                _isValidatable: function(rule, value) {
                    if (Rules.isImplicit(rule.name)) {
                        return !0
                    }
                    return this.getRule('required').validate(value)
                },
                _shouldStopValidating: function(attribute, rulePassed) {
                    var stopOnAttributes = this.stopOnAttributes;
                    if (stopOnAttributes === !1 || rulePassed === !0) {
                        return !1
                    }
                    if (stopOnAttributes instanceof Array) {
                        return stopOnAttributes.indexOf(attribute) > -1
                    }
                    return !0
                },
                setAttributeNames: function(attributes) {
                    this.messages._setAttributeNames(attributes)
                },
                setAttributeFormatter: function(func) {
                    this.messages._setAttributeFormatter(func)
                },
                getRule: function(name) {
                    return Rules.make(name, this)
                },
                stopOnError: function(attributes) {
                    this.stopOnAttributes = attributes
                },
                passes: function(passes) {
                    var async = this._checkAsync('passes', passes);
                    if (async) {
                        return this.checkAsync(passes)
                    }
                    return this.check()
                },
                fails: function(fails) {
                    var async = this._checkAsync('fails', fails);
                    if (async) {
                        return this.checkAsync(function() {}, fails)
                    }
                    return !this.check()
                },
                _checkAsync: function(funcName, callback) {
                    var hasCallback = typeof callback === 'function';
                    if (this.hasAsync && !hasCallback) {
                        throw funcName + ' expects a callback when async rules are being tested.'
                    }
                    return this.hasAsync || hasCallback
                }
            };
            Validator.setMessages = function(lang, messages) {
                Lang._set(lang, messages);
                return this
            };
            Validator.getMessages = function(lang) {
                return Lang._get(lang)
            };
            Validator.useLang = function(lang) {
                this.prototype.lang = lang
            };
            Validator.getDefaultLang = function() {
                return this.prototype.lang
            };
            Validator.setAttributeFormatter = function(func) {
                this.prototype.attributeFormatter = func
            };
            Validator.stopOnError = function(attributes) {
                this.prototype.stopOnAttributes = attributes
            };
            Validator.register = function(name, fn, message) {
                var lang = Validator.getDefaultLang();
                Rules.register(name, fn);
                Lang._setRuleMessage(lang, name, message)
            };
            Validator.registerAsync = function(name, fn, message) {
                var lang = Validator.getDefaultLang();
                Rules.registerAsync(name, fn);
                Lang._setRuleMessage(lang, name, message)
            };
            module.exports = Validator
        }, {
            "./async": 1,
            "./attributes": 2,
            "./errors": 3,
            "./lang": 4,
            "./rules": 7
        }]
    }, {}, [8])(8)
})

function toggleModuleAccordion(e) {
    if (e.type === "click" || e.keyCode === 13) {
        var minusIcon = `
            <svg width="32" height="32" viewBox="0 0 32 32" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                <g clip-path="url(#clip0_153_328)">
                    <path
                        d="M-1.06665 16.0001C-1.06665 14.1601 0.426683 12.6667 2.26668 12.6667H29.7333C31.5733 12.6667 33.0667 14.1601 33.0667 16.0001C33.0667 17.8401 31.5733 19.3334 29.7333 19.3334H2.26668C0.426683 19.3334 -1.06665 17.8401 -1.06665 16.0001V16.0001Z"
                    />
                </g>
                <defs>
                    <clipPath id="clip0_153_328">
                        <rect width="32" height="32" />
                    </clipPath>
                </defs>
            </svg>
        `;
        var plusIcon = `
            <svg width="32" height="32" viewBox="0 0 32 32" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                <g clip-path="url(#clip0_153_430)">
                    <path
                        d="M29.7333 12.6667H19.3334V2.26668C19.3334 0.426683 17.84 -1.06665 16 -1.06665C14.16 -1.06665 12.6667 0.426683 12.6667 2.26668V12.6667H2.26668C0.426683 12.6667 -1.06665 14.16 -1.06665 16C-1.06665 17.84 0.426683 19.3334 2.26668 19.3334H12.6667V29.7333C12.6667 31.5733 14.16 33.0667 16 33.0667C17.84 33.0667 19.3334 31.5733 19.3334 29.7333V19.3334H29.7333C31.5733 19.3334 33.0667 17.84 33.0667 16C33.0667 14.16 31.5733 12.6667 29.7333 12.6667Z"
                    />
                </g>
                <defs>
                    <clipPath id="clip0_153_430">
                        <rect width="32" height="32" />
                    </clipPath>
                </defs>
            </svg>
        `;
        var customMinusClass = 'custom-icon-closer';
        var customPlusClass = 'custom-icon-opener';
        var accordionElement = e.target.closest('.accordion-item');
        var accordionDescription = accordionElement.querySelector('.accordion-item-description');
        var accordionSwitcher = accordionElement.querySelector('.icon-container .accordion-minus-plus');
        var accordionSwitcherCustom = accordionElement.querySelector('.icon-container span.custom-icon');
        if (accordionDescription.classList.contains('collapsed')) {
            accordionDescription.classList.remove('collapsed');
            $(e.target).closest('.accordion-item').find('.description-container').slideUp(200, 'linear');
            if (accordionSwitcher) {
                accordionSwitcher.innerHTML = plusIcon
            }
            if (accordionSwitcherCustom) {
                accordionSwitcherCustom.classList.add(customPlusClass);
                accordionSwitcherCustom.classList.remove(customMinusClass)
            }
        } else if (!accordionDescription.classList.contains('collapsed')) {
            accordionDescription.classList.add('collapsed');
            $(e.target).closest('.accordion-item').find('.description-container').slideDown(200, 'linear');
            if (accordionSwitcher) {
                accordionSwitcher.innerHTML = minusIcon
            }
            if (accordionSwitcherCustom) {
                accordionSwitcherCustom.classList.add(customMinusClass);
                accordionSwitcherCustom.classList.remove(customPlusClass)
            }
        }
    }
}
(function() {
    function getArticles(button) {
        let $loadmoreButton = button,
            moduleId = $loadmoreButton.getAttribute('data-module-id'),
            pageIndex = $loadmoreButton.getAttribute('data-page-index'),
            categoryId = $loadmoreButton.getAttribute('data-category-id'),
            orderBy = $loadmoreButton.getAttribute('data-orderBy'),
            paginationType = $loadmoreButton.getAttribute('data-pagination-type'),
            articleSpinner = document.querySelector('[data-module-id="' + moduleId + '"] .article-loading .article-spinner');
        $loadmoreButton.parentElement.classList.add('hide');
        articleSpinner.classList.add('loading-spinner');
        if (!document.documentElement.classList.contains('admin-mode')) {
            var data = {
                moduleId: moduleId,
                pageIndex: pageIndex,
                currentLangId: window.currentLanguageObject.id,
                categoryId: categoryId,
                orderBy: orderBy,
            };
            $loadmoreButton.classList.add('disabled');
            let action = 'loadMore';
            if (document.documentElement.classList.contains('preview-mode')) {
                action += '?previewMode=true'
            }
            api.publicCall('default', 'ModuleArticle', action, JSON.stringify(data), function(response) {
                if (response.type == 1) {
                    var elements = $(response.data.html);
                    $('[data-module-id="' + moduleId + '"] .article-items').append(elements);
                    $loadmoreButton.setAttribute('data-page-index', response.data.nextPageIndex);
                    if (elements.length && elements.hasClass('article2-item')) {
                        setGallerySettings(moduleId, !0, null, null)
                    }
                    if (response.data.loadmore || (parseInt(pageIndex) !== 1 && paginationType === 'standard')) {
                        $loadmoreButton.parentNode.classList.remove('hide')
                    } else {
                        $loadmoreButton.parentNode.classList.add('hide')
                    }
                }
                articleSpinner.classList.remove('loading-spinner');
                $loadmoreButton.classList.remove('disabled')
            }, 'GET')
        }
    }
    window.addEventListener('load', function() {
        document.querySelectorAll('.ModuleArticle .article-items-loadmore a.load-more').forEach((button) => {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                if (global_GallerySettings[this.getAttribute('data-module-id')]) {
                    global_GallerySettings[this.getAttribute('data-module-id')].imagesAll = null;
                    global_GallerySettings[this.getAttribute('data-module-id')].loadMoreCount++
                }
                getArticles(this)
            })
        })
    })
})()
document.addEventListener('DOMContentLoaded', function() {
    if (document.documentElement.classList.contains('admin-mode')) {
        return !1
    }
    document.querySelectorAll('.ModuleArticleCategories [data-stretch-labels]').forEach(function(elem) {
        if (elem.dataset.stretchLabels) {
            elem.parentNode.classList.add('stretch-labels')
        }
    })
})
$(document).ready(function() {
    if ($('.mainRow').find('.article-items.masonry').length && $('.mainRow').find('.article-items.standard').length) {
        $('.article-items.standard').height('auto')
    }
    $('.ModuleArticleRelated .article-items-loadmore .load-more').each(function() {
        loadmoreRelatedArticles($(this))
    });
    $('.ModuleArticleRelated .article-items-loadmore .load-more').click(function(e) {
        e.preventDefault();
        if (global_GallerySettings[this.getAttribute('data-module-id')]) {
            global_GallerySettings[this.getAttribute('data-module-id')].imagesAll = null;
            global_GallerySettings[this.getAttribute('data-module-id')].loadMoreCount++
        }
        loadmoreRelatedArticles($(this))
    });

    function loadmoreRelatedArticles($loadmoreButton) {
        var moduleId = $loadmoreButton.attr('data-module-id');
        var pageIndex = $loadmoreButton.attr('data-page-index');
        var articleId = $loadmoreButton.attr('data-article-id');
        $loadmoreButton.parent().addClass('hide');
        $('[data-module-id="' + moduleId + '"] .article-loading').children().addClass('loading-spinner');
        if (!$('html').hasClass('admin-mode')) {
            data = {
                moduleId: moduleId,
                pageIndex: pageIndex,
                currentLangId: window.currentLanguageObject.id,
                articleId: articleId
            };
            $loadmoreButton.addClass('disabled');
            api.publicCall('default', 'ModuleArticleRelated', 'loadMore', JSON.stringify(data), function(response) {
                if (response.type == 1) {
                    var elements = $(response.data.html);
                    $('[data-module-id="' + moduleId + '"] .article-items').append(elements);
                    $loadmoreButton.attr('data-page-index', response.data.nextPageIndex);
                    if (elements.length && elements.hasClass('article2-item')) {
                        setGallerySettings(moduleId, !0, null, null)
                    }
                    if (response.data.loadmore) {
                        $loadmoreButton.parent().removeClass('hide')
                    } else {
                        $loadmoreButton.parent().addClass('hide')
                    }
                }
                $('[data-module-id="' + moduleId + '"] .article-loading').children().removeClass('loading-spinner');
                $loadmoreButton.removeClass('disabled')
            })
        }
    }
})
$(document).ready(function() {
    let articleSingle = document.querySelector('.current-article'),
        hits = document.querySelector('.single-article-hits'),
        articleId = articleSingle && articleSingle.dataset.id;
    if (hits) {
        hits.classList.add('loading-spinner')
    }
    if (articleId) {
        let action = 'getSingleArticleHits';
        if (document.documentElement.classList.contains('preview-mode')) {
            action += '?previewMode=true'
        }
        api.publicCall('default', 'ModuleArticleSingle', action, JSON.stringify({
            articleId: articleId
        }), function(response) {
            if (response.type === 1) {
                if (hits) {
                    hits.innerHTML = response.data.hits;
                    hits.classList.remove('loading-spinner')
                }
            }
        }, 'GET')
    }
});

function signIn(loginUrl) {
    window.location.hash = `#/?${loginUrl}`
}



var countdown = {};
countdown.getTimeRemaining = function(endTime) {
    let t = endTime.split(/[- :]/);
    let d = new Date(t[0], t[1] - 1, t[2], t[3], t[4], t[5]);
    t = d.getTime() - (new Date()).getTime();
    if (t <= 0 || isNaN(t)) {
        return {
            'total': t,
            'days': '00',
            'hours': '00',
            'minutes': '00',
            'seconds': '00'
        }
    }
    let seconds = Math.floor((t / 1000) % 60);
    let minutes = Math.floor((t / 1000 / 60) % 60);
    let hours = Math.floor((t / (1000 * 60 * 60)) % 24);
    let days = Math.floor(t / (1000 * 60 * 60 * 24));
    return {
        'total': t,
        'days': days < 10 ? ('0' + days).slice(-2) : days,
        'hours': ('0' + hours).slice(-2),
        'minutes': ('0' + minutes).slice(-2),
        'seconds': ('0' + seconds).slice(-2)
    }
};
countdown.timerFunc = function(clock, endTime, timeInterval) {
    let t = countdown.getTimeRemaining(endTime);
    let className = 'hide';
    if (clock) {
        let end = clock.querySelector('.after-countdown-ends');
        let start = clock.querySelector('.after-countdown-starts');
        if (isNaN(t.total) || t.total <= 0) {
            if (end) {
                end.classList.remove(className)
            }
            if (start) {
                start.classList.add(className)
            }
            if (timeInterval) {
                clearInterval(timeInterval)
            }
        } else {
            clock.querySelector('.days').textContent = t.days;
            clock.querySelector('.hours').textContent = t.hours;
            clock.querySelector('.minutes').textContent = t.minutes;
            clock.querySelector('.seconds').textContent = t.seconds;
            if (end) {
                end.classList.add(className)
            }
            if (start) {
                start.classList.remove(className)
            }
        }
    }
};
countdown.initializeClock = function(id, endTime) {
    let clock = document.getElementById(id);
    countdown.timerFunc(clock, endTime, null);
    let timeInterval = setInterval(function() {
        countdown.timerFunc(clock, endTime, timeInterval)
    }, 1000)
};
countdown.getFullData = function(data) {
    if (typeof moment !== 'undefined') {
        return moment.unix(data).format('YYYY-MM-DD HH:mm:ss')
    }
    let date = new Date(parseInt(data) * 1000),
        year = date.getFullYear(),
        month = date.getMonth() + 1,
        day = date.getDate(),
        hours = date.getHours(),
        minutes = date.getMinutes(),
        seconds = date.getSeconds();
    month < 10 && (month = `0${month}`);
    day < 10 && (day = `0${day}`);
    hours < 10 && (hours = `0${hours}`);
    minutes < 10 && (minutes = `0${minutes}`);
    seconds < 10 && (seconds = `0${seconds}`);
    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`
};
document.addEventListener("DOMContentLoaded", function() {
    let countdowns = document.querySelectorAll('.countdown-module-container');
    countdowns.forEach((index) => {
        let id = index.getAttribute('id');
        let data = index.getAttribute('data-end-date');
        if (+index.getAttribute('data-fixed-time') === 1) {
            data = countdown.getFullData(data)
        }
        countdown.initializeClock(id, data);
        let paddingId = `${id}padding`;
        let padding = document.getElementById(paddingId);
        if (window.winWidth < 810 && padding.value < 15) {
            let colons = document.getElementsByClassName(id);
            for (let colon of colons) {
                colon.classList.add("padding")
            }
        }
    })
})




function onUcraftFormSubmitError(error) {
    let errorContainer = curModule.find('.error-message-container'),
        errorContainerText = curModule.find('.error-message');
    errorContainerText.text(error);
    errorContainer.removeClass('hide');
    setTimeout(function() {
        errorContainer.addClass('hide')
    }, 5000)
}

function onUcraftFormSubmit(token) {
    var button = window.button,
        curForm = window.curForm,
        captchaOn = window.captchaOn,
        curModule = curForm.closest('.module'),
        data = {};
    let baseUrlProtocol = baseUrl.includes('https:') ? 'https:' : 'http:';
    if (location.protocol !== baseUrlProtocol) {
        let errorContainer = curModule.find('.error-message-container'),
            errorContainerText = curModule.find('.error-message');
        errorContainerText.text(window.translations['validation.enableSslMessage']);
        curForm.parent().find('form').each(function(it, form) {
            form.reset();
            $(form).find('.attached-file').val("");
            $(form).find('.public-file-uploader-button').trigger('change');
            $(form).find('.selected-file').trigger('change').addClass('hidden');
            $(form).find('.public-file-upload-attach').trigger('change').removeClass('hidden');
            $(form).find('.public-file-upload-attach').trigger('change').removeClass('error')
        });
        curForm.find('select').trigger('chosen:updated');
        curForm.one("change", ":input", function() {
            errorContainerText.text('error-message')
        });
        errorContainer.removeClass('hide');
        setTimeout(function() {
            errorContainer.addClass('hide')
        }, 5000);
        return
    }
    data.fields = curForm.serializeArray();
    curForm.find('.checkbox-group').each(function() {
        var name = '';
        var arr = [];
        var c = 0;
        $(this).find('input[type=checkbox]').each(function() {
            name = $(this).attr('data-name');
            if ($(this).prop('checked')) {
                arr[c++] = $(this).val()
            }
        });
        for (var i = 0; i < data.fields.length; i++) {
            if (i === $(this).closest('.form-element').data('index') && data.fields[i].name === name) {
                data.fields[i].value = arr.join(',')
            }
        }
    });
    var newFields = [];
    for (var i = 0; i < data.fields.length; i++) {
        var name = data.fields[i].name;
        if (name.includes('"')) {
            name = name.replace(/"/g, '\\"')
        }
        newFields[i] = data.fields[i]
    }
    data.fields = newFields;
    data.id = curForm.data('module-id');
    data.pageUrl = window.location.href;
    let buttonWidth = $(button).outerWidth();
    $(button).css({
        width: buttonWidth
    });
    $(button).children('span').addClass('loading-spinner');
    var that = $(button);
    if (captchaOn) {
        data['g-recaptcha-response'] = token
    }
    api.sendForm(JSON.stringify(data), function(response) {
        $(button).css({
            width: 'auto'
        });
        that.children('span').removeClass('loading-spinner');
        if (response.type === 1) {
            if (!!parseInt(response.msg.thankYouMessage)) {
                if (response.data.length) {
                    console.error(response.data)
                }
                var thankYouContainer = curModule.find('.thank-you-message-container'),
                    thankYouContainerText = curModule.find('.thank-you-message');
                thankYouContainerText.text(response.msg.thankYouText);
                curForm.one("change", ":input", function() {
                    thankYouContainerText.text('thank-you-message')
                });
                let customCodeForFormElement = window['customCodeForFormElement' + data.id];
                if (customCodeForFormElement) {
                    var customCode = customCodeForFormElement[0];
                    let fields = data.fields;
                    for (let i = 0; i < fields.length; i++) {
                        customCode = customCode.replace('@@field' + (i + 1), fields[i].value)
                    }
                    var inlineScript = document.createElement('script');
                    inlineScript.innerHTML = customCode;
                    document.body.insertAdjacentElement('beforeend', inlineScript)
                }
                thankYouContainer.removeClass('hide');
                setTimeout(function() {
                    thankYouContainer.addClass('hide');
                    curForm.parent().find('form').each(function(it, form) {
                        form.reset();
                        $(form).find('.attached-file').val("");
                        $(form).find('.public-file-uploader-button').trigger('change');
                        $(form).find('.selected-file').trigger('change').addClass('hidden');
                        $(form).find('.public-file-upload-attach').trigger('change').removeClass('hidden');
                        $(form).find('.public-file-upload-attach').trigger('change').removeClass('error')
                    });
                    curForm.find('select').trigger('chosen:updated')
                }, 5000)
            } else if (!!parseInt(response.msg.sendTo)) {
                if (response.msg.linkType === 4) {
                    window.openPopup(response.msg.link)
                } else {
                    if (window.dataOnClick) {
                        eval(window.dataOnClick);
                        window.dataOnClick = !1
                    } else {
                        if (response.msg.linkType === 3) {
                            window.location = response.msg.link
                        } else {
                            window.top.location = response.msg.link
                        }
                        window.UcAnchor.checkAndScrollAnchor(!0)
                    }
                }
            }
        }
    });
    if (window.isCaptchaLoaded && grecaptcha && captchaOn) {
        grecaptcha.reset()
    }
}
$(document).ready(function() {
    if (window.hasCaptcha && !window.isCaptchaLoaded) {
        var form = document.getElementsByTagName('body').item(0),
            script = document.createElement('script');
        script.setAttribute('type', 'text/javascript');
        script.setAttribute('src', "https://www.google.com/recaptcha/api.js?hl=" + window.currentLanguagePrefix);
        script.setAttribute('async', 'async');
        script.setAttribute('defer', 'defer');
        form.appendChild(script);
        script.onload = function() {
            window.isCaptchaLoaded = !0
        }
    }
    $('.module.ModuleForm ').each(function() {
        var form = $(this).find('form').first();
        form.find('input').on('keydown', function(e) {
            if (e.keyCode != 9) {
                e.currentTarget.classList.add("remove-outline")
            } else {
                e.currentTarget.classList.remove("remove-outline")
            }
            if (e.keyCode == 13) {
                e.preventDefault();
                form.find('.moduleForm-submit').click()
            }
        });
        form.find('textarea').on('keydown', function(e) {
            if (e.keyCode != 9) {
                e.currentTarget.classList.add("remove-outline")
            } else {
                e.currentTarget.classList.remove("remove-outline")
            }
        })
    });
    $(document).on('change', '.ModuleForm input[data-type=datatime]', function() {
        var parent = $(this).closest('.form-three-one');
        var val = "";
        $(parent.find("input[data-type=datatime]").get()).each(function() {
            var newVal = $(this).val();
            if (newVal.length == 1) {
                newVal = '0' + newVal
            }
            val += newVal + "/"
        });
        parent.find('input.realValue').val(val.slice(0, -1))
    });
    $(document).on('click', '.ModuleForm .moduleForm-submit', function(e) {
        e.preventDefault();
        if (!$('html').hasClass('admin-mode')) {
            window.button = $(this);
            window.curForm = window.button.closest('form');
            window.dataOnClick = e.target.getAttribute('data-onclick') || !1;
            window.captchaOn = window.curForm.children('#recaptcha').length;
            if (window.curForm.validate()) {
                if (window.isCaptchaLoaded && grecaptcha && captchaOn) {
                    try {
                        grecaptcha.execute().then((token) => {
                            onUcraftFormSubmit(token)
                        })
                    } catch (error) {
                        let errorContainer = curModule.find('.error-message-container'),
                            errorContainerText = curModule.find('.error-message');
                        errorContainerText.text('Google recaptcha configuration issue');
                        errorContainer.removeClass('hide');
                        setTimeout(function() {
                            errorContainer.addClass('hide')
                        }, 5000)
                    }
                } else {
                    onUcraftFormSubmit()
                }
            } else {
                if (window.curForm.find('input.attached-file').hasClass('error')) {
                    window.curForm.find('.public-file-upload-attach').addClass('error')
                }
            }
        }
    });
    const phoneRegEx = /[a-zA-Zа-яА-ЯЁё!@#$%^&*()_|}\[\]{\-”?.,'`~"№;/\\<>:=]/,
        phoneInputs = document.querySelectorAll('input[attr-form-type="phone"]:not([data-mask])');
    if (phoneInputs) {
        phoneInputs.forEach(phoneInput => {
            phoneInput.addEventListener("input", function() {
                if (this.value === "")
                    this.value = "+";
                if (this.value.match(phoneRegEx))
                    this.value = this.value.replace(phoneRegEx, "")
            });
            phoneInput.addEventListener("focusin", function() {
                if (!this.value)
                    this.value = "+"
            });
            phoneInput.addEventListener("focusout", function() {
                this.value = this.value.trim() === "+" ? "" : this.value.trim()
            });
            $(phoneInput).on("paste", function(e) {
                if (e.originalEvent.clipboardData.getData("text/plain").match(phoneRegEx))
                    return !1
            });
            $(phoneInput).on("drop", function(e) {
                if (e.originalEvent.dataTransfer.getData("text/plain").match(phoneRegEx))
                    return !1
            })
        })
    }
    let urlInputs = document.querySelectorAll('input[attr-form-type="url"]');
    if (urlInputs) {
        urlInputs.forEach((urlInput) => {
            urlInput.addEventListener('focus', function() {
                if (!this.value) {
                    this.value = 'https://'
                }
            })
        })
    }
});

function toggleCheckOption(event) {
    const label = event.target.closest('.checkbox');
    if (label) {
        const input = label.getElementsByClassName('checkbox-checkmark-input');
        if (input.length) {
            const checkmark = label.getElementsByClassName('uci-checkmark')[0];
            checkmark.style.display = input[0].checked ? 'block' : 'none'
        }
    }
}


document.addEventListener("DOMContentLoaded", function() {
    const imgContainers = document.getElementsByClassName('fixed-ratio');
    if (imgContainers.length) {
        for (let item of imgContainers) {
            item.querySelector('img.fixed-ratio-content').onload = function(e) {
                item.style.paddingBottom = null;
                item.classList.remove('fixed-ratio');
                e.target.classList.remove('fixed-ratio-content')
            }
        }
    }
})


$(document).ready(function() {
    if (window.parent && window.currentLanguageObject) {
        let obj = {
            currentLanguage: window.currentLanguageObject,
            page: window.page,
            isMobile: !!window.isMobile,
            isTablet: !!window.isTablet,
            currentRoute: window.location
        }
        window.parent.postMessage(JSON.stringify(obj), "*")
    }
    setLanguageSwitcherEventListeners()
});

function setLanguageSwitcherEventListeners() {
    $('.ModuleLanguageSwitcher .languages').on('mouseenter', function(e) {
        if (global_isAdmin || (!global_isAdmin && !global_IsMobile)) {
            configureSubLanguagesToOpen('hover', e)
        }
    });
    $('.ModuleLanguageSwitcher .languages').on('click', function(e) {
        if (global_IsMobile) {
            configureSubLanguagesToOpen('click', e)
        } else {
            e.preventDefault();
            e.stopPropagation()
        }
    })
}

function configureSubLanguagesToOpen(action, e) {
    let item = e.target.classList.contains('.subMenu__item') ? e.target : e.target.closest('.subMenu__item'),
        elementId = item.closest('[datamodule-id]').getAttribute('datamodule-id'),
        subItems = item.querySelector('.native-scroll-box'),
        event = global_IsMobile && !global_isAdmin ? e : null;
    if (subItems) {
        openUcSubMenu(elementId, item, subItems, event);
        if (action === 'hover') {
            item.addEventListener('mouseleave', () => {
                closeUcSubMenu(subItems)
            })
        }
    }
}

function changeLanguage(element, prefix, url = null) {
    if (!url && element) {
        url = element.getAttribute('data-href')
    }
    if (window.popupIframe) {
        window.parent.postMessage({
            action: 'changeLanguage',
            prefix: prefix,
            url: url + window.location.hash
        }, '*')
    } else {
        var d = new Date();
        var hour = 20;
        d.setTime(d.getTime() + (hour * 60 * 60 * 1000));
        var cookieExpireDate = "expires=" + d.toString();
        document.cookie = "lastlanguage=" + prefix + ";path=/; " + cookieExpireDate;
        if (window.activePopupAlias) {
            window.closePopup(window.activePopupAlias)
        }
        window.location.replace(url)
    }
}

function initializeMap(forceReload) {
    var selector = '.map:not(.loaded)';
    if (forceReload) {
        selector = '.map'
    }
    $(selector).each(function() {
        $(this).addClass('loaded');
        var mapParams = JSON.parse($(this).parents('.module.ModuleMap').attr('data-params')) || {};
        var centerLat = '';
        var centerLng = '';
        var zoom = 2;
        var hasMarker = !1;
        var fullscreenControl = !1;
        if (!isEmpty(mapParams)) {
            var addresses = mapParams.fields;
            if (mapParams.lat && mapParams.lng && mapParams.address) {
                var oldObj = {
                    params: {
                        vars: {
                            address: {
                                value: mapParams.address
                            },
                            lat: {
                                value: mapParams.lat
                            },
                            lng: {
                                value: mapParams.lng
                            }
                        }
                    }
                };
                addresses.unshift(oldObj)
            }
            if (addresses.length) {
                var firstAddressParamsVars = addresses[0].params.vars;
                if (firstAddressParamsVars.lat.value != '' || firstAddressParamsVars.lng.value != '') {
                    hasMarker = !0;
                    centerLat = firstAddressParamsVars.lat.value;
                    centerLng = firstAddressParamsVars.lng.value
                }
            }
            if (mapParams.hasOwnProperty('zoomLevel') && mapParams.zoomLevel != '') {
                zoom = parseInt(mapParams.zoomLevel)
            }
        }
        var center = new google.maps.LatLng(centerLat, centerLng);
        var mapCanvas = $(this).get(0);
        var shades_of_grey_style = [{
            "featureType": "all",
            "elementType": "labels.text.fill",
            "stylers": [{
                "saturation": 36
            }, {
                "color": "#000000"
            }, {
                "lightness": 40
            }]
        }, {
            "featureType": "all",
            "elementType": "labels.text.stroke",
            "stylers": [{
                "visibility": "on"
            }, {
                "color": "#000000"
            }, {
                "lightness": 16
            }]
        }, {
            "featureType": "all",
            "elementType": "labels.icon",
            "stylers": [{
                "visibility": "off"
            }]
        }, {
            "featureType": "administrative",
            "elementType": "geometry.fill",
            "stylers": [{
                "color": "#000000"
            }, {
                "lightness": 20
            }]
        }, {
            "featureType": "administrative",
            "elementType": "geometry.stroke",
            "stylers": [{
                "color": "#000000"
            }, {
                "lightness": 17
            }, {
                "weight": 1.2
            }]
        }, {
            "featureType": "landscape",
            "elementType": "geometry",
            "stylers": [{
                "color": "#000000"
            }, {
                "lightness": 20
            }]
        }, {
            "featureType": "poi",
            "elementType": "geometry",
            "stylers": [{
                "color": "#000000"
            }, {
                "lightness": 21
            }]
        }, {
            "featureType": "road.highway",
            "elementType": "geometry.fill",
            "stylers": [{
                "color": "#000000"
            }, {
                "lightness": 17
            }]
        }, {
            "featureType": "road.highway",
            "elementType": "geometry.stroke",
            "stylers": [{
                "color": "#000000"
            }, {
                "lightness": 29
            }, {
                "weight": 0.2
            }]
        }, {
            "featureType": "road.arterial",
            "elementType": "geometry",
            "stylers": [{
                "color": "#000000"
            }, {
                "lightness": 18
            }]
        }, {
            "featureType": "road.local",
            "elementType": "geometry",
            "stylers": [{
                "color": "#000000"
            }, {
                "lightness": 16
            }]
        }, {
            "featureType": "transit",
            "elementType": "geometry",
            "stylers": [{
                "color": "#000000"
            }, {
                "lightness": 19
            }]
        }, {
            "featureType": "water",
            "elementType": "geometry",
            "stylers": [{
                "color": "#000000"
            }, {
                "lightness": 17
            }]
        }];
        var blue_water_style = [{
            "featureType": "administrative",
            "elementType": "labels.text.fill",
            "stylers": [{
                "color": "#444444"
            }]
        }, {
            "featureType": "landscape",
            "elementType": "all",
            "stylers": [{
                "color": "#f2f2f2"
            }]
        }, {
            "featureType": "poi",
            "elementType": "all",
            "stylers": [{
                "visibility": "off"
            }]
        }, {
            "featureType": "road",
            "elementType": "all",
            "stylers": [{
                "saturation": -100
            }, {
                "lightness": 45
            }]
        }, {
            "featureType": "road.highway",
            "elementType": "all",
            "stylers": [{
                "visibility": "simplified"
            }]
        }, {
            "featureType": "road.arterial",
            "elementType": "labels.icon",
            "stylers": [{
                "visibility": "off"
            }]
        }, {
            "featureType": "transit",
            "elementType": "all",
            "stylers": [{
                "visibility": "off"
            }]
        }, {
            "featureType": "water",
            "elementType": "all",
            "stylers": [{
                "color": "#46bcec"
            }, {
                "visibility": "on"
            }]
        }];
        var midnight_commander_style = [{
            "featureType": "all",
            "elementType": "labels.text.fill",
            "stylers": [{
                "color": "#ffffff"
            }]
        }, {
            "featureType": "all",
            "elementType": "labels.text.stroke",
            "stylers": [{
                "color": "#000000"
            }, {
                "lightness": 13
            }]
        }, {
            "featureType": "administrative",
            "elementType": "geometry.fill",
            "stylers": [{
                "color": "#000000"
            }]
        }, {
            "featureType": "administrative",
            "elementType": "geometry.stroke",
            "stylers": [{
                "color": "#144b53"
            }, {
                "lightness": 14
            }, {
                "weight": 1.4
            }]
        }, {
            "featureType": "landscape",
            "elementType": "all",
            "stylers": [{
                "color": "#08304b"
            }]
        }, {
            "featureType": "poi",
            "elementType": "geometry",
            "stylers": [{
                "color": "#0c4152"
            }, {
                "lightness": 5
            }]
        }, {
            "featureType": "road.highway",
            "elementType": "geometry.fill",
            "stylers": [{
                "color": "#000000"
            }]
        }, {
            "featureType": "road.highway",
            "elementType": "geometry.stroke",
            "stylers": [{
                "color": "#0b434f"
            }, {
                "lightness": 25
            }]
        }, {
            "featureType": "road.arterial",
            "elementType": "geometry.fill",
            "stylers": [{
                "color": "#000000"
            }]
        }, {
            "featureType": "road.arterial",
            "elementType": "geometry.stroke",
            "stylers": [{
                "color": "#0b3d51"
            }, {
                "lightness": 16
            }]
        }, {
            "featureType": "road.local",
            "elementType": "geometry",
            "stylers": [{
                "color": "#000000"
            }]
        }, {
            "featureType": "transit",
            "elementType": "all",
            "stylers": [{
                "color": "#146474"
            }]
        }, {
            "featureType": "water",
            "elementType": "all",
            "stylers": [{
                "color": "#021019"
            }]
        }];
        var unsaturated_browns_style = [{
            "elementType": "geometry",
            "stylers": [{
                "hue": "#ff4400"
            }, {
                "saturation": -68
            }, {
                "lightness": -4
            }, {
                "gamma": 0.72
            }]
        }, {
            "featureType": "road",
            "elementType": "labels.icon"
        }, {
            "featureType": "landscape.man_made",
            "elementType": "geometry",
            "stylers": [{
                "hue": "#0077ff"
            }, {
                "gamma": 3.1
            }]
        }, {
            "featureType": "water",
            "stylers": [{
                "hue": "#00ccff"
            }, {
                "gamma": 0.44
            }, {
                "saturation": -33
            }]
        }, {
            "featureType": "poi.park",
            "stylers": [{
                "hue": "#44ff00"
            }, {
                "saturation": -23
            }]
        }, {
            "featureType": "water",
            "elementType": "labels.text.fill",
            "stylers": [{
                "hue": "#007fff"
            }, {
                "gamma": 0.77
            }, {
                "saturation": 65
            }, {
                "lightness": 99
            }]
        }, {
            "featureType": "water",
            "elementType": "labels.text.stroke",
            "stylers": [{
                "gamma": 0.11
            }, {
                "weight": 5.6
            }, {
                "saturation": 99
            }, {
                "hue": "#0091ff"
            }, {
                "lightness": -86
            }]
        }, {
            "featureType": "transit.line",
            "elementType": "geometry",
            "stylers": [{
                "lightness": -48
            }, {
                "hue": "#ff5e00"
            }, {
                "gamma": 1.2
            }, {
                "saturation": -23
            }]
        }, {
            "featureType": "transit",
            "elementType": "labels.text.stroke",
            "stylers": [{
                "saturation": -64
            }, {
                "hue": "#ff9100"
            }, {
                "lightness": 16
            }, {
                "gamma": 0.47
            }, {
                "weight": 2.7
            }]
        }];
        var neutral_blue_style = [{
            "featureType": "water",
            "elementType": "geometry",
            "stylers": [{
                "color": "#193341"
            }]
        }, {
            "featureType": "landscape",
            "elementType": "geometry",
            "stylers": [{
                "color": "#2c5a71"
            }]
        }, {
            "featureType": "road",
            "elementType": "geometry",
            "stylers": [{
                "color": "#29768a"
            }, {
                "lightness": -37
            }]
        }, {
            "featureType": "poi",
            "elementType": "geometry",
            "stylers": [{
                "color": "#406d80"
            }]
        }, {
            "featureType": "transit",
            "elementType": "geometry",
            "stylers": [{
                "color": "#406d80"
            }]
        }, {
            "elementType": "labels.text.stroke",
            "stylers": [{
                "visibility": "on"
            }, {
                "color": "#3e606f"
            }, {
                "weight": 2
            }, {
                "gamma": 0.84
            }]
        }, {
            "elementType": "labels.text.fill",
            "stylers": [{
                "color": "#ffffff"
            }]
        }, {
            "featureType": "administrative",
            "elementType": "geometry",
            "stylers": [{
                "weight": 0.6
            }, {
                "color": "#1a3541"
            }]
        }, {
            "elementType": "labels.icon",
            "stylers": [{
                "visibility": "off"
            }]
        }, {
            "featureType": "poi.park",
            "elementType": "geometry",
            "stylers": [{
                "color": "#2c5a71"
            }]
        }];
        var lunar_landscape_style = [{
            "stylers": [{
                "hue": "#ff1a00"
            }, {
                "invert_lightness": !0
            }, {
                "saturation": -100
            }, {
                "lightness": 33
            }, {
                "gamma": 0.5
            }]
        }, {
            "featureType": "water",
            "elementType": "geometry",
            "stylers": [{
                "color": "#2D333C"
            }]
        }];
        var greyscale_style = [{
            "featureType": "all",
            "elementType": "all",
            "stylers": [{
                "saturation": -100
            }, {
                "gamma": 0.5
            }]
        }];
        var old_dry_mud_style = [{
            "featureType": "landscape",
            "stylers": [{
                "hue": "#FFAD00"
            }, {
                "saturation": 50.2
            }, {
                "lightness": -34.8
            }, {
                "gamma": 1
            }]
        }, {
            "featureType": "road.highway",
            "stylers": [{
                "hue": "#FFAD00"
            }, {
                "saturation": -19.8
            }, {
                "lightness": -1.8
            }, {
                "gamma": 1
            }]
        }, {
            "featureType": "road.arterial",
            "stylers": [{
                "hue": "#FFAD00"
            }, {
                "saturation": 72.4
            }, {
                "lightness": -32.6
            }, {
                "gamma": 1
            }]
        }, {
            "featureType": "road.local",
            "stylers": [{
                "hue": "#FFAD00"
            }, {
                "saturation": 74.4
            }, {
                "lightness": -18
            }, {
                "gamma": 1
            }]
        }, {
            "featureType": "water",
            "stylers": [{
                "hue": "#00FFA6"
            }, {
                "saturation": -63.2
            }, {
                "lightness": 38
            }, {
                "gamma": 1
            }]
        }, {
            "featureType": "poi",
            "stylers": [{
                "hue": "#FFC300"
            }, {
                "saturation": 54.2
            }, {
                "lightness": -14.4
            }, {
                "gamma": 1
            }]
        }];
        var papuportal_dark_style = [{
            "featureType": "all",
            "elementType": "labels",
            "stylers": [{
                "visibility": "on"
            }]
        }, {
            "featureType": "all",
            "elementType": "labels.text.fill",
            "stylers": [{
                "saturation": 36
            }, {
                "color": "#000000"
            }, {
                "lightness": 40
            }]
        }, {
            "featureType": "all",
            "elementType": "labels.text.stroke",
            "stylers": [{
                "visibility": "on"
            }, {
                "color": "#000000"
            }, {
                "lightness": 16
            }]
        }, {
            "featureType": "all",
            "elementType": "labels.icon",
            "stylers": [{
                "visibility": "off"
            }]
        }, {
            "featureType": "administrative",
            "elementType": "geometry.fill",
            "stylers": [{
                "color": "#000000"
            }, {
                "lightness": 20
            }]
        }, {
            "featureType": "administrative",
            "elementType": "geometry.stroke",
            "stylers": [{
                "color": "#000000"
            }, {
                "lightness": 17
            }, {
                "weight": 1.2
            }]
        }, {
            "featureType": "administrative.country",
            "elementType": "labels.text.fill",
            "stylers": [{
                "color": "#ed5929"
            }]
        }, {
            "featureType": "administrative.locality",
            "elementType": "labels.text.fill",
            "stylers": [{
                "color": "#c4c4c4"
            }]
        }, {
            "featureType": "administrative.neighborhood",
            "elementType": "labels.text.fill",
            "stylers": [{
                "color": "#ed5929"
            }]
        }, {
            "featureType": "landscape",
            "elementType": "geometry",
            "stylers": [{
                "color": "#000000"
            }, {
                "lightness": 20
            }]
        }, {
            "featureType": "poi",
            "elementType": "geometry",
            "stylers": [{
                "color": "#000000"
            }, {
                "lightness": 21
            }, {
                "visibility": "on"
            }]
        }, {
            "featureType": "poi.business",
            "elementType": "geometry",
            "stylers": [{
                "visibility": "on"
            }]
        }, {
            "featureType": "road.highway",
            "elementType": "geometry.fill",
            "stylers": [{
                "color": "#ed5929"
            }, {
                "lightness": "0"
            }]
        }, {
            "featureType": "road.highway",
            "elementType": "geometry.stroke",
            "stylers": [{
                "visibility": "off"
            }]
        }, {
            "featureType": "road.highway",
            "elementType": "labels.text.fill",
            "stylers": [{
                "color": "#ffffff"
            }]
        }, {
            "featureType": "road.highway",
            "elementType": "labels.text.stroke",
            "stylers": [{
                "color": "#ed5929"
            }]
        }, {
            "featureType": "road.arterial",
            "elementType": "geometry",
            "stylers": [{
                "color": "#000000"
            }, {
                "lightness": 18
            }]
        }, {
            "featureType": "road.arterial",
            "elementType": "geometry.fill",
            "stylers": [{
                "color": "#575757"
            }]
        }, {
            "featureType": "road.arterial",
            "elementType": "labels.text.fill",
            "stylers": [{
                "color": "#ffffff"
            }]
        }, {
            "featureType": "road.arterial",
            "elementType": "labels.text.stroke",
            "stylers": [{
                "color": "#2c2c2c"
            }]
        }, {
            "featureType": "road.local",
            "elementType": "geometry",
            "stylers": [{
                "color": "#000000"
            }, {
                "lightness": 16
            }]
        }, {
            "featureType": "road.local",
            "elementType": "labels.text.fill",
            "stylers": [{
                "color": "#999999"
            }]
        }, {
            "featureType": "transit",
            "elementType": "geometry",
            "stylers": [{
                "color": "#000000"
            }, {
                "lightness": 19
            }]
        }, {
            "featureType": "water",
            "elementType": "geometry",
            "stylers": [{
                "color": "#000000"
            }, {
                "lightness": 17
            }]
        }];
        var light_green_style = [{
            "stylers": [{
                "hue": "#baf4c4"
            }, {
                "saturation": 10
            }]
        }, {
            "featureType": "water",
            "stylers": [{
                "color": "#effefd"
            }]
        }, {
            "featureType": "all",
            "elementType": "labels",
            "stylers": [{
                "visibility": "off"
            }]
        }, {
            "featureType": "administrative",
            "elementType": "labels",
            "stylers": [{
                "visibility": "on"
            }]
        }, {
            "featureType": "road",
            "elementType": "all",
            "stylers": [{
                "visibility": "off"
            }]
        }, {
            "featureType": "transit",
            "elementType": "all",
            "stylers": [{
                "visibility": "off"
            }]
        }];
        var taste206_style = [{
            "featureType": "water",
            "elementType": "geometry",
            "stylers": [{
                "color": "#a0d6d1"
            }, {
                "lightness": 17
            }]
        }, {
            "featureType": "landscape",
            "elementType": "geometry",
            "stylers": [{
                "color": "#ffffff"
            }, {
                "lightness": 20
            }]
        }, {
            "featureType": "road.highway",
            "elementType": "geometry.fill",
            "stylers": [{
                "color": "#dedede"
            }, {
                "lightness": 17
            }]
        }, {
            "featureType": "road.highway",
            "elementType": "geometry.stroke",
            "stylers": [{
                "color": "#dedede"
            }, {
                "lightness": 29
            }, {
                "weight": 0.2
            }]
        }, {
            "featureType": "road.arterial",
            "elementType": "geometry",
            "stylers": [{
                "color": "#dedede"
            }, {
                "lightness": 18
            }]
        }, {
            "featureType": "road.local",
            "elementType": "geometry",
            "stylers": [{
                "color": "#ffffff"
            }, {
                "lightness": 16
            }]
        }, {
            "featureType": "poi",
            "elementType": "geometry",
            "stylers": [{
                "color": "#f1f1f1"
            }, {
                "lightness": 21
            }]
        }, {
            "elementType": "labels.text.stroke",
            "stylers": [{
                "visibility": "on"
            }, {
                "color": "#ffffff"
            }, {
                "lightness": 16
            }]
        }, {
            "elementType": "labels.text.fill",
            "stylers": [{
                "saturation": 36
            }, {
                "color": "#333333"
            }, {
                "lightness": 40
            }]
        }, {
            "elementType": "labels.icon",
            "stylers": [{
                "visibility": "off"
            }]
        }, {
            "featureType": "transit",
            "elementType": "geometry",
            "stylers": [{
                "color": "#f2f2f2"
            }, {
                "lightness": 19
            }]
        }, {
            "featureType": "administrative",
            "elementType": "geometry.fill",
            "stylers": [{
                "color": "#fefefe"
            }, {
                "lightness": 20
            }]
        }, {
            "featureType": "administrative",
            "elementType": "geometry.stroke",
            "stylers": [{
                "color": "#fefefe"
            }, {
                "lightness": 17
            }, {
                "weight": 1.2
            }]
        }];
        var style = $(greyscale_style);
        if (mapParams.hasOwnProperty('styles') && mapParams.styles != '') {
            var getStyle = mapParams.styles;
            switch (getStyle) {
                case 'shades_of_grey_style':
                    style = shades_of_grey_style;
                    break;
                case 'blue_water_style':
                    style = blue_water_style;
                    break;
                case 'midnight_commander_style':
                    style = midnight_commander_style;
                    break;
                case 'unsaturated_browns_style':
                    style = unsaturated_browns_style;
                    break;
                case 'neutral_blue_style':
                    style = neutral_blue_style;
                    break;
                case 'lunar_landscape_style':
                    style = lunar_landscape_style;
                    break;
                case 'greyscale_style':
                    style = greyscale_style;
                    break;
                case 'old_dry_mud_style':
                    style = old_dry_mud_style;
                    break;
                case 'papuportal_dark_style':
                    style = papuportal_dark_style;
                    break;
                case 'light_green_style':
                    style = light_green_style;
                    break;
                case 'taste206_style':
                    style = taste206_style;
                    break;
                default:
                    style = []
            }
        }
        var mapOptions = {
            center: center,
            zoom: zoom,
            gestureHandling: 'cooperative',
            mapTypeId: google.maps.MapTypeId.ROADMAP,
            styles: style,
            fullscreenControl: fullscreenControl
        };
        var map = new google.maps.Map(mapCanvas, mapOptions);
        if (hasMarker) {
            var image = '';
            var shape = {};
            if (mapParams.hasOwnProperty('image') && mapParams.image) {
                image = {
                    url: window.croppedUrlPrefix + '/' + mapParams.image,
                };
                shape = {
                    coords: [1, 1, 1, 20, 18, 20, 18, 1],
                    type: 'poly'
                }
            }
            for (let i = 0; i < addresses.length; i++) {
                let item = addresses[i].params.vars;
                if (item.address.value !== '' || item.lat.value !== '' || item.lng.value !== '') {
                    new google.maps.Marker({
                        position: {
                            lat: Number(item.lat.value),
                            lng: Number(item.lng.value)
                        },
                        map: map,
                        optimized: !1,
                        icon: image,
                        shape: shape,
                    })
                }
            }
        }
    })
}
$(document).ready(function() {
    if ($(document).find('.ModuleMap').length > 0) {
        var timer = 0;
        var timeInterval = 10;
        var waitTime = 500;
        var ifMapJSAlreadyExists = setInterval(() => {
            if ((typeof google === 'undefined' || !google.maps) && typeof googleMapKey !== 'undefined' && typeof ModuleMap === "undefined" && timer >= waitTime) {
                loadJS("https://maps.googleapis.com/maps/api/js?v=3.44&key=" + googleMapKey + "&callback=initializeMap");
                clearInterval(ifMapJSAlreadyExists)
            }
            if (typeof google !== 'undefined' && google.maps && timer >= waitTime) {
                clearInterval(ifMapJSAlreadyExists)
            }
            timer += timeInterval
        }, timeInterval)
    }
    $(document).on('googleObjectIsLoaded', function() {
        initializeMap()
    })
});

function loadJS(file) {
    if (window.googleIsDefined === !0) {
        return
    }
    var jsElm = document.createElement("script");
    jsElm.type = "application/javascript";
    jsElm.src = file;
    jsElm.onload = function() {
        window.googleLoaded = document.createEvent('Event');
        window.googleLoaded.initEvent('googleObjectIsLoaded', !0, !0);
        document.dispatchEvent(window.googleLoaded)
    };
    document.body.appendChild(jsElm);
    window.googleIsDefined = !0
}

function isEmpty(obj) {
    for (var key in obj) {
        if (obj.hasOwnProperty(key))
            return !1
    }
    return !0
}

$(document).ready(function() {
    let iconElements = document.querySelectorAll(".off-canvas-button.icon");
    let scrollTop = 0;
    var pages = $('.ModuleNavigation li.page');
    var currentHash = location.href.split('#')[1];
    var html = document.querySelector('html');
    var body = document.querySelector('body');
    if (iconElements) {
        iconElements.forEach((element) => {
            let svg = element.querySelector('svg');
            if (svg) {
                svg.setAttribute("role", "none")
            }
        })
    }
    if ($('html').hasClass('admin-mode')) {
        return !1
    }
    if (currentHash && 0 !== $('[data-anchor = "' + currentHash + '"]').length) {
        addActiveClass(currentHash, pages)
    }
    $('li.page.has-childes').on('mouseenter', function(e) {
        if ($(this).hasClass('on-hover') && !global_IsMobile) {
            configureSubMenuToOpen('hover', e)
        }
    });
    $('li.page.has-childes').on('click', function(e) {
        configureSubMenuToOpen('click', e)
    });
    $('input[type=hidden].burger-navigation').each(function(index, el) {
        var navModuleContainer = $(el).closest('.ModuleNavigation.module-container');
        if (navModuleContainer.length) {
            navModuleContainer.addClass("burger-module")
        }
    });
    const moduleNavigations = document.querySelectorAll('.ModuleNavigation.module');
    for (const moduleNavigation of Array.from(moduleNavigations)) {
        const moduleStretchLabels = moduleNavigation.querySelector('.stretch-labels');
        if (!moduleStretchLabels) {
            moduleNavigation.style.width = 'auto'
        }
    }
    $('.off-canvas-button').on('click keydown', function(event) {
        let offCanvas = $('.layers-container .layer .off-canvas');
        let alignment = event.target.getAttribute('data-attribute');
        if (offCanvas && offCanvas.style().display === 'none') {
            offCanvas.style().display = ''
        }
        if (offCanvas && !offCanvas.hasClass('open')) {
            if (alignment && alignment === 'left') {
                if (offCanvas.hasClass('right-alignment')) {
                    offCanvas.removeClass('right-alignment')
                }
                if (!offCanvas.hasClass('left-alignment')) {
                    offCanvas.addClass('left-alignment')
                }
            } else {
                if (offCanvas.hasClass('left-alignment')) {
                    offCanvas.removeClass('left-alignment')
                }
                if (!offCanvas.hasClass('right-alignment')) {
                    offCanvas.addClass('right-alignment')
                }
            }
        }
        setTimeout(function() {
            if (event.type === "click" || event.keyCode === 13) {
                let badgeElement = document.querySelector('div.active.landing');
                offCanvas.toggleClass('open');
                if (offCanvas.hasClass('open')) {
                    $('.off-canvas-button svg').hide();
                    if (!global_IsMobile) {
                        $('.off-canvas-button').css({
                            'cursor': 'auto',
                            'pointer-events': 'none'
                        })
                    }
                    if (badgeElement) {
                        badgeElement.classList.add('hide')
                    }
                    if (typeof $().lazyload !== "undefined") {
                        offCanvas.find('.lazy').lazyload({
                            container: $(".navigation-inner .standard-view"),
                            effect: "fadeIn",
                            threshold: 300,
                            failure_limit: 10
                        })
                    }
                    event.currentTarget.classList.add('open');
                    event.currentTarget.style.outline = "none"
                } else {
                    if (badgeElement) {
                        badgeElement.classList.remove('hide')
                    }
                    $('.off-canvas-button svg').show();
                    $('.off-canvas-button').css({
                        'cursor': 'pointer',
                        'pointer-events': 'all'
                    });
                    $('body').removeClass('fixed no-scroll');
                    event.currentTarget.classList.remove('open');
                    event.currentTarget.style.outline = ""
                }
                body.classList.add('no-scroll');
                $(".off-canvas-inner-container").scrollTop(0)
            }
        }, 250)
    });
    $('.off-canvas-close').click(function(e) {
        let badgeElement = document.querySelector('div.active.landing');
        if (badgeElement) {
            badgeElement.classList.remove('hide')
        }
        $('.layers-container .layer .off-canvas').removeClass('open');
        $('.navigation .page-children').removeClass('collapsed');
        $('body').removeClass('no-scroll fixed');
        $('.off-canvas-button svg').show();
        $('.off-canvas-button').css({
            'cursor': 'pointer',
            'pointer-events': 'all'
        });
        if (scrollTop) {
            html.scrollTop = scrollTop
        }
    });
    $('.ModuleNavigation .module .navigation-inner:not(.clickable-dropdown)').hover(function() {
        $(this).parents('.uc-row').addClass('row-forward')
    }, function() {
        $(this).parents('.uc-row').removeClass('row-forward')
    });
    var startX, dist, startTime, endTime;
    $(document).on('touchstart', '.off-canvas.open .off-canvas-inner-container', function(event) {
        var touchObj = event.originalEvent.changedTouches[0];
        startX = touchObj.clientX;
        startTime = new Date().getTime();
        $(document).one('touchend', function(e) {
            var touchObj = e.originalEvent.changedTouches[0];
            dist = touchObj.clientX - startX;
            endTime = new Date().getTime();
            if (startTime - endTime < 500) {
                if (dist > 0 && dist >= 70) {
                    $('.layers-container .layer .off-canvas.open').removeClass('open');
                    $('.navigation .page-children').removeClass('collapsed');
                    $('.off-canvas-button svg').show();
                    $('.off-canvas-button').css({
                        'cursor': 'pointer',
                        'pointer-events': 'all'
                    });
                    $('body').removeClass('no-scroll fixed')
                }
            }
        })
    });
    $(document).on('mouseup', function(e) {
        let badgeElement = document.querySelector('div.active.landing');
        if (e.which === 1 && $('.layers-container .layer .off-canvas').hasClass('open') && !$(e.target).closest('.popup-tool-container').length && !$(e.target).closest('.off-canvas').length && !$(e.target).closest('.off-canvas-button').length) {
            $('.layers-container .layer .off-canvas.open').removeClass('open');
            $('.off-canvas-button svg').show()
            document.querySelector('.off-canvas-button.open').style.outline = "";
            $('.off-canvas-button').css({
                'cursor': 'pointer',
                'pointer-events': 'all'
            });
            $('body').removeClass('fixed no-scroll');
            var parent = $(e.target).closest('li.page');
            if (badgeElement) {
                badgeElement.classList.remove('hide')
            }
            if (!parent.length) {
                $('.navigation .page-children').removeClass('collapsed')
            }
        }
    });
    $('html:not(.admin-mode) .off-canvas.open .off-canvas-inner-container').on('touchmove', function(e) {
        e.preventDefault()
    });
    $(pages).on('mouseup', function() {
        var dataAnchor = $(this).data('anchor');
        if ('' !== dataAnchor) {
            addActiveClass(dataAnchor, pages);
            $('.off-canvas-button svg').show();
            $('.off-canvas-button').css({
                'cursor': 'pointer',
                'pointer-events': 'all'
            });
            $('body').removeClass('fixed no-scroll');
            let parentRow = this.closest('.uc-row');
            parentRow.classList.remove("row-forward", "z-minus");
            let dropdownOpened = document.querySelector('.clickable-dropdown .collapsed');
            if (dropdownOpened) {
                dropdownOpened.classList.remove('collapsed')
            }
        }
    });

    function addActiveClass(anchor, pages) {
        pages.removeClass('active');
        $('[data-anchor = "' + anchor + '"]').addClass('active')
    }
    let closeNavMenu = function() {
        $('.page-children').removeClass('collapsed');
        document.removeEventListener('click', closeNavMenu)
        $('.pages-accordion-type a').attr("aria-expanded", !1);
        $('.pages-accordion-type').closest(".uc-row").removeClass('row-forward')
    }

    function configureSubMenuToOpen(action, e) {
        let item = e.target.closest('.subMenu__item'),
            elementAlignCenter = item.closest('.module-container.ModuleNavigation') && item.closest('.module-container.ModuleNavigation').classList.contains('align-center'),
            elementId = item.closest('[datamodule-id]').getAttribute('datamodule-id'),
            subItems = item.querySelector('.page-children'),
            checkHorizontalPosition = !1,
            event = action === 'hover' && !global_IsMobile ? null : e,
            sameLevelVertical = !1,
            sameLevelHorizontal = !1,
            showHorizontalArrow = !1,
            isAccordion = subItems && subItems.closest('.pages-accordion-type'),
            isVerticalLayout = subItems && subItems.closest('.vertical');
        if (subItems) {
            if (subItems.getAttribute('sub-menu-index') !== '0') {
                sameLevelVertical = !0;
                if (!isAccordion && !subItems.closest('.off-canvas-inner-container')) {
                    checkHorizontalPosition = !0;
                    showHorizontalArrow = !0
                }
            } else if (global_IsMobile) {
                sameLevelHorizontal = !0
            }
            if (global_IsMobile) {
                if (!elementAlignCenter) {
                    if (subItems.getAttribute('sub-menu-index') === '0') {
                        checkHorizontalPosition = !0;
                        if (item.querySelector('a')) {
                            item = item.querySelector('a')
                        }
                    } else if (!isAccordion) {
                        checkHorizontalPosition = !0
                    }
                } else if (!subItems.closest('.off-canvas-inner-container') && !isAccordion && !isVerticalLayout) {
                    checkHorizontalPosition = !0;
                    if (subItems.getAttribute('sub-menu-index') !== '0') {
                        showHorizontalArrow = !0
                    }
                }
            }
            openUcSubMenu(elementId, item, subItems, event, !0, showHorizontalArrow, !0, checkHorizontalPosition, sameLevelVertical, sameLevelHorizontal, null);
            if (action === 'hover') {
                item.addEventListener('mouseleave', () => {
                    closeUcSubMenu(subItems)
                })
            }
        }
    }
})
window.addEventListener("load", () => {
    if (window.ScrollBooster) {
        new ScrollBooster({
            viewport: document.querySelector('.uc-slider-container'),
            content: document.querySelector('.uc-slider-wrapper'),
            scrollMode: 'native',
            direction: 'horizontal',
            pointerMode: 'mouse',
            onPointerDown: (state, event) => {
                let elementWrapper = event.target.closest('.uc-slider-container');
                if (elementWrapper) {
                    elementWrapper.style.cursor = 'grabbing'
                    elementWrapper.addEventListener('mouseup', mouseUp = () => {
                        elementWrapper.style.cursor = 'grab';
                        elementWrapper.removeEventListener('mouseup', mouseUp)
                    })
                }
            }
        })
    }
})

const input = document.getElementById("set-password-control");
if (input) {
    input.onpaste = function(event) {
        let paste = (event.clipboardData || window.clipboardData).getData('text');
        changePasswordProtectionValue({
            value: paste
        })
    }
}
submitPasswordProtectedForm = function(formElement, event) {
    event.preventDefault();
    var buttonTextElement = formElement.querySelector('span.password-protected-btn-text');
    if (buttonTextElement.classList.contains('loading-spinner')) {
        return
    }
    buttonTextElement.classList.add('loading-spinner');
    var rawData = new FormData(formElement);
    var data = {
        pageId: window.pageId
    };
    for (var value of rawData.entries()) {
        data[value[0]] = value[1]
    }
    api.viewPage(JSON.stringify(data), (response) => {
        if (response.type === 1) {
            location.reload()
        } else {
            buttonTextElement.classList.remove('loading-spinner')
        }
    })
};

function changePasswordProtectionValue(input) {
    let submitBtn = document.querySelector('.password-protection-submit');
    if (input.value === '') {
        if (!submitBtn.classList.contains('password-protection-disabled')) {
            submitBtn.classList.add('password-protection-disabled')
        }
    } else {
        if (submitBtn.classList.contains('password-protection-disabled')) {
            submitBtn.classList.remove('password-protection-disabled')
        }
    }
}
document.querySelectorAll('.paypal-content form').forEach((form) => {
    form.setAttribute('target', '_blank')
})
let startHeight;
$(document).on("click", ".period-switcher .monthly", function() {
    $(".period-switcher .switcher-option.yearly").removeClass("active");
    $(".period-switcher .switcher-option.monthly").addClass("active");
    $(".pricing-view .plan-group").removeClass("active");
    $(".pricing-view .other-monthly-plans").addClass("active");
    $(".pricing-info-container.yearly").removeClass("active");
    $(".pricing-info-container.monthly").addClass("active");
    if (document.querySelector('.new-pricing-container')) {
        document.querySelector('.new-pricing-container .package-group .plan-group.other-yearly-plans').classList.remove('active');
        document.querySelector('.new-pricing-container .package-group .plan-group.other-monthly-plans').classList.add('active');
        let wlPackage = document.querySelector('.new-pricing-container .package-group.whitelabel_package');
        if (wlPackage) {
            let wlYearlyPackage = wlPackage.querySelector('.plan-group.other-yearly-plans');
            if (wlYearlyPackage) {
                wlYearlyPackage.classList.remove('active')
            }
            let wlMonthlyPackage = wlPackage.querySelector('.plan-group.other-monthly-plans');
            if (wlMonthlyPackage) {
                wlMonthlyPackage.classList.add('active')
            }
        }
    }
    activateSwipe(!0)
});
$(document).on("click", ".period-switcher .yearly", function() {
    $(".period-switcher .switcher-option.monthly").removeClass("active");
    $(".period-switcher .switcher-option.yearly").addClass("active");
    $(".pricing-view .plan-group").removeClass("active");
    $(".pricing-view .other-yearly-plans").addClass("active");
    $(".pricing-info-container.yearly").addClass("active");
    $(".pricing-info-container.monthly").removeClass("active");
    if (document.querySelector('.new-pricing-container')) {
        document.querySelector(".new-pricing-container .package-group .plan-group.other-monthly-plans").classList.remove("active");
        document.querySelector(".new-pricing-container .package-group .plan-group.other-yearly-plans").classList.add("active");
        let wlPackage = document.querySelector('.new-pricing-container .package-group.whitelabel_package');
        if (wlPackage) {
            let wlYearlyPackage = wlPackage.querySelector('.plan-group.other-yearly-plans');
            if (wlYearlyPackage) {
                wlYearlyPackage.classList.add('active')
            }
            let wlMonthlyPackage = wlPackage.querySelector('.plan-group.other-monthly-plans');
            if (wlMonthlyPackage) {
                wlMonthlyPackage.classList.remove('active')
            }
        }
    }
    activateSwipe(!0)
});
$(document).on("click", ".swiper-slide-active .round-button", function() {
    var parentContainer = $(this).closest('.swiper-slide-active').find('.mobile-features-container');
    parentContainer.toggleClass('show');
    togglePlanRoundButton()
});
$(document).on("click", "#pricing-container .compare-plans.desktop-view", function() {
    if ($('.header-rows').length) {
        scrollToFeatures($(this).closest('.features-container').get(0), $('.header-rows').height() + 70)
    } else {
        scrollToFeatures($(this).closest('.features-container').get(0), 80)
    }
});

function scrollToFeatures(domNode, difference) {
    var defaultZoom = $("body .full-width-page").css('zoom');
    if (!defaultZoom) {
        defaultZoom = 1
    }
    var scrollToPos = $(document).scrollTop() + domNode.getBoundingClientRect().top;
    $('html, body').animate({
        scrollTop: scrollToPos * defaultZoom + difference
    }, 400)
}
$(document).on("click", "#pricing-container .swiper-slide-active .compare-plans", function() {
    if ($('.header-rows').length) {
        scrollToFeatures($('.swiper-slide-active .pricing-info-container')[0], $('.header-rows').height() - 80)
    } else {
        scrollToFeatures($('.swiper-slide-active .pricing-info-container')[0], -90)
    }
});
if (document.querySelector('.new-pricing-container')) {
    document.addEventListener('scroll', () => {
        checkFixHeader()
    })
}

function togglePackagePricing(switcher) {
    let wlPackage = document.querySelector('.new-pricing-container .package-group.whitelabel_package');
    let sitePackage = document.querySelector('.new-pricing-container .package-group.site_package');
    let wlSwitcherPersonalInfo = document.querySelector('.new-pricing-container .wl-switcher .personal-info');
    let wlSwitcherInfoBranded = document.querySelector('.new-pricing-container .wl-switcher .branded-info');
    if (switcher.checked) {
        wlPackage.classList.add('active');
        sitePackage.classList.remove('active');
        wlSwitcherInfoBranded.classList.add('show');
        wlSwitcherPersonalInfo.classList.remove('show')
    } else {
        wlPackage.classList.remove('active');
        sitePackage.classList.add('active');
        wlSwitcherInfoBranded.classList.remove('show');
        wlSwitcherPersonalInfo.classList.add('show')
    }
    activateSwipe(!0)
}

function activateSwipe(force) {
    var pricingBox = document.getElementById('pricing-container');
    var newPricingBox = document.querySelector('.new-pricing-container');
    var popularElementIndex = $('.plan-group.active .swiper-container .swiper-slide.popular').index();
    var isFirstLoaded = 0;
    var ww;
    var startSize;
    var spaceBetween = 0;
    if (force === !0) {
        destroySwipe()
    }
    if (newPricingBox) {
        ww = newPricingBox.closest('.module-container.ModulePricing').getBoundingClientRect().width;
        startSize = 896;
        popularElementIndex--
    } else {
        if (pricingBox) {
            ww = pricingBox.getBoundingClientRect().width;
            startSize = 991;
            spaceBetween = 15
        }
    }
    if (ww <= startSize) {
        if (window.swiperBox) {
            return
        }
        window.swiperBox = new Swiper('.swiper-container ', {
            spaceBetween: spaceBetween,
            slidesPerView: 'auto',
            centeredSlides: !0,
            initialSlide: popularElementIndex,
            pagination: {
                el: '.swiper-pagination',
                type: 'bullets',
                clickable: !0,
            },
            on: {
                slideChange: function() {
                    if (isFirstLoaded >= popularElementIndex) {
                        openMobileFeatures(!1);
                        togglePlanRoundButton(!0)
                    }
                    isFirstLoaded++
                },
            }
        })
    } else {
        $("#pricing-container .swiper-wrapper ").removeAttr("style");
        destroySwipe()
    }
}

function destroySwipe() {
    if (window.swiperBox) {
        if (window.swiperBox.length) {
            window.swiperBox.map((item) => {
                item.destroy()
            })
        }
        window.swiperBox = undefined
    }
}

function togglePlanRoundButton(force) {
    var buttonBox = $(".swiper-slide-active");
    if (!buttonBox.find("i.plus-minus").hasClass('sb-plus') || force === !0) {
        openMobileFeatures(!1);
        buttonBox.find("i.plus-minus").html(`
            <svg width="32" height="32" viewBox="0 0 32 32"  xmlns="http://www.w3.org/2000/svg">
                <g clip-path="url(#clip0_153_430)">
                    <path
                        d="M29.7333 12.6667H19.3334V2.26668C19.3334 0.426683 17.84 -1.06665 16 -1.06665C14.16 -1.06665 12.6667 0.426683 12.6667 2.26668V12.6667H2.26668C0.426683 12.6667 -1.06665 14.16 -1.06665 16C-1.06665 17.84 0.426683 19.3334 2.26668 19.3334H12.6667V29.7333C12.6667 31.5733 14.16 33.0667 16 33.0667C17.84 33.0667 19.3334 31.5733 19.3334 29.7333V19.3334H29.7333C31.5733 19.3334 33.0667 17.84 33.0667 16C33.0667 14.16 31.5733 12.6667 29.7333 12.6667Z"
                        fill="#444444" />
                </g>
                <defs>
                    <clipPath id="clip0_153_430">
                        <rect width="32" height="32" fill="white" />
                    </clipPath>
                </defs>
            </svg>
        `)
    } else {
        buttonBox.find("i.plus-minus").html(`
            <svg width="32" height="32" viewBox="0 0 32 32"  xmlns="http://www.w3.org/2000/svg">
                <g clip-path="url(#clip0_153_328)">
                    <path
                        d="M-1.06665 16.0001C-1.06665 14.1601 0.426683 12.6667 2.26668 12.6667H29.7333C31.5733 12.6667 33.0667 14.1601 33.0667 16.0001C33.0667 17.8401 31.5733 19.3334 29.7333 19.3334H2.26668C0.426683 19.3334 -1.06665 17.8401 -1.06665 16.0001V16.0001Z"
                        fill="#444444" />
                </g>
                <defs>
                    <clipPath id="clip0_153_328">
                        <rect width="32" height="32" fill="white" />
                    </clipPath>
                </defs>
            </svg>
        `)
    }
}

function openMobileFeatures(status) {
    if (!document.querySelector('.new-pricing-container')) {
        if (status === !1) {
            $('html, body').animate({
                scrollTop: $("#pricing-container").offset().top - 120
            }, 300);
            $(".swiper-slide-active .mobile-features-container").removeClass("show")
        } else {
            $(".swiper-slide-active .mobile-features-container").addClass("show")
        }
    }
}

function checkMobileFeatures() {
    document.querySelectorAll('.mobile-features-accordion').forEach(node => {
        var frature = node.querySelector('.mobile-features-block .mobile-feature-title');
        if (!frature) {
            node.classList.add('empty')
        }
    })
}

function calculatePosDifference() {
    var headerFixedRows = document.querySelectorAll('.header-rows .header-row-fix');
    var posDifference = 0;
    headerFixedRows.forEach((fixRow) => {
        var fixRowWrapper = fixRow.closest('.header-row-wrapper');
        posDifference += fixRowWrapper.offsetHeight
    });
    return posDifference
}

function checkFixHeader() {
    var posDifference = calculatePosDifference();
    document.querySelectorAll('.plan-group').forEach(node => {
        let priceContainer = node.querySelector('.swiper-container');
        let mobilePriceContainer = node.querySelectorAll('.plan');
        let mobileAccordionListHeader = node.querySelectorAll('.mobile-accordion-list-header ');
        let priceContainerHeight = priceContainer ? priceContainer.offsetHeight : 0;
        if (priceContainer && priceContainer.style) {
            priceContainer.style.top = `${posDifference}px`
        }
        mobilePriceContainer.forEach(plan => {
            if (plan && plan.style) {
                plan.style.top = `${posDifference}px`
            }
        });
        mobileAccordionListHeader.forEach(header => {
            let planContainer = header.closest('.plan-container ');
            let plan;
            if (planContainer) {
                for (let i = 0; i < planContainer.childNodes.length; i++) {
                    let classList = planContainer.childNodes[i].classList;
                    if (classList && classList.contains("plan") !== -1) {
                        plan = planContainer.childNodes[i];
                        break
                    }
                }
                let top = plan.offsetHeight - 1;
                if (header && header.style) {
                    header.style.top = `${top + posDifference}px`
                }
            }
        });
        node.querySelectorAll('.features-block .feature-column .accordion-list-header').forEach(header => {
            header.style.top = `${posDifference + priceContainerHeight}px`
        })
    })
}
if (document.querySelector('.new-pricing-container')) {
    window.addEventListener("load", checkFixHeader)
}
$(window).resize(function() {
    activateSwipe();
    if (document.querySelector('.new-pricing-container')) {
        checkFixHeader()
    }
});
$(document).ready(function() {
    activateSwipe();
    if (document.querySelector('.new-pricing-container')) {
        checkMobileFeatures()
    }
});

function onClickFeatureSwitcher(target) {
    let planContainer = target.closest('.plan-container'),
        mobileFeatures, switcherIcon;
    if (planContainer) {
        mobileFeatures = planContainer.querySelector('.mobile-features-container'), switcherIcon = $(planContainer).find('.switcher-icon')
    }
    if (!target.classList || (target.classList && !target.classList.contains('show'))) {
        let plans = document.querySelectorAll('.plan-container');
        let posDifference = calculatePosDifference();
        Array.from(plans).map((plan) => {
            window[`planTop${plan.getAttribute('data-id')}`] = plan.getBoundingClientRect().top + window.scrollY - posDifference
        })
    }
    if (target.classList && target.classList.contains('show')) {
        window.scrollTo({
            top: window[`planTop${planContainer.getAttribute('data-id')}`]
        })
    }
    if (target.classList) {
        target.classList.toggle("show")
    }
    if (mobileFeatures && mobileFeatures.classList) {
        mobileFeatures.classList.toggle("show")
    }
    if (switcherIcon) {
        switcherIcon.classList.toggle('uci-up-arrow');
        switcherIcon.classList.toggle('uci-down-arrow')
    }
}
$(document).ready(function() {
    $('body').on('mouseup', '.icon-print', function() {
        if (!$('html').hasClass('admin-mode')) {
            let originalContents = document.body.innerHTML;
            $('.icon-print').hide();
            $('.header-rows').hide();
            $('.footer-rows').hide();
            window.print();
            document.body.innerHTML = originalContents
        }
    })
})
$(document).ready(function() {
    $(document).on('click', '.ModulePromoCode .modulePromoCode-submit', function(e) {
        e.preventDefault();
        if (!$('html').hasClass('admin-mode')) {
            var button = $(this),
                curForm = button.closest('form');
            if (curForm.validate()) {
                if (curForm.find("[name='linkType']").val() == '2' && curForm.find("[name='link']").val() != '') {
                    window.location.href = curForm.find("[name='link']").val()
                }
            }
        }
    })
})
window.addEventListener('load', function() {
    document.querySelectorAll('.module.ModuleQuotes').forEach(function(elem) {
        var slider = elem.querySelector('.slider-wrapper');
        if (slider) {
            var id = slider.getAttribute('id');
            var options = window[id + 'options'];
            if (options) {
                options.currentSlideId = 0;
                options.sliderItems = $(slider).find("> .slider-container > .slider-item");
                options.paginationItems = $(slider).find("> .slide-pagination").find(".slide-pointer");
                $(elem).find('.slider-wrapper').first().jqueryUcSlider(options, !0, !0);
                if (window.UcAnchor) {
                    window.UcAnchor.checkAndScrollAnchor(!1)
                }
            }
        }
    })
})

if (!document.documentElement.classList.contains('admin-mode')) {
    document.querySelectorAll('.ModuleSearch').forEach((search) => {
        search.closest('.uc-row').classList.add('zIndex')
    })
}

document.querySelectorAll('.module.ModuleSlider').forEach(function(elem) {
    let slider = elem.querySelector('.slider-wrapper');
    if (slider) {
        let id = slider.getAttribute('id'),
            options = window[id + 'options'];
        if (options) {
            $(elem).find('.slider-wrapper').first().jqueryUcSlider(options, !0)
        }
    }
})



function onSubscribeError(error) {
    let curModule = window.subscribecurForm.closest('.module'),
        errorContainer = curModule.find('.error-message-container'),
        errorContainerText = curModule.find('.error-message');
    errorContainerText.text(error);
    errorContainer.removeClass('hide');
    setTimeout(function() {
        errorContainer.addClass('hide')
    }, 5000)
}

function onSubscribe(token) {
    let baseUrlProtocol = baseUrl.includes('https:') ? 'https:' : 'http:',
        subscriptionCaptchaOn = window.subscriptionCaptchaOn,
        button = window.subscribeButton,
        curForm = window.subscribeButton.closest('form'),
        curModule = window.subscribecurForm.closest('.module'),
        data = {
            fields: {}
        };
    dataReplacer = {};
    if (location.protocol !== baseUrlProtocol) {
        let errorContainer = curModule.find('.error-message-container'),
            errorContainerText = curModule.find('.error-message');
        errorContainerText.text(window.translations['validation.enableSslMessage']);
        curForm[0].reset();
        curForm.find('select').trigger('chosen:updated');
        curForm.one("change", ":input", function() {
            errorContainerText.text('error-message')
        });
        if (typeof customCodeForSubscriptionElement !== 'undefined') {
            $('body').append(customCodeForSubscriptionElement)
        }
        errorContainer.removeClass('hide');
        setTimeout(function() {
            errorContainer.addClass('hide')
        }, 5000);
        return
    }
    curForm.find('input').each(function(index, input) {
        if (input.type === 'text') {
            data.fields.name = {
                [input.name]: input.value
            };
            dataReplacer[input.name.toLowerCase()] = input.value
        }
        if (input.type === 'email') {
            data.fields.email = {
                [input.name]: input.value
            };
            dataReplacer[input.name.toLowerCase()] = input.value
        }
    });
    data.id = curForm.data('module-id');
    data.pageUrl = window.location.href;
    let buttonWidth = $(button).outerWidth();
    button.css({
        width: buttonWidth
    });
    button.children('span').addClass('loading-spinner');
    var that = button;
    if (subscriptionCaptchaOn) {
        data['g-recaptcha-response'] = token
    }
    api.publicCall('default', 'ModuleSubscription', 'subscribe', JSON.stringify(data), function(response) {
        that.css({
            width: 'auto'
        });
        that.children('span').removeClass('loading-spinner');
        if (response.type == 1) {
            if (response.msg.sendTo) {
                if (window.dataOnClick) {
                    eval(window.dataOnClick);
                    window.dataOnClick = !1
                } else {
                    if (response.msg.linkType === 4) {
                        window.openPopup(response.msg.link)
                    } else {
                        if (response.msg.linkType === 2) {
                            Object.entries(dataReplacer).forEach(([key, value]) => {
                                response.msg.link = response.msg.link.replace(`{${key}}`, value)
                            })
                        }
                        if (curForm.closest('.popup-wrapper-container').length) {
                            window.parent.location = response.msg.link
                        } else {
                            window.location = response.msg.link
                        }
                        window.UcAnchor.checkAndScrollAnchor(!0)
                    }
                }
            } else {
                if (response.msg.subscribeMessage) {
                    var thankYouContainerText = curModule.find('.thank-you-message');
                    var thankYouContainer = curModule.find('.thank-you-message-container');
                    thankYouContainerText.text(response.msg.thankYouText);
                    curForm[0].reset();
                    curForm.find('select').trigger('chosen:updated');
                    curForm.one("change", ":input", function() {
                        thankYouContainerText.text('thank-you-message')
                    });
                    thankYouContainer.removeClass('hide');
                    let customCodeForSubscriptionElement = window['customCodeForSubscriptionElement' + data.id];
                    if (customCodeForSubscriptionElement) {
                        var customCode = customCodeForSubscriptionElement[0];
                        let fields = data.fields;
                        if (fields.email) {
                            customCode = customCode.replace('@@email', fields.email.Email)
                        }
                        if (fields.name) {
                            customCode = customCode.replace('@@name', fields.name.Name)
                        }
                        var inlineScript = document.createElement('script');
                        inlineScript.innerHTML = customCode;
                        document.body.insertAdjacentElement('beforeend', inlineScript)
                    }
                    setTimeout(function() {
                        thankYouContainer.addClass('hide')
                    }, 5000)
                }
            }
        }
    });
    if (window.isSubscribeCaptchaLoaded && grecaptcha && subscriptionCaptchaOn) {
        grecaptcha.reset()
    }
};
$(document).ready(function() {
    if (window.subscribeHasCaptcha && !window.isSubscribeCaptchaLoaded) {
        var form = document.getElementsByTagName('body').item(0),
            script = document.createElement('script');
        script.setAttribute('type', 'text/javascript');
        script.setAttribute('src', "https://www.google.com/recaptcha/api.js?hl=" + window.currentLanguagePrefix);
        script.setAttribute('async', 'async');
        script.setAttribute('defer', 'defer');
        form.appendChild(script);
        script.onload = function() {
            window.isSubscribeCaptchaLoaded = !0
        }
    }
    $(document).on('click', '.ModuleSubscription .moduleSubscription-submit', function(e) {
        e.preventDefault();
        if (!$('html').hasClass('admin-mode')) {
            window.subscribeButton = $(this);
            window.dataOnClick = e.target.getAttribute('data-onclick') || !1;
            window.subscribecurForm = window.subscribeButton.closest('form');
            window.subscriptionCaptchaOn = window.subscribecurForm.children('#subscribeRecaptcha').length;
            let curModule = window.subscribecurForm.closest('.module');
            if (window.subscribecurForm.validate()) {
                if (window.isSubscribeCaptchaLoaded && grecaptcha && subscriptionCaptchaOn) {
                    let siteKey = document.querySelector('#subscribeRecaptcha').dataset.sitekey;
                    try {
                        grecaptcha.execute()
                    } catch (err) {
                        let errorContainer = curModule.find('.error-message-container'),
                            errorContainerText = curModule.find('.error-message');
                        errorContainerText.text('Google recaptcha configuration issue');
                        errorContainer.removeClass('hide');
                        setTimeout(function() {
                            errorContainer.addClass('hide')
                        }, 5000)
                    }
                } else {
                    onSubscribe()
                }
            }
        }
    });
    $('.module.ModuleSubscription ').each(function() {
        var form = $(this).find('form').first();
        form.find('input').on('keydown', function(e) {
            if (e.keyCode != 9) {
                e.currentTarget.classList.add("remove-outline")
            } else {
                e.currentTarget.classList.remove("remove-outline")
            }
            if (e.keyCode == 13) {
                e.preventDefault();
                form.find('.moduleForm-submit').click()
            }
        })
    })
})
const isDevice = navigator.userAgent.match(/Android/i) || navigator.userAgent.match(/webOS/i) || navigator.userAgent.match(/iPhone/i) || navigator.userAgent.match(/iPad/i) || navigator.userAgent.match(/iPod/i) || navigator.userAgent.match(/BlackBerry/i) || navigator.userAgent.match(/Windows Phone/i);
let controlsBtnBox = document.querySelectorAll('.template-body .controls');
if (controlsBtnBox) {
    controlsBtnBox.forEach(function(btnBox) {
        if (isDevice) {
            btnBox.addEventListener('touchstart', (event) => {
                btnBox.addEventListener('touchend', (event) => {
                    this.showButtons(event);
                    btnBox.removeEventListener('touchend')
                });
                let touchstartEvent;
                document.addEventListener('touchstart', touchstartEvent = () => {
                    this.hideButtons(event);
                    document.removeEventListener('touchstart', touchstartEvent)
                })
            })
        } else {
            btnBox.addEventListener('mouseover', (event) => {
                this.showButtons(event)
            });
            btnBox.addEventListener('mouseout', (event) => {
                this.hideButtons(event)
            })
        }
    })
}

function showButtons(event) {
    let element = event.target.closest('.controls');
    if (element) {
        event.target.closest('.controls').classList.add('show-buttons')
    }
}

function hideButtons(event) {
    let element = event.target.closest('.controls');
    if (element) {
        event.target.closest('.controls').classList.remove('show-buttons')
    }
}
let infoButton = document.querySelectorAll('.info-button');
if (infoButton) {
    infoButton.forEach(function(button) {
        button.addEventListener('click', (event) => {
            let parent = event.target.closest('.controls').parentNode;
            let item = parent.querySelector('.template-info-container');
            if (!item.classList.contains('show')) {
                item.classList.add('show')
            }
        })
    })
}
let closeInfo = document.querySelectorAll('.close-info');
if (closeInfo) {
    closeInfo.forEach(function(button) {
        button.addEventListener('click', (event) => {
            let parent = event.target.closest('.template-info-container').parentNode;
            let item = parent.querySelector('.template-info-container');
            if (item.classList.contains('show')) {
                item.classList.remove('show')
            }
        })
    })
}
let loadMore = document.querySelector('.templates-container .load-more');
if (loadMore) {
    loadMore.classList.add('hide');
    loadMore.addEventListener('click', (event) => {
        let parent = event.target.closest('.template-view');
        let tagId = parent.querySelector('.templates-section').getAttribute('active-tag');
        let showCount = parent.querySelectorAll('.template-item:not(.hide)').length;
        let limit = parent.querySelector('.templates-section').getAttribute('limit-templates');
        parent.querySelector('.templates-container .load-more').classList.add('hide');
        let module = parent.querySelector('.templates-section');
        filterByTag(tagId, parseInt(limit) + parseInt(showCount), module)
    })
}

function filterByTag(tagId, limit, module) {
    let option = module.querySelector(`.tag-select option[value='${tagId}']`);
    let templateCount = Infinity;
    if (option) {
        templateCount = parseInt(option.getAttribute('templatecount'))
    }
    let allContainer = module.querySelector('.all-container');
    let popularContainer = module.querySelector('.popular-container');
    if (tagId === '0') {
        if (popularContainer) {
            allContainer.classList.add('show');
            popularContainer.classList.remove('show')
        }
        let allItems = module.querySelectorAll('.all-container .template-item');
        let i = 0;
        for (const item of allItems) {
            if (i >= limit) {
                break
            }
            let templateImg = item.querySelector('.template-image');
            if (templateImg) {
                templateImg = templateImg.querySelector('img');
                let attrSrc = templateImg.getAttribute('attrSrc');
                if (templateImg.getAttribute('src') === '') {
                    templateImg.setAttribute('src', attrSrc)
                }
            }
            item.classList.add('show');
            item.classList.remove('hide');
            i++
        }
    } else if (tagId === 'popular') {
        if (popularContainer) {
            allContainer.classList.remove('show');
            popularContainer.classList.add('show')
        }
        let allItems = module.querySelectorAll('.popular-container .template-item');
        let i = 0;
        for (const item of allItems) {
            if (i >= limit) {
                break
            }
            let templateImg = item.querySelector('.template-image').querySelector('img');
            let attrSrc = templateImg.getAttribute('attrSrc');
            if (templateImg.getAttribute('src') === '') {
                templateImg.setAttribute('src', attrSrc)
            }
            item.classList.remove('hide');
            item.classList.add('show');
            i++
        }
    } else {
        if (popularContainer) {
            allContainer.classList.add('show');
            popularContainer.classList.remove('show')
        }
        let allItems = module.querySelectorAll('.all-container .template-item');
        let i = 0;
        for (const item of allItems) {
            if (i >= limit) {
                break
            }
            let tagIds = item.querySelector('.template-tags').value;
            tagIds = tagIds.split(",");
            tagIds = tagIds.map(Number);
            tagId = parseInt(tagId);
            if (tagIds.indexOf(tagId) !== -1) {
                item.classList.remove('hide');
                item.classList.add('show');
                let templateImg = item.querySelector('.template-image').querySelector('img');
                let attrSrc = templateImg.getAttribute('attrSrc');
                if (templateImg.getAttribute('src') === '') {
                    templateImg.setAttribute('src', attrSrc)
                }
                i++
            } else {
                item.classList.add('hide');
                item.classList.remove('show')
            }
        }
    }
    setTimeout(() => {
        for (const item of module.querySelectorAll('.template-item:not(.show)')) {
            item.classList.add('hide');
            item.classList.add('hidden')
        }
        for (const item of module.querySelectorAll('.template-item:not(.hide)')) {
            item.classList.add('show');
            item.classList.remove('hidden')
        }
    }, 300);
    if (templateCount > limit) {
        let loadMore = module.querySelector('.templates-container .load-more');
        if (loadMore) {
            loadMore.classList.remove('hide')
        }
    }
}
const tags = document.querySelectorAll('.tags .tag');
if (tags) {
    tags.forEach(function(tag) {
        tag.addEventListener('click', (event) => {
            const tagElement = event.target.closest('.tag');
            const tagId = tagElement.getAttribute('attr-id');
            const tagName = tagElement.getAttribute('attr-tagname');
            const parent = tagElement.closest('.row');
            const limit = parseInt(parent.querySelector('.templates-section').getAttribute('limit-templates'));
            const module = parent.querySelector('.templates-section');
            const loadMore = parent.querySelector('.templates-container .load-more');
            parent.querySelector('.template').parentNode.classList.add('hide');
            if (loadMore) {
                loadMore.classList.add('hide')
            }
            history.pushState(null, null, tagName);
            parent.querySelector('.templates-section').setAttribute('active-tag', tagId);
            const activeTag = parent.querySelector('.tags .tag.active');
            if (activeTag) {
                activeTag.classList.remove('active')
            }
            tagElement.classList.add('active');
            filterByTag(tagId, limit, module)
        })
    })
}
document.querySelectorAll('.templates-section').forEach(function(elem) {
    let tagId = elem.getAttribute('active-tag');
    let limit = elem.getAttribute('limit-templates');
    filterByTag(tagId, limit, elem)
});
let hashs = window.location.hash;
if (hashs) {
    let tag = document.querySelector(`.tag[attr-tagname="${hashs}"]`);
    if (tag) {
        tag.click()
    }
}


function openPopUp(event) {
    document.body.appendChild(event.target.closest('.ModuleTypeform').querySelector('.typeform-container').cloneNode(!0));
    document.body.classList.add('no-scroll');
    document.querySelector('body > .typeform-container').classList.add('active')
}

function closePopUp(event) {
    document.body.removeChild(event.target.closest('.typeform-container'));
    document.body.classList.remove('no-scroll')
}
if ($(window).width() > 1024) {
    var timeout = '';
    $(document).on('mouseover', '.user-profile', function(e) {
        clearTimeout(timeout);
        $(this).find('.dropdown-menu-profile').addClass('show');
        var ucRow = closestByClass(e.target, 'uc-row');
        if (ucRow) {
            ucRow.classList.add('row-forward')
        }
    });
    $(document).on('mouseleave', '.user-profile', function(e) {
        e.currentTarget.querySelector('.dropdown-menu-profile').classList.remove('show');
        timeout = setTimeout(function() {
            var ucRow = closestByClass(e.target, 'uc-row');
            if (ucRow) {
                ucRow.classList.remove('row-forward')
            }
        }, 300)
    })
} else {
    $(document).on('click', '.user-profile', function(e) {
        e.stopPropagation();
        $(this).find('.dropdown-menu-profile').toggleClass('show');
        var ucRow = closestByClass(e.target, 'uc-row');
        if (ucRow) {
            ucRow.classList.toggle('row-forward')
        }
    });
    $(document).on('click touchstart', '.dropdown-menu-profile, .user-profile', function(e) {
        e.stopPropagation()
    });
    if (document.querySelector('.user-profile')) {
        $(document).on('click touchstart', function(e) {
            $('.user-profile .dropdown-menu-profile').removeClass('show');
            var ucRow = closestByClass(document.querySelector('.user-profile'), 'uc-row');
            if (ucRow) {
                ucRow.classList.remove('row-forward')
            }
        })
    }
}
var closestByClass = function(el, className) {
    if (!el) {
        return null
    }
    while (!el.classList.contains(className)) {
        el = el.parentNode;
        if (!el || el === document) {
            return null
        }
    }
    return el
}

function playVideo(event) {
    if (!document.documentElement.classList.contains('admin-mode')) {
        var parentModule = event.target.closest('.module');
        setTimeout(function() {
            $(event.target).closest('.module').find('.iframe-thumbnail').fadeOut()
        }, 1000);
        let iframe = parentModule.querySelector('.iframe-container iframe');
        iframe.setAttribute('src', iframe.getAttribute('data-src'));
        if (iframe.getAttribute('src').indexOf('?') == -1) {
            iframe.setAttribute('src', event.target.closest('.iframe-thumbnail').nextElementSibling.getAttribute('src') + '?autoplay=1')
        } else {
            iframe.setAttribute('src', event.target.closest('.iframe-thumbnail').nextElementSibling.getAttribute('src') + '&autoplay=1')
        }
    }
}

if ($('.application-icon').length !== 0) {
    let left = $('.application-icon').offset().left;
    let right = $(document).width() - $('.application-icon').offset().left;
    if ($(document).width() < 768) {
        if (left > right) {
            $('.spring-bme-apps').css({
                'right': (-right + 30) + 'px',
                'left': 'auto'
            });
            $('.triangle').css({
                'right': (right - 40) + 'px',
                'left': 'auto'
            })
        } else {
            $('.spring-bme-apps').css({
                'left': -left + 'px',
                'right': 'auto'
            });
            $('.triangle').css({
                'left': (left - 10) + 'px',
                'right': 'auto'
            })
        }
    } else if (left < 300) {
        $('.spring-bme-apps').addClass('spring-bme-right')
    }
}
$('.spring-bme-apps').closest(".row-container").css("z-index", "auto")


$(document).ready(function() {
    let reg = /[a-zA-z_,]/;
    $(document).on('click', '.clicable-area .sales-image, .sales-name-part', function(elem) {
        let that = $(this).parents('.sales-items');
        let imgSrc = that.find('.sales-image  img').attr('src');
        let name = that.find('.sales-name-part').text();
        let position = that.find('.sales-position').text();
        let ownerId = that.find('.owner-id').attr('data-id');
        let isOnline = that.find('.sales-name-part').attr('data-isOnline');
        $('.single-sales-language').html('');
        that.find($('.sales-lang-part > div')).each(function() {
            let flags = $(this).attr('style');
            $('.single-sales-language').append('<div style="' + flags + '"></div>')
        });
        $('.sales-single-image img').attr('src', imgSrc);
        $('.sales-name').text(name);
        $('.sales-name').addClass(isOnline);
        $('.about-sales').text(position);
        $('.api-owner-id').val(ownerId);
        $('.sales-container').hide();
        $('.sales-single-page').show();
        $(document).scrollTop($('.sales-single-page').offset().top - 50)
    });
    $(document).on('click', '.sales-back-arrow div', function() {
        $('.sales-container').show();
        $('.sales-single-page').hide();
        $('.sales-name').removeClass('active').removeClass('disable')
        $('.sales-single-page .form-control').children().removeClass('error')
        $('.sales-single-page .form-control .input-message').detach();
        $('.sales-single-page .form-control').children().val('')
    });
    $('.val-phone').on('input', function() {
        if ($(this).val().match(reg)) {
            let newStr = $(this).val().replace(reg, '');
            $(this).val(newStr)
        }
    });
    $(document).on('click', '.moduleForm-submit-btn', function() {
        let emailVal = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,15}(?:\.[a-z]{2})?)$/i;
        if (!emailVal.test($('.sales-single-page .val-email').val())) {
            $('.sales-single-page .val-email').addClass('error')
        }
        $('.sales-single-page .form-control').each(function() {
            if ($(this).children().val() == "") {
                $(this).children().addClass('error')
            }
        });
        if ($('.error').length == 0) {
            $.ajax({
                url: "/addContactSaleApi",
                type: "POST",
                data: {
                    ownerID: $('.api-owner-id').val(),
                    lastName: $('.api-user-name').val(),
                    email: $('.api-user-email').val(),
                    phone: $('.api-user-phone').val(),
                    description: $('.api-user-msg').val(),
                },
                beforeSend: () => {
                    $(this).addClass('btn-loading')
                },
                success: (data) => {
                    $(this).removeClass('btn-loading');
                    if ($(data).find('error').length == 0) {
                        $('.sales-single-page .thank-you-message-container').fadeTo(700, 1, function() {
                            $('.sales-single-page .form-control').children().val('')
                        }).delay(3000).fadeOut(1000, 0)
                    } else {
                        $('.sales-single-page .error-message-container').fadeTo(700, 1, function() {
                            $('.sales-single-page .form-control').children().val('')
                        }).delay(3000).fadeOut(1000, 0)
                    }
                },
                error: function(data) {
                    console.log(data)
                }
            })
        }
    });
    $(document).on('focus', '.sales-single-page  [class*="val-"].error', function() {
        $(this).validate()
    })
})


if (window.getCookie('themeMode')) {
    document.querySelector('html').setAttribute('data-theme', "v3-" + window.getCookie('themeMode'))
}



$(document).ready(function() {
    if ($('html').hasClass('admin-mode')) {
        return !1
    }
    $('.ModuleSbAccount').closest('.header-row-wrapper').addClass('sb-account-row')
})
$(document).ready(function() {
    $(document).on('click', '.VirtualKey button', function() {
        if (!$(this).hasClass('clear-but') && !$(this).hasClass('doneButton')) {
            $(this).addClass("clicked-button").delay(200).queue(function(next) {
                $(this).removeClass("clicked-button");
                next()
            })
        } else {
            $(this).addClass("color-button").delay(200).queue(function(next) {
                $(this).removeClass("color-button");
                next()
            })
        }
    })
})

$(document).ready(function() {
    if (window.isMobile) {
        $('.module.ModuleSbSelectedSportGames').each(function() {
            var slider = $(this).find('.slider-container').first();
            var id = slider.attr('id');
            var options = window[id + 'options'];
            if (options) {
                slider.jqueryUcSlider(options, !0)
            }
        })
    }
})

$(document).ready(function() {
    if (window.isMobile) {
        $('.module.ModuleSbSelectedSportGames').each(function() {
            var slider = $(this).find('.slider-container').first();
            var id = slider.attr('id');
            var options = window[id + 'options'];
            if (options) {
                slider.jqueryUcSlider(options, !0)
            }
        })
    }
})
let hasNotTabs, tabContainer, hiddenTabContainer, activeTab;

function selectTab(event) {
    if (tabContainer !== null) {
        if (document.querySelector('.ModuleVirtualSports .tabs-container .active')) {
            document.querySelector('.ModuleVirtualSports .tabs-container .active').classList.remove('active')
        }
        event.currentTarget.classList.add('active');
        let tab = event.currentTarget.dataset.route;
        document.querySelectorAll('.ModuleVirtualSports .tab-content').forEach(function(elem) {
            elem.classList.remove('show')
        });
        document.querySelector('.ModuleVirtualSports .tab-content.' + tab).classList.add('show');
        if (window.location.href.indexOf('edit') === -1) {
            window.location.hash = '/' + tab
        }
    }
}
$(document).ready(function() {
    hasNotTabs = document.querySelector('.public-hidden-element-message');
    if (hasNotTabs === null) {
        tabContainer = document.querySelector('.ModuleVirtualSports .tabs-container');
        hiddenTabContainer = document.querySelector('.ModuleVirtualSports .hidden-tabs-container');
        if (tabContainer === null && hiddenTabContainer !== null) {
            activeTab = window.location.hash ? window.location.hash.split("#/").pop().split('/').shift() : hiddenTabContainer.querySelector('.tab').dataset.route;
            if (activeTab.indexOf('?') + 1) {
                activeTab = activeTab.split('?').shift()
            }
            if (window.location.href.indexOf('edit') === -1) {
                if (hiddenTabContainer.querySelector(`.${activeTab}`) === null && activeTab) {
                    activeTab = hiddenTabContainer.querySelector('.tab').dataset.route;
                    if (activeTab) {
                        window.location.hash = '/' + activeTab
                    }
                }
                document.querySelector(`.ModuleVirtualSports .tab-content.${activeTab}`).classList.add('show');
                if (!window.location.hash && activeTab) {
                    window.location.hash = '/' + activeTab
                }
            }
        } else if (tabContainer !== null) {
            let tabs = document.querySelectorAll('.tabs-container .tab'),
                tabsWidth = 0;
            tabs.forEach(function(tab) {
                tabsWidth += tab.offsetWidth
            });
            if (document.body.clientWidth < tabsWidth) {
                document.querySelector('.tabs-container').classList.remove('right', 'center')
            }
            activeTab = window.location.hash ? window.location.hash.split("#/").pop().split('/').shift() : tabContainer.querySelector('.tab').dataset.route;
            if (activeTab.indexOf('?') + 1) {
                activeTab = activeTab.split('?').shift()
            }
            if (window.location.href.indexOf('edit') === -1) {
                if (tabContainer.querySelector(`.${activeTab}`) === null && activeTab) {
                    activeTab = tabContainer.querySelector('.tab').dataset.route;
                    if (activeTab) {
                        window.location.hash = '/' + activeTab
                    }
                }
                if (tabContainer.querySelector(`.${activeTab}`)) {
                    tabContainer.querySelector(`.${activeTab}`).classList.add('active')
                }
                if (document.querySelector(`.ModuleVirtualSports .tab-content.${activeTab}`)) {
                    document.querySelector(`.ModuleVirtualSports .tab-content.${activeTab}`).classList.add('show')
                }
                if (!window.location.hash && activeTab) {
                    window.location.hash = '/' + activeTab
                }
            }
        }
    }
})
if (window.getCookie('themeMode')) {
    document.querySelector('html').setAttribute('data-theme', "v3-" + window.getCookie('themeMode'))
}
let openedSubMenu = null,
    global_isAdmin = document.querySelector('html').classList.contains('admin-mode'),
    global_IsMobile = document.querySelector('body').classList.contains('mobile'),
    ucSubMenuCloseEvent = global_isAdmin ? new Event('ucSubMenuClosed') : null;

function openUcSubMenu(moduleId, item, subItems, event = null, showVerticalArrow = !1, showHorizontalArrow = !1, verticalCheck = !0, horizontalCheck = !1, sameLevelVertical = !1, sameLevelHorizontal = !1, additionalContainer = null) {
    if (subItems.classList.contains('subMenu__hide')) {
        if (!openedSubMenu) {
            openedSubMenu = moduleId
        } else {
            if (openedSubMenu !== moduleId) {
                document.querySelector('.subMenu__show') && closeUcSubMenu(document.querySelectorAll('.subMenu__show'));
                openedSubMenu = moduleId
            } else {
                checkToCloseUcSubMenu(subItems)
            }
        }
        let subToLeftClass = sameLevelHorizontal ? 'subMenu__to-left' : 'subMenu__to-left-main',
            subToRightClass = sameLevelHorizontal ? 'subMenu__to-right' : 'subMenu__to-right-main',
            subToTopClass = sameLevelVertical ? 'subMenu__to-top' : 'subMenu__to-top-main',
            subToBottomClass = sameLevelVertical ? 'subMenu__to-bottom' : 'subMenu__to-bottom-main',
            parentUcRowClass = global_isAdmin ? '.uc-row-design' : '.uc-row',
            currentWindowWidth = global_isAdmin && global_IsMobile ? document.querySelector('.mobile-scale').offsetWidth + document.querySelector('.mobile-scale').getBoundingClientRect().left : window.innerWidth,
            currentWindowHeight = global_isAdmin && global_IsMobile ? document.querySelector('.mobile-scale').offsetHeight + document.querySelector('.mobile-scale').getBoundingClientRect().top : window.innerHeight;
        if (event) {
            event.preventDefault();
            event.stopPropagation()
        }
        subItems.classList.add('subMenu__not-checked');
        subItems.classList.replace('subMenu__hide', 'subMenu__show');
        subItems.closest('.module-container').classList.add('subMenu__parent-module');
        subItems.closest(parentUcRowClass).parentNode.classList.add('subMenu__parent-row');
        if (!sameLevelVertical && showVerticalArrow) {
            subItems.classList.add('subMenu__show-arrow')
        }
        let footerRow = subItems.closest('.footer-rows');
        footerRow && footerRow.classList.add('subMenu__footer-row');
        setTimeout(() => {
            if (verticalCheck) {
                let scrollableContainer = null,
                    scrollableContainerOffset = 0,
                    scrollableContainerHeight = 0,
                    additionalContainerHeight = additionalContainer ? additionalContainer.offsetHeight : 0,
                    poweredByContainer = document.querySelector('.powered-by-container.active'),
                    poweredByContainerHeight = 0;
                if (item.closest('.off-canvas-inner-container')) {
                    scrollableContainer = item.closest('.off-canvas-inner-container')
                } else if (item.closest('.popup-wrapper-inner')) {
                    scrollableContainer = item.closest('.popup-wrapper-inner')
                } else if (item.closest('.popup-tool-container')) {
                    scrollableContainer = item.closest('.popup-tool-container .layer-rows')
                } else if (global_isAdmin && document.querySelector('body.mobile')) {
                    scrollableContainer = item.closest('.main-container')
                }
                if (scrollableContainer) {
                    scrollableContainerOffset = scrollableContainer.getBoundingClientRect().top;
                    scrollableContainerHeight = scrollableContainer.offsetHeight
                } else {
                    scrollableContainerHeight = currentWindowHeight;
                    if (poweredByContainer) {
                        poweredByContainerHeight = poweredByContainer.offsetHeight
                    }
                }
                if (scrollableContainerHeight - item.getBoundingClientRect().top + scrollableContainerOffset > item.getBoundingClientRect().height + subItems.getBoundingClientRect().height + additionalContainerHeight + poweredByContainerHeight) {
                    subItems.classList.add(subToBottomClass);
                    subItems.classList.remove(subToTopClass)
                } else {
                    if (item.getBoundingClientRect().top - scrollableContainerOffset > subItems.getBoundingClientRect().height + additionalContainerHeight + poweredByContainerHeight) {
                        subItems.classList.remove(subToBottomClass);
                        subItems.classList.add(subToTopClass)
                    } else {
                        subItems.classList.add(subToBottomClass);
                        subItems.classList.remove(subToTopClass)
                    }
                }
            }
            if (horizontalCheck) {
                subItems.classList.remove(subToLeftClass, subToRightClass);
                let navSubItemRight = parseFloat(item.getBoundingClientRect().left) + parseFloat(item.getBoundingClientRect().width) + parseFloat(subItems.getBoundingClientRect().width);
                if (navSubItemRight > currentWindowWidth) {
                    subItems.classList.add(subToLeftClass);
                    if (showHorizontalArrow) {
                        item.classList.add('subMenu__horizontal-arrow-left')
                    }
                } else {
                    subItems.classList.add(subToRightClass);
                    if (showHorizontalArrow) {
                        item.classList.add('subMenu__horizontal-arrow-right')
                    }
                }
            }
            subItems.classList.remove('subMenu__not-checked')
        })
    }
}

function closeUcSubMenu(item, fromCheck = !1) {
    if (item) {
        let items = item.length ? item : [item],
            parentRow = null;
        items.forEach(closedItem => {
            parentRow = closedItem.closest('.subMenu__parent-row');
            closedItem.closest('.subMenu__item').classList.remove('subMenu__horizontal-arrow-left', 'subMenu__horizontal-arrow-right');
            closedItem.classList.add('subMenu__hide');
            closedItem.classList.remove('subMenu__show', 'subMenu__show-arrow', 'subMenu__to-top', 'subMenu__to-top-main', 'subMenu__to-bottom', 'subMenu__to-bottom-main', 'subMenu__to-left', 'subMenu__to-right');
            if (parentRow && !(parentRow.querySelector('.subMenu__show'))) {
                parentRow.classList.remove('subMenu__parent-row');
                parentRow.closest('.subMenu__footer-row') && parentRow.closest('.subMenu__footer-row').classList.remove('subMenu__footer-row');
                if (parentRow.closest('.subMenu__parent-row')) {
                    parentRow.closest('.subMenu__parent-row').classList.remove('subMenu__parent-row')
                }
                if (parentRow.querySelector('.subMenu__parent-module')) {
                    parentRow.querySelectorAll('.subMenu__parent-module').forEach(module => {
                        module.classList.remove('subMenu__parent-module')
                    })
                }
                if (!fromCheck) {
                    openedSubMenu = null
                }
                ucSubMenuCloseEvent && document.dispatchEvent(ucSubMenuCloseEvent)
            }
        })
    }
}

function checkToCloseUcSubMenu(item) {
    let parentOpenedMenu = item.closest('.subMenu__show'),
        openedMenu = null;
    if (parentOpenedMenu) {
        if (parentOpenedMenu.querySelector('.subMenu__show')) {
            openedMenu = parentOpenedMenu.querySelector('.subMenu__show')
        }
    } else {
        openedMenu = document.querySelectorAll('.subMenu__show')
    }
    if (openedMenu) {
        closeUcSubMenu(openedMenu, !0)
    }
};